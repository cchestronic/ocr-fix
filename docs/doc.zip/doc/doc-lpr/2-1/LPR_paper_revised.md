---
title: "Efficient Recognition of One-Row and Two-Row License Plates by Combining CTC and Parallel Decoding with Format-Aware Visual and Linguistic Context"
subtitle: "A Format-Aware Draft-and-Refine Framework Built on SVTRv2 and CPPD"
author: "[Author name and affiliation — to be added]"
date: "6 November 2026"
lang: en
---

> **Draft status. All experimental results in Chapter 5, and every number quoted from them in other chapters, are projected placeholders. They are highlighted in yellow and marked PROJECTED. They are not measurements. Replace them with measured values before submission.**

## Abstract

License plate recognition must read short identifiers with a strict structure. The characters can be arranged in one row or in two rows, they can come from more than one script, and the image can be degraded by blur, low resolution and glare. Connectionist Temporal Classification (CTC) reads one-row plates efficiently, but it needs a feature sequence that already follows the reading order. Attention-based parallel decoders can read two-dimensional layouts and use the context of other characters, but they cost more computation. Neither family uses the most reliable linguistic knowledge that exists for license plates: the plate formats that the issuing authorities define. This paper proposes Format-Aware Draft-and-Refine recognition (FADR). FADR improves both mechanisms and combines them on one shared hierarchical vision-transformer encoder. A layout–format head predicts the plate format and the number of text rows from visual evidence. The CTC draft branch extends the feature rearrangement module of SVTRv2 with row-selective tokens, so that a two-row plate becomes a sequence in the correct reading order. The branch then decodes this sequence with a beam search that is constrained by automata compiled from the known plate formats. A penalised open-format path keeps unfamiliar plates readable. A format-conditioned parallel refiner, derived from CPPD, re-reads only the uncertain characters in one parallel pass. Its slot queries contain the format template and the CTC draft, in which characters with low confidence are masked. Each prediction therefore combines visual context and linguistic context. A confidence gate sends clear plates directly to the output. For the remaining plates, a joint score of CTC, refiner and format evidence selects the final string. In projected experiments, FADR reaches <mark>97.2%</mark> on two-row plates, compared with <mark>88.7%</mark> for SVTRv2 and <mark>94.4%</mark> for CPPD. It reaches an average of <mark>98.2%</mark> on one-row Chinese plates and adds only about <mark>4.5%</mark> CPU latency to CTC-only recognition. The open-format path keeps the accuracy on unseen formats at <mark>91.5%</mark>, compared with <mark>59.8%</mark> when hard format constraints are used.

**Keywords:** automatic license plate recognition; Chinese license plates; two-row license plates; Connectionist Temporal Classification; parallel decoding; plate format; constrained decoding; visual and linguistic context; SVTRv2; CPPD; edge inference.

## Contents

**Introduction**

**Chapter 1. Literature Review of License Plate Recognition Before 2024**\
1.1. License Plate Detection and End-to-End Recognition Frameworks\
1.2. Character Detection, CTC, Attention-Based Recognition, and Their Combination\
1.3. Multinational Datasets, Two-Row Layouts, Plate Formats, Degradation, and Research Gaps

**Chapter 2. Efficient CTC-Based Recognition for One-Row and Two-Row Plates**\
2.1. Conventional CTC Recognition and Its Limitations\
2.2. SVTRv2: Multi-Size Resizing, Feature Rearrangement, and Semantic Guidance\
2.3. Proposed CTC Draft Branch: Row-Selective Rearrangement and Format-Constrained Decoding

**Chapter 3. Format-Aware Parallel Decoding Based on CPPD**\
3.1. Limitations of Autoregressive and Conventional Parallel Decoders\
3.2. Context Perception Parallel Decoding Through Character Counting and Ordering\
3.3. Proposed Format-Conditioned Parallel Refiner

**Chapter 4. Combining CTC and Parallel Decoding: The Format-Aware Draft-and-Refine Framework**\
4.1. Architecture and Joint Training\
4.2. Confidence-Gated Inference and Joint Scoring\
4.3. Recognition of Degraded Plates\
4.4. Computational Cost, Deployment, and Safeguards

**Chapter 5. Experiments (Projected Results) and Discussion**\
5.1. Datasets, Evaluation Protocol, and Implementation\
5.2. Main Results on One-Row and Two-Row Plates\
5.3. Format Awareness, Ablation Study, and Efficiency\
5.4. Degraded Plates, Error Analysis, Limitations, and Conclusion

**References**

**Appendix A. Format Templates of Chinese Plate Types**\
**Appendix B. Planned Training and Decoding Settings**\
**Appendix C. Replacing the Projected Results**\
**Appendix D. Notation**\
**Appendix E. Worked Example of Format-Constrained Decoding**\
**Appendix F. Template File Used in the Experiments**

## Terminology and scope

This paper uses the following terms in a fixed sense.

- A **plate crop** is an image region that a detector or a human annotator has already located. An **end-to-end ALPR system** also includes plate detection, optional geometric correction and, for video, tracking.
- A **one-row plate** has all characters in one row. A **two-row plate** has two rows of characters. The reading order of a two-row plate is the whole upper row, followed by the whole lower row.
- A **format template** is the official arrangement of characters for one plate type. It is an ordered list of **slots**. Each slot has a row index and a **slot type**. The slot type is the set of characters that are allowed in that position, for example a provincial character, a letter, or a digit.
- The **open format** accepts any string of characters from the recognition vocabulary. It represents plates whose template is not known to the system.
- A **draft** is the string that the CTC branch produces. **Refinement** is the new prediction of the uncertain characters of a draft by the parallel decoder.
- A **format shift** is a new arrangement of known characters. A **script shift** is the appearance of characters that the system has never seen.
- The **recognition rate (RR)** is the percentage of plates whose complete string is correct.
- A **projected result** is a placeholder number that is used to plan the experiments. It is not a measurement.

The main examples in this paper are Chinese plates, because one Chinese plate can contain a Chinese provincial character, Latin letters and digits, and because China uses both one-row and two-row plates. All plate images in the figures are illustrative drawings with fictional strings. They are not photographs of real vehicles.

![Figure 1](figs/fig01_plate_formats.png)

*Figure 1. Illustrative Chinese-style plates: a blue one-row plate, a green new-energy plate, a yellow two-row plate and a yellow one-row plate. The figure shows variation in characters, colour and layout. The plates are drawings, not official registration samples.*

## Introduction

A license plate is a small field of structured text inside an unconstrained scene. Its small size does not make it easy to read. A plate can contain characters from several scripts. The order of letters and digits is different between countries and between vehicle types. The characters can be arranged in one row or in two rows. In traffic images, the plate is also affected by perspective distortion, defocus, motion blur, reflections, compression and low resolution. These factors interact. A recognizer that reads a clear one-row plate correctly can fail on a clear two-row plate because it reads the rows in the wrong order. A recognizer that understands the layout can still fail when the strokes that separate two similar characters are lost [11,20,27,29].

Two families of sequence recognizers are used in practice. CTC-based recognizers predict one class distribution for each position of an ordered feature sequence. They then merge repeated symbols and remove blank symbols to obtain the output string [11,12]. They are fast and easy to deploy. However, they assume that the feature sequence already follows the reading order, and their final classifier does not model dependencies between characters. Encoder–decoder recognizers use attention to connect each output position with image regions. They can read irregular layouts and use the context of other characters. However, autoregressive decoding is sequential, and even parallel decoders add computation [33,36,37]. SVTRv2 and CPPD are strong recent members of the two families. SVTRv2, presented by Du and colleagues at ICCV 2025, makes a CTC recognizer robust to irregular text with multi-size resizing, feature rearrangement and semantic guidance during training [50]. CPPD, published by Du and colleagues in IEEE TPAMI in 2025, predicts all characters in one parallel pass and builds context with two auxiliary tasks: character counting and character ordering [51].

License plates have a source of linguistic context that ordinary scene text does not have: the plate formats that the issuing authorities define. For example, a slot that may contain only a digit cannot contain the letter B. A Chinese provincial character can appear only in the first slot of a civilian plate. A yellow two-row plate on the rear of a Chinese truck has the provincial character and the issuing-authority letter in the upper row. Earlier systems used this knowledge mainly as heuristic post-processing after a layout classifier [26]. As a hard rule, format knowledge improves familiar plates. However, it changes unfamiliar plates, such as a new plate series, a foreign vehicle or a special plate, into confident errors. A recognizer that is efficient on one-row plates, correct on two-row plates and able to use format knowledge without losing unseen formats therefore needs both mechanisms. Each mechanism must be improved for license plates, and the two must be combined in a principled way.

This paper proposes **Format-Aware Draft-and-Refine recognition (FADR)**. Figure 2 gives an overview. A shared hierarchical vision-transformer encoder in the style of SVTRv2 feeds three light heads. The **layout–format head (LFH)** predicts the plate format, and therefore the number of rows, from visual evidence such as colour, aspect ratio and character arrangement. The **CTC draft branch** rearranges the encoder features with row-selective tokens, so that a two-row plate gives an upper-row sequence followed by a lower-row sequence. It decodes the result with a beam search that is constrained by automata compiled from the known formats, together with a penalised open-format path. The **format-conditioned parallel refiner (FCPR)**, derived from CPPD, receives the format template and the CTC draft. It masks the characters with low confidence and predicts them again in one parallel pass, using both the surrounding characters and the visual features. A confidence gate accepts clear drafts that match a known format immediately. The refiner therefore runs only for the small share of difficult plates. A joint score of CTC, refiner and format evidence then selects the final string.

![Figure 2](figs/fig02_framework.png)

*Figure 2. Overview of the proposed Format-Aware Draft-and-Refine (FADR) recognizer. One shared encoder feeds a layout–format head, a CTC draft branch and a format-conditioned parallel refiner. Clear plates leave after the draft. Uncertain plates are refined and scored again.*

The work is motivated by deployment. Many ALPR systems run on small computers at road sides, at gates or in vehicles, where the recognizer must process every plate within a few milliseconds on a CPU or a small accelerator. In such systems, most plates are clear one-row plates, and a fast CTC recognizer reads them correctly. The difficult minority, such as two-row plates, blurred plates and plates with confusable characters, causes most of the errors. A design that spends extra computation only on this minority can increase accuracy without increasing the average cost much. China is a demanding test case for this design. Its plates contain more than thirty provincial characters, Latin letters and digits. It uses blue, green, yellow, white and black plates. It uses one-row plates on most cars and two-row plates on the rear of large vehicles, on trailers and on motorcycles.

The contributions of this paper are as follows.

1. **Row-selective feature rearrangement (RS-FRM).** The vertical selection step of the feature rearrangement module of SVTRv2 is extended with layout-specific selecting tokens, one for each text row. The module is trained with row-factorized CTC losses. A two-row plate becomes a CTC sequence in the correct order without line splitting in the image, and CTC inference stays fully parallel.
2. **Format-constrained CTC decoding with an open-format path.** Plate formats are compiled into automata, and the automata constrain a CTC prefix beam search. The constraint is soft. The format priors come from the visual layout–format head, and a penalised open-format path prevents the system from forcing unseen formats into known ones.
3. **Format-conditioned parallel refiner (FCPR).** The CPPD decoder is turned into a refiner. Its slot queries encode the slot position, the row, the slot type and the CTC draft, in which characters with low confidence are masked. Self-attention between slots supplies linguistic context. Cross-attention to the two-dimensional feature map supplies visual context.
4. **Confidence-gated draft-and-refine inference.** A calibrated gate, a constrained beam stage and a refinement stage are combined with a joint score. The average cost stays close to the cost of CTC-only recognition, while difficult plates receive the context of a decoder.
5. **An evaluation protocol.** The protocol separates one-row and two-row plates, known and unseen formats, and single-frame and multi-frame low-resolution recognition. This draft reports projected results for this protocol. They will be replaced by measurements.

SVTRv2 and CPPD are the published starting points of this work. Their original components are described as such, and the new elements are the five items above. The paper has five chapters. Chapter 1 reviews research published before 2024. Chapter 2 develops the CTC side, from conventional CTC and SVTRv2 to the proposed draft branch. Chapter 3 develops the decoder side, from CPPD to the proposed refiner. Chapter 4 combines the two parts into the FADR framework and discusses degraded plates and deployment. Chapter 5 describes the evaluation protocol and presents the projected results, the ablation study, the efficiency estimates and the limitations.


# Chapter 1. Literature Review of License Plate Recognition Before 2024

This chapter reviews research that was formally published before 1 January 2024. Later work, including SVTRv2 and CPPD, is discussed in Chapters 2 to 5. The synthesis and the research questions at the end of the chapter are the analysis of the author of this paper. The chapter has three parts. Section 1.1 describes how ALPR systems are built and why the recognition stage should be studied separately. Section 1.2 reviews the recognition methods: CTC, attention decoders, parallel decoders and their combinations. Section 1.3 reviews datasets, two-row layouts, plate formats and degradation, and it defines the research gap.

## 1.1. License Plate Detection and End-to-End Recognition Frameworks

### 1.1.1. From constrained traffic imaging to recognition in the wild

Automatic license plate recognition (ALPR) developed from traffic engineering, image processing and optical character recognition. Its objective is to transform a camera image of a vehicle into the sequence of symbols on its registration plate. This objective is simple to state but difficult to achieve. The system must classify characters, but it must also find a small and often oblique object in a large image and decide which visual evidence belongs to the identifier. Early installations used fixed camera positions, nearly frontal views and one regional plate style. Under these conditions, hand-designed image-processing rules worked well. The conditions change when cameras are mounted on vehicles, installed at different heights or used in several regions. The plate then occupies a variable number of pixels, its angle changes, and the reflective material of the plate produces local overexposure. A system that works well for one camera or one plate style can therefore work poorly for another.

A conventional ALPR system has several stages. First, a detector finds candidate plate regions in the camera image. Second, a geometric normalization step produces a crop that is easier to read. Third, a recognizer returns a character string and a confidence value. Fourth, an optional post-processing step checks the string against known formats. In video, detection and recognition are combined with tracking and temporal fusion. This decomposition is useful because it shows where an error comes from. A recognition error can be caused by the recognizer. It can also be caused by a detector that cut off the first character, by a correction step that stretched a short row, or by a frame-selection step that chose a blurred image (Figure 3). If every error is attributed to the recognizer, the conclusions about recognition methods are wrong.

![Figure 3](figs/fig03_end_to_end.png)

*Figure 3. The detector, the geometric normalization step and the recognizer are separate subsystems. A recognition rate measured on plate crops cannot be compared directly with an end-to-end ALPR rate.*

### 1.1.2. Detection by learned visual features

Learned detectors replaced most hand-designed localization rules. YOLO showed that object localization and classification can be obtained in a single network evaluation [47]. Later designs such as YOLOv4 and YOLOv7 improved the balance between localization quality and real-time speed [48,49]. For license plates, a rectangular box is not always sufficient. A plate that is seen at an oblique angle becomes a quadrilateral in the image. A rectangle around it contains background and can cut characters after resizing. Silva and Jung therefore detected and corrected strongly distorted plates in unconstrained scenes [23]. Xu and colleagues released the Chinese City Parking Dataset (CCPD) with annotations of the four plate corners, which support corner-based correction [22]. These works also showed that the quality of the detector limits every recognizer that follows it. A perfect recognizer cannot restore a character that the crop has removed.

ALPR systems can be one-stage or two-stage. A one-stage system shares features between localization and transcription. A two-stage system separates detection from recognition, so that each stage can be developed and replaced independently. Xu and colleagues demonstrated a joint detection and recognition baseline on CCPD [22]. A joint design can avoid repeated feature extraction. However, it makes it harder to change the recognized alphabet, to add a stronger geometric correction step, or to analyze whether an error comes from localization or from reading. A modular pipeline is more convenient for research on recognition, because the detector can stay fixed while several recognizers are compared on the same crops. This paper uses the modular view.

### 1.1.3. Corner estimation, rectification, and their trade-offs

Geometric normalization has two forms. Explicit rectification uses the detected corners of the plate to compute a projective transform that maps the quadrilateral to a rectangle. Learned rectification, such as a Spatial Transformer Network, predicts the transformation inside the recognition network [15]. STAR-Net used a spatial transformer together with residual feature extraction for scene text [17]. Explicit rectification depends on accurate corners and on the assumption that the plate is planar. Learned rectification depends on the transformation model and on the training data. Strong distortions can sometimes be corrected. Other transformations can compress strokes or remove useful border features.

Rectification must also be judged by the real geometry of the plate. The border can surround two rows of text, an emblem can occupy part of the plate, and the rows can have different lengths. A projective transform straightens the plate surface, but it does not turn two rows of text into one row. In addition, resizing the crop to a fixed size changes the width-to-height ratio of the characters. A Chinese provincial character, a Latin letter and a digit have different stroke densities, so the same distortion can damage one class more than another. Preprocessing should therefore be evaluated by its effect on the recognition rate and on the character errors, not by the visual regularity of the corrected crop.

### 1.1.4. Chinese plates as an example of a multinational problem

Chinese registration plates are a useful case study, because one plate combines a Chinese provincial character, Latin letters and Arabic digits (Figure 4). The national standard GA 36 defines the plate types, sizes, colours and character rules.[^ga36] On a civilian plate, the first symbol is the abbreviation of the province, autonomous region or municipality. The second symbol is a letter that identifies the issuing authority. The remaining symbols form the serial. The letters I and O are not used in the serial, so that they cannot be confused with the digits 1 and 0. Small cars use a blue plate with seven characters. Small new-energy vehicles use a green plate with eight characters, in which the third character is D or F. Large new-energy vehicles use a yellow-and-green plate, in which the eighth character is D or F. Large vehicles carry a yellow one-row plate at the front and a yellow two-row plate at the rear. Trailers and motorcycles also use two-row plates. Some plates end with a special character, such as 挂 for trailers, 学 for driving-school vehicles and 警 for police vehicles, and plates of vehicles from Hong Kong and Macau end with 港 or 澳.

[^ga36]: Ministry of Public Security of the People's Republic of China, GA 36-2018, *License plates of motor vehicles of the People's Republic of China*, issued 20 April 2018 and implemented 1 May 2018. The format templates in this paper are simplified illustrations. A deployed system must follow the current official text.

![Figure 4](figs/fig_cn_plate_gallery.png)

*Figure 4. Chinese plate types and layouts that are used as examples in this paper. The plates differ in colour, length, number of rows and special characters. All plates are illustrative drawings with fictional strings.*

These rules show that one Chinese template does not cover every legal plate. A recognizer must learn the shape of each character, the script, the layout and the reading order. These properties are related, but they are not the same. The CCPD study supported experiments on localization and recognition under realistic distortions [22]. LPRNet then showed that a compact convolutional network can read Chinese plate crops without character segmentation, which made CTC-style recognizers attractive for embedded devices [21]. These results were obtained on particular data distributions and alphabets, mostly blue one-row plates. They do not show robustness to other layouts or to two-row plates. The value of Chinese plates for this paper is that they make mixed scripts, several colours, two layouts and explicit format rules visible in one country.

### 1.1.5. Character detection as an alternative to sequence recognition

Another family of methods detects each character separately and then builds the string from the character positions. For two-row plates, this approach has a conceptual advantage. The detector returns two-dimensional character coordinates, so the characters can be grouped into rows and sorted inside each row. The row structure is therefore explicit. The cost is that every small character must be detected and classified reliably. This becomes difficult at long distance, under reflections, and when characters touch each other. The ordering step also needs rules for row separation, separators and uneven character spacing.

Laroca and colleagues built real-time ALPR systems around learned character detection and showed practical operation on images from moving vehicles [24]. They later combined plate detection with layout classification, so that layout-specific rules could correct the recognized string [26]. Such systems are transparent, because missing characters can be seen directly, and they remain strong baselines. However, they add their own errors: a character can be missed, detected twice, assigned to the wrong row or confused with an emblem. When character detection is compared with CTC or with an attention decoder, the same plate crops and the same target strings must be used. Otherwise, one method can be credited or penalized for a different localization problem.

### 1.1.6. Why a controlled comparison of recognizers is needed

Historical studies differed in detectors, training splits, image sizes, alphabets and hardware. Some studies reported recognition under the condition that the crop was correct. Other studies reported the accuracy of a complete video pipeline. A speed that is measured on one GPU cannot be transferred to a CPU. A crop-level recognition rate cannot be compared with a track-level recognition rate. Baek and colleagues showed that inconsistent datasets and experimental choices can change the apparent ranking of text recognizers [20]. They proposed a framework with four stages: transformation, feature extraction, sequence modeling and prediction. This framework separates the effect of the visual representation from the effect of the decoding method.

This paper follows the same principle. Plate detection supplies a standardized crop. A shared visual encoder extracts the same type of two-dimensional features for all recognition heads. All heads use the same vocabulary, the same label normalization, the same input size policy and the same hardware. Published numbers from models with different encoders remain informative, but they cannot replace a controlled comparison.

## 1.2. Character Detection, CTC, Attention-Based Recognition, and Their Combination

### 1.2.1. From segmentation to segmentation-free recognition

A traditional text-recognition pipeline isolates each symbol before it classifies the symbol. It usually needs binarization, extraction of connected components and rules that separate touching characters. Such pipelines are sensitive to image quality and to national differences in fonts, spacing and decoration. They are especially fragile when a Chinese character consists of several separate strokes, or when blur merges neighbouring characters. Segmentation-free recognition learns a direct mapping from the plate image to the character sequence. It still makes assumptions about alignment, but it does not need a precise box for every character in the training data.

Connectionist Temporal Classification (CTC) was introduced for sequence labelling when the alignment between input frames and output symbols is unknown [11]. In text recognition, the input frames are positions of the visual feature map instead of moments in a speech signal. CRNN combined convolutional features, recurrent sequence modeling and CTC in one network that is trained end to end [12]. The main benefit is that a label for the whole string is enough for training. The annotator does not need to mark the boundaries of each character. This matters for multinational data, in which character-level boxes are expensive and inconsistent.

### 1.2.2. Understanding CTC correctly

CTC adds a special blank symbol to the vocabulary and allows a symbol to be emitted at several consecutive time steps. A collapse operation first merges consecutive repeated symbols and then removes the blanks [11]. For example, the frame-level prediction *blank, A, A, blank, 1, blank, 1* represents the string *A11*, because a blank separates the two copies of the digit 1. CTC therefore does not forbid repeated characters. It needs enough time steps and a blank in the correct place. Recognition becomes difficult when two identical neighbouring characters receive too few time steps, or when the order of the visual features does not match the order of the label.

The alignment assumption of CTC concerns the relation between feature positions and output order. In a horizontal word, the features progress from the left edge to the right edge, which is the reading order. In a two-row plate, the correct reading order is the whole upper row followed by the whole lower row. A simple horizontal collapse of the two-dimensional feature map mixes the two rows (Figure 5). CTC itself does not prevent two-row recognition. Line segmentation, a row-aware serialization of the features or a learned rearrangement of the features can all produce a valid order. The limitation is in the way the visual grid becomes a sequence. Chapter 2 addresses exactly this point with the proposed row-selective rearrangement.

![Figure 5](figs/fig04_row_interleaving.png)

*Figure 5. Correct row-by-row reading order compared with the mixing of rows that a single horizontal scan produces on a two-row plate. The plate string is fictional.*

### 1.2.3. STAR-Net, LPRNet and the CTC lineage

STAR-Net, introduced in 2016, is an informative historical example, because it combines a learned spatial transformation with a residual feature extractor [16,17]. The transformation corrects distorted text before recognition. Residual blocks extract fine features without the optimization problems of very deep plain networks. The broader line of work couples such features with recurrent sequence modeling and a CTC head. This gives a clear progression: normalize the crop, compute visual features, arrange the features as a sequence and transcribe the sequence without character segmentation.

The strengths of this progression are clear. Labels for whole strings are cheap, convolutional features are effective for small strokes, and the CTC head is highly parallel. The weaknesses are also structural. Recurrent layers add sequential computation. Fixed input sizes distort unusual plate shapes. A one-dimensional feature sequence loses the vertical order of the characters. LPRNet is an efficiency-oriented example of a different kind. It is a lightweight convolutional recognizer without recurrent layers, and it reads Chinese plates in real time [21]. A dedicated plate vocabulary and short strings allow simpler inference than general scene-text recognition. However, strong regularities in one national dataset do not show that a recognizer can separate two rows or read a new writing system. These two paths, STAR-Net with geometric correction and LPRNet with compact design, motivate an evaluation that considers both alignment robustness and computational cost.

### 1.2.4. Attention-based sequence decoding

Attention-based recognizers select the relevant regions of the visual representation for each output position. RARE and ASTER combined rectification with attention decoding for irregular words. SAR attended to a two-dimensional feature map, and MORAN combined a rectification network with an attention-based recognizer [18,19,31,32]. Attention gives a more flexible connection between an output position and its source pixels than a fixed horizontal scan. This is attractive for two-row plates, because a decoder can, in principle, attend to the upper row first and to the lower row second. This ability is not automatic. It depends on the training data, on whether the features keep vertical detail, and on whether the decoder learns the intended reading order.

An autoregressive decoder generates one symbol at a time, and each symbol is conditioned on the previous symbols. Transformer-based recognizers such as NRTR and SATRN applied this design to scene text [33,35]. The conditional structure lets the decoder use context and handle strings of variable length. It also makes decoding sequential: the decoder must wait for one prediction before it can form the next one. For six to eight characters, the absolute delay can be small. However, the number of sequential steps grows with the string length, and sequential decoding can be difficult to optimize on some embedded runtimes. An early wrong character can also influence the following steps and lead to a coherent but wrong continuation.

### 1.2.5. Parallel prediction and language context

Before 2024, SRN, ABINet, VisionLAN and PARSeq showed different ways to combine visual and linguistic information in scene-text recognition [30,36–38]. A character that is visually ambiguous is easier to identify when the neighbouring characters and the plausible word structures provide additional evidence. Words and license plates are different, however. A word recognizer benefits from vocabulary statistics. Plate identifiers are designed to be arbitrary within their format. The useful linguistic knowledge for plates is therefore structural: which character classes may appear in which slot of which format. It is not lexical knowledge about frequent words.

Parallel prediction computes all characters at the same time. However, predicting each output slot independently from a fixed position query does not model the relation between the number of characters, their order and their content. A decoder may recognize the correct set of symbols but place them in the wrong order, especially when the rows are offset. It may also fill one slot twice and leave another slot empty. Replacing autoregression with a set of classifiers is therefore not enough. The decoder needs structural information, so that each output slot corresponds to the correct visual evidence. This is the motivation for the context-perception methods that Chapter 3 discusses.

### 1.2.6. Vision Transformers and spatial representation

Vision Transformers encode an image as a sequence of patch tokens and use self-attention to model the relations between the tokens [40,41]. A recognizer that collapses the feature map into a horizontal sequence early loses the vertical structure. A ViT-style encoder can keep a two-dimensional grid of tokens until the prediction stage. Hierarchical designs such as the Swin Transformer combine local detail with wider context at several scales [43]. In text recognition, ViTSTR used a plain Transformer encoder for efficient recognition [34]. SVTR showed that a single visual model, built from local and global mixing blocks, can recognize scene text without a recurrent sequence model [39].

These works show that a ViT-style encoder is a suitable shared basis for a CTC head and an attention decoder. However, two recognizers are not equivalent only because both use attention. Patch size, positional encoding, input resizing, pooling and the shape of the feature grid decide what information reaches the prediction head. For license plates, the vertical resolution of the feature grid is especially important, because it decides whether two rows of characters remain separable.

### 1.2.7. Combining CTC with attention and with external knowledge

Speech recognition and text recognition already provide several ways to combine CTC with attention decoders and with external linguistic knowledge. CRNN supported lexicon-based transcription, in which the CTC output is matched against a lexicon [12]. EESEN decoded CTC outputs with weighted finite-state transducers, which add lexicons and language models to the search [44]. CTC prefix beam search is an efficient algorithm that can combine CTC probabilities with other scores during decoding [70]. The hybrid CTC/attention architecture trains one shared encoder with a CTC objective and an attention decoder, and it decodes with a joint score of both [13]. GTC uses an attention decoder only during training, to guide the feature alignment of a CTC text recognizer, and it keeps the fast CTC inference [42]. Mask CTC starts from the greedy CTC output, masks the tokens with low confidence and predicts them again in parallel with a conditional masked decoder [14].

These methods show that CTC and attention are complementary. CTC supplies an efficient monotonic alignment, and the attention decoder supplies context. Constrained search shows how external knowledge can enter CTC decoding without retraining. However, none of these methods was designed for two-row layouts or for the structured, country-specific formats of license plates. Their ideas are a starting point for the method of this paper, not a solution to the plate problem.

## 1.3. Multinational Datasets, Two-Row Layouts, Plate Formats, Degradation, and Research Gaps

### 1.3.1. Why the country of origin changes the recognition task

License plates are not one universal visual language. They differ in character inventory, character arrangement, colour, proportions, permitted symbols and official format rules. Some countries use only Latin letters and digits. Other countries combine local characters with Latin letters, or use non-Latin scripts. A model whose vocabulary does not contain a legitimate symbol cannot predict that symbol, however strong its encoder is. An ordering method that assumes one row reads a two-row plate incorrectly, even when it detects every character. These are design limitations, not only problems of image quality.

Henry and colleagues addressed multinational recognition with generalized character-sequence detection. They explicitly recognized that specialization to one national format limits deployment across borders [27]. Their work treats layout and characters as a problem of the whole system, not as a local classification problem. A robust multinational recognizer must not encode one national format as a universal rule. Format information can increase confidence after transcription, but the visual recognizer must remain able to read a string that does not follow the dominant format. This matters because new plate series appear and vehicles from other regions enter a deployment unexpectedly.

### 1.3.2. What the main pre-2024 datasets measure

The Taiwanese AOLP benchmark covers three imaging conditions: access control, law enforcement and road patrol [25]. CCPD provides a large collection of Chinese blue one-row plates with varied distortions and corner annotations [22]. UFPR-ALPR contains video frames of moving vehicles that several cameras recorded [24]. RodoSol-ALPR contains 20,000 images from toll booths, with Brazilian and Mercosur layouts. Half of its images show motorcycles, whose plates have two rows of characters [28]. The Chinese Road Plate Dataset (CRPD) provides road-surveillance images with plate-type labels. The labels distinguish blue plates, yellow one-row plates, yellow two-row plates and white plates [46].

These datasets do not cover the same vehicles, cameras, scripts or weather conditions. Their reported accuracies therefore cannot be placed in one ranking. Their annotation protocols also differ. Some datasets provide only plate strings. Others provide the plate corners or character boxes. Only some datasets provide the row structure that a two-row evaluation needs. A recognizer that is trained on plate crops needs text labels. A projective correction step needs corners. A multi-frame study needs a track identifier that proves that several frames show the same physical plate. Without this information, wrong grouping of images can produce an artificially strong agreement between frames. Dataset licences and privacy rules also matter, because images with registration numbers are often restricted to research use.

### 1.3.3. Two-row layouts and multi-line recognition methods

Two kinds of change are often confused. A *format shift* changes the sequence of allowed character classes. A *layout shift* changes the spatial arrangement of the characters. RodoSol-ALPR contains both kinds of change, because Brazilian and Mercosur plates differ in format and motorcycle plates differ in layout [28]. A recognizer can generalize to a new character order and still fail on two-row geometry. Another recognizer can follow both rows correctly and still impose an obsolete format. These failure modes should be measured separately. The same reasoning applies to Chinese plates. A blue one-row plate, a green new-energy plate and a yellow two-row plate differ in colour, length and spatial arrangement. Colour alone should not decide the reading. A model can learn that a blue background predicts one pattern and a green background predicts another, but this shortcut fails in unusual lighting or in images from another camera.

Dedicated multi-line plate recognizers existed before this paper. Cao and colleagues proposed an end-to-end network that reads both one-line and two-line plates without segmenting the image into lines [45]. Chen and colleagues proposed an end-to-end multi-line recognizer that cascades global type perception with parallel character perception, in order to improve both accuracy and inference speed [57]. The second design is the closest precedent to the present work: it predicts the plate type from global features and then reads all characters in parallel. However, it does not combine the parallel reader with a CTC branch, and it does not use the plate format as an explicit, soft constraint during decoding.

### 1.3.4. Plate formats, layout classification, and the risk of overcorrection

National rules restrict which characters may appear in which positions. These restrictions are valuable when the plate type is known. Laroca and colleagues classified the plate layout together with detection and used layout-specific heuristic rules to correct the recognized string [26]. Such rules can reject impossible outputs and help to choose between several likely candidates. However, the same restrictions can create artificial accuracy when a test set contains almost only known templates. A misread character can be replaced by the only character that the rule permits, which produces a correct answer even though the visual reading was wrong. When the system later meets a new plate series or a foreign plate, the same rule becomes a source of systematic errors.

Three conclusions follow for the design of a format-aware recognizer. First, the raw recognition result and the format-corrected result should be reported separately, because the raw result shows visual generalization and the corrected result shows the benefit for a defined application. Second, format knowledge should be applied in a way that strong visual evidence can overrule. Third, the plate type should be inferred from the image, not assumed from the deployment site, because vehicles from other regions and new plate types appear at every site. Chapters 2 and 4 turn these conclusions into a soft, recall-preserving use of format knowledge.

### 1.3.5. Label normalization

An ALPR recognizer predicts a string, but a benchmark often evaluates a normalized version of that string. Depending on the dataset, separators, decorative marks, regional symbols and uncertain characters are kept, removed or merged. This changes both the character vocabulary and the definition of a correct prediction. A method that reads every visible character correctly can receive an error if its output contains a symbol that the ground truth omits. Another method can appear more accurate because its post-processing silently removes symbols that the test set ignores. Studies before 2024 already showed that such evaluation conventions can change conclusions substantially [20,28,29]. A defensible comparison must therefore keep the raw annotation, state the normalized form, and distinguish a reading error from a label-conversion error. For Chinese plates, this applies, for example, to the separator dot after the second character, which this paper does not include in the label.

### 1.3.6. Dataset bias, near-duplicates, and apparent generalization

Laroca and colleagues showed that license plate datasets contain identifiable signatures of their acquisition sources [29]. A recognizer can therefore score well partly because its test images resemble its training images in camera, compression, background or font. The same model can score much lower when these details change. The same group also showed that near-duplicate images, shared between the training and test splits of popular datasets, inflate the reported recognition rates [68]. A strong result on several datasets is more convincing when the evaluation includes held-out cameras, plate types or countries, and when the split is made at the level of the vehicle or the track instead of the image.

A useful evaluation trains on some formats and tests on others, with a realistic output alphabet. Holding out a format whose characters are already known tests composition and layout generalization. Holding out a script with unseen characters tests a different ability, which normally requires new labelled data or a larger vocabulary. These two questions must not be confused. For Chinese plates, a model that was trained in China knows the provincial characters, but it does not know the characters of unrelated scripts. A model is not multinational only because it reads Chinese characters and Latin letters.

### 1.3.7. Visual degradation and the information limit

Low-resolution plate recognition is not ordinary image classification. One wrong character makes the whole identifier wrong, and a character stroke can be only one or two pixels wide. Downsampling removes the separation between similar symbols. Motion blur merges neighbouring strokes. Compression creates block edges that look like strokes. Reflections can erase whole character regions. Some symbols in Chinese plates are particularly easy to confuse at low resolution (Figure 6). The letter B and the digit 8, the letter D and the digit 0, the letter Z and the digit 2, and the letter S and the digit 5 differ by a few pixels. Several provincial characters, such as 津, 沪, 渝, 湘 and 浙, share the same left component, so only the right part separates them. If different plate strings produce almost the same pixels, no recognizer can guarantee the correct string. Context can only choose the most plausible string, and this is different from observing the true characters.

![Figure 6](figs/fig_cn_confusable.png)

*Figure 6. Confusable symbols in Chinese plates. Each symbol is shown clean and at low resolution. Letter–digit pairs and provincial characters with the same left component become hard to separate when the resolution drops.*

The scene-text literature already identified low resolution, occlusion, unusual fonts and labelling problems as persistent challenges [20]. Super-resolution can make an image look sharper, but a sharper image does not prove that the character identity is preserved. A recognition-oriented study must ask whether an enhancement improves the exact transcription of unseen real images. Several frames of the same plate are another source of evidence. Neighbouring frames can show different unblurred strokes or different reflection patterns. They add real observations, although they do not guarantee a perfect result. These observations motivate the treatment of degraded plates in Chapter 4.

### 1.3.8. Research gap and questions addressed

The literature before 2024 established capable detectors, learned rectification, efficient CTC recognizers, attention decoders, ViT-style encoders, multi-line plate recognizers and datasets from several countries. Outside license plate recognition, it also showed that CTC and attention decoding can be trained together and combined at inference [13,14,42], and that CTC decoding can use external knowledge through constrained search [12,44,70]. Three questions remained open for license plates:

1. How can a recognizer read one-row and two-row plates with the efficiency of CTC, without line splitting in the image?
2. How can a recognizer use the official plate formats as linguistic context, without losing plates whose format is unseen?
3. How can a recognizer apply the visual and linguistic context of a decoder only to the plates that need it, so that the average cost stays low?

This paper answers these questions with three design decisions. Chapter 2 develops a row-aware CTC draft branch with format-constrained decoding. Chapter 3 develops a format-conditioned parallel refiner. Chapter 4 combines the two parts with a confidence gate and explicit safeguards against overcorrection. Chapter 5 defines an evaluation that separates the effects of layout, format and degradation, and it reports projected results that will be replaced by measurements.


# Chapter 2. Efficient CTC-Based Recognition for One-Row and Two-Row Plates

This chapter develops the CTC side of the proposed recognizer. Section 2.1 explains what CTC computes and why its assumptions matter for license plates. Section 2.2 describes SVTRv2 as published by its authors [50], because SVTRv2 is the starting point of the draft branch. Section 2.3 presents the proposed extensions: a layout–format head, a row-selective feature rearrangement module, row-factorized CTC training and a CTC decoding procedure that is constrained by plate formats. Sections 2.1 and 2.2 describe existing methods. Section 2.3 describes the new contributions of this paper.

## 2.1. Conventional CTC Recognition and Its Limitations

### 2.1.1. The task solved by CTC

In license plate recognition, the input is a rectangular array of pixel values and the output is an ordered string. Unlike ordinary classification, the model must predict several symbols and decide their order. The annotation normally records only the final registration string. It does not say which pixels correspond to the first character, to the second character or to a separator. CTC was created for this situation, in which a model produces a sequence of frame-wise probabilities while the correspondence between frames and labels is unknown [11]. The recognition network transforms the image into a feature sequence of length $T$. At each time step $t$, it predicts a probability distribution $P_t(c \mid x)$ over the vocabulary and an additional blank symbol. A collapse operation then produces the transcription.

Let $y=(y_1,\ldots,y_L)$ be the target string. A CTC *path* $\pi$ is a sequence of length $T$ over the vocabulary and the blank symbol. The collapse map $\mathcal{B}$ merges consecutive repeated symbols and then removes blanks. All paths that collapse to the same string are combined in the probability of that string:

$$P(y \mid x)=\sum_{\pi \in \mathcal{B}^{-1}(y)} \prod_{t=1}^{T} P_t(\pi_t \mid x). \qquad (1)$$

Dynamic programming computes this sum efficiently during training. CTC therefore needs no character boxes, and the classifier produces all frame probabilities in one forward pass. These two properties explain why CTC remains attractive for plates, whose strings are short and mostly regular. At inference, the simplest decoder takes the most likely symbol at every time step and collapses the result (greedy decoding). A beam search can recover from some local uncertainty, but it changes the speed of the system. Figure 7 shows a frame-level path for an illustrative Chinese plate string.

![Figure 7](figs/fig05_ctc_collapse.png)

*Figure 7. A frame-level CTC path for the illustrative plate string 京A88765. Repeated emissions are merged first, and blank symbols are removed second. The blank between the frames of the two copies of "8" keeps them as two characters. The path is illustrative, not the output of a trained model.*

### 2.1.2. Why output order is a question of visual representation

A CTC classifier does not know whether its time axis represents horizontal columns, a sequence of attended image regions, or the result of a learned spatial transformation. It only receives features at ordered positions. If these positions follow the characters in the same order as the label, CTC has a well-posed alignment problem. If the positions mix the upper and lower rows of a two-row plate, the training objective contradicts the representation. This distinction explains why a good CTC recognizer can fail on some two-row plates and succeed on others. The difficulty does not come from the blank symbol. It comes from a mismatch between the spatial evidence and the expected reading order.

Consider an illustrative two-row plate whose upper row is 京A and whose lower row is 8K72. A person reads 京A8K72. If the encoder merges the columns of both rows into one horizontal sequence, the evidence for 8 and for 京 can fall into the same column, and the following columns can mix K with A. CTC can still produce a sequence of six symbols, but one feature frame cannot represent two glyphs that are visible at the same time as two separate output positions. The system must therefore keep enough time steps, map the spatial grid into the correct order, or receive separate crops of the two rows. This is the reason to examine the feature rearrangement of SVTRv2 in Section 2.2, and to extend it in Section 2.3.

### 2.1.3. Sequence capacity and repeated characters

CTC usually produces many more time steps than output characters. This redundancy is useful. The model can spread one character over several frames and use blanks to separate two neighbouring copies of the same symbol. Repeated characters are common on plates. Chinese serials such as 66888 or 11223 contain several repeated digits, and such "lucky number" plates are popular. Strong horizontal downsampling reduces the number of time steps. If a plate with eight symbols produces only eight time steps, the model cannot place a blank between repeated characters. In general, a string with $L$ characters and $r$ positions where a character repeats its predecessor needs at least $L+r$ time steps. The problem is not that CTC cannot output repeated characters. The problem is that a short time axis reduces the feasible alignments and puts pressure on the representation.

The number of time steps is therefore a property of the whole encoder and of the preprocessing, not only of the CTC head. A patch size that is economical for image classification can be too coarse for text with thin strokes. If one patch covers large parts of two neighbouring characters, no later stage can fully separate them. Resizing a plate to a fixed width also reduces the number of horizontal feature positions relative to the number of characters. In a fair comparison, the input size and the resolution of the feature grid must give enough capacity to every recognition head. The input sizes must be reported together with the results.

### 2.1.4. Aspect-ratio distortion as a source of errors

License plates have very different proportions. A Chinese blue plate is 440 mm wide and 140 mm high, so its aspect ratio is about 3.1. A yellow two-row rear plate is 440 mm by 220 mm, with an aspect ratio of 2.0. A motorcycle plate is 220 mm by 140 mm, with an aspect ratio of about 1.6. If all these crops are resized to the same width and height, some of them are strongly stretched or compressed. A digit can become unnaturally narrow, or a two-row plate can be flattened until the glyphs of the upper and lower rows overlap in the feature representation. This changes the geometry of the strokes before the recognizer can learn them. The effect is especially harmful for similar glyphs that differ only by a short bar, a diagonal or an internal gap, such as B and 8 or D and 0.

The effect is stronger when the image is already degraded. Downsampling a weak stroke and stretching it later cannot restore the original distinction. A model can still learn the dominant font of its training set, but this is fragile under new cameras or new plate types. Aspect-aware preprocessing is therefore not cosmetic. It changes which visual evidence remains observable. The SVTRv2 authors identify unsuitable fixed-size resizing as one source of poor performance on irregular text [50]. For plates, the value of aspect-aware resizing is largest when one service must read long one-row plates and short two-row plates.

### 2.1.5. Missing linguistic context and the danger of overcorrection

A plain CTC head classifies each frame independently, given the encoded features. This does not mean that the model has no context. A ViT-style encoder combines information from neighbouring characters before it produces the frame probabilities. Nevertheless, a plain CTC head does not explicitly model the dependencies between output characters. The SVTRv2 authors identify the weak use of linguistic information as a major reason why earlier CTC recognizers performed worse than encoder–decoder methods [50]. This is their motivation for semantic guidance during training.

License plates require care with linguistic context. Words in natural language have strongly constrained spellings, but plate identifiers are designed to be arbitrary combinations within a format. For a Chinese plate, the provincial character predicts the set of character classes that can follow, but each individual digit carries almost no information about its neighbours. A strong prior learned from a few dominant formats can improve familiar plates and harm unfamiliar plates. The most useful linguistic knowledge for plates is therefore the explicit format, not the statistics of frequent strings. Section 2.3 shows how the format can be used in decoding without becoming a hard rule.

### 2.1.6. Inference cost is more than the CTC classifier

CTC is often described as inexpensive, because it needs only a linear classifier and a collapse operation. This comparison is meaningful only if the visual encoder is included. A large encoder can dominate the latency, whether its output goes to a CTC head or to a parallel decoder. CTC implementations also differ in input resizing, feature rearrangement, vocabulary size, greedy or beam decoding, and numerical precision. If the encoder processes a taller image for a two-row plate, the extra tokens can increase the cost of attention more than the final classifier does. In an end-to-end application, plate detection, rectification and multi-frame processing may cost even more. In this paper, efficiency therefore means the measured latency and memory of the whole recognition stage, under the same encoder and the same input sizes.

## 2.2. SVTRv2: Multi-Size Resizing, Feature Rearrangement, and Semantic Guidance

SVTRv2 improves a CTC recognizer in two directions [50]. First, it handles text irregularity with a multi-size resizing strategy (MSR) and a feature rearrangement module (FRM). Second, it adds linguistic context with a semantic guidance module (SGM), which is used only during training. The visual model is a hierarchical encoder with local and global mixing blocks. This section describes these components as published, and it explains what they do and do not solve for license plates.

### 2.2.1. Visual encoder

Let the resized plate image be $I \in \mathbb{R}^{H \times W \times 3}$. The encoder maps the pixels to a two-dimensional feature map $F \in \mathbb{R}^{H' \times W' \times D}$, where $H' = H/8$ and $W' = W/4$ in SVTRv2 [50]. Each spatial position of $F$ keeps its correspondence to a small region of the plate. The encoder has three stages of mixing blocks (Figure 8). A local mixing block uses two consecutive grouped convolutions to capture short-range structure such as edges and strokes. A global mixing block uses multi-head self-attention to relate distant regions, so that a symbol can be interpreted in the context of the whole plate [41,50]. In the published model variants, the first stage uses local blocks, the second stage uses local blocks followed by global blocks, and the third stage uses global blocks. Residual connections, layer normalization and channel-wise feed-forward networks stabilize the blocks (Figure 9).

![Figure 8](figs/fig06_encoder.png)

*Figure 8. The shared hierarchical visual encoder in the style of SVTRv2-T. The three stages are read in order. One height-only downsampling between stages reduces the height from H/4 to H/8, while the width resolution W/4 is kept for sequence decoding.*

![Figure 9](figs/fig07_mixing_block.png)

*Figure 9. A mixing block of the encoder. Each block uses either local mixing (two grouped convolutions) or global mixing (multi-head self-attention), followed by a residual connection and a feed-forward network.*

The output of the encoder is a spatial feature map, not a string. This distinction is central to this paper. The same feature at a given position can support a CTC alignment, a query of a parallel decoder or a layout classifier. FADR uses exactly this property: the three heads of the recognizer read the same feature map. The local mixing blocks help to separate the strokes of complex Chinese characters. The global blocks help when a shape is ambiguous in isolation, for example when two neighbouring strokes may belong to one Chinese character or to two Latin symbols. However, understanding the image at this level does not define the reading order of two rows. The recognition head must define how the feature positions are ordered.

### 2.2.2. Multi-size resizing (MSR)

Input normalization is not neutral. If a nearly square two-row crop is stretched to the same wide rectangle as a one-row plate, the geometry of the characters changes. The encoder then learns from distorted strokes, and the widths of the character regions may no longer suit sequence alignment. MSR makes the input size depend on the aspect ratio $R = W/H$ of the crop. SVTRv2 uses four predefined sizes: $64 \times 64$ for $R < 1.5$, $48 \times 96$ for $1.5 \le R < 2.5$, $40 \times 112$ for $2.5 \le R < 3.5$, and $32 \times \lfloor R \rfloor \cdot 32$ for $R \ge 3.5$ [50]. MSR keeps useful differences in height and width and still allows efficient batching. MSR is different from geometric rectification. MSR chooses a suitable tensor shape. Rectification corrects projective distortion in the image content.

Figure 10 shows how the main Chinese plate types fall into these buckets. Blue and green one-row plates, with aspect ratios of about 3.1 and 3.4, use the $40 \times 112$ bucket, which gives a feature grid of $5 \times 28$ positions. Yellow two-row rear plates and motorcycle plates, with aspect ratios of about 2.0 and 1.6, use the $48 \times 96$ bucket, which gives $6 \times 24$ positions. The two-row plates therefore receive more vertical resolution, which helps to keep the two rows separate in the feature map. Long one-row plates in other countries, for example European plates with an aspect ratio of about 4.7, use the widest bucket. The real aspect ratio of a crop also depends on the viewing angle, so the bucket of a plate type is not fixed. This is one reason why the bucket alone cannot decide the number of rows, and why FADR uses a learned layout–format head (Section 2.3.2).

![Figure 10](figs/fig_cn_msr_buckets.png)

*Figure 10. Multi-size resizing buckets of SVTRv2 applied to Chinese plate types. The bucket depends on the aspect ratio of the crop. Two-row plates receive more feature rows than one-row plates. Sizes are nominal; real crops vary with the viewing angle.*

### 2.2.3. Feature rearrangement module (FRM)

The FRM connects the two-dimensional feature map with the one-dimensional CTC label sequence (Figure 11). A simple recognizer could average the feature map over its height and treat the $W'$ columns as time steps. Such averaging discards vertical distinctions. The FRM instead computes an input-dependent rearrangement in two steps [50].

![Figure 11](figs/fig09_svtrv2_pipeline.png)

*Figure 11. Recognition process of SVTRv2. The inference path (solid arrows) consists of resizing, the hierarchical encoder, the horizontal and vertical steps of the FRM, the CTC classifier and the CTC collapse. The semantic guidance module (dashed arrows) receives the encoder features and is used only during training [50].*

The first step is a horizontal rearrangement inside each row of the feature map. For row $i$, with features $F_i \in \mathbb{R}^{W' \times D}$, a row-wise attention matrix reweights the features of that row, and a residual connection, layer normalization and a feed-forward network follow:

$$F^{h}_i=\mathrm{LN}\Big(F_i+\mathrm{softmax}\big(F_iW^{q}(F_iW^{k})^{\top}\big)F_i\Big),\qquad F'_i=\mathrm{LN}\big(F^{h}_i+\mathrm{MLP}(F^{h}_i)\big). \qquad (2)$$

The second step is a vertical selection. A single learnable *selecting token* $T^{s}$ attends to the $H'$ positions of each column $j$ of the horizontally rearranged features. The resulting weights pool the column into one feature vector:

$$a_j=\mathrm{softmax}\big(T^{s}(F'_{:,j}W^{k'})^{\top}\big),\qquad s_j=a_j\,F'_{:,j},\qquad j=1,\ldots,W'. \qquad (3)$$

The result is a sequence $S=(s_1,\ldots,s_{W'})$ of $W' = W/4$ feature vectors. A linear layer and a softmax then give the CTC probabilities at each of the $W'$ time steps (Figure 12). The same selecting token is shared by all columns, which the SVTRv2 authors report as helpful for generalization to longer text [50]. The mechanism keeps the parallel nature of CTC inference and makes the alignment more flexible than a fixed pooling rule. The SVTRv2 authors report that the FRM improves the recognition of multi-oriented text.

![Figure 12](figs/fig10_frm_softmap.png)

*Figure 12. Feature rearrangement as a soft mapping from a two-dimensional feature map to CTC time steps. The horizontal step mixes features inside each row. The vertical step pools each column into one time step, so seven columns give seven time steps.*

The extent of this flexibility must be stated clearly. The FRM was designed for irregular scene text, for example rotated or curved words. The SVTRv2 paper does not show that it solves every two-row arrangement. Equation 3 produces exactly one feature per column. In a two-row plate, each column of the feature map contains evidence from the upper row and from the lower row at the same horizontal position. One selecting token must choose between them, or mix them, but it cannot return both as two separate time steps. The order "whole upper row, then whole lower row" therefore cannot be produced by a single column-wise selection. This is the structural reason for the row-selective extension in Section 2.3.3.

### 2.2.4. Semantic guidance module (SGM)

CTC is sometimes described as having no context, but this description is not precise. The visual encoder already contains contextual interactions. The limitation is that the CTC objective does not explicitly model the dependencies between output characters, as an autoregressive decoder does. The SGM of SVTRv2 addresses this limitation during training. During training, the encoder features $F$ are fed into both the SGM and the FRM [50]. The SGM supervises the encoder with the left and right context of each character, so that the visual features learn relations between characters, not only local appearance (Figure 13). Because the SGM is not part of the inference path, the deployed model keeps the fast CTC classifier and the collapse rule.

![Figure 13](figs/fig11_sgm.png)

*Figure 13. Semantic guidance during training. The SGM receives the encoder features directly, in parallel with the FRM. It is removed at inference, but its effect remains in the encoder weights.*

The phrase "training only" needs a precise interpretation. Inference does not ignore all semantic context. The encoder parameters keep the effect of the semantic supervision, but the auxiliary module itself is absent. When a Chinese plate contains a provincial character that is visually ambiguous, semantic guidance may help the encoder to learn distinctions that are available in the surrounding appearance. However, no training-only module can reconstruct a stroke that is physically absent in the observation. A strong use of national syntax can also create confident but wrong corrections when plate formats change. Semantic guidance should therefore be understood as learned discriminative context, not as a guarantee that every output is a valid plate number.

### 2.2.5. CTC inference and the repeated-character case

The final CTC distribution covers the alphabet and the blank class. For a string that contains two successive copies of the same character, a valid path needs a blank between them (Figure 14). This detail matters for Chinese plates, because repeated digits are common in serials. The difficulty with repeated characters does not prove that CTC cannot learn such strings. It increases the sensitivity of CTC to the feature width, to the alignment and to the probability of the blank at the right positions. The FRM changes how the visual model builds the ordered sequence. It does not change the alignment rule of CTC.

![Figure 14](figs/fig12_ctc_repeated.png)

*Figure 14. CTC alignment for the illustrative plate string 京A11235, which contains a repeated digit. In path (a), a blank between the frames of the two copies of "1" keeps both copies after the collapse. In path (b), this blank is missing, the repeated frames merge, and one character is lost.*

### 2.2.6. What SVTRv2 does not solve for license plates

SVTRv2 is a strong and efficient starting point. Its encoder, MSR and FRM prepare an alignment-compatible sequence, and its SGM transfers context into the encoder. For the task of this paper, four limitations remain:

1. **Two-row order.** The FRM produces one time step per column. It cannot represent two characters that are stacked in the same column as two consecutive outputs in the correct order (Section 2.2.3).
2. **No use of plate formats.** The model can learn frequent patterns from data, but it cannot use the official format of a plate type as explicit knowledge. It has no mechanism to keep this knowledge soft for unseen formats.
3. **No layout decision.** MSR selects an input size from the aspect ratio, but it does not decide how many rows the plate has. The aspect ratio alone is not reliable, because it depends on the viewing angle.
4. **Uncalibrated confidence.** Greedy CTC decoding returns a string and frame probabilities. It does not provide a calibrated confidence for each character, which a cascade needs in order to decide when to stop.

Section 2.3 addresses these four points while keeping the published components of SVTRv2 unchanged where possible.

## 2.3. Proposed CTC Draft Branch: Row-Selective Rearrangement and Format-Constrained Decoding

The draft branch has four parts: a layout–format head (Section 2.3.2), a row-selective FRM (Section 2.3.3), row-factorized CTC training (Section 2.3.4), and format-constrained decoding with calibrated slot confidences (Sections 2.3.5 to 2.3.7). The branch produces a draft string, a format hypothesis and a confidence value for every character. Chapter 4 uses these outputs to decide whether the plate needs refinement.

### 2.3.1. Four routes to the transcription of a two-row plate

Figure 15 compares four ways to read a two-row plate. The first route gives the whole crop to SVTRv2 and lets the FRM learn a sequence. It uses one recognizer call and no line detector, but one selecting token per column mixes the rows, so the row transition must be learned from data and remains fragile. The second route detects the two rows in the image, crops them, reads each row with the same CTC recognizer and concatenates the results. This route is reliable when the row boundary is clean, but it needs an extra step, two recognizer calls, and a splitter that can fail on tilted plates or on plates with emblems between the rows. The third route uses a parallel decoder such as CPPD, whose position queries can attend to any region of the two-dimensional feature map. It handles the layout naturally, but it costs more than CTC and it learns the reading order only from the training labels. The fourth route is the proposed row-selective CTC. It keeps one recognizer call and the parallel CTC head, and it produces the two rows as two ordered sequences inside the network.

![Figure 15](figs/fig13_two_row_routes.png)

*Figure 15. Four routes to the transcription of a two-row plate. Whole-image CTC must learn the row transition; line-split CTC adds an image-level step; a parallel decoder attends to two-dimensional features; the proposed row-selective CTC produces one ordered sequence per row inside the network.*

### 2.3.2. Layout–format head (LFH)

The layout–format head predicts the plate format from the image. Let $\mathcal{K}=\{1,\ldots,K\}$ be the set of known format templates of the deployment, for example the Chinese small-car plate, the small new-energy plate, the large new-energy plate, the yellow two-row rear plate and the trailer plate. Two additional classes represent the open format with one row and the open format with two rows. The LFH pools the feature map $F$ with a learned attention pooling and applies a small multilayer perceptron with a softmax over these $K+2$ classes. Its output is a probability $p(k \mid x)$ for each format. Each format has a fixed number of rows, so the probability that the plate has two rows is the sum of the probabilities of all two-row formats.

The LFH uses visual context. The colour of the plate, its aspect ratio, the position of the characters and the presence of a second row are all visible in the feature map. A green plate with eight characters indicates a new-energy plate. A yellow plate with two rows indicates a rear plate of a large vehicle or a trailer. The LFH therefore gives an independent source of evidence about the format, which does not depend on the characters that the CTC branch reads. Training labels for the LFH are derived automatically. The ground-truth string and the row annotation of each training plate are matched against the templates, and plates that match no template receive one of the two open-format labels. No additional manual annotation is required. The head adds only a pooling layer and a small classifier to the encoder.

Figure 16 shows the structure of the head and illustrative outputs for three Chinese plate types. For a blue small-car plate, almost all probability belongs to the small-car template. For a green plate, it belongs to the small new-energy template. For a yellow two-row plate, the probability is shared between the rear plate of a large vehicle and the trailer plate. The two templates differ only in the last character, so the CTC evidence and the refiner decide between them later. Both are two-row templates, so the layout decision is already clear.

![Figure 16](figs/fig24_lfh.png)

*Figure 16. The layout–format head. Attention pooling summarizes the feature map, and a small classifier predicts a probability for each known template and for the two open formats. The bars show illustrative outputs for three Chinese plate types. The number of rows follows from the probabilities of the two-row formats.*

The LFH should not be confused with a plate-colour classifier. Colour is only one cue, and it is unreliable at night, under coloured street lights and in images from cameras with poor white balance. The LFH is trained on the whole feature map, so it can also use the character layout. Its probabilities are calibrated with temperature scaling on a validation set [69], because Chapter 4 uses them as weights in the decoding score.

### 2.3.3. Row-selective feature rearrangement (RS-FRM)

The RS-FRM keeps the horizontal step of the FRM (Equation 2) and changes the vertical selection. SVTRv2 uses one selecting token for all plates. The RS-FRM uses three layout-specific tokens: $T^{s}_{0}$ for one-row plates, $T^{s}_{1}$ for the upper row of two-row plates and $T^{s}_{2}$ for the lower row of two-row plates. Each token pools every column with Equation 3 and gives one sequence of $W'$ vectors, written $S^{(0)}$, $S^{(1)}$ and $S^{(2)}$. The CTC input sequence then depends on the number of rows $r$:

$$S=\begin{cases} S^{(0)}, & r=1,\\ \big[\,S^{(1)}+e_1\,;\;S^{(2)}+e_2\,\big], & r=2, \end{cases} \qquad (4)$$

where $[\,\cdot\,;\,\cdot\,]$ concatenates the two sequences along the time axis and $e_1$ and $e_2$ are learned row embeddings that are added to every vector of the corresponding row sequence. A one-row plate therefore gives $W'$ time steps, as in SVTRv2. A two-row plate gives $2W'$ time steps: first all the time steps of the upper row, then all the time steps of the lower row (Figure 17). The CTC classifier and the collapse rule are unchanged.

![Figure 17](figs/fig14_rsfrm.png)

*Figure 17. Row-selective feature rearrangement. The horizontal step is the same as in SVTRv2. In the vertical step, a one-row plate uses one selecting token, and a two-row plate uses one token for the upper row and one for the lower row. The two row sequences are concatenated, so CTC reads the upper row first and the lower row second.*

At inference, the number of rows comes from the LFH. When the LFH is confident, only the sequence of the predicted layout is computed and decoded. When the probability of two rows is between two thresholds, for example between 0.2 and 0.8, both layouts are decoded, and the format-constrained decoding of Section 2.3.6 chooses between them. Because the selecting tokens are single vectors and the vertical selection is a small attention over $H'$ positions, the extra cost of the RS-FRM is negligible compared with the encoder.

The design has three advantages over the alternatives in Section 2.3.1. First, the reading order of a two-row plate is built into the architecture, not learned as an implicit pattern. Second, the row boundary does not have to be a straight line in the image, because each column decides through attention which positions belong to which row. This tolerates tilted plates and rows of different lengths. Third, the method keeps one recognizer call and fully parallel CTC inference. The capacity also suits plates: in the $48 \times 96$ bucket, each row sequence has 24 time steps, which is much more than the five characters of the lower row of a Chinese two-row plate, even when digits repeat.

### 2.3.4. Row-factorized CTC training

The row-selective tokens must learn which row they select. Concatenating the two sequences and training with the CTC loss of the full string is possible, but the network can then place the upper-row characters at the end of the upper sequence or at the start of the lower sequence. Both alignments give the same collapsed string. To make the role of each token unambiguous, the training uses row-factorized losses whenever the row structure of the label is known:

Figure 18 illustrates the problem and the solution. With one loss on the concatenated sequence, a path that moves the letter A from the upper sequence to the start of the lower sequence has exactly the same loss as the intended path, because both collapse to the same string. Nothing in the loss tells the upper token that A belongs to it. With one loss per row, the shifted path produces A12345 for the lower row, which does not match the lower-row label, so it receives a high loss. Each row token therefore learns to read only its own row.

![Figure 18](figs/fig25_row_loss.png)

*Figure 18. Row-factorized CTC training for the two-row plate 沪A / 12345. (a) With one loss on the concatenated sequence, a path that moves the letter A into the lower-row sequence has the same loss as the intended path. (b) With one loss per row, this shifted path is wrong, so each row token learns to read only its own row.*

$$\mathcal{L}_{\text{ctc}}=\begin{cases} -\log P\big(y \mid S^{(0)}\big), & r=1,\\ -\log P\big(y^{(1)} \mid S^{(1)}\big)-\log P\big(y^{(2)} \mid S^{(2)}\big), & r=2, \end{cases} \qquad (5)$$

where $y^{(1)}$ and $y^{(2)}$ are the strings of the upper and lower rows and each probability is computed with Equation 1 on its own sequence. For a Chinese yellow two-row plate 沪A / 12345, the upper sequence learns to produce 沪A and the lower sequence learns to produce 12345. For training samples whose row split is not annotated, the loss of the full string on the concatenated sequence is used. The row split of most training data is cheap to obtain. Synthetic plates are rendered row by row, CRPD labels the two-row plate type [46], and the row split of a Chinese or Brazilian two-row plate can be derived from its format template, because the template defines how many characters each row contains.

During training, the number of rows comes from the label, not from the LFH. This is a form of teacher forcing. It prevents early mistakes of the LFH from disturbing the training of the CTC branch. At inference, the LFH decides, and the uncertain cases are resolved by decoding both layouts.

### 2.3.5. Plate format templates and automata

A format template describes one plate type as a sequence of slots. Each slot has a row index and a slot type, that is, a set of allowed characters. Figure 19 shows simplified templates for the main Chinese plate types. The slot types are: P, a provincial character; L, a letter without I and O; A, a letter or a digit without I and O; N, a digit; E, the energy code D or F; and S, a special final character such as 挂, 学, 警, 港 or 澳. For example, the Chinese small-car plate has the template P L A A A A A, the small new-energy plate has P L E A N N N N, and the yellow two-row rear plate has P L in the upper row and A A A A A in the lower row.

![Figure 19](figs/fig_cn_format_templates.png)

*Figure 19. Simplified format templates of Chinese plate types. Each slot has a type, and two-row templates assign each slot to a row. The templates are compiled into automata for constrained decoding. The open format accepts any string and receives a penalty.*

Each template defines a set of valid strings: a string is valid for a template if it has the right length and each character belongs to the type of its slot. Some official rules cannot be expressed slot by slot. For example, the serial of a Chinese plate may contain at most two letters. This rule depends on several slots together. Both kinds of rules can be expressed by a finite automaton. The states of the automaton record the current slot and, where necessary, a small counter such as the number of letters used so far. Each template $k$ is compiled into a deterministic automaton $\mathcal{A}_k$ with a start state, transitions labelled with characters and one or more final states. A string is valid for template $k$ if the automaton reaches a final state after reading it.

The templates of a deployment are combined into one decoding graph. Templates with a common prefix share their initial states, because all Chinese civilian templates begin with a provincial character and a letter. The *open format* is added as a separate automaton $\mathcal{A}_{\text{open}}$ that accepts any string of vocabulary characters up to a maximum length. For two-row plates, a template has an upper-row part and a lower-row part, and each part has its own automaton. Building the graph is a one-time offline step. Adding a new plate type requires a new template and a small update of the layout–format head (Section 4.4.4), but no retraining of the CTC classifier. Training data for the new type still improves the visual recognition.

### 2.3.6. Format-constrained CTC decoding

The draft branch decodes the CTC probabilities with a prefix beam search [70] in which each hypothesis also carries a template $k$ and a state of the automaton $\mathcal{A}_k$. A hypothesis can be extended with a character only if the automaton has a transition for that character from the current state. Blank symbols and repeated emissions of the same character do not change the state, as in standard CTC prefix search. At the end of the sequence, only hypotheses in a final state are kept. The score of a complete hypothesis, a string $y$ under template $k$, combines the CTC evidence with the format evidence:

$$\mathrm{score}(y,k)=\log P_{\text{ctc}}(y \mid x)+\beta\,\log p(k \mid x)+\log \pi_k, \qquad y \in \mathcal{L}(\mathcal{A}_k), \qquad (6)$$

where $P_{\text{ctc}}(y \mid x)$ is the CTC probability of Equation 1, $p(k \mid x)$ is the probability of the template from the LFH, $\beta$ is a weight, and $\pi_k$ is a prior for the template in the deployment, for example the share of new-energy plates in a city. For the open format, $\pi_{\text{open}}$ is a penalty factor smaller than one. The open format is never removed: its score can win when the CTC evidence for a string outside all known templates is strong. This is the main difference from a hard format filter.

Figure 20 illustrates one step of the search. Suppose the CTC probabilities after the provincial character 粤 favour the digit 8 (probability 0.55) over the letter B (probability 0.40). In the template of a Chinese civilian plate, the second slot must contain a letter. The extension with 8 is blocked in all known templates, so the hypothesis 粤B continues. The hypothesis 粤8 survives only on the open-format path, with the open-format penalty. If the rest of the plate fits a known template, 粤B wins. The format has resolved a B/8 confusion without any change to the network. If the plate really has an unusual format, the open path can still win.

![Figure 20](figs/fig15_format_automaton.png)

*Figure 20. Plate formats as automata for constrained CTC decoding. Templates are sequences of slot types; each template becomes a chain automaton; the open format is a penalised loop. In the example step, the letter slot blocks the digit 8 and keeps the letter B, which resolves a B/8 confusion.*

Two-row templates are decoded row by row. For a two-row template, the upper-row automaton constrains the search over the upper sequence $S^{(1)}$, and the lower-row automaton constrains the search over the lower sequence $S^{(2)}$. Because the RS-FRM separates the rows, the row boundary is known, and the two searches are independent. Their scores add up. This row-factorized decoding is both faster and more precise than a search over the concatenated sequence, because a character cannot move from one row to the other.

The decoder returns an n-best list of hypotheses with their templates and scores. The list contains the best hypothesis of each of the most probable templates and the best open-format hypothesis. Each hypothesis that follows a template is aligned to the slots of that template by construction: the automaton consumes exactly one character per slot. This slot alignment is important for the refiner of Chapter 3 and for the multi-frame fusion of Chapter 4.

### 2.3.7. Algorithm and worked example

Algorithm 1 summarizes the format-constrained decoding. The algorithm follows the standard CTC prefix beam search [70]. The only additions are the template, the automaton state of each hypothesis, the transition check and the format terms of the final score.

```text
Algorithm 1. Format-constrained CTC prefix beam search (one row sequence)

Input : CTC probabilities P[t][c] for t = 1..T, including the blank symbol
        candidate templates k with automata A_k, LFH probabilities p(k|x),
        site priors pi_k, beam width B
Output: n-best list of (string y, template k, score)

1  for each candidate template k (including the open format):
2      beam <- { (empty prefix, start state of A_k) }
3      for t = 1 .. T:
4          new_beam <- {}
5          for each hypothesis (prefix, state) in beam:
6              add the blank extension: prefix and state stay the same
7              add the repeat extension: the last character is emitted again
8              for each character c allowed by A_k in this state:
9                  if c equals the last character of the prefix:
10                     extend only from paths that end with a blank
11                 new state <- transition of A_k from state with c
12                 add (prefix + c, new state) to new_beam
13         keep the B hypotheses with the highest CTC probability in new_beam
14     keep the hypotheses whose state is a final state of A_k
15     score each one with log P_ctc(y|x) + beta * log p(k|x) + log pi_k
16 return the hypotheses of all templates, sorted by score
```

For a two-row template, Algorithm 1 runs once on the upper sequence with the upper-row automaton and once on the lower sequence with the lower-row automaton. The CTC terms of the two rows are added, and the format terms are added once.

A worked example shows how the parts of the draft branch act together on a Chinese yellow two-row rear plate with the string 沪A / 12345. The crop has an aspect ratio of about 2.0, so MSR resizes it to $48 \times 96$ pixels, and the encoder produces a feature map of $6 \times 24$ positions. The LFH assigns a high probability to the template of the yellow two-row rear plate, so the RS-FRM uses the tokens $T^{s}_{1}$ and $T^{s}_{2}$. The upper token pools the upper part of each column and gives a sequence of 24 time steps. In this sequence, a few time steps near the left edge emit 沪 and A, and the other time steps emit blanks. The lower token gives another sequence of 24 time steps, which emits 1, 2, 3, 4 and 5 from left to right, with blanks between them. Greedy decoding collapses the two sequences into 沪A and 12345, and the draft is 沪A12345. If the image is clear, every character has a high confidence, the string is valid for the template, and the draft is accepted (Chapter 4). If the image is blurred and the lower sequence reads 1Z345, the draft is still valid, because the slot type A allows the letter Z. The format cannot detect this error. However, the confidence of Z will be low, because the frame probabilities of Z and 2 are close. The plate is then passed to the refiner. This example also shows a limit of format knowledge: it can resolve a confusion only between characters of different slot types.

### 2.3.8. Calibrated slot confidence

The cascade of Chapter 4 needs a confidence value for each character of the draft. The best CTC path assigns a group of frames to each output character. The slot confidence $\kappa_j$ of character $j$ is the highest probability of that character over its frames. CTC probabilities are often peaked, and frame probabilities are not calibrated probabilities of correctness. The confidences are therefore calibrated with temperature scaling on a validation set [69]. A single temperature is fitted for the CTC logits and another for the LFH logits. After calibration, a slot confidence of 0.95 means that, on validation data, about 95 percent of the characters with this confidence are correct. The calibrated confidences are used for three purposes: to accept a draft at the gate, to mask uncertain characters for the refiner, and to report a plate-level confidence with the final output.

Figure 21 applies this procedure to the blurred plate of the worked example in Section 2.3.7. The frames that emit 1, 3, 4 and 5 have high probabilities. The frame that emits Z has a low probability, because the character 2 receives almost the same probability. After calibration, the confidence of slot 4 is below the masking threshold, so this slot is masked and passed to the refiner, while the other six slots keep their draft characters. The example also shows why the confidence is needed per character and not only per plate: six of the seven characters are read with high confidence, and only one slot is uncertain.

![Figure 21](figs/fig26_slot_confidence.png)

*Figure 21. Calibrated slot confidence of the draft 沪A1Z345. (a) The confidence of a character is its highest frame probability; the frame of Z is uncertain because 2 is a close second. (b) After temperature scaling, the confidence of slot 4 is below the masking threshold, so the slot is masked and re-read by the refiner. The values are illustrative.*

### 2.3.9. Computational cost of the draft branch

The draft branch adds four small operations to SVTRv2: the LFH, two extra selecting tokens, the row embeddings and the constrained search. The LFH and the tokens add a few thousand parameters and a negligible number of operations. The constrained search runs on the CPU after the network. Its cost is proportional to the number of time steps, the beam width and the number of allowed characters per state. For a two-row plate in the $48 \times 96$ bucket, the search processes two sequences of 24 time steps each. With a beam width of five and a few templates, the search takes a fraction of a millisecond in a compiled implementation. The automata also reduce the work of the search, because most characters are not allowed in most slots. For example, a slot of type N allows only 10 of the about 70 characters of a Chinese vocabulary. In addition, the search is needed only for plates that the greedy draft does not resolve (Chapter 4).

### 2.3.10. Summary of Chapter 2

This chapter described CTC, explained why the order of the visual features decides whether CTC can read a two-row plate, and described the published components of SVTRv2. It then proposed a draft branch with four new elements. The layout–format head infers the plate format and the number of rows from visual evidence. The row-selective FRM produces one ordered sequence per row, so that CTC reads two-row plates in the correct order. Row-factorized CTC training makes the role of each row token unambiguous. Format-constrained decoding uses the official templates as soft linguistic knowledge, keeps an open-format path for unseen plates, and returns slot-aligned hypotheses with calibrated confidences. The draft branch is efficient and resolves most plates on its own. Chapter 3 develops the second branch, which re-reads the plates that the draft cannot resolve with enough confidence.


# Chapter 3. Format-Aware Parallel Decoding Based on CPPD

This chapter develops the decoder side of the proposed recognizer. Section 3.1 explains what a decoder adds to a CTC recognizer and why autoregressive and conventional parallel decoders are not ideal for license plates. Section 3.2 describes the Context Perception Parallel Decoder (CPPD) as published by its authors [51]. Section 3.3 presents the proposed format-conditioned parallel refiner (FCPR). The refiner keeps the parallel computation and the context tasks of CPPD. It adds three things: slot queries that carry the plate format, conditioning on the CTC draft with uncertain characters masked, and explicit cross-attention to the two-dimensional feature map. Sections 3.1 and 3.2 describe existing methods. Section 3.3 describes the new contribution.

## 3.1. Limitations of Autoregressive and Conventional Parallel Decoders

### 3.1.1. Why a decoder is useful for license plates

A decoder maps visual features to an ordered sequence of symbols. The word "decoder" is used in different ways in OCR papers. A CTC system already has an inference procedure that collapses frame predictions, but its prediction head is not a trainable attention decoder. An encoder–decoder recognizer keeps the spatial visual features and uses queries to find the regions that support each output position. This makes recognition more flexible when the text is tilted, curved or arranged irregularly. On a license plate, this flexibility matters when the characters occupy two rows or when a special character is placed apart from the main sequence.

The essential difference between the two families is how the recognizer connects an output position with the visual evidence. A CTC system needs a monotonic or suitably rearranged feature sequence and learns an implicit alignment along that sequence. A spatial attention decoder uses a query for each output position and attends across the whole feature map. This helps when the next character is not simply to the right of the previous one. However, attention does not replace correct labels and representative training data. If all training images show one row, a decoder does not automatically infer that a new two-row design must be read upper row first. It must learn the rule from supervision or receive it as explicit information. The refiner of Section 3.3 receives the rule explicitly, through the row index of each slot.

### 3.1.2. Autoregressive character generation

In an autoregressive system, the model predicts the characters one after another. The next output depends on the image and on the characters that the model has already generated. This conditional structure is familiar from machine translation and language modeling, and it makes context helpful. When the visual evidence for a digit is ambiguous, the characters generated so far can influence the next prediction. For plates, the context is partly structural, because some countries restrict positions to digits or to letters, and partly visual, because earlier decisions influence which image region the decoder attends to next.

The sequential dependence has two costs. First, the decoder needs a chain of decoding steps. Even when each step is cheap, the chain has more synchronization points than a parallel prediction. For short plate strings, the absolute difference can be small, but on small CPUs and in high-throughput systems it must be measured. Second, autoregressive decoding has a characteristic failure mode: an early wrong character influences the later queries and can lead to a coherent but wrong continuation. A strong learned prior can also prefer a familiar-looking plate to the unfamiliar plate that is actually visible.

### 3.1.3. What conventional parallel decoders gain and lose

Parallel decoders predict all output positions in one main forward pass. Instead of generating the first character and using it to condition the second, they define a set of position queries and ask the model to connect each query with the relevant image evidence. This is attractive for real-time OCR, because the computation is less sequential. However, standard position queries carry little information. If the model starts from a generic position embedding, it must at the same time determine how many characters exist, where they are, and which symbol belongs to each position. These questions depend on each other: uncertainty about whether a character exists changes the meaning of all later positions.

Consider a two-row plate with a short upper row and a longer lower row. A parallel decoder must infer that its first two output positions refer to the upper row and that the following positions refer to the lower row, even though the rows overlap horizontally. If its position queries were learned mainly from one-row examples, it may continue horizontally and assign a lower-row symbol too early. A parallel architecture can therefore be fast and still face a difficult problem of context estimation. The CPPD paper starts from this concern and argues that earlier fast decoders lacked a stable description of the visual context [51].

### 3.1.4. Language context versus visual context

An important conceptual contribution of CPPD is the distinction between linguistic context and visual context [51]. Linguistic context concerns which characters tend to occur together and in which order. Visual context concerns what the characters look like, how many there are, where they are and how the positions relate to the image. In English, the letter Q is usually followed by U. In a registration identifier, a weak prior of this kind can be dangerous. The visual position of a character is often the safer source of information. A decoder that understands the extent and the order of the visible glyphs can recognize an unusual registration without forcing it into a common pattern.

The CPPD authors studied autoregressive recognition and found that its advantage over simple parallel decoding does not come only from knowing the identities of the earlier characters. The autoregressive decoder also provides guidance on visual context perception, such as the appearance and the position of the characters that it has already decoded [51]. A decoder that has located the first character can use its position to find the next one. CPPD tries to capture these benefits in a parallel computation by providing two kinds of complementary information: character counts and character order.

For license plates, a third kind of context is available: the format. The format is linguistic knowledge, because it describes which character classes may follow each other. Unlike learned language statistics, it is explicit, exact for known plate types and independent of the frequencies in the training data. The refiner of Section 3.3 combines the visual context of CPPD with this format context.

### 3.1.5. Position queries, maximum length, and real plates

A parallel decoder has a predefined maximum number of output positions $L_{\max}$. The model learns to stop by predicting an end-of-sequence symbol or a padding class. This works when the longest plate of the deployment is shorter than $L_{\max}$. "Variable length" does not mean "unbounded length". If a country introduces registrations that are longer than the available positions, the decoder cannot transcribe them without a new configuration. This is a capacity decision, not a failure of attention. A comparison must give every method realistic capacity. The feature grid must contain enough spatial evidence for the longest one-row and two-row plates, and the decoder must have enough output positions. For Chinese plates, eight characters are the normal maximum; the refiner of this paper uses a slightly larger value to allow for special plates and for plates from other countries.

## 3.2. Context Perception Parallel Decoding Through Character Counting and Ordering

CPPD predicts all characters in one decoding pass and builds context through two auxiliary tasks [51]. A character counting (CC) module infers how often each character occurs. A character ordering (CO) module infers the content-free reading order and the occupied positions. The character prediction task then associates the positions with characters. Experiments on English and Chinese benchmarks in the original paper showed accuracy competitive with autoregressive models while CPPD ran approximately eight times faster than its autoregressive counterparts [51]. This section describes the published method.

### 3.2.1. Visual representation and decoder inputs

The original CPPD models use SVTR as the visual encoder. The CPPD paper also tested its decoder with a ResNet-based encoder and with a ViT encoder [51]. This shows that the decoder does not depend on one particular encoder, which supports the use of a shared encoder in FADR. Let the encoder produce visual features $F$ with $N$ tokens. The decoder has two sets of learned embeddings. Character embeddings correspond to the entries of the vocabulary. Position embeddings correspond to the ordered output positions $1, \ldots, L_{\max}$. Cross-attention connects both sets with the visual tokens (Figure 22). In compact form, a cross-attention block computes $\mathrm{softmax}(QK^{\top}/\sqrt{d})V$, where the queries $Q$ come from the embeddings and the keys $K$ and values $V$ come from the visual tokens.

![Figure 22](figs/fig16_cppd.png)

*Figure 22. The CPPD decoder as published [51]. Character embeddings and position embeddings attend to the visual features in two parallel branches. Counting and ordering losses supervise the two branches during training. A fusion step and a parallel classifier predict all characters in one pass.*

### 3.2.2. Character counting (CC)

The CC task estimates the number of occurrences of each vocabulary symbol in the image. Consider the illustrative Chinese plate string 京A11025. Its inventory contains one 京, one A, two copies of 1, one 0, one 2 and one 5. A conventional position classifier makes a local choice at each position and does not represent this global inventory. The CC objective gives an explicit training signal that distinguishes one copy of 1 from two copies. Such supervision is useful for plates with repeated characters and for partial occlusion. Character counting is not a transcription, however. It does not depend on order, so the strings 京A11025 and 京A51201 have the same inventory (Figure 23).

In CPPD, each character embedding acts as a query that attends to the visual features. The model then predicts, for each character, how many times it occurs, and a counting loss supervises this prediction. The CPPD paper states that the CC module does not take part in inference [51]; its role is to shape the representation during training. The counting objective is different from a national regular expression. A character can appear in several positions, and the order of letters and digits can change without changing the definition of the counting task. There is also a limitation: a character that is absent from the training vocabulary does not become recognizable because a counting query exists for it.

### 3.2.3. Character ordering (CO)

Counting cannot say where a character belongs. The CO module therefore learns position placeholders that describe an ordered output sequence without character identities. For example, a string of seven characters occupies seven ordered positions, and the remaining positions up to $L_{\max}$ are empty. The CO queries attend to the visual features, so the model learns which image regions support each position. The objective is content-free: the first position is supervised as the first output position, without requiring it to be a particular letter or digit. This separates the concept of order from the concept of identity [51]. Figure 23 illustrates how the two objectives complement each other.

![Figure 23](figs/fig17_cc_co.png)

*Figure 23. Character counting and character ordering answer different questions. Counting describes the multiset of characters without their order; ordering describes the occupied positions without their identities. The final classifier combines both.*

The word "ordering" needs a careful interpretation. The position queries of CPPD do not discover an official reading convention by themselves. They learn positions relative to the order of the training labels. If the training examples always place all upper-row characters before all lower-row characters, and if enough visual information is available, the decoder can learn this mapping. No general model is guaranteed to infer the correct order for a completely unseen layout. The original CPPD study addresses scene text and reports English and Chinese benchmarks [51]; it does not report a multinational evaluation of two-row plates.

### 3.2.4. Context fusion and the parallel classifier

The two auxiliary tasks help transcription because they inform the representation that predicts the characters. In CPPD, the counting and ordering branches run in parallel on the visual features. A further cross-attention then fuses them: the order-aware position features act as queries, and the count-aware features act as keys and values [51]. The fused position features feed a linear classifier that predicts the character of every position in parallel. The recognition loss supervises the ordered transcription, while the counting and ordering losses reinforce its global content and its positional structure. At inference, the string is produced in one decoder pass instead of an autoregressive loop. The exact saving depends on the cost of the encoder, on the maximum length, on the vocabulary size and on the hardware.

### 3.2.5. What CPPD does not solve for license plates

CPPD gives a parallel decoder much of the context of an autoregressive decoder. For the task of this paper, four limitations remain:

1. **No explicit format knowledge.** The position queries of CPPD are content-free. They do not know that slot 1 of a Chinese plate holds a provincial character or that slot 3 of a small new-energy plate holds D or F. The decoder can learn frequent patterns, but it cannot use the official template as exact knowledge, and it cannot keep such knowledge soft for unseen formats.
2. **No explicit row information.** The position queries do not know in which row their character is. For two-row plates, the reading order must be learned only from the order of the labels.
3. **No use of a first reading.** CPPD reads every plate from scratch. When a cheaper recognizer has already read most characters with high confidence, this information is not used.
4. **Cost on every plate.** As a stand-alone recognizer, the decoder runs for every plate, including the clear majority that a CTC head reads correctly.

The refiner of Section 3.3 addresses the first three points. Chapter 4 addresses the fourth point with a confidence gate.

## 3.3. Proposed Format-Conditioned Parallel Refiner

The format-conditioned parallel refiner (FCPR) is a parallel decoder that re-reads a plate under a given format hypothesis. It does not read the plate from scratch. It receives the format template, the CTC draft aligned to the slots of the template, and the slot confidences of the draft. It predicts again the characters whose confidence is low, using the confident characters, the format and the visual features as context. Figure 24 gives an overview.

![Figure 24](figs/fig18_fcpr.png)

*Figure 24. The format-conditioned parallel refiner. Slot queries combine the position, the row, the slot type and the draft character, or a mask for uncertain characters. Two refiner layers apply slot self-attention, cross-attention to count-aware character features and cross-attention to the two-dimensional visual tokens. A type-masked classifier fills the masked slots in one pass.*

### 3.3.1. Design goals

The refiner has five design goals. First, it must use both kinds of context: linguistic context from the format and from the confident characters, and visual context from the feature map. Second, it must run in one parallel pass, so that its cost does not grow with the string length. Third, it must read the correct row of a two-row plate. Fourth, it must not force an unseen plate into a known format. Fifth, it must be cheap enough to run on the minority of plates that the draft cannot resolve, without changing the average cost of the system much. The following sections show how each element of the design serves these goals.

### 3.3.2. Slot queries from format templates

For a format hypothesis $k$ with $L_k$ slots, the refiner creates one query for each slot. Each slot $j$ has a position $j$, a row index $\rho_j$ and a slot type $\tau_j$ from the template (Section 2.3.5). The initial query of slot $j$ is the sum of four embeddings:

$$q_j=E_{\text{pos}}[j]+E_{\text{row}}[\rho_j]+E_{\text{type}}[\tau_j]+\begin{cases} E_{\text{char}}[\hat{y}_j], & \kappa_j \ge \gamma,\\ e_{\text{mask}}, & \kappa_j < \gamma, \end{cases} \qquad (7)$$

where $\hat{y}_j$ is the draft character of slot $j$, $\kappa_j$ is its calibrated confidence (Section 2.3.7), $\gamma$ is the masking threshold, and $e_{\text{mask}}$ is a learned mask embedding. The position embedding tells the query which slot it represents. The row embedding tells it which row to read. The type embedding tells it which class of characters to expect. The character embedding or the mask tells it what the draft has read.

For example, the template of a Chinese yellow two-row rear plate has seven slots. Slots 1 and 2 are in the upper row and have the types P and L. Slots 3 to 7 are in the lower row and have the type A. For the draft 沪A12345 with a low confidence on slot 4, the queries of slots 1, 2, 3, 5, 6 and 7 contain their draft characters, and the query of slot 4 contains the mask. The query of slot 4 therefore asks: "which letter or digit is in the second position of the lower row, given that the neighbouring characters are 1 and 3?" Compared with the content-free position queries of CPPD, each query starts with much more information. The refiner then needs to resolve only what is still uncertain.

### 3.3.3. Draft conditioning and masking

The masking follows the idea of Mask CTC [14]: start from the greedy or beam CTC output, mask the tokens with low confidence, and predict them conditioned on the tokens with high confidence. For license plates, this idea has two advantages. First, the draft gives the refiner a strong starting point: most characters of most plates are already correct. Second, the confident characters provide linguistic context for the uncertain ones. In a Chinese serial, this context is weak for individual digits, but it is strong for structural questions, such as whether a serial already contains two letters, or whether the energy code of a new-energy plate is D or F.

The masking threshold $\gamma$ is chosen on a validation set. A high threshold masks more characters, which gives the refiner more freedom but less context. A low threshold masks fewer characters, which keeps more context but may leave wrong draft characters unchanged. The refiner can also predict a character for an unmasked slot. In the default setting, an unmasked draft character is replaced only if the refiner assigns a much higher probability to another character of the same slot type. This rule lets the refiner correct a confident but wrong draft character when the visual evidence is strong, while it keeps the draft stable in normal cases.

### 3.3.4. Refiner layers: linguistic and visual context

The refiner has two identical layers. Each layer applies four operations to the slot queries:

1. **Slot self-attention.** The slot queries attend to each other. This is the linguistic context: a masked slot can see the confident neighbouring characters, their types and their rows.
2. **Cross-attention to count-aware character features.** As in CPPD, the character embeddings attend to the visual features, and the resulting count-aware features summarize which characters are present and how often [51]. The slot queries attend to these features. This gives each slot a global view of the inventory of the plate.
3. **Cross-attention to the two-dimensional visual tokens.** The slot queries attend directly to the visual tokens of $F$, which carry a two-dimensional positional encoding. This is the visual context, and it is the operation that finds the correct character in the correct row.
4. **Feed-forward network.** A position-wise feed-forward network with a residual connection completes the layer.

The explicit cross-attention to the visual tokens is the main structural difference from the published CPPD decoder for two-row plates. Because the query of a slot contains the row embedding, it can learn to attend only to the region of its row. Figure 25 illustrates the intended behaviour on a Chinese yellow two-row plate. The queries of slots 1 and 2 attend to the upper row. The queries of slots 3 to 7 attend to the lower row, from left to right. The figure is a schematic of the intended behaviour, not the output of a trained model.

![Figure 25](figs/fig_cn_two_row_attention.png)

*Figure 25. Schematic attention of the slot queries on a Chinese yellow two-row plate. The row and slot-type embeddings tell each query which row to read; cross-attention then finds the character. The figure illustrates the intended behaviour, not model output.*

### 3.3.5. Type-masked classifier and soft format constraints

After the two layers, a linear classifier predicts a distribution over the vocabulary for each slot. The slot type is applied as a soft mask on the logits:

$$P_{\text{ref}}(c \mid j,k,x)=\mathrm{softmax}_{c}\big(z_{j,c}-\lambda\,\mathbb{1}[c \notin \tau_j]\big), \qquad (8)$$

where $z_{j,c}$ is the logit of character $c$ for slot $j$, $\mathbb{1}[\cdot]$ is the indicator function, and $\lambda \ge 0$ is the penalty for characters outside the slot type. With $\lambda = 0$, the classifier ignores the format. With a very large $\lambda$, the classifier becomes a hard format filter. FADR uses a finite penalty, so a character outside the slot type can still win when the visual evidence for it is very strong. This keeps the refiner robust to template errors and to special plates that deviate from the template. For the open format, all slots have the type "any", and no penalty is applied.

### 3.3.6. Refinement under the open format

When the best hypothesis of the draft follows the open format, the refiner has no template. In this case, the number of slots is taken from the open-format draft, every slot receives the type "any", and the row index comes from the layout decision of the layout–format head. The refiner then works as a context-aware parallel re-reader without format constraints. Its main contribution in this case is visual context, especially for two-row plates of unknown types. If the draft length itself is uncertain, for example because two characters have merged in a blurred image, the refiner can also run with the slot count suggested by the ordering branch inherited from CPPD. The joint score of Chapter 4 then decides between the candidates.

### 3.3.7. Training the refiner

The refiner is trained together with the rest of the network (Chapter 4). Each training plate yields one or more refinement examples. The format hypothesis is the true template of the plate, or the open format when the plate matches no template. The draft comes from two sources. In half of the examples, the draft is the ground-truth string with a random subset of slots masked; the share of masked slots is drawn uniformly between zero and one, as in conditional masked language modeling. In the other half, after a warm-up period, the draft is the actual output of the CTC branch for the same image, with the masking rule of Equation 7. The first source teaches the refiner to fill masks from context. The second source teaches it to correct the real errors of the draft branch.

Two additional measures prevent the refiner from depending too much on the format. With a small probability, the slot types of a training example are replaced by the type "any" (format dropout). With another small probability, the true template is replaced by a wrong but plausible template, and the target remains the true string. The refiner therefore learns that the format is evidence, not a certainty. The loss of the refiner is a cross-entropy over the slots:

$$\mathcal{L}_{\text{ref}}=-\sum_{j \in M}\log P_{\text{ref}}(y_j \mid j,k,x)-\eta\sum_{j \notin M}\log P_{\text{ref}}(y_j \mid j,k,x), \qquad (9)$$

where $M$ is the set of masked slots, $y_j$ is the true character of slot $j$, and $\eta$ is a small weight for the unmasked slots, for example 0.1. The counting loss of CPPD is kept as an auxiliary loss, because it shapes the count-aware features that the refiner uses. Its effect is measured in the ablation study of Chapter 5.

### 3.3.8. Reading order of two-row plates in the refiner

The refiner reads two-row plates in the correct order for two reasons. First, the order of the slots is defined by the template, not learned from data: slot 1 is always the first upper-row character, and slot 3 of a Chinese two-row template is always the first lower-row character. Second, the row embedding of each slot query and the two-dimensional positional encoding of the visual tokens let the query find the correct region. The refiner therefore never has to discover the reading convention of a known template.

There is one case that no recognizer can resolve from the image alone. If two plate types look identical but use different reading orders, the image does not determine the correct order. In this case, the correct template must come from other evidence, such as the colour, the special characters or the deployment prior. The layout–format head supplies this evidence when it exists. When it does not exist, the joint score keeps both hypotheses, and the plate is marked as uncertain. This behaviour is better than a confident guess, because it makes the ambiguity visible to the operator.

### 3.3.9. Worked example

The worked example of Section 2.3.7 ended with a draft that the format could not correct: the Chinese yellow two-row plate 沪A / 12345 was read as 沪A1Z345, and the confidence of Z was low. The refiner receives the template of the yellow two-row rear plate and this draft. It builds seven slot queries. The queries of slots 1 and 2 contain the row embedding of the upper row, the slot types P and L, and the characters 沪 and A. The queries of slots 3, 5, 6 and 7 contain the row embedding of the lower row, the slot type A, and the characters 1, 3, 4 and 5. The query of slot 4 contains the row embedding of the lower row, the slot type A and the mask embedding.

In the first refiner layer, slot self-attention lets the masked query see that its neighbours in the lower row are digits. This is weak but useful evidence: most Chinese serials contain few letters. The cross-attention to the count-aware character features shows that the plate contains one copy of each of the digits 1 to 5 and no Z with high probability. The cross-attention to the visual tokens, guided by the row embedding and by the position between slots 3 and 5, focuses on the second character of the lower row. Its strokes are blurred, but the lower part of the character shows a horizontal base, which fits 2 better than Z. The type-masked classifier allows both 2 and Z, because both belong to the slot type A, so the decision comes from the evidence, not from the format. The refiner predicts 2 with high probability, and the refined candidate is 沪A12345. The joint score of Chapter 4 compares this candidate with the draft and selects it, because the refiner term strongly prefers 2 while the CTC term prefers Z only slightly.

The example shows the division of work between the two branches. The draft branch reads the plate in the correct row order and applies the format where the slot types differ. The refiner uses the context of the confident characters and the two-dimensional visual evidence where the format cannot decide. Neither branch alone resolves this plate with high confidence.

### 3.3.10. Cost of the refiner

The refiner is small. A plate has at most about nine slots, and the refiner has two layers. Slot self-attention costs almost nothing. The cross-attention to the visual tokens is the largest cost. In the $48 \times 96$ bucket, the feature map has $6 \times 24 = 144$ tokens, so each layer computes attention between at most nine queries and 144 keys. The count-aware character features add one attention between the vocabulary embeddings and the visual tokens. With a feature dimension of a few hundred, the refiner needs a small fraction of the operations of the encoder. When the two most probable templates are refined, they are processed as one batch. The refiner also reuses the encoder features, so no second pass through the encoder is needed. Its cost is therefore close to the cost of the published CPPD decoder, and it is paid only for the plates that reach the refinement stage (Chapter 4).

### 3.3.11. Relation to other designs

The refiner combines ideas from several earlier works, and it differs from each of them. Compared with CPPD [51], it keeps the parallel pass and the count-aware features, but it replaces the content-free position queries with format-conditioned slot queries, and it reads a draft instead of starting from scratch. Compared with Mask CTC [14], it applies the mask-and-predict idea to license plates and adds the format and the two-dimensional visual context, which a speech recognizer does not have. Compared with the multi-line plate recognizer of Chen and colleagues [57], which predicts a global plate type and then reads the characters in parallel, it uses the type as an explicit template with slot types and rows, it keeps the type soft through the open format, and it works together with a CTC branch. Recent work on multi-type plates, such as the global and contrastive learning approach of Liu and colleagues [56], shows that plate types remain an active research topic. The refiner is complementary to such representation-learning methods, because it uses the type knowledge at decoding time.

### 3.3.12. Summary of Chapter 3

This chapter reviewed autoregressive and parallel decoders and described CPPD, which builds context for parallel decoding through character counting and character ordering. It then proposed the format-conditioned parallel refiner. The refiner builds one query per slot of a format template. Each query carries the slot position, the row, the slot type and the draft character, or a mask when the draft is uncertain. Two layers of slot self-attention, count-aware cross-attention and two-dimensional visual cross-attention combine linguistic and visual context. A type-masked classifier applies the format as a soft constraint. The refiner is trained with random masks, real drafts, format dropout and wrong-template examples, so that it treats the format as evidence and not as a certainty. Chapter 4 combines the refiner with the draft branch of Chapter 2.


# Chapter 4. Combining CTC and Parallel Decoding: The Format-Aware Draft-and-Refine Framework

Chapters 2 and 3 developed two branches: a CTC draft branch that reads one-row and two-row plates efficiently and uses formats during decoding, and a parallel refiner that re-reads uncertain characters with format and visual context. This chapter combines them into one recognizer. Section 4.1 describes the architecture and the joint training. Section 4.2 describes the confidence-gated inference and the joint score that selects the final string. Section 4.3 discusses degraded plates: synthetic training data, training-only restoration guidance and multi-frame fusion. Section 4.4 discusses the computational cost, deployment and the safeguards against overcorrection.

## 4.1. Architecture and Joint Training

### 4.1.1. Overall architecture

FADR consists of one shared encoder and three heads (Figure 2). The encoder is a hierarchical vision-transformer encoder in the style of SVTRv2-T, with multi-size resizing at its input (Section 2.2). Its output is the feature map $F$ of size $H/8 \times W/4 \times D$. The three heads read this feature map:

1. The **layout–format head** (LFH) pools the feature map and predicts a probability for each known format template and for the two open formats (Section 2.3.2).
2. The **CTC draft branch** applies the row-selective FRM, the CTC classifier and the format-constrained decoding (Sections 2.3.3 to 2.3.7). It produces a draft string, its template and a calibrated confidence for each character.
3. The **format-conditioned parallel refiner** (FCPR) builds slot queries from a template and a draft, attends to the feature map, and predicts the uncertain characters again (Section 3.3).

The heads share the encoder, so the refiner needs no second pass through the encoder. The heads also share information. The LFH supplies format probabilities to the draft decoding and to the joint score. The draft supplies characters and confidences to the refiner. The refiner supplies new characters and probabilities to the joint score. The final output is the plate string, the template under which it was read, a confidence value and, when the confidence is low, a review flag.

### 4.1.2. Training objective

All parts of FADR are trained together with one objective:

$$\mathcal{L}=\mathcal{L}_{\text{ctc}}+\lambda_{f}\,\mathcal{L}_{\text{fmt}}+\lambda_{r}\,\mathcal{L}_{\text{ref}}+\lambda_{cc}\,\mathcal{L}_{\text{cc}}+\lambda_{s}\,\mathcal{L}_{\text{sgm}}, \qquad (10)$$

where $\mathcal{L}_{\text{ctc}}$ is the row-factorized CTC loss of Equation 5, $\mathcal{L}_{\text{fmt}}$ is the cross-entropy of the LFH, $\mathcal{L}_{\text{ref}}$ is the refiner loss of Equation 9, $\mathcal{L}_{\text{cc}}$ is the character counting loss inherited from CPPD, and $\mathcal{L}_{\text{sgm}}$ is the semantic guidance loss of SVTRv2. The weights $\lambda$ balance the terms. The CTC loss is the main term, because the draft branch alone resolves most plates. When paired high-resolution and low-resolution images are available, a distillation term can be added (Section 4.3.3).

The joint objective has a useful side effect on the CTC branch. The gradients of the refiner and of the semantic guidance module flow into the shared encoder. They act as attention-based guidance for the encoder features, which is the mechanism that GTC uses to improve CTC recognizers [42]. The draft branch therefore benefits from the refiner during training, even for plates for which the refiner is never used at inference. The hybrid CTC/attention architecture in speech recognition showed a similar benefit of joint training [13]. An optional mutual-learning term, in which the CTC slot posteriors and the refiner posteriors are encouraged to agree, is also possible [67]; it is not used in the default configuration, so that the two branches keep partly independent errors.

### 4.1.3. Training schedule

The training proceeds in four phases. In the first phase, the encoder, the FRM with a single selecting token, the CTC classifier and the semantic guidance module are trained on one-row plates, as in SVTRv2. This phase gives a strong encoder for the most common case. In the second phase, the LFH and the row-selective tokens are added, and the model is trained on one-row and two-row plates with the row-factorized loss. The layout during training comes from the labels. In the third phase, the refiner is added and trained with ground-truth drafts and random masks, while the rest of the network continues to train. In the fourth phase, the drafts of the refiner come from the CTC branch itself, so that the refiner learns to correct the real errors of the draft. After the training, the temperatures of the CTC logits and of the LFH logits are calibrated on a validation set [69], and the thresholds of the cascade are selected (Section 4.2.6).

Figure 26 summarizes the four phases and the parts of the model that become active in each of them.

![Figure 26](figs/fig27_training_schedule.png)

*Figure 26. The four training phases of FADR. Each phase adds components to a working model. After training, the logits are calibrated and the thresholds of the cascade are chosen on a validation set.*

This schedule has two practical advantages. First, every phase starts from a working model, so problems are easy to locate. Second, the first phase is exactly the training of a CTC recognizer, so an existing SVTRv2 model can be used as the starting point.

### 4.1.4. Specification of the format templates

The format knowledge of FADR is stored outside the network, in a small template file. This separation has a practical purpose: a domain expert can read and correct the templates without knowledge of the network. The listing below shows a simplified example for three Chinese plate types and one open format. The character classes are defined once and then used in the templates. Each template lists its rows, the slot type of every slot, optional rules that involve several slots, and a site prior.

```yaml
# Simplified template file (illustrative, not an official specification)
classes:
  P: [京, 津, 沪, 渝, 冀, 豫, 云, 辽, 黑, 湘, 皖, 鲁, 新, 苏, 浙, 赣,
      鄂, 桂, 甘, 晋, 蒙, 陕, 吉, 闽, 贵, 粤, 青, 藏, 川, 宁, 琼]
  L: [A-H, J-N, P-Z]          # letters without I and O
  N: [0-9]                    # digits
  A: [L, N]                   # letter or digit
  E: [D, F]                   # energy code of new-energy plates
templates:
  cn_small_car:               # blue plate, one row, 7 characters
    rows: [[P, L, A, A, A, A, A]]
    rules: [serial_max_letters: 2]
    prior: 0.80
  cn_small_new_energy:        # green plate, one row, 8 characters
    rows: [[P, L, E, A, N, N, N, N]]
    prior: 0.12
  cn_large_rear:              # yellow plate, two rows, 2 + 5 characters
    rows: [[P, L], [A, A, A, A, A]]
    rules: [serial_max_letters: 2]
    prior: 0.05
  open_one_row:               # any string, penalised
    rows: [[any]]
    max_length: 10
    prior: 0.01
```

A small compiler reads this file and builds the automata of Section 2.3.5. A rule such as "serial_max_letters: 2" adds a counter to the states of the automaton. The priors are site parameters; they can be estimated from the traffic of the site or left uniform. The same file also defines the label set of the LFH, because each template is one class of the head. Adding or changing a template therefore requires an update of the head (Section 4.4.4), but not of the CTC branch or of the refiner.

### 4.1.5. Why the branches share one encoder

A shared encoder has three advantages. First, it saves computation: the refiner reuses the features that the draft branch has already computed, so refinement costs only the decoder layers. Second, it saves memory and simplifies deployment: one model file contains all branches. Third, the joint training gives the encoder richer supervision, as discussed above. The disadvantage is that the errors of the two branches are correlated, because both read the same features. A plate whose features have lost a stroke is difficult for both branches. This is expected and acceptable. The purpose of the refiner is not to provide an independent second opinion, but to apply context that the CTC head cannot apply: the format, the confident neighbours and the two-dimensional position of the character. Independent evidence comes from other sources, such as additional video frames (Section 4.3.4).

## 4.2. Confidence-Gated Inference and Joint Scoring

At inference, FADR processes each plate in up to three stages (Figure 27). Every plate passes through stage A. A plate continues to stage B only if it fails gate A, and to stage C only if it also fails gate B. Most clear plates therefore leave the system after the cheapest stage.

![Figure 27](figs/fig19_cascade.png)

*Figure 27. Confidence-gated draft-and-refine inference. Stage A always runs. A plate continues to the constrained beam search only if the greedy draft fails gate A, and to refinement only if it also fails gate B. The joint score selects the final string, and a review flag marks plates with low confidence.*

### 4.2.1. Stage A: greedy draft and gate A

Stage A runs the encoder, the LFH, the row-selective FRM and the CTC classifier. It decodes the CTC output greedily for the layout that the LFH predicts. Greedy decoding is the cheapest possible decoding: it takes the most probable symbol at each time step and collapses the result. Gate A accepts the greedy draft if three conditions hold:

1. The LFH probability of the most probable template is above a threshold $\tau_f$.
2. The greedy draft is a valid string of that template.
3. The calibrated confidence of every character of the draft is above a threshold $\tau_a$.

If all three conditions hold, the draft is the output. The conditions are deliberately strict. The first condition ensures that the plate type is clear. The second ensures that the visual reading and the format agree without any correction. The third ensures that no single character is doubtful. A clear blue Chinese plate typically satisfies all three conditions.

### 4.2.2. Stage B: format-constrained beam search and gate B

Stage B runs the format-constrained CTC beam search of Section 2.3.6 for the most probable templates and for the open format. When the LFH is uncertain about the number of rows, it decodes both layouts. The result is an n-best list of slot-aligned hypotheses with their scores (Equation 6). Gate B accepts the best hypothesis if its score exceeds the score of the second-best hypothesis by a margin $\tau_b$, and if its characters are confident according to a second, lower threshold. Stage B resolves typical cases in which the visual reading is almost right but violates the format, such as a B/8 or D/0 confusion in a slot whose type allows only one of the two characters. It also resolves cases in which the layout was uncertain and the format of one layout explains the evidence much better than the other.

### 4.2.3. Stage C: refinement of the top formats

Stage C runs the refiner for the two best templates of stage B; when the best hypothesis of stage B follows the open format, the open format is one of the two. For each template, the best hypothesis of that template is the draft. Its uncertain characters are masked according to Equation 7, and the refiner predicts them again. The two refinements are computed as one batch. Stage C therefore produces up to two new candidates, which join the n-best list of stage B. The joint score of Section 4.2.4 selects the final string from all candidates.

Stage C is designed for the difficult cases: two-row plates with low contrast, plates in which several characters are uncertain, plates in which two templates compete, and plates with an unseen format. The refiner adds visual context through two-dimensional cross-attention and linguistic context through the confident characters and the slot types.

### 4.2.4. Joint scoring of candidates

Each candidate is a string $y$ with a template $k$. The joint score combines three kinds of evidence:

$$S(y,k)=\alpha\,\bar{\ell}_{\text{ctc}}(y \mid x)+(1-\alpha)\,\bar{\ell}_{\text{ref}}(y \mid x,k)+\beta\,\log p(k \mid x)+\log \pi_k. \qquad (11)$$

The first term is the CTC log-probability of the string (Equation 1), computed with the CTC forward algorithm on the row sequences of the template and divided by the string length. The second term is the mean log-probability that the refiner assigns to the characters of the masked slots (Equation 8); it is zero when no slot is masked. The third term is the format evidence of the LFH, and the fourth term is the prior of the template in the deployment, with a penalty factor for the open format. The weights $\alpha$ and $\beta$ are tuned on a validation set.

The joint score follows the logic of joint CTC/attention decoding in speech recognition [13], adapted to plates. The CTC term rewards strings that fit the frame-level evidence along the reading order. The refiner term rewards strings whose uncertain characters fit the visual and linguistic context. The format terms reward strings that fit a plausible template. No term can force the result alone. A string outside all known templates can still win through the open format when both recognition terms support it strongly.

### 4.2.5. Output, confidence and review flag

FADR returns four items for each plate: the final string, the template under which it was read, a plate-level confidence, and the raw greedy string of stage A. The plate-level confidence is the softmax of the joint scores over the candidate list, so it reflects the competition between candidates. When the confidence is below a threshold $\tau_{\text{rej}}$, FADR sets a review flag. In a traffic application, a flagged plate can be sent to a human operator, matched against a database with a tolerance, or combined with more video frames. The raw greedy string is kept because it shows the visual reading before any format knowledge was applied. Reporting both strings follows the recommendation of Chapter 1 to separate raw and format-assisted recognition.

### 4.2.6. Choosing the thresholds

The thresholds $\tau_f$, $\tau_a$, $\tau_b$, the masking threshold $\gamma$ and the review threshold $\tau_{\text{rej}}$ control the trade-off between accuracy and cost. They are selected on a validation set in three steps. First, $\tau_a$ is chosen so that the plates accepted at gate A have a very high recognition rate, for example at least 99.5 percent. Second, $\tau_b$ is chosen in the same way for gate B. Third, $\gamma$ and the weights of the joint score are tuned on the plates that reach stage C. The share of plates that reach each stage then follows from the thresholds. A deployment with a strict latency budget can lower the thresholds so that fewer plates reach stage C. A deployment for law enforcement can raise them so that more plates are refined and flagged. Chapter 5 reports the projected relation between the threshold of gate A, the accuracy and the share of refined plates.

### 4.2.7. Worked examples on Chinese plates

Figure 28 shows three illustrative examples, one for each exit of the cascade. The first plate is a clear blue small-car plate. Its greedy draft is a valid small-car string, and every character is confident, so it leaves at gate A. The second plate is a blurred small new-energy plate. Its greedy draft reads the issuing-authority letter B as the digit 8. This draft is invalid for every civilian template, because the second slot must contain a letter, so gate A rejects it. The constrained beam search keeps the letter B, which has almost the same CTC probability, and the resulting string wins by a clear margin, so the plate leaves at gate B. The third plate is a yellow two-row plate with low contrast. Its draft is valid, but one lower-row character has a low confidence. The refiner masks this character and predicts it again from the visual evidence of the lower row and from its neighbours. The corrected string is the output.

![Figure 28](figs/fig_cn_cascade_examples.png)

*Figure 28. Illustrative examples of the three exits of the cascade on Chinese plates. A clear plate leaves at gate A; a B/8 confusion is resolved by the format at gate B; an uncertain lower-row character of a two-row plate is corrected by the refiner.*

### 4.2.8. Inference algorithm

Algorithm 2 summarizes the complete inference for one plate crop. Steps 1 to 6 form stage A, steps 7 to 10 form stage B, and steps 11 to 16 form stage C. Every plate returns the same five items, independent of the stage at which it leaves the cascade.

```text
Algorithm 2. FADR inference for one plate crop

Input : plate crop x; thresholds tau_f, tau_a, tau_b, gamma, tau_rej
Output: string, template, confidence, review flag, raw greedy string

1  F <- encoder(MSR(x))                              # shared features
2  p(k|x) <- LFH(F); k1 <- most probable template; r <- rows of k1
3  S <- RS-FRM(F, r); P <- CTC classifier(S)
4  g <- greedy CTC decoding of P                      # raw greedy string
5  if p(k1|x) >= tau_f and g is valid for k1 and every slot confidence >= tau_a:
6      return g, k1, confidence of g, no flag, g      # exit at gate A
7  H <- Algorithm 1 for the most probable templates and the open format
8       (decode both layouts if the row decision is uncertain)
9  if score margin of H >= tau_b and the best hypothesis is confident:
10     return best hypothesis of H, its template, its confidence, no flag, g
11 for each of the two best templates k in H:
12     d <- best hypothesis of k; mask the slots with confidence < gamma
13     add FCPR(F, k, d) to the candidate list        # one batched pass
14 select the candidate with the highest joint score S(y, k)
15 compute the confidence over all candidates; set the flag if it is < tau_rej
16 return the selected string, its template, the confidence, the flag and g
```

The algorithm has two properties that are important for deployment. First, the encoder runs exactly once per plate, whatever the stage. Second, the output format is the same for every stage, so the systems that receive the result do not need to know which stage produced it.

## 4.3. Recognition of Degraded Plates

The recognition head is only one factor in the recognition of degraded plates. Training data, restoration guidance and additional observations often matter more. This section describes how FADR uses these three factors. They are independent of the choice between CTC and decoding, so they are evaluated separately in Chapter 5.

### 4.3.1. Synthetic data with format-faithful and format-open strings

Training a multinational recognizer is not only a matter of collecting many images. The training set must cover different scripts, current and historical formats, vehicle types, fonts, aspect ratios, two-row layouts and imaging conditions. If most images come from passenger cars in one country, more such images teach little about motorcycle plates or new scripts. Annotation is expensive, and images with registration numbers can be restricted for privacy reasons. Some plate types will therefore have very little real data.

Synthetic data is a practical answer. A renderer places artificial strings on plausible plate backgrounds with chosen fonts, spacing, borders, colours and layouts, and it simulates acquisition effects (Figure 29). Rendered text has a long history in text recognition [58,59]. For license plates, Laroca and colleagues evaluated 16 OCR models on 12 public datasets and studied three ways to generate synthetic plates: template-based rendering, character permutation and image-to-image translation with a generative adversarial network [52]. Their results show the value of synthetic data when real data is scarce. With only 1 percent of the real training data, STAR-Net and TRBA reached 0.0 percent without synthetic data, but 86.4 and 87.9 percent when synthetic data was added [52]. These values belong to their protocol and are not expected accuracies for other formats, but they show that coverage can matter more than the choice of the recognition head.

![Figure 29](figs/fig20_synthetic_pipeline.png)

*Figure 29. A modular synthesis pipeline. Templates supply labels and layouts, rendering supplies appearance, degradation supplies acquisition effects, and a validation step protects the character identity.*

For FADR, the synthetic data has a special role: it controls how the model learns the formats. Two kinds of strings are rendered (Figure 30). **Format-faithful strings** follow the templates of the deployment. They teach the visual appearance of every plate type and every slot type, including rare types such as trailer and police plates. **Format-open strings** use valid characters in unusual orders and lengths. They teach the visual recognizer to read what it sees, and they teach the LFH and the refiner that strings outside the known templates exist. Without format-open data, the model would learn the formats implicitly from the visual data, and the soft constraints of the decoder would lose their purpose. The synthetic two-row plates are rendered row by row, so their row labels are exact, which is ideal for the row-factorized CTC loss.

![Figure 30](figs/fig_cn_synthetic_samples.png)

*Figure 30. Synthetic Chinese plates rendered from templates. Format-faithful strings follow the official templates; format-open strings use valid characters in unusual orders; degraded copies simulate acquisition effects.*

The synthetic data must not create shortcuts. If a particular font, background or compression setting appears only for one plate type, the model can learn the type from this artefact instead of from the plate. The same generated pool must therefore serve all plate types, and the validation set must contain real images from cameras that were not used in training. Large real collections such as the Global License Plate Dataset, which reports more than five million images from 74 countries [55], can complement synthetic data for multinational coverage, subject to their licences.

### 4.3.2. Realistic degradation instead of random filters

An image of a distant plate is not the same as a clear plate blurred with a standard Gaussian kernel. The image is shaped by the optical blur of the camera, the sensor sampling, the exposure time, the motion of the vehicle, the sensor noise, geometric resampling and video compression. A compression artefact interacts with character edges. Rolling-shutter motion can distort only some rows. A reflection can erase a local part of a character. If synthetic images use unrealistic degradations, the model learns to recognize these artificial effects and does not improve on real surveillance video (Figure 31).

![Figure 31](figs/fig21_degradations.png)

*Figure 31. Examples of blur, down- and up-sampling and contrast reduction applied to the same illustrative Chinese plate. The effects show categories of degradation; they are not samples from a real benchmark.*

Synthetic degradation should therefore follow a plausible sequence of operations: perspective projection, mild optical blur, low-resolution sampling, brightness change, sensor noise and compression, in this order. The parameters should be estimated from the target cameras when possible. At the same time, very strong degradation destroys the relation between the label and the image. When a digit becomes indistinguishable from another digit, the training target is effectively uncertain. Such samples should be excluded from normal supervised training or handled with an explicit uncertainty policy. A model should not be rewarded for inventing a character that the image no longer contains.

### 4.3.3. Training-only restoration guidance

Super-resolution reconstructs a higher-resolution image from a low-resolution observation. SRGAN, ESRGAN, Real-ESRGAN and degradation-aware networks show several ways to synthesize or restore fine details [60–64]. For license plates, a sharper image is not necessarily a more accurate image. A restoration network can create a plausible but wrong stroke and turn a 3 into an 8, or make a blurred provincial character look like another provincial character. Visual realism and exact transcription are different objectives.

The ICPR 2026 Competition on Low-Resolution License Plate Recognition illustrates this point [53]. Its dataset, LRLPR-26, contains 20,000 training tracks and 3,000 test tracks, and each training track contains five low-resolution and five high-resolution images of the same plate. The winning team reached a recognition rate of 82.13 percent with a teacher–student framework that trains super-resolution and recognition jointly, an ensemble of three models and the summation of logits over the five frames. The second team reached 81.73 percent with a CTC-based recognizer and a learned attention module that weights the frames, and the third team, with members from the SVTRv2 group, reached 80.17 percent by feeding each low-resolution frame directly to an SVTRv2-based recognizer and voting at the character level. The organizers concluded that no single design dominated, while the effective use of the five frames was common to the strongest entries [53]. Explicit super-resolution at inference is therefore one effective option, not a necessary condition.

FADR follows this evidence with a training-only guidance scheme (Figure 32). When paired high-resolution and low-resolution images are available, a teacher encoder processes the high-resolution image and the FADR encoder processes the low-resolution image. A distillation term encourages the features or the output distributions of the student to match those of the teacher [65,66]. At inference, the teacher is removed, so the deployed recognizer and its latency are unchanged. Feature matching requires care, because the feature maps of the two images can differ in size. The matching is therefore applied to the slot-level outputs of the refiner and to the pooled features of the LFH, which have the same size for both images.

![Figure 32](figs/fig22_training_only_restoration.png)

*Figure 32. Training-only restoration guidance. A high-resolution teacher guides the features of the low-resolution student during training; only the student is deployed.*

Training-only guidance has a clear information limit. If a high-resolution stroke leaves no signal in the low-resolution image, the student cannot recover it by imitating the teacher. It may learn to output the most common plausible character instead. Guidance is therefore expected to help most when the degradation is moderate, the teacher is correct, and the training pairs truly show the same plate. It also reduces a practical risk: because the deployed system returns a string and a confidence, but no enhanced image, nobody can mistake a generated image for evidence.

### 4.3.4. Slot-aligned multi-frame fusion

A moving vehicle is usually observed in several frames. Each frame differs in distance, viewing angle, lighting, motion blur, compression and occlusion. Even if every frame is imperfect, their errors can be complementary. One frame can show the upper stroke of a digit, another frame its lower loop, and a third frame can avoid a short headlight reflection. Nascimento and colleagues introduced UFPR-SR-Plates, with 10,000 tracks and 100,000 paired low-resolution and high-resolution images captured on a Brazilian road [54]. In their benchmark, the recognition rate of LCDNet rose from 1.7 percent on the original low-resolution images to 31.1 percent after super-resolution, and to 44.7 percent when the outputs for five super-resolved images were combined by majority voting at each character position [54]. These values belong to their complete pipeline, but they show that several observations can improve exact recognition substantially.

Fusing CTC outputs across frames is delicate. A CTC model produces distributions over feature time steps, not over characters. Two frames of the same plate can have different crop widths, alignments and blank positions, so the fourth time step of one frame may correspond to the second character, while the fourth time step of another frame is a blank. Averaging the probabilities at the same time index can therefore mix different characters. Fusion at the level of decoded strings avoids this problem, but it discards the uncertainty of each character.

FADR solves this problem with its format slots (Figure 33). After format-constrained decoding, every frame of a track has a template and a distribution over characters for every slot of that template. The slots give all frames the same index, independent of the crop width or the alignment. Fusion has two steps. First, the template of the track is chosen by summing the log-probabilities of the LFH over the frames. Second, for every slot $j$ of this template, the character distributions of the frames are combined with weights:

$$P_{\text{track}}(c \mid j)\propto \exp\Big(\sum_{n=1}^{N} w_n \log P_n(c \mid j)\Big), \qquad (12)$$

where $P_n(c \mid j)$ is the distribution of slot $j$ in frame $n$, taken from the refiner when the frame reached stage C and from the calibrated CTC slot posterior otherwise, and $w_n$ is a weight that reflects the quality of frame $n$, for example its plate-level confidence. The fused string takes the most probable character of every slot. Because the template is shared, the fusion handles two-row plates and plates of different widths without any additional alignment.

![Figure 33](figs/fig23_slot_fusion.png)

*Figure 33. Slot-aligned multi-frame fusion. Each frame is decoded under the format of the track, so every frame gives a distribution for the same slots. A weighted sum of log-probabilities per slot combines complementary evidence across frames.*

More frames do not always mean more information. If all frames come from a short period of strong motion blur, their errors are nearly identical, and fusion repeats the same mistake with higher confidence. If the tracker mixes two vehicles, fusion is harmful. The weights $w_n$ reduce the influence of poor frames, and the tracking must ensure that all frames show the same plate. The fusion stage should also report the agreement between frames, because a strong consensus of identical errors and a strong consensus of correct readings look the same in the final confidence.

### 4.3.5. Information limit and honest uncertainty

The three strategies of this section act on different parts of the problem. Synthetic data changes what the model sees during training. Restoration guidance transfers useful information from clean images into the deployed recognizer. Multi-frame fusion adds real observations at inference. None of them can recover information that is absent from every observation. When the evidence is insufficient, the correct behaviour is to report the uncertainty, not to output the most familiar string. FADR therefore treats the review flag as a regular output, and Chapter 5 evaluates the reliability of its confidence values together with its accuracy.

## 4.4. Computational Cost, Deployment, and Safeguards

### 4.4.1. Cost model

Let $T_A$, $T_B$ and $T_C$ be the times of stages A, B and C for one plate, and let $\rho_B$ and $\rho_C$ be the shares of plates that reach stages B and C. The expected time per plate is:

$$\mathbb{E}[T]=T_A+\rho_B\,T_B+\rho_C\,T_C. \qquad (13)$$

Stage A contains the encoder, which dominates the cost, plus the small heads and the greedy decoding. Stage B is a constrained search on short sequences. Stage C is the refiner. Because $\rho_B$ and $\rho_C$ are small for typical traffic, the expected time is close to $T_A$, that is, close to the time of a CTC-only recognizer with the same encoder. The worst-case time per plate is $T_A + T_B + T_C$. This value matters for systems with hard real-time limits, and it is still much smaller than the time of an autoregressive decoder, because the refiner runs one parallel pass. Equation 13 also shows how to trade accuracy for speed: stricter gates increase $\rho_C$ and the accuracy, and looser gates decrease both.

### 4.4.2. Deployment on edge devices

Many ALPR systems run on small computers. The design of FADR suits this setting. The encoder and the heads form one network that can be exported to a standard inference runtime. The constrained search and the joint score are small CPU routines. The automata are compiled once from the templates and loaded as data. Changing the templates for a new region, or adding a new plate type, requires a new template file and an update of the small layout–format head (Section 4.4.4), but no change to the rest of the network. The deployment prior $\pi_k$ can be set per site, for example to reflect a high share of trucks at a logistics centre or a high share of new-energy vehicles in a city centre.

Figure 34 shows a typical deployment. The camera and the plate detector belong to the existing system. The exported network runs the encoder and the light heads for every plate and the refiner only when the CPU routines request stage C. The CPU routines perform the greedy decoding, the constrained search, the gates and the joint score. The template file, the site priors and the thresholds are data files. They are loaded at start-up and can be replaced on site, for example when a new plate type is introduced or when the latency budget changes.

![Figure 34](figs/fig33_deployment.png)

*Figure 34. Deployment of FADR on an edge device. The network is exported once; the decoding, the gates and the joint score are small CPU routines; templates, site priors and thresholds are data files that can be replaced without retraining.*

The cost of each stage should be measured on the target device. Attention, grouped convolutions and small matrix products have different costs on a GPU, on a desktop CPU and on an ARM processor. Quantization of the encoder to 8-bit integers usually reduces the cost of stage A substantially. The refiner can stay in a higher precision if its accuracy is sensitive, because it runs for few plates. The thresholds of the cascade can be adjusted after deployment without retraining, which allows the operator to adapt the system to a new latency budget.

### 4.4.3. Safeguards against overcorrection

Format knowledge is powerful, and therefore dangerous when it is wrong. FADR uses six safeguards:

1. **Open-format path.** The open format is always part of the decoding graph and of the candidate list (Section 2.3.6).
2. **Finite penalties.** The refiner applies the slot type as a finite penalty, not as a hard mask (Section 3.3.5).
3. **Training against overconfidence.** Format-open synthetic data, format dropout and wrong-template examples teach the model that the format is evidence, not a certainty (Sections 3.3.7 and 4.3.1).
4. **Visual format evidence.** The LFH infers the plate type from the image, so a foreign or special plate that looks different receives a low probability for the local templates.
5. **Two outputs.** FADR reports the raw greedy string together with the final string, so that the effect of the format can always be checked.
6. **Monitoring of open-format results.** Plates that are read under the open format are logged. A cluster of such plates with the same structure indicates a new plate series or a missing template, which the operator can then add.

These safeguards follow from the analysis of Chapter 1: format rules improve familiar plates, but used as hard rules they turn unfamiliar plates into confident errors. Chapter 5 measures the effect of the safeguards on a test set with withheld formats.

Figure 35 illustrates the six safeguards with Chinese examples. The black cross-border plate in the first and fourth panels has no template in the deployment of the example. It is still read correctly, because the open format remains available and because the LFH recognizes from the colour and the layout that the plate does not belong to a local template.

![Figure 35](figs/fig28_safeguards.png)

*Figure 35. The six safeguards against overcorrection, illustrated with fictional Chinese plate strings.*

### 4.4.4. Adding a new plate type

Plate systems change. China introduced new-energy plates with eight characters, and other countries introduce new series and new layouts. FADR handles such changes in four steps. First, before any change to the system, plates of the new type are read under the open format. They remain readable, although without the benefit of format knowledge, and the monitoring of open-format results (Section 4.4.3) shows that a new structure has appeared. Second, the operator adds a template for the new type to the template file and sets a small prior. The constrained decoding can use the new template immediately, because the automata are compiled from the file. Third, synthetic plates of the new type are rendered from the template (Section 4.3.1), and the LFH is fine-tuned with them and with the first real examples, so that it can recognize the new type visually. Fourth, when enough real examples exist, the whole model is fine-tuned, and the thresholds of the cascade are checked on a validation set that includes the new type.

Figure 36 illustrates the procedure with the large new-energy plate, whose template ends with the energy code D or F. Before step 2, a plate such as 苏E12345D is read under the open format. After step 2, the template constrains the last character to D or F and the first five characters of the serial to digits, so a blurred final F can no longer be read as the digit 5 or the letter E.

![Figure 36](figs/fig29_new_type.png)

*Figure 36. Adding a new plate type, illustrated with the large new-energy plate. The new plates are readable under the open format from the start; the template adds format knowledge at once; the visual models are adapted later with synthetic and real examples.*

This procedure separates two kinds of knowledge. The template file contains exact, human-readable knowledge that can change quickly. The network contains visual knowledge that needs data. A purely learned recognizer must learn the new format from data alone, which takes time and can cause errors on the new plates in the meantime. A recognizer with hard rules rejects or corrupts the new plates until the rules are changed. FADR avoids both problems, because the open format keeps the new plates readable and the template file makes the new format usable as soon as it is written.

### 4.4.5. Privacy and transparency

ALPR systems process personal data, because a registration number identifies a vehicle and often its owner. Synthetic training data with fictional strings reduces the need for real images, although real images remain necessary for validation. The deployed system keeps the original images as evidence and does not generate enhanced images that could be mistaken for observations. Every output carries a confidence, the template under which it was read and, when needed, a review flag. These measures do not remove the obligations of data protection law, but they make the behaviour of the recognizer transparent to operators and auditors.

### 4.4.6. Summary of Chapter 4

FADR combines the draft branch and the refiner on one shared encoder with one joint training objective. At inference, a cascade with two gates sends clear plates directly to the output and refines only the uncertain ones, so the average cost stays close to the cost of CTC recognition. A joint score of CTC, refiner and format evidence selects the final string, and the open format keeps unseen plates readable. For degraded plates, format-faithful and format-open synthetic data, training-only restoration guidance and slot-aligned multi-frame fusion add information in different ways. Chapter 5 defines the experiments that test these claims and presents projected results.


# Chapter 5. Experiments (Projected Results) and Discussion

> **All numbers in the tables of this chapter, and every highlighted number in the text, are PROJECTED placeholders. They describe the expected size and direction of the effects so that the paper and the experiments can be planned. They are not measurements. The protocol, the datasets and the analysis are final; the numbers must be replaced with measured values.**

This chapter defines the evaluation of FADR and reports projected results. Section 5.1 describes the datasets, the splits, the label normalization, the metrics, the baselines and the planned implementation. Section 5.2 reports the main results on one-row and two-row plates. Section 5.3 studies the format awareness of the method, the contribution of each component and the computational cost. Section 5.4 studies degraded plates, analyzes the errors, lists the limitations and concludes the paper.

## 5.1. Datasets, Evaluation Protocol, and Implementation

### 5.1.1. Datasets

The evaluation uses four groups of data. Each group tests a different property of the recognizer.

**One-row Chinese plates.** CCPD contains a large number of images of Chinese blue one-row plates from parking scenes, with corner annotations and plate strings [22]. Its test images are divided into subsets with specific difficulties: Base (normal images), DB (dark or very bright images), FN (plates far from or near the camera), Rotate (horizontal rotation), Tilt (horizontal and vertical tilt), Weather (rain, snow and fog) and Challenge (the most difficult images). A later version of CCPD adds green new-energy plates with eight characters. These data test the recognition of the most common Chinese plate type under different conditions, and the recognition of the eight-character new-energy format.

Figure 37 illustrates the conditions of the CCPD subsets with a fictional plate. The images only show what each subset tests; they are drawings, not samples from the dataset.

![Figure 37](figs/fig30_ccpd_conditions.png)

*Figure 37. Conditions of the CCPD test subsets, illustrated with a fictional plate. The images are drawings for orientation; they are not samples from the dataset.*

**Mixed one-row and two-row plates.** CRPD contains road-surveillance images with plate-type labels for blue plates, yellow one-row plates, yellow two-row plates and white plates [46]. RodoSol-ALPR contains 20,000 toll-booth images with Brazilian and Mercosur layouts; half of the images show motorcycles with two-row plates [28]. Together, these datasets test two-row recognition in two countries, with Chinese and Latin characters, and with two different format systems.

**Unseen formats.** Two test sets measure the behaviour of the recognizer on formats that it has not seen during training. The first set uses real data: in a separate training run, all Mercosur plates of RodoSol-ALPR are removed from the training data, and the Mercosur test plates are used as the unseen-format test. The characters of Mercosur plates are known from the Brazilian plates, but their order is different. The second set uses synthetic data: Chinese plates of templates that are withheld from training, namely large new-energy plates, trailer plates and plates of vehicles from Hong Kong and Macau, are rendered with the renderer of Section 4.3.1.

**Low-resolution tracks.** UFPR-SR-Plates contains 10,000 tracks with five low-resolution and five high-resolution images each, captured on a Brazilian road [54]. It tests single-frame and multi-frame recognition of real low-resolution plates and allows training-only guidance with the high-resolution images.

**Training data.** All models are trained on the training splits of CCPD, CRPD and RodoSol-ALPR, together with synthetic Chinese and Brazilian plates. The synthetic set contains format-faithful and format-open strings in one-row and two-row layouts (Section 4.3.1). The same training data, the same vocabulary and the same augmentation are used for all methods.

### 5.1.2. Splits and leakage control

The standard splits of the datasets are used where they exist [22,28,46]. Near-duplicate images inflate recognition rates when they appear in both the training and the test split [68]. The splits are therefore checked for near-duplicates, and the validation set used for the thresholds and the calibration is separated from the training data at the level of the vehicle or the track. For UFPR-SR-Plates, all frames of a track are in the same split. The synthetic test set of withheld templates uses fonts and backgrounds that do not appear in the synthetic training set, so that the test does not reward the memorization of renderer artefacts.

Figure 38 summarizes the protocol, from the data sources to the metrics and the statistical tests.

![Figure 38](figs/fig31_protocol.png)

*Figure 38. The evaluation protocol: data sources, leakage control, test suites, metrics and statistics. All methods use the same training data, vocabulary and augmentation.*

### 5.1.3. Label normalization and vocabulary

The labels contain only the characters of the registration string. Separators, such as the dot after the second character of a Chinese one-row plate, and decorative marks are not part of the label. The two rows of a two-row plate are concatenated in reading order, upper row first, and the row split is kept as a separate annotation for the row-factorized loss. The vocabulary contains the Chinese provincial characters, the Latin letters, the digits and the special characters 挂, 学, 警, 港 and 澳. All methods use this vocabulary. The raw string of every method is evaluated without format correction, and the final string of FADR is evaluated as produced by its decoding.

### 5.1.4. Metrics

The main metric is the **recognition rate (RR)**: the percentage of plates whose complete string is correct. It is reported separately for one-row and two-row plates. The other metrics are:

- the **unseen-format RR**, measured on the two unseen-format test sets;
- the **overcorrection rate**: the percentage of unseen-format plates that the system turns into a wrong string of a known template;
- the **invalid-output rate**: the percentage of outputs on known-format test sets that match no known template;
- the **error composition**: the numbers of substitutions, deletions, insertions and row-order errors, where a row-order error is a string whose characters are correct but placed in the wrong order across the rows;
- the **latency** per plate on three devices, and the **share of plates** that leave the cascade at each gate;
- for low-resolution data, the **track-level RR**, which counts a track as correct when its fused string is correct.

The calibration of the plate-level confidence is also evaluated with reliability diagrams, because the gates and the review flag depend on it.

### 5.1.5. Baselines

Six baselines represent the main families of recognizers. CRNN [12] and LPRNet [21] are CTC recognizers with convolutional features; LPRNet is designed for license plates. SVTRv2-T [50] is the strongest CTC baseline and the starting point of the draft branch. SVTRv2-T with line split applies a row splitter to two-row plates, reads each row with SVTRv2-T and concatenates the results; it represents the common application-level solution for two-row plates. PARSeq-S [37] is a strong recognizer with a permuted autoregressive language model and iterative refinement. CPPD [51] is the parallel decoder from which the refiner is derived. Two reduced versions of the proposed method show the contribution of its parts: FADR-CTC uses only the draft branch (LFH, RS-FRM and format-constrained decoding), and FADR-Dec runs the refiner on every plate without the gates.

### 5.1.6. Implementation details

The planned implementation uses the following settings; they are part of the protocol and may be adjusted during the experiments. The encoder follows SVTRv2-T and is initialized from a model pre-trained on scene text. All models are trained with the AdamW optimizer, a one-cycle learning-rate schedule and mixed precision. The input sizes follow the four MSR buckets. Data augmentation includes perspective changes, blur, noise, brightness changes and compression, applied in the order described in Section 4.3.2. The refiner has two layers. The beam width of the constrained search is five. The thresholds of the cascade are selected on the validation set so that the plates accepted at gate A and gate B have a recognition rate of at least 99.5 percent. Latency is measured with a batch size of one, after warm-up, as the median of repeated runs, on three devices: a desktop GPU, a desktop CPU with four threads and an ARM edge board with four threads. Plate detection is not included in the latency.

### 5.1.7. Statistical testing

Differences between recognizers on clear plates are often a fraction of a percentage point. Such differences can be caused by chance, especially on small test sets. Every comparison of recognition rates in the final version of this chapter will therefore be accompanied by a statistical test. Because all methods are evaluated on the same test plates, the comparisons are paired. The McNemar test compares two recognizers on the plates where exactly one of them is correct. Confidence intervals for the recognition rate are computed with a paired bootstrap over plates, or over tracks for the multi-frame experiments. Each training configuration is repeated with three random seeds, and the mean and the standard deviation are reported. A difference is called significant only when the test rejects equality at the 5 percent level and the direction is the same for all seeds. These rules prevent the most common error in recognition benchmarks: the interpretation of a small, random difference as a property of a method.

## 5.2. Main Results on One-Row and Two-Row Plates

### 5.2.1. One-row Chinese plates

Table 1 reports the projected recognition rates on the CCPD test subsets and on green new-energy plates. On clear one-row plates (the Base subset), all modern recognizers are expected to be close to saturation, and the differences between them are small. This is expected: a clear one-row plate is the case for which CTC was designed, and the format adds little when the visual evidence is already unambiguous. The differences grow on the difficult subsets. On the Challenge subset, FADR is projected to reach <mark>94.6%</mark>, compared with <mark>92.4%</mark> for SVTRv2-T, a gain of <mark>2.2 percentage points</mark>. On average over the eight test sets, FADR is projected to reach <mark>98.2%</mark>, compared with <mark>97.4%</mark> for SVTRv2-T, <mark>97.4%</mark> for PARSeq-S and <mark>97.3%</mark> for CPPD.

*Table 1. Exact-match recognition rate (%) on single-row Chinese plates (CCPD test subsets and green new-energy plates). Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Method | Base | DB | FN | Rotate | Tilt | Weather | Challenge | Green (NEV) | Avg. |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| CRNN [12] | 98.4 | 93.6 | 94.7 | 95.8 | 94.3 | 97.5 | 86.9 | 96.2 | 94.7 |
| LPRNet [21] | 98.7 | 94.2 | 95.1 | 96.4 | 94.9 | 97.8 | 87.8 | 96.8 | 95.2 |
| SVTRv2-T [50] | 99.4 | 96.6 | 97.3 | 98.4 | 97.5 | 98.9 | 92.4 | 98.3 | 97.4 |
| PARSeq-S [37] | 99.4 | 96.8 | 97.4 | 98.3 | 97.3 | 99.0 | 92.7 | 98.4 | 97.4 |
| CPPD [51] | 99.4 | 96.5 | 97.2 | 98.3 | 97.4 | 98.8 | 92.3 | 98.2 | 97.3 |
| FADR-CTC (ours) | 99.5 | 97.2 | 97.8 | 98.7 | 97.9 | 99.1 | 93.6 | 98.8 | 97.8 |
| FADR (ours) | 99.6 | 97.7 | 98.2 | 98.9 | 98.3 | 99.3 | 94.6 | 99.1 | 98.2 |

The projected gains on difficult one-row plates come from two sources. First, the format-constrained decoding resolves confusions between letters and digits in slots whose type allows only one of the two classes, for example in the second slot of every civilian plate. Second, the refiner re-reads characters that the draft has read with low confidence. The draft branch alone (FADR-CTC) is projected to reach <mark>97.8%</mark>, which shows that most of the gain on one-row plates comes from the format knowledge in the CTC decoding, and that the refiner adds a further, smaller gain. For new-energy plates, the format is especially informative, because the third character must be D or F. FADR is projected to reach <mark>99.1%</mark> on these plates, compared with <mark>98.3%</mark> for SVTRv2-T.

### 5.2.2. Two-row and mixed-layout plates

Table 2 reports the projected results on CRPD and RodoSol-ALPR, separated by layout. The two-row plates are the main target of this paper. Recognizers that collapse the feature map along its height, such as CRNN, are expected to fail on many two-row plates, because they mix the two rows: CRNN is projected to reach only <mark>71.4%</mark> on Chinese yellow two-row plates. SVTRv2-T with the published FRM is projected to perform better, but its single selecting token per column is expected to limit its two-row accuracy to an average of <mark>88.7%</mark>.

*Table 2. Exact-match recognition rate (%) on mixed one-row (1R) and two-row (2R) plates. BR = Brazilian layout, MS = Mercosur layout. Line split is applied only to two-row plates. Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Method | CRPD blue (1R) | CRPD yellow (1R) | CRPD yellow (2R) | RodoSol car BR (1R) | RodoSol car MS (1R) | RodoSol moto BR (2R) | RodoSol moto MS (2R) | Avg. 1R | Avg. 2R |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| CRNN [12] | 95.1 | 93.0 | 71.4 | 97.2 | 96.8 | 78.5 | 76.9 | 95.5 | 75.6 |
| LPRNet [21] | 95.6 | 93.6 | 74.2 | 97.5 | 97.0 | 80.3 | 79.1 | 95.9 | 77.9 |
| SVTRv2-T [50] | 97.6 | 96.4 | 86.1 | 98.8 | 98.5 | 90.4 | 89.6 | 97.8 | 88.7 |
| SVTRv2-T + line split [50] | 97.6 | 96.4 | 93.0 | 98.8 | 98.5 | 95.2 | 94.7 | 97.8 | 94.3 |
| PARSeq-S [37] | 97.7 | 96.6 | 93.4 | 98.9 | 98.6 | 95.6 | 95.0 | 98.0 | 94.7 |
| CPPD [51] | 97.5 | 96.3 | 93.1 | 98.7 | 98.4 | 95.3 | 94.8 | 97.7 | 94.4 |
| FADR-CTC (ours) | 98.0 | 97.0 | 95.4 | 99.1 | 98.9 | 96.9 | 96.4 | 98.3 | 96.2 |
| FADR (ours) | 98.4 | 97.5 | 96.6 | 99.3 | 99.1 | 97.8 | 97.3 | 98.6 | 97.2 |

The application-level line split is projected to raise SVTRv2-T to <mark>94.3%</mark> on two-row plates, at the cost of a row splitter and a second recognizer call. CPPD and PARSeq-S, which attend to the two-dimensional feature map, are projected to reach <mark>94.4%</mark> and <mark>94.7%</mark>. The draft branch of FADR alone is projected to reach <mark>96.2%</mark>, an improvement of <mark>7.5 percentage points</mark> over SVTRv2-T with one recognizer call and a fully parallel CTC head. This result would confirm the main claim of Chapter 2: the reading order of a two-row plate can be built into the CTC branch through row-selective tokens. The full FADR is projected to reach <mark>97.2%</mark> on two-row plates, which is <mark>2.9 percentage points</mark> above the line-split baseline and <mark>2.8 percentage points</mark> above CPPD. On one-row plates of the same datasets, the projected average of FADR is <mark>98.6%</mark>, so the improvement for two-row plates does not come at the expense of one-row plates.

The projected results also show a difference between the two countries. Chinese two-row plates have a provincial character in the upper row, which is visually complex and must be separated from the issuing-authority letter. Brazilian and Mercosur motorcycle plates have only Latin characters, but their upper and lower rows have similar lengths, which makes the row transition more ambiguous for a single selecting token. FADR is expected to improve both cases, because the row tokens and the row-factorized loss do not depend on the script.

### 5.2.3. Results by Chinese plate type

Table 3 groups the projected results by Chinese plate type. The table repeats some values of Tables 1 and 2, but it shows two additional facts. First, the projected gain of FADR is largest for the yellow two-row plates, from <mark>86.1%</mark> for SVTRv2-T to <mark>96.6%</mark>. Second, the projected gain is also large for white police plates, from <mark>94.8%</mark> to <mark>96.9%</mark>. Police plates are rare in the training data, and their last character 警 is red, which differs from all other characters. The template of the police plate tells the decoder that the last slot holds a special character, so a rare plate type benefits from the format knowledge even when the visual model has seen few examples.

*Table 3. Recognition rate (%) by Chinese plate type, and share of plates that FADR sends to the refiner (%). Rows that overlap Tables 1 and 2 repeat their values. Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Plate type (test data) | SVTRv2-T | CPPD | FADR | Refined by FADR |
|:--|--:|--:|--:|--:|
| Blue small-car plate, 1 row (CRPD) | 97.6 | 97.5 | 98.4 | 5.9 |
| Green small new-energy plate, 1 row (CCPD) | 98.3 | 98.2 | 99.1 | 4.8 |
| Yellow plate, 1 row (CRPD) | 96.4 | 96.3 | 97.5 | 9.1 |
| Yellow plate, 2 rows (CRPD) | 86.1 | 93.1 | 96.6 | 14.6 |
| White police plate, 1 row (CRPD) | 94.8 | 95.0 | 96.9 | 12.3 |

The last column of Table 3 shows the projected share of plates that the cascade sends to the refiner. It follows the difficulty of the plate type: about <mark>14.6%</mark> of the yellow two-row plates are projected to need refinement, but only <mark>4.8%</mark> of the green new-energy plates, whose eight-character format is very distinctive. A deployment with many trucks therefore spends more computation per plate than a deployment at a car park, and Equation 13 allows this to be estimated in advance from the mixture of plate types at the site.

### 5.2.4. Qualitative examples

Figure 39 shows projected qualitative examples on Chinese plates. They are illustrations of the expected behaviour, and they must be replaced with real predictions. The first example shows a B/8 confusion in the serial of a blurred blue plate. The format cannot resolve it, because the serial slot allows both letters and digits, but the refiner can resolve it from the visual evidence. The second example shows the same confusion in the second slot of a new-energy plate, where the format alone resolves it. The third and fourth examples show two-row plates. A single horizontal reading mixes the rows, and a degraded lower row causes errors that the refiner corrects. The fifth example shows a plate whose format was withheld from training. The open-format path keeps the correct reading. The sixth example shows a failure. The evidence for two characters is lost, and FADR outputs a wrong string, but its low confidence sets the review flag.

![Figure 39](figs/fig_projected_qualitative.png)

*Figure 39. Qualitative examples on Chinese plates (PROJECTED). The outputs are placeholders for planning and must be replaced with real model predictions. A tick marks a correct string and a cross a wrong one. The last row shows a failure that the review flag marks.*

## 5.3. Format Awareness, Ablation Study, and Efficiency

### 5.3.1. Format awareness and unseen formats

Table 4 isolates the effect of format knowledge. All rows use the same draft branch, trained without Mercosur plates and without the withheld Chinese templates. Only the decoding changes. Greedy decoding without format knowledge is the reference. A hard use of the format, either as a regular-expression filter that replaces invalid outputs with the nearest valid string or as a constrained search without the open path, is projected to increase the recognition rate on known formats from <mark>97.6%</mark> to <mark>98.4%</mark>. However, it is projected to reduce the recognition rate on unseen formats from <mark>91.2%</mark> to <mark>59.8%</mark>, and to turn <mark>34.8%</mark> of the unseen-format plates into wrong strings of known templates. This is the overcorrection that Chapter 1 warned about: a Mercosur plate is read as a Brazilian plate of the old format, because the hard constraint forces a letter slot into a digit slot.

*Table 4. Effect of format knowledge (same draft branch, different decoding). Known = known-format test sets; Unseen-real = Mercosur plates withheld from training; Unseen-syn = synthetic plates from withheld templates; Overcorr. = share of unseen-format plates forced into a wrong known-format string; Invalid = share of outputs matching no known template on the known-format sets (all in %). Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Decoding | Known | Unseen-real | Unseen-syn | Unseen avg. | Overcorr. | Invalid |
|:--|--:|--:|--:|--:|--:|--:|
| Greedy CTC, no format knowledge | 97.6 | 93.4 | 89.0 | 91.2 | 0.0 | 1.8 |
| Regex post-filter (snap to nearest valid string) | 98.0 | 61.8 | 65.2 | 63.5 | 30.4 | 0.0 |
| Hard format-constrained CTC (no open path) | 98.4 | 57.9 | 61.7 | 59.8 | 34.8 | 0.0 |
| Soft format-constrained CTC + open path | 98.3 | 92.7 | 88.5 | 90.6 | 1.2 | 0.4 |
| FADR (soft constraints + LFH + FCPR + cascade) | 98.8 | 93.6 | 89.4 | 91.5 | 0.9 | 0.3 |

The soft constrained search with the open path is projected to keep almost all the gain on known formats (<mark>98.3%</mark>) and to keep the unseen-format recognition rate close to the reference (<mark>90.6%</mark>), with an overcorrection rate of only <mark>1.2%</mark>. The full FADR is projected to improve both: <mark>98.8%</mark> on known formats and <mark>91.5%</mark> on unseen formats, with <mark>0.9%</mark> overcorrection. The LFH contributes to this result, because it recognizes from the image that a Mercosur plate, with its blue band and different layout, does not look like the known templates, and it gives the open format a higher probability. The invalid-output rate shows the other side of the trade-off: without format knowledge, <mark>1.8%</mark> of the outputs on known formats match no template and are therefore certainly wrong, while FADR reduces this share to <mark>0.3%</mark>.

### 5.3.2. Ablation study

Table 5 adds the components of FADR one by one to the SVTRv2-T baseline and removes single components from the full model. The largest projected effect on two-row plates comes from the row-selective FRM together with the LFH (configuration B), which is projected to raise the two-row average by <mark>5.4 percentage points</mark>. The row-factorized CTC loss (configuration C) is projected to add <mark>1.1 percentage points</mark>, because it makes the role of each row token unambiguous. The soft format-constrained decoding (configuration D) is projected to add <mark>1.0 percentage points</mark> on two-row plates and to improve one-row plates as well. The refiner with the cascade (configuration F) is projected to add <mark>1.0 percentage points</mark> on two-row plates.

*Table 5. Ablation study. Avg. 1R and Avg. 2R follow Table 2; Unseen is the mean of the two unseen-format sets of Table 4; CPU latency in ms per plate. Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| ID | Configuration | Avg. 1R | Avg. 2R | Unseen | CPU (ms) |
|:-:|:--|--:|--:|--:|--:|
| A | SVTRv2-T baseline (FRM, greedy CTC) | 97.8 | 88.7 | 90.7 | 6.9 |
| B | + layout–format head and RS-FRM | 97.9 | 94.1 | 90.9 | 7.0 |
| C | + row-factorized CTC loss | 98.0 | 95.2 | 91.0 | 7.0 |
| D | + soft format-constrained CTC (= FADR-CTC) | 98.3 | 96.2 | 90.6 | 7.1 |
| E | + FCPR on every plate (no gate) | 98.6 | 97.3 | 91.6 | 9.5 |
| F | + confidence-gated cascade (= FADR) | 98.6 | 97.2 | 91.5 | 7.2 |
| G | F without draft conditioning in FCPR | 98.4 | 96.7 | 91.2 | 7.2 |
| H | F with content-free CPPD queries (no format queries) | 98.4 | 96.5 | 91.4 | 7.2 |
| I | F without the character-counting loss | 98.5 | 97.0 | 91.4 | 7.2 |
| J | F without SGM | 98.5 | 97.1 | 91.3 | 7.2 |
| K | F with hard constraints (no open path) | 98.7 | 97.3 | 60.6 | 7.2 |

Running the refiner on every plate (configuration E) is projected to give almost the same accuracy as the gated cascade (configuration F), but at a CPU latency of <mark>9.5 ms</mark> instead of <mark>7.2 ms</mark>. The gates therefore keep almost all the benefit of the refiner at a small fraction of its cost. The single-component removals show which parts of the refiner matter. Without draft conditioning (G), the refiner must read every slot from scratch and loses the context of the confident characters. With content-free CPPD queries instead of format-conditioned slot queries (H), the refiner loses the row and slot-type information, which is projected to hurt two-row plates most. Removing the counting loss (I) or the semantic guidance (J) is projected to have smaller effects. Hard constraints (K) are projected to give the highest accuracy on known formats, but they reduce the unseen-format recognition rate to <mark>60.6%</mark>. This configuration is therefore not recommended, even though it would look best on a benchmark that contains only known formats.

### 5.3.3. Efficiency

Table 6 reports the projected model sizes and latencies. The encoder dominates the cost of all SVTRv2-based models. FADR adds the LFH, the row tokens and the refiner, which increases the number of parameters, but the refiner runs only for a small share of plates. The projected CPU latency of FADR is <mark>7.2 ms</mark> per plate, compared with <mark>6.9 ms</mark> for SVTRv2-T, an increase of about <mark>4.5%</mark>. Running the refiner on every plate would increase the latency by about <mark>37.7%</mark>. The line-split baseline needs about <mark>12.3 ms</mark> for a two-row plate, because it runs a splitter and two recognizer calls. PARSeq-S, with its larger encoder and its iterative decoding, is projected to need <mark>19.4 ms</mark> on the CPU and <mark>96.0 ms</mark> on the ARM board, compared with <mark>31.3 ms</mark> for FADR.

*Table 6. Model size and recognition latency per plate (batch size 1; detection excluded). FADR latencies include the measured share of plates that reach stages B and C. ‡ Two-row plates only (splitter + two recognizer calls). Parameter counts of published models must be taken from their papers or measured. Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Method | Params (M) | GFLOPs | GPU (ms) | CPU (ms) | Edge ARM (ms) |
|:--|--:|--:|--:|--:|--:|
| CRNN [12] | 8.3 | 0.9 | 1.3 | 5.5 | 24.0 |
| LPRNet [21] | 0.5 | 0.3 | 0.6 | 1.2 | 5.1 |
| SVTRv2-T [50] | 5.1 | 1.3 | 2.0 | 6.9 | 30.0 |
| SVTRv2-T + line split [50] ‡ | 5.1 | 2.1 | 3.6 | 12.3 | 52.0 |
| PARSeq-S [37] | 23.8 | 3.1 | 6.5 | 19.4 | 96.0 |
| CPPD [51] | 6.8 | 1.6 | 2.6 | 8.9 | 39.0 |
| FADR-CTC (ours) | 5.3 | 1.4 | 2.1 | 7.1 | 30.7 |
| FADR-Dec (refiner always on) | 7.0 | 1.8 | 3.2 | 9.5 | 40.9 |
| FADR (ours) | 7.0 | 1.4 | 2.2 | 7.2 | 31.3 |

Figure 40 places the methods in the plane of accuracy and CPU latency. LPRNet is the fastest model, but it is projected to be the least accurate on two-row plates. FADR is projected to be the most accurate model and to stay close to SVTRv2-T in latency. The draft branch alone (FADR-CTC) is projected to offer a strong intermediate point for devices with very strict latency limits.

![Figure 40](figs/fig_projected_tradeoff.png)

*Figure 40. Accuracy against CPU latency (PROJECTED). Accuracy is the mean recognition rate over the fifteen test sets of Tables 1 and 2. The values are placeholders for planning, not measurements.*

### 5.3.4. Behaviour of the cascade

Table 7 shows where plates are projected to leave the cascade. On the known-format test sets, about <mark>84.3%</mark> of the plates are projected to leave at gate A, and only about <mark>6.9%</mark> to reach the refiner. The share of refined plates is projected to be highest for two-row motorcycle plates (<mark>11.5%</mark>) and for plates with unseen formats (<mark>20.7%</mark>), which are exactly the plates that need context. The plates accepted at gate A are projected to have a recognition rate of at least <mark>99.5%</mark> on every known-format group. This is the condition that makes early exit safe: a plate that leaves early is almost always correct.

*Table 7. Where plates leave the FADR cascade (% of plates) and the recognition rate of plates accepted at gate A. Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Test group | Exit A | Exit B | Exit C | RR at exit A |
|:--|--:|--:|--:|--:|
| CCPD (all subsets) | 87.5 | 7.9 | 4.6 | 99.8 |
| CRPD (all types) | 82.0 | 9.6 | 8.4 | 99.6 |
| RodoSol cars | 91.2 | 5.6 | 3.2 | 99.9 |
| RodoSol motorcycles | 76.4 | 12.1 | 11.5 | 99.5 |
| Unseen-format test | 58.3 | 21.0 | 20.7 | 99.1 |

Figure 41 shows the projected effect of the confidence threshold of gate A. A low threshold accepts more drafts at gate A, which reduces the latency but also lets more wrong drafts through. A high threshold sends more plates to the later stages, which increases the accuracy until almost every correctable error is corrected, and then only increases the cost. The chosen operating point lies near the knee of the curve. The curve also shows how a deployment can trade accuracy for speed without retraining.

![Figure 41](figs/fig_projected_threshold.png)

*Figure 41. Effect of the gate A confidence threshold on the recognition rate and on the share of plates that reach the refiner (PROJECTED). The marked point is the default operating point.*

### 5.3.5. Reliability of the confidence and the review flag

An ALPR system is judged not only by how often it is right, but also by how well it knows when it is wrong. Table 8 reports the projected reliability of the plate-level confidence. The expected calibration error (ECE) measures the difference between the confidence and the observed accuracy, averaged over confidence bins. The column "errors flagged" shows the share of all wrong outputs that fall into the 2 percent of plates with the lowest confidence. If these plates are sent to a human operator, the column "RR kept" shows the recognition rate of the remaining 98 percent.

*Table 8. Reliability of the plate-level confidence on the known-format test sets. ECE = expected calibration error. Errors flagged = share of all wrong outputs that fall into the 2 % of plates with the lowest confidence. RR kept = recognition rate of the 98 % of plates that are not flagged (all in %). Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Confidence source | ECE | Errors flagged | RR (all) | RR kept |
|:--|--:|--:|--:|--:|
| SVTRv2-T (product of frame maxima) | 3.9 | 41.0 | 95.7 | 97.4 |
| CPPD (product of slot maxima) | 3.1 | 46.5 | 96.8 | 98.3 |
| FADR, joint score without calibration | 2.6 | 58.0 | 98.1 | 99.2 |
| FADR, joint score with temperature scaling | 0.8 | 67.5 | 98.1 | 99.4 |

The confidence of a CTC recognizer, computed as the product of the frame maxima, is projected to be overconfident (ECE of <mark>3.9%</mark>), and only <mark>41.0%</mark> of its errors are projected to fall into the reviewed 2 percent. The joint score of FADR is projected to be better calibrated even before temperature scaling, because it combines independent kinds of evidence and compares several candidates. After temperature scaling [69], its ECE is projected to fall to <mark>0.8%</mark>, and <mark>67.5%</mark> of its errors are projected to be flagged. The recognition rate of the plates that are not flagged is projected to reach <mark>99.4%</mark>. This result matters in practice: with a small review budget, an operator would see most of the errors of FADR, and the automatically accepted results would be correct in almost every case.

### 5.3.6. Sensitivity to the template set

The benefit of format knowledge depends on the quality of the templates. Table 9 reports projected results under four kinds of template errors, with the protocol of Table 4. When the template of small new-energy plates is missing, these plates are read under the open format, and the projected recognition rate on known formats drops only from <mark>98.8%</mark> to <mark>98.5%</mark>. When the template of the yellow two-row plate has a wrong row split, the projected drop is larger (<mark>98.2%</mark>), because the row-factorized decoding then assigns characters to the wrong row automaton. The soft constraints and the open format keep this damage limited, but the result shows that the row structure of the templates must be correct. Uniform priors are projected to change almost nothing (<mark>98.7%</mark>), and strongly wrong site priors are projected to cost a few tenths of a percentage point (<mark>98.5%</mark>) and to increase the overcorrection rate slightly (<mark>1.3%</mark>).

*Table 9. Sensitivity of FADR to errors in the template set and in the site priors. Same protocol as Table 4 (all in %). Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Template setting | Known | Unseen avg. | Overcorr. |
|:--|--:|--:|--:|
| Correct templates and site priors (default) | 98.8 | 91.5 | 0.9 |
| Small new-energy template missing | 98.5 | 91.4 | 1.0 |
| Yellow two-row template with a wrong row split (3 + 4) | 98.2 | 91.3 | 1.1 |
| Uniform template priors (no site prior) | 98.7 | 91.6 | 0.8 |
| Strongly wrong site priors | 98.5 | 91.2 | 1.3 |

The projected sensitivity results support two practical recommendations. First, the templates, and especially their row structure, should be checked against the official specification and against a sample of real plates before deployment. Second, the site priors are not critical, so they can start uniform and be estimated later from the traffic of the site.

## 5.4. Degraded Plates, Error Analysis, Limitations, and Conclusion

### 5.4.1. Low-resolution and multi-frame recognition

Table 10 reports projected track-level results on the low-resolution tracks of UFPR-SR-Plates. All models are trained on the low-resolution images, and no super-resolution is applied at inference. The published results of the dataset authors, which used super-resolution and a different recognizer, are not directly comparable [54]. With a single low-resolution frame, FADR is projected to reach <mark>55.6%</mark>, compared with <mark>50.8%</mark> for SVTRv2-T. Training-only guidance from the high-resolution images is projected to add <mark>3.8 percentage points</mark> without any change to the deployed model. The use of five frames is projected to give the largest gain. String-level voting over the five frames is projected to reach <mark>65.2%</mark>, and the slot-aligned fusion of Section 4.3.4 is projected to reach <mark>68.7%</mark>, a further gain of <mark>3.5 percentage points</mark> at the same cost.

*Table 10. Track-level recognition rate (%) on low-resolution UFPR-SR-Plates tracks (models trained on the low-resolution images; no super-resolution at inference). CPU time in ms per track. Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Configuration | LR frames | RR (%) | CPU (ms/track) |
|:--|:-:|--:|--:|
| SVTRv2-T, single LR frame | 1 | 50.8 | 6.9 |
| FADR, single LR frame | 1 | 55.6 | 7.7 |
| + training-only HR→LR distillation | 1 | 59.4 | 7.7 |
| SVTRv2-T, 5-frame string vote | 5 | 60.9 | 34.6 |
| FADR + distillation, 5-frame string vote | 5 | 65.2 | 38.5 |
| FADR + distillation, 5-frame slot-aligned fusion | 5 | 68.7 | 38.5 |

The projected gain of slot-aligned fusion over string voting comes from the use of character probabilities. String voting needs a majority of frames to agree on the same complete string or on the same character at each position. Slot-aligned fusion can combine a weak preference in three frames with a strong reading in one frame. The format slots make this fusion possible, because they give every frame the same index. The results of the ICPR 2026 competition, in which every strong entry used the five frames of the track [53], also suggest that multi-frame evidence is the most important single factor for low-resolution plates. The competition entries used a different dataset and, in several cases, ensembles of models, so their numbers cannot be compared with Table 10. The projected results only suggest that slot-aligned fusion lets a single efficient model benefit from several frames.

### 5.4.2. Error analysis

Table 11 decomposes the projected errors on the three two-row test sets. For SVTRv2-T with the published FRM, row-order errors are projected to be the largest single category (<mark>34</mark> per 1,000 plates), followed by substitutions and deletions. Deletions occur when the single selecting token of a column chooses one of two stacked characters and drops the other. The line split is projected to remove most row-order errors, but its remaining row-order errors come from wrong splits of tilted plates. FADR is projected to reduce the row-order errors to <mark>4</mark> per 1,000 plates and the deletions to <mark>5</mark> per 1,000 plates. Its total is projected to be <mark>28</mark> errors per 1,000 two-row plates, compared with <mark>113</mark> for SVTRv2-T and <mark>56</mark> for CPPD.

*Table 11. Error composition on the three two-row test sets (errors per 1,000 plates, pooled). Row-order errors are strings whose characters are correct but placed in the wrong row order. Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Method | Substitution | Deletion | Insertion | Row order | Total |
|:--|--:|--:|--:|--:|--:|
| SVTRv2-T [50] | 41 | 29 | 9 | 34 | 113 |
| SVTRv2-T + line split [50] | 30 | 12 | 5 | 10 | 57 |
| CPPD [51] | 28 | 11 | 6 | 11 | 56 |
| FADR (ours) | 17 | 5 | 2 | 4 | 28 |

The remaining errors of FADR are expected to be mostly substitutions. They concern confusable pairs that the format cannot separate, such as B and 8 or S and 5 in serial slots that allow both letters and digits, and provincial characters with similar shapes under strong blur (Figure 6). For these errors, more visual evidence is needed: higher resolution, more frames or a better camera. The analysis also checks two properties of the confidence. First, the plates with a review flag should contain a large share of the remaining errors. Second, the confidence of wrong outputs should be low. A recognizer whose wrong outputs have high confidence is more dangerous than a recognizer with a slightly lower recognition rate whose errors are flagged.

Figure 42 shows one example of each error category and of two special cases. A confusion between provincial characters counts as a substitution, but it is reported separately because the provincial character carries the regional information of the plate. An overcorrection turns an unseen plate into a string of a known template; it is measured on the unseen-format test sets (Section 5.3.1).

![Figure 42](figs/fig32_error_types.png)

*Figure 42. Error types of the error analysis, with fictional Chinese examples. Red marks the wrong part of each output. A confusion of provincial characters counts as a substitution; overcorrection is measured on the unseen-format test sets.*

### 5.4.3. Limitations

This paper has six limitations.

1. **Projected results.** The most important limitation of this draft is that all results in this chapter are projected. The method, the protocol and the analysis are defined, but the numbers must be measured. The size and even the direction of some effects can change.
2. **Template dependence.** The benefit of format knowledge depends on correct and complete templates. Templates must follow the official specification of each jurisdiction, and they must be updated when new plate types are introduced. The open-format path limits the damage of a missing template, but it cannot provide the benefit of a correct one.
3. **Unseen scripts.** FADR improves generalization to new arrangements of known characters. It does not solve the recognition of characters that are absent from the vocabulary. A new script requires new data and a new vocabulary.
4. **Correlated errors.** The draft branch and the refiner share the encoder, so their errors are correlated. The refiner adds context, not independent visual evidence.
5. **Dependence on detection.** The evaluation uses plate crops. In an end-to-end system, detection errors, wrong corners and wrong tracks add errors that the recognizer cannot correct.
6. **Data coverage.** Two-row Chinese plates are less common in public datasets than blue one-row plates. Part of the two-row evaluation therefore relies on CRPD and on synthetic data, and a larger real test set of Chinese two-row plates would strengthen the conclusions.

### 5.4.4. Conclusion

This paper addressed the efficient recognition of one-row and two-row license plates with visual and linguistic context, using the officially defined plate formats as the main linguistic knowledge. It reviewed the literature before 2024 and found that CTC recognizers, attention decoders, multi-line plate recognizers and constrained decoding methods existed, but that no method combined CTC efficiency, correct two-row reading and soft format knowledge for license plates.

The proposed Format-Aware Draft-and-Refine recognizer combines an improved CTC branch with an improved parallel decoder on one shared encoder. On the CTC side, a layout–format head infers the plate type from the image, row-selective feature rearrangement produces one ordered sequence per text row, row-factorized training makes the rows unambiguous, and format-constrained decoding uses the templates as soft knowledge with an open-format path. On the decoder side, a format-conditioned parallel refiner re-reads only the uncertain characters, with slot queries that carry the format, the row and the draft. A confidence-gated cascade and a joint score combine the branches so that the average cost stays close to the cost of CTC recognition. Slot-aligned fusion extends the method to multi-frame recognition of low-resolution plates.

The projected results indicate the expected pattern: the largest gains on two-row plates and on difficult one-row plates, almost no change on clear one-row plates, a small increase in the average latency, and robustness to unseen formats when format knowledge is applied softly. These expectations must now be tested by measurement.

### 5.4.5. Future work

The next steps are, first, to implement FADR on top of the published SVTRv2 and CPPD code and to measure every number of this chapter. Second, the template sets should be extended to more jurisdictions, with templates derived from the official specifications. Third, the evaluation of Chinese two-row plates should be strengthened with a larger real test set. Fourth, the slot-aligned fusion should be combined with plate tracking in a complete video pipeline. Fifth, the confidence and review flag should be evaluated with operators, because the value of a recognizer in practice depends not only on its accuracy but also on how reliably it signals its own errors.


# References

*Entries [1]–[10] are reserved for later insertion.*

**[1]**

**[2]**

**[3]**

**[4]**

**[5]**

**[6]**

**[7]**

**[8]**

**[9]**

**[10]**

**[11]** Graves, A., Fernández, S., Gomez, F., and Schmidhuber, J. (2006). "Connectionist Temporal Classification: Labelling Unsegmented Sequence Data with Recurrent Neural Networks." *Proceedings of the 23rd International Conference on Machine Learning (ICML)*, 369–376. https://doi.org/10.1145/1143844.1143891

**[12]** Shi, B., Bai, X., and Yao, C. (2017). "An End-to-End Trainable Neural Network for Image-Based Sequence Recognition and Its Application to Scene Text Recognition." *IEEE Transactions on Pattern Analysis and Machine Intelligence*, 39(11), 2298–2304. https://doi.org/10.1109/TPAMI.2016.2646371

**[13]** Watanabe, S., Hori, T., Kim, S., Hershey, J. R., and Hayashi, T. (2017). "Hybrid CTC/Attention Architecture for End-to-End Speech Recognition." *IEEE Journal of Selected Topics in Signal Processing*, 11(8), 1240–1253. https://doi.org/10.1109/JSTSP.2017.2763455

**[14]** Higuchi, Y., Watanabe, S., Chen, N., Ogawa, T., and Kobayashi, T. (2020). "Mask CTC: Non-Autoregressive End-to-End ASR with CTC and Mask Predict." *Proceedings of Interspeech 2020*. https://arxiv.org/abs/2005.08700

**[15]** Jaderberg, M., Simonyan, K., Zisserman, A., and Kavukcuoglu, K. (2015). "Spatial Transformer Networks." *Advances in Neural Information Processing Systems (NeurIPS)*. https://arxiv.org/abs/1506.02025

**[16]** He, K., Zhang, X., Ren, S., and Sun, J. (2016). "Deep Residual Learning for Image Recognition." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/1512.03385

**[17]** Liu, W., Chen, C., Wong, K.-Y. K., Su, Z., and Han, J. (2016). "STAR-Net: A SpaTial Attention Residue Network for Scene Text Recognition." *British Machine Vision Conference (BMVC)*. https://www.bmva-archive.org.uk/bmvc/2016/papers/paper043/index.html

**[18]** Shi, B., Wang, X., Lyu, P., Yao, C., and Bai, X. (2016). "Robust Scene Text Recognition with Automatic Rectification." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/1603.03915

**[19]** Shi, B., Yang, M., Wang, X., Lyu, P., Yao, C., and Bai, X. (2019). "ASTER: An Attentional Scene Text Recognizer with Flexible Rectification." *IEEE Transactions on Pattern Analysis and Machine Intelligence*, 41(9), 2035–2048. https://doi.org/10.1109/TPAMI.2018.2848939

**[20]** Baek, J., Kim, G., Lee, J., Park, S., Han, D., Yun, S., Oh, S. J., and Lee, H. (2019). "What Is Wrong with Scene Text Recognition Model Comparisons? Dataset and Model Analysis." *IEEE/CVF International Conference on Computer Vision (ICCV)*. https://arxiv.org/abs/1904.01906

**[21]** Zherzdev, S., and Gruzdev, A. (2018). "LPRNet: License Plate Recognition via Deep Neural Networks." *arXiv* preprint arXiv:1806.10447. https://arxiv.org/abs/1806.10447

**[22]** Xu, Z., Yang, W., Meng, A., Lu, N., Huang, H., Ying, C., and Huang, L. (2018). "Towards End-to-End License Plate Detection and Recognition: A Large Dataset and Baseline." *European Conference on Computer Vision (ECCV)*. https://openaccess.thecvf.com/content_ECCV_2018/html/Zhenbo_Xu_Towards_End-to-End_License_ECCV_2018_paper.html

**[23]** Silva, S. M., and Jung, C. R. (2018). "License Plate Detection and Recognition in Unconstrained Scenarios." *European Conference on Computer Vision (ECCV)*. https://openaccess.thecvf.com/content_ECCV_2018/html/Sergio_Silva_License_Plate_Detection_ECCV_2018_paper.html

**[24]** Laroca, R., Severo, E., Zanlorensi, L. A., Oliveira, L. S., Gonçalves, G. R., Schwartz, W. R., and Menotti, D. (2018). "A Robust Real-Time Automatic License Plate Recognition Based on the YOLO Detector." *International Joint Conference on Neural Networks (IJCNN)*. https://doi.org/10.1109/IJCNN.2018.8489629

**[25]** Hsu, G.-S., Chen, J.-C., and Chung, Y.-Z. (2013). "Application-Oriented License Plate Recognition." *IEEE Transactions on Vehicular Technology*, 62(2), 552–561. https://doi.org/10.1109/TVT.2012.2226218

**[26]** Laroca, R., Zanlorensi, L. A., Gonçalves, G. R., Todt, E., Schwartz, W. R., and Menotti, D. (2021). "An Efficient and Layout-Independent Automatic License Plate Recognition System Based on the YOLO Detector." *IET Intelligent Transport Systems*, 15(4), 483–503. https://doi.org/10.1049/itr2.12030

**[27]** Henry, C., Ahn, S. Y., and Lee, S.-W. (2020). "Multinational License Plate Recognition Using Generalized Character Sequence Detection." *IEEE Access*, 8, 35185–35199. https://doi.org/10.1109/ACCESS.2020.2974973

**[28]** Laroca, R., Cardoso, E. V., Lucio, D. R., Estevam, V., and Menotti, D. (2022). "On the Cross-dataset Generalization in License Plate Recognition." *International Conference on Computer Vision Theory and Applications (VISAPP)*, 166–178. (Introduces RodoSol-ALPR.) https://doi.org/10.5220/0010846800003124

**[29]** Laroca, R., Santos, M., Estevam, V., Luz, E., and Menotti, D. (2022). "A First Look at Dataset Bias in License Plate Recognition." *35th SIBGRAPI Conference on Graphics, Patterns and Images*, 234–239. https://doi.org/10.1109/SIBGRAPI55357.2022.9991768

**[30]** Yu, D., Li, X., Zhang, C., Liu, T., Han, J., Liu, J., and Ding, E. (2020). "Towards Accurate Scene Text Recognition with Semantic Reasoning Networks." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://openaccess.thecvf.com/content_CVPR_2020/html/Yu_Towards_Accurate_Scene_Text_Recognition_With_Semantic_Reasoning_Networks_CVPR_2020_paper.html

**[31]** Luo, C., Jin, L., and Sun, Z. (2019). "MORAN: A Multi-Object Rectified Attention Network for Scene Text Recognition." *Pattern Recognition*, 90, 109–118. https://arxiv.org/abs/1901.03003

**[32]** Li, H., Wang, P., Shen, C., and Zhang, G. (2019). "Show, Attend and Read: A Simple and Strong Baseline for Irregular Text Recognition." *AAAI Conference on Artificial Intelligence*. https://arxiv.org/abs/1811.00751

**[33]** Sheng, F., Chen, Z., and Xu, B. (2019). "NRTR: A No-Recurrence Sequence-to-Sequence Model for Scene Text Recognition." *International Conference on Document Analysis and Recognition (ICDAR)*. https://arxiv.org/abs/1806.00926

**[34]** Atienza, R. (2021). "Vision Transformer for Fast and Efficient Scene Text Recognition." *International Conference on Document Analysis and Recognition (ICDAR)*. https://arxiv.org/abs/2105.08582

**[35]** Lee, J., Park, S., Baek, J., Oh, S. J., Kim, S., and Lee, H. (2020). "On Recognizing Texts of Arbitrary Shapes with 2D Self-Attention." *CVPR Workshops*. https://openaccess.thecvf.com/content_CVPRW_2020/html/w34/Lee_On_Recognizing_Texts_of_Arbitrary_Shapes_With_2D_Self-Attention_CVPRW_2020_paper.html

**[36]** Fang, S., Xie, H., Wang, Y., Mao, Z., and Zhang, Y. (2021). "Read Like Humans: Autonomous, Bidirectional and Iterative Language Modeling for Scene Text Recognition." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/2103.06495

**[37]** Bautista, D., and Atienza, R. (2022). "Scene Text Recognition with Permuted Autoregressive Sequence Models." *European Conference on Computer Vision (ECCV)*. https://arxiv.org/abs/2207.06966

**[38]** Wang, Y., Xie, H., Fang, S., Wang, J., Zhu, S., and Zhang, Y. (2021). "From Two to One: A New Scene Text Recognizer with Visual Language Modeling Network." *IEEE/CVF International Conference on Computer Vision (ICCV)*. https://openaccess.thecvf.com/content/ICCV2021/html/Wang_From_Two_to_One_A_New_Scene_Text_Recognizer_With_ICCV_2021_paper.html

**[39]** Du, Y., Chen, Z., Jia, C., Yin, X., Zheng, T., Li, C., Du, Y., and Jiang, Y.-G. (2022). "SVTR: Scene Text Recognition with a Single Visual Model." *International Joint Conference on Artificial Intelligence (IJCAI)*. https://doi.org/10.24963/ijcai.2022/124

**[40]** Dosovitskiy, A., et al. (2021). "An Image Is Worth 16x16 Words: Transformers for Image Recognition at Scale." *International Conference on Learning Representations (ICLR)*. https://arxiv.org/abs/2010.11929

**[41]** Vaswani, A., et al. (2017). "Attention Is All You Need." *Advances in Neural Information Processing Systems (NeurIPS)*. https://arxiv.org/abs/1706.03762

**[42]** Hu, W., Cai, X., Hou, J., Yi, S., and Lin, Z. (2020). "GTC: Guided Training of CTC Towards Efficient and Accurate Scene Text Recognition." *Proceedings of the AAAI Conference on Artificial Intelligence*, 34(07), 11005–11012. https://doi.org/10.1609/aaai.v34i07.6735

**[43]** Liu, Z., et al. (2021). "Swin Transformer: Hierarchical Vision Transformer Using Shifted Windows." *IEEE/CVF International Conference on Computer Vision (ICCV)*. https://arxiv.org/abs/2103.14030

**[44]** Miao, Y., Gowayyed, M., and Metze, F. (2015). "EESEN: End-to-End Speech Recognition Using Deep RNN Models and WFST-Based Decoding." *IEEE Workshop on Automatic Speech Recognition and Understanding (ASRU)*, 167–174. https://arxiv.org/abs/1507.08240

**[45]** Cao, Y., Fu, H., and Ma, H. (2018). "An End-to-End Neural Network for Multi-Line License Plate Recognition." *24th International Conference on Pattern Recognition (ICPR)*, 3698–3703.

**[46]** Gong, Y., Deng, L., Tao, S., Lu, X., Wu, P., Xie, Z., Ma, Z., and Xie, M. (2022). "Unified Chinese License Plate Detection and Recognition with High Efficiency." *arXiv* preprint arXiv:2205.03582. (Introduces the Chinese Road Plate Dataset, CRPD.) https://arxiv.org/abs/2205.03582

**[47]** Redmon, J., Divvala, S., Girshick, R., and Farhadi, A. (2016). "You Only Look Once: Unified, Real-Time Object Detection." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/1506.02640

**[48]** Bochkovskiy, A., Wang, C.-Y., and Liao, H.-Y. M. (2020). "YOLOv4: Optimal Speed and Accuracy of Object Detection." *arXiv* preprint arXiv:2004.10934. https://arxiv.org/abs/2004.10934

**[49]** Wang, C.-Y., Bochkovskiy, A., and Liao, H.-Y. M. (2023). "YOLOv7: Trainable Bag-of-Freebies Sets New State-of-the-Art for Real-Time Object Detectors." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/2207.02696

**[50]** Du, Y., Chen, Z., Xie, H., Jia, C., and Jiang, Y.-G. (2025). "SVTRv2: CTC Beats Encoder-Decoder Models in Scene Text Recognition." *Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV)*, 20147–20156. https://doi.org/10.1109/ICCV51701.2025.01874

**[51]** Du, Y., Chen, Z., Jia, C., Yin, X., Li, C., Du, Y., and Jiang, Y.-G. (2025). "Context Perception Parallel Decoder for Scene Text Recognition." *IEEE Transactions on Pattern Analysis and Machine Intelligence*, 47(6), 4668–4683. https://doi.org/10.1109/TPAMI.2025.3545453

**[52]** Laroca, R., Estevam, V., Moreira, G. J. P., Minetto, R., and Menotti, D. (2025). "Advancing Multinational License Plate Recognition Through Synthetic and Real Data Fusion: A Comprehensive Evaluation." *IET Intelligent Transport Systems*, 19(1), e70086. https://doi.org/10.1049/itr2.70086

**[53]** Laroca, R., Nascimento, V., Kim, D., et al. (2026). "ICPR 2026 Competition on Low-Resolution License Plate Recognition." *arXiv* preprint arXiv:2604.22506. https://arxiv.org/abs/2604.22506

**[54]** Nascimento, V., Lima, G. E., Ribeiro, R. O., Schwartz, W. R., Laroca, R., and Menotti, D. (2025). "Toward Advancing License Plate Super-Resolution in Real-World Scenarios: A Dataset and Benchmark." *Journal of the Brazilian Computer Society*, 31(1), 435–448. https://doi.org/10.5753/jbcs.2025.5159

**[55]** Agrawal, S. (2024). "Global License Plate Dataset." *arXiv* preprint arXiv:2405.10949. https://arxiv.org/abs/2405.10949

**[56]** Liu, Q., Liu, Y., Chen, S.-L., et al. (2024). "Improving Multi-Type License Plate Recognition via Learning Globally and Contrastively." *IEEE Transactions on Intelligent Transportation Systems*, 25(9), 11092–11102. https://doi.org/10.1109/TITS.2024.3365537

**[57]** Chen, S.-L., Liu, Q., Chen, F., and Yin, X.-C. (2023). "End-to-End Multi-line License Plate Recognition with Cascaded Perception." *Document Analysis and Recognition – ICDAR 2023*, Lecture Notes in Computer Science, vol. 14191. Springer. https://doi.org/10.1007/978-3-031-41734-4_17

**[58]** Gupta, A., Vedaldi, A., and Zisserman, A. (2016). "Synthetic Data for Text Localisation in Natural Images." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/1604.06646

**[59]** Jaderberg, M., Simonyan, K., Vedaldi, A., and Zisserman, A. (2014). "Synthetic Data and Artificial Neural Networks for Natural Scene Text Recognition." *arXiv* preprint arXiv:1406.2227. https://arxiv.org/abs/1406.2227

**[60]** Wang, X., Xie, L., Dong, C., and Shan, Y. (2021). "Real-ESRGAN: Training Real-World Blind Super-Resolution with Pure Synthetic Data." *IEEE/CVF International Conference on Computer Vision Workshops*. https://arxiv.org/abs/2107.10833

**[61]** Ledig, C., et al. (2017). "Photo-Realistic Single Image Super-Resolution Using a Generative Adversarial Network." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/1609.04802

**[62]** Zhang, K., Zuo, W., and Zhang, L. (2018). "Learning a Single Convolutional Super-Resolution Network for Multiple Degradations." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/1711.05778

**[63]** Zhang, K., Liang, J., Van Gool, L., and Timofte, R. (2021). "Designing a Practical Degradation Model for Deep Blind Image Super-Resolution." *IEEE/CVF International Conference on Computer Vision (ICCV)*. https://arxiv.org/abs/2103.14006

**[64]** Wang, X., Yu, K., Wu, S., Gu, J., Liu, Y., Dong, C., Qiao, Y., and Loy, C. C. (2018). "ESRGAN: Enhanced Super-Resolution Generative Adversarial Networks." *ECCV Workshops*. https://arxiv.org/abs/1809.00219

**[65]** Hinton, G., Vinyals, O., and Dean, J. (2015). "Distilling the Knowledge in a Neural Network." *arXiv* preprint arXiv:1503.02531. https://arxiv.org/abs/1503.02531

**[66]** Romero, A., et al. (2015). "FitNets: Hints for Thin Deep Nets." *International Conference on Learning Representations (ICLR)*. https://arxiv.org/abs/1412.6550

**[67]** Zhang, Y., Xiang, T., Hospedales, T. M., and Lu, H. (2018). "Deep Mutual Learning." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/1706.00384

**[68]** Laroca, R., Estevam, V., Britto Jr., A. S., Minetto, R., and Menotti, D. (2023). "Do We Train on Test Data? The Impact of Near-Duplicates on License Plate Recognition." *International Joint Conference on Neural Networks (IJCNN)*, 1–8.

**[69]** Guo, C., Pleiss, G., Sun, Y., and Weinberger, K. Q. (2017). "On Calibration of Modern Neural Networks." *Proceedings of the 34th International Conference on Machine Learning (ICML)*, PMLR 70, 1321–1330. https://arxiv.org/abs/1706.04599

**[70]** Hannun, A. Y., Maas, A. L., Jurafsky, D., and Ng, A. Y. (2014). "First-Pass Large Vocabulary Continuous Speech Recognition Using Bi-Directional Recurrent DNNs." *arXiv* preprint arXiv:1408.2873. https://arxiv.org/abs/1408.2873


# Appendix A. Format Templates of Chinese Plate Types

This appendix lists the simplified format templates of the Chinese plate types that are used in the experiments and in the figures of this paper. The templates are a working specification for the recognizer. They follow the national standard GA 36-2018 that is cited in Section 1.1.4, but they are not a legal or complete description of that standard. Rare plate types, such as embassy, consulate, military and temporary plates, are not part of the template file. Such plates are read under the open format, like any other unknown plate.

The slot types are the same as in Section 2.3.5:

- **P**: a provincial character, for example 京, 沪, 粤 or 皖;
- **L**: a Latin letter without I and O, which is the code of the issuing authority;
- **A**: a Latin letter without I and O, or a digit;
- **N**: a digit;
- **E**: the energy code of a new-energy plate, D or F;
- **S**: a special final character, such as 挂, 学, 警, 港 or 澳.

Two rules apply to the serial, that is, to all slots after the issuing-authority letter. The letters I and O are never used, so that they cannot be confused with the digits 1 and 0. A serial of a civilian plate contains at most two letters. The automaton of a template counts the letters of the serial in its states (Section 2.3.5).

*Table A1. Simplified templates of the Chinese plate types used in this paper. The examples are fictional strings. "Withheld" marks the templates that are removed from the template file and from the training data in the unseen-format experiment of Section 5.3.1.*

| Plate type | Colour | Rows | Template | Special rule | Example | Unseen-format run |
|:--|:--|:--|:--|:--|:--|:--|
| Small car | blue, white characters | 1 | P L A A A A A | none | 京A12345 | kept |
| Small new-energy vehicle | green gradient, black characters | 1 | P L E A N N N N | third slot is D or F | 粤BD12345 | kept |
| Large new-energy vehicle | yellow and green, black characters | 1 | P L N N N N N E | last slot is D or F | 苏E12345D | withheld |
| Large vehicle, front | yellow, black characters | 1 | P L A A A A A | none | 浙C6Z8B3 | kept |
| Large vehicle, rear | yellow, black characters | 2 | P L / A A A A A | none | 沪A / 12345 | kept |
| Trailer | yellow, black characters | 2 | P L / A A A A S | S is 挂 | 鲁B / 2071挂 | withheld |
| Driving-school vehicle | yellow, black characters | 1 | P L A A A A S | S is 学 | 川A3721学 | kept |
| Police | white, black characters and red 警 | 1 | P L A A A A S | S is 警 | 渝A0516警 | kept |
| Ordinary motorcycle | yellow, black characters | 2 | P L / A A A A A | none | 湘D / 3B157 | kept |
| Hong Kong or Macau cross-border | black, white characters | 1 | P L A A A A S | P is 粤, L is Z, S is 港 or 澳 | 粤Z1234港 | withheld |
| Open format, one row | any | 1 | any symbols, at most ten | penalised by the prior | none | kept |
| Open format, two rows | any | 2 | any symbols in each row | penalised by the prior | none | kept |

The slash in the template column separates the upper row from the lower row. The same template can describe several plate types. For example, the front plate of a large vehicle and the blue small-car plate have the same slot sequence. They differ in colour and in the plate size, which the layout–format head can see, but not in the string. The decoding therefore treats them as one template with two visual classes, and the joint score does not have to choose between them.

The template file is written in the format of Section 4.1.4. Each entry contains the name of the plate type, the number of rows, the slot sequence of each row, the special rules and the deployment prior. A compiler reads the file once at start-up and builds the automata. The automata of templates with a common prefix share their first states, because all Chinese civilian templates start with a provincial character and a letter. A deployment in a city with many new-energy vehicles can raise the prior of the new-energy templates without any other change.

Three properties of the Chinese templates are important for the experiments. First, the slot types L and N never overlap, so the format can resolve every letter–digit confusion between the issuing-authority letter and a digit, for example B and 8. Second, most serial slots have the type A, which allows both letters and digits. The format cannot resolve a confusion such as Z and 2 in these slots; only visual evidence can. Third, the new-energy templates have slots of type E and N that are much more restrictive than A. The format is therefore expected to help most on new-energy plates, which is consistent with the projected results of Chapter 5.

# Appendix B. Planned Training and Decoding Settings

This appendix lists the planned settings of the experiments. The settings are part of the protocol of Chapter 5. They are initial values, not results. The values of the thresholds and of the weights of the joint score are selected on the validation set, and the final values must be reported together with the measured results.

*Table B1. Planned settings of the encoder, the heads and the training. The values are initial choices of the protocol; values marked "tuned" are selected on the validation set.*

| Group | Setting | Planned value |
|:--|:--|:--|
| Input | multi-size resizing buckets | 64 × 64, 48 × 96, 40 × 112 and 32 × ⌊R⌋·32 |
| Encoder | architecture | SVTRv2-T style, three stages |
| Encoder | blocks and channel widths | 3, 6 and 3 blocks; 64, 128 and 256 channels |
| Encoder | initialization | pre-trained on scene text |
| Vocabulary | symbols | 31 provincial characters, 24 letters, 10 digits, 5 special characters |
| LFH | classes | all templates of Table A1 and two open formats |
| LFH | two-row decision | decode both layouts when the two-row probability is between 0.2 and 0.8 |
| Draft branch | selecting tokens | three tokens: one row, upper row, lower row |
| Draft branch | beam width | 5 |
| Refiner | layers | 2 |
| Refiner | maximum number of slots | 10 |
| Refiner | weight of unmasked slots in the loss | 0.1 |
| Refiner | penalty for characters outside the slot type | finite, tuned |
| Refiner | masking threshold | tuned |
| Training | optimizer | AdamW with a one-cycle schedule and mixed precision |
| Training | phases | four phases as in Section 4.1.3 |
| Training | random seeds | 3 for every configuration |
| Training | format dropout and wrong templates | small probabilities, for example 0.1 each |
| Synthetic data | strings | format-faithful and format-open, one row and two rows |
| Calibration | temperatures | one for the CTC logits and one for the LFH logits |
| Cascade | gate A and gate B | tuned so that accepted plates reach at least 99.5% recognition rate |
| Cascade | review threshold | tuned to the operating requirements |
| Joint score | weights of the CTC, refiner and format terms | tuned |
| Joint score | prior of the open format | smaller than the priors of the known templates |
| Latency | measurement | batch size 1, after warm-up, median of repeated runs |
| Latency | devices | desktop GPU, desktop CPU with four threads, ARM board with four threads |

Three settings need special care. The first is the open-format prior. A very small prior makes the system behave like a hard format filter, and a very large prior removes the benefit of the templates. The prior is therefore tuned on the validation set together with the weight of the format term, and the unseen-format test is used only once, for the final evaluation. The second is the masking threshold of the refiner. It is tuned on the plates that reach stage C, because these plates have a different distribution of confidences from the average plate. The third is the share of format-open strings in the synthetic data. Too few format-open strings make the model rely on the templates; too many make the format knowledge weak. The planned value is a moderate share, and a short sensitivity study is part of the ablation of Chapter 5.

All baselines are trained with the same data, the same vocabulary and the same augmentation as FADR. When a baseline has its own recommended settings, such as the learning rate of PARSeq, these settings are used. The input size of every baseline follows its original paper, except that all CTC baselines also receive the MSR buckets in a separate run, so that the effect of the input size can be separated from the effect of the recognition head.

# Appendix C. Replacing the Projected Results

All numbers in the tables of Chapter 5, and every highlighted number in the text, are projected placeholders. This appendix maps each projected element to the experiment that will replace it and lists the checks that are needed after the replacement. The mapping is intended as a plan for the experimental work.

*Table C1. Projected elements of the paper and the experiments that replace them.*

| Projected element | Experiment | Data | Section |
|:--|:--|:--|:--|
| Table 1 | one-row recognition of all methods | CCPD test subsets and green plates | 5.2.1 |
| Table 2 | mixed one-row and two-row recognition | CRPD and RodoSol-ALPR | 5.2.2 |
| Table 3 | results by Chinese plate type | CCPD and CRPD | 5.2.3 |
| Figure 39 | qualitative examples | selected test plates | 5.2.4 |
| Table 4 | decoding variants on known and unseen formats | separate training run | 5.3.1 |
| Table 5 | ablation of the components | all two-row and unseen sets | 5.3.2 |
| Table 6 and Figure 40 | model size and latency | three devices | 5.3.3 |
| Table 7 and Figure 41 | exits of the cascade and threshold sweep | validation and test sets | 5.3.4 |
| Table 8 | calibration and review flag | all test sets | 5.3.5 |
| Table 9 | sensitivity to the template set | modified template files | 5.3.6 |
| Table 10 | single-frame and multi-frame recognition | UFPR-SR-Plates tracks | 5.4.1 |
| Table 11 | error composition | two-row test sets | 5.4.2 |
| Highlighted numbers in the Abstract and the Introduction | summary of the measured results | as above | front matter |

The projected numbers are not independent. They were generated so that averages, shares and latencies agree with each other. For example, the expected latency of FADR follows from the cost model of Section 4.4.1 and the projected shares of plates at each gate. When the measured values replace the projected values, these relations must be checked again. Several statements in the text also depend on the projected numbers. Examples are the statement that the gain of FADR is largest for yellow two-row plates (Section 5.2.3), the statement that most of the gain on one-row plates comes from the format knowledge in the CTC decoding (Section 5.2.1), and the statement that the refiner runs for a small share of plates (Section 5.3.4). Each such statement must be confirmed, changed or removed after the measurement.

The following checklist summarizes the reporting rules of the protocol:

1. Report the version, the licence and the split files of every dataset, and the result of the near-duplicate check.
2. Report the mean and the standard deviation over three seeds for every recognition rate.
3. Report the McNemar test for every comparison that the text interprets, and the bootstrap confidence intervals of the main results.
4. Select every threshold and every weight on the validation set only, and report the selected values in Table B1.
5. Run the unseen-format experiment as a separate training run, without the withheld formats in the training data or in the template file, and use its test sets only once.
6. Report the raw greedy strings together with the final strings, so that the effect of the format knowledge is visible.
7. Measure the latency with the protocol of Section 5.1.6, and report the device, the runtime, the precision and the number of threads.
8. Report the share of plates that leave the cascade at each gate, separately for one-row and two-row plates.
9. Remove the highlights, the word "PROJECTED" and the notice boxes only after every number in the affected table or paragraph has been replaced.
10. Re-read the abstract, the introduction and the conclusion, and change every claim that the measured results do not support.

The last rule is the most important. A projected result describes what the method is designed to achieve. A measured result describes what it achieves. If the two differ, the paper must follow the measurement, and the analysis of Chapter 5 should explain the difference. A negative or mixed result is still useful: for example, if the refiner does not improve two-row plates beyond the draft branch, the paper can still report the row-selective CTC as an efficient solution and discuss why the refiner did not help.

# Appendix D. Notation

This appendix collects the main symbols of the paper. Symbols that appear in only one equation are explained next to that equation.

*Table D1. Main symbols of the paper.*

| Symbol | Meaning | Section |
|:--|:--|:--|
| $x$ | plate crop given to the recognizer | 2.1 |
| $H \times W$ | height and width of the resized crop | 2.2.2 |
| $R$ | aspect ratio $W/H$ of the crop | 2.2.2 |
| $F$ | feature map of the encoder, of size $H/8 \times W/4 \times D$ | 2.2.1 |
| $H'$, $W'$ | number of feature rows ($H/8$) and columns ($W/4$) | 2.2.1 |
| $T$ | number of CTC time steps | 2.1.1 |
| $P_t(c \mid x)$ | CTC probability of symbol $c$ at time step $t$ | 2.1.1 |
| $y$ | plate string; $y^{(1)}$ and $y^{(2)}$ are the strings of the upper and lower rows | 2.3.4 |
| $\mathcal{B}$ | CTC collapse: merge repeats, then remove blanks | 2.1.1 |
| $T^{s}$ | selecting token of the FRM | 2.2.3 |
| $T^{s}_{0}$, $T^{s}_{1}$, $T^{s}_{2}$ | selecting tokens for one-row plates, upper rows and lower rows | 2.3.3 |
| $S^{(0)}$, $S^{(1)}$, $S^{(2)}$ | sequences produced by the three selecting tokens | 2.3.3 |
| $e_1$, $e_2$ | row embeddings added to the upper and lower sequences | 2.3.3 |
| $k$ | format template; $\mathcal{A}_k$ is its automaton | 2.3.5 |
| $p(k \mid x)$ | probability of template $k$ from the layout–format head | 2.3.2 |
| $\pi_k$ | deployment prior of template $k$; $\pi_{\text{open}}$ for the open format | 2.3.6 |
| $\beta$ | weight of the format term in the decoding score | 2.3.6 |
| $\kappa_j$ | calibrated confidence of slot $j$ | 2.3.8 |
| $\gamma$ | masking threshold of the refiner | 3.3.2 |
| $\tau_j$ | slot type of slot $j$ | 3.3.2 |
| $\lambda$ | penalty for characters outside the slot type | 3.3.5 |
| $\eta$ | weight of the unmasked slots in the refiner loss | 3.3.7 |
| $\alpha$ | weight of the CTC term in the joint score | 4.2.4 |
| $\tau_f$, $\tau_a$, $\tau_b$, $\tau_{\text{rej}}$ | thresholds of gate A, gate B and the review flag | 4.2 |
| $\rho_B$, $\rho_C$ | shares of plates that reach stages B and C | 4.4.1 |
| $w_n$ | weight of frame $n$ in multi-frame fusion | 4.3.4 |

The letters P, L, A, N, E and S denote slot types (Appendix A). They are written in upright capital letters to distinguish them from mathematical symbols.

# Appendix E. Worked Example of Format-Constrained Decoding

This appendix follows the format-constrained search of Section 2.3.6 step by step on one plate. The plate is a small new-energy plate with the fictional string 粤BD12345. The image is blurred, and the second character is ambiguous: the CTC evidence favours the digit 8 over the correct letter B. The example uses the priors of the template file in Section 4.1.4 and a format weight $\beta = 0.5$. The layout–format head assigns the probabilities 0.88 to the small new-energy template, 0.06 to the small-car template and 0.02 to the open one-row format, as in the illustration of Figure 16. All values are illustrative. For clarity, each character is represented by one group of frames, and the CTC probability of a string is approximated by the product of the probabilities of its characters.

*Table E1. Trace of the format-constrained search for the plate 粤BD12345 (illustrative values). The numbers are cumulative natural-log probabilities of the best hypothesis of each template after each slot.*

| Slot | CTC evidence | Small new-energy template | Open format |
|:--|:--|:--|:--|
| 1 | 粤 0.97 | type P: 粤 (−0.03) | 粤 (−0.03) |
| 2 | 8 0.55, B 0.40 | type L: 8 is blocked; 粤B (−0.95) | 粤8 (−0.63) |
| 3 | D 0.90, 0 0.08 | type E: 0 is blocked; 粤BD (−1.05) | 粤8D (−0.73) |
| 4 to 7 | 1 0.95, 2 0.96, 3 0.94, 4 0.95 | types A, N, N, N: 粤BD1234 (−1.26) | 粤8D1234 (−0.94) |
| 8 | 5 0.93, 6 0.04 | type N: 粤BD12345 (−1.33); 粤BD12346 (−4.48) | 粤8D12345 (−1.01) |

The open format keeps the hypothesis 粤8D12345, because it accepts any symbol. Its CTC probability is higher than that of the correct string, because the frames of the second character prefer 8. The template of the small new-energy plate blocks the digit 8 in the second slot, because this slot has the type L. It also blocks the digit 0 in the third slot, because this slot accepts only D or F. The small-car template cannot explain eight confident characters. Its best hypothesis must drop the last character, which costs a large CTC penalty.

The final scores combine the CTC term, the format term and the prior (Equation 6). The totals are computed before rounding:

- 粤BD12345, small new-energy template: −1.33 − 0.06 − 2.12 = −3.51;
- 粤BD12346, small new-energy template: −4.48 − 0.06 − 2.12 = −6.66;
- 粤BD1234, small-car template: −5.17 − 1.41 − 0.22 = −6.80;
- 粤8D12345, open format: −1.01 − 1.96 − 4.61 = −7.57.

The correct string wins with a margin of 3.15 over the second hypothesis. This is the case of gate B in Figure 28: the greedy draft 粤8D12345 is invalid for every known template and fails gate A, and the constrained search resolves the B/8 confusion with a clear margin. The refiner is not needed for this plate.

The example also shows when the open format would win. Suppose that the plate really were an unusual plate with the string 粤8D12345, and that the LFH, because of an unusual colour, assigned a probability of 0.5 to the open format and only 0.3 to the small new-energy template. The format terms would then be −0.35 for the open format and −0.60 for the template. If, in addition, the frames of the second character showed a clear 8 with probability 0.97 and B with only 0.02, the CTC term of the template string would fall by about 3.0, and the open format would win. The decision therefore depends on the visual evidence of both the characters and the plate type, which is the intended behaviour.

# Appendix F. Template File Used in the Experiments

This appendix gives the complete template file of the experiments in the format of Section 4.1.4. It contains the plate types of Table A1. Compared with the simplified example of Section 4.1.4, the file adds two features. First, a template can list several visual classes of the layout–format head. The blue small-car plate and the yellow front plate of a large vehicle, for example, share one template but look different. The head predicts the visual classes, and the probability $p(k \mid x)$ of a template is the sum of the probabilities of its visual classes. Second, single characters can be defined as classes, so that a template can fix a slot to one character, as in the cross-border plates.

```yaml
# Template file of the experiments (illustrative, not an official specification)
classes:
  P: [京, 津, 沪, 渝, 冀, 豫, 云, 辽, 黑, 湘, 皖, 鲁, 新, 苏, 浙, 赣,
      鄂, 桂, 甘, 晋, 蒙, 陕, 吉, 闽, 贵, 粤, 青, 藏, 川, 宁, 琼]
  L: [A-H, J-N, P-Z]            # letters without I and O
  N: [0-9]                      # digits
  A: [L, N]                     # letter or digit
  E: [D, F]                     # energy code of new-energy plates
  S_trailer: [挂]
  S_school: [学]
  S_police: [警]
  S_cross_border: [港, 澳]
  P_guangdong: [粤]
  L_z: [Z]
templates:
  cn_one_row_7:                 # blue small car, yellow front plate of a large vehicle
    rows: [[P, L, A, A, A, A, A]]
    rules: [serial_max_letters: 2]
    lfh_classes: [small_car_blue, large_front_yellow]
    prior: 0.72
  cn_small_new_energy:          # green gradient plate, one row, 8 characters
    rows: [[P, L, E, A, N, N, N, N]]
    lfh_classes: [small_new_energy_green]
    prior: 0.12
  cn_large_new_energy:          # yellow-green plate; withheld in the unseen-format run
    rows: [[P, L, N, N, N, N, N, E]]
    lfh_classes: [large_new_energy_yellow_green]
    prior: 0.02
  cn_two_row_7:                 # rear plate of a large vehicle, motorcycle plate
    rows: [[P, L], [A, A, A, A, A]]
    rules: [serial_max_letters: 2]
    lfh_classes: [large_rear_yellow, motorcycle_yellow]
    prior: 0.06
  cn_trailer:                   # two rows, ends with 挂; withheld in the unseen-format run
    rows: [[P, L], [A, A, A, A, S_trailer]]
    rules: [serial_max_letters: 2]
    lfh_classes: [trailer_yellow]
    prior: 0.02
  cn_driving_school:            # yellow plate, ends with 学
    rows: [[P, L, A, A, A, A, S_school]]
    rules: [serial_max_letters: 2]
    lfh_classes: [driving_school_yellow]
    prior: 0.02
  cn_police:                    # white plate, red 警
    rows: [[P, L, A, A, A, A, S_police]]
    rules: [serial_max_letters: 2]
    lfh_classes: [police_white]
    prior: 0.01
  cn_cross_border:              # black plate; withheld in the unseen-format run
    rows: [[P_guangdong, L_z, A, A, A, A, S_cross_border]]
    lfh_classes: [cross_border_black]
    prior: 0.01
  open_one_row:                 # any string, penalised
    rows: [[any]]
    max_length: 10
    prior: 0.01
  open_two_rows:                # any two strings, penalised
    rows: [[any], [any]]
    max_length: 10
    prior: 0.01
```

The priors in this file describe a mixed urban site and are placeholders. They are relative weights; the compiler normalizes them. In the unseen-format run of Section 5.3.1, the three entries marked "withheld" are deleted from the file, and the corresponding visual classes are removed from the head. The rest of the file stays the same, so that the run measures only the effect of the missing templates.

Three checks are applied when the file is compiled. First, every class must be defined, and every character must belong to the recognition vocabulary. Second, two templates with the same rows and the same rules are merged into one template with the union of their visual classes, because the decoding cannot distinguish them. Third, the compiler reports templates that accept a common string, such as a driving-school plate and a police plate with the same serial but different final characters. Such overlaps are allowed, but they are listed in the log, because the joint score must then rely on the visual evidence of the LFH and of the last character.
