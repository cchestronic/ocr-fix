---
title: "Efficient Recognition of One-Row and Two-Row License Plates by Combining CTC and Parallel Decoding with Format-Aware Visual and Linguistic Context"
subtitle: "A Format-Aware Draft-and-Refine Framework Built on SVTRv2 and CPPD"
author: "[Author name and affiliation — to be added]"
date: "12 November 2026"
lang: en
---

> **Draft status. All experimental results in Chapter 5, and every number quoted from them in other chapters, are projected placeholders. They are highlighted in yellow and marked PROJECTED. They are not measurements. Replace them with measured values before submission.**

## Abstract

License plate recognition must read short identifiers with a strict structure. The characters can be arranged in one row or in two rows, the plate can be rotated, shifted or warped in the image, and the image can be degraded by blur, low resolution and glare. Connectionist Temporal Classification (CTC) reads one-row plates efficiently, but it needs a feature sequence that already follows the reading order. Attention-based parallel decoders can read two-dimensional layouts and use the context of other characters, but they cost more computation. Methods that split a two-row plate into rows, or that first classify the plate type, fail when the rows cannot be separated or when the classification is wrong. This paper proposes Format-Aware Draft-and-Refine recognition (FADR), which improves both mechanisms and combines them on one shared encoder. On the CTC side, learned reading-order queries replace the column-wise selection of SVTRv2. Each query attends to the whole two-dimensional feature map, and the outputs of the queries are the time steps of CTC. One-row, two-row and rotated plates are read by the same mechanism, without a row split, a row count or a plate type. On the decoder side, a context-aware parallel decoder, built on CPPD, reads a plate independently in one pass and scores candidate strings with the context of their other characters. A gate accepts a CTC result when all its characters are confident and its string fits a known plate format. Only the remaining plates are read by the decoder. When the two readers disagree, a joint score of CTC evidence, decoder evidence and format evidence selects the final string from the candidates of both. The official plate formats are applied to candidate strings as a finite score, with a lower prior for strings outside all known formats, so no classifier of the plate type is needed and unfamiliar plates stay readable. In projected experiments, FADR reaches <mark>97.1%</mark> on two-row plates, compared with <mark>88.7%</mark> for SVTRv2 and <mark>94.4%</mark> for CPPD. On two-row plates that are rotated by 30 degrees, it reaches <mark>94.0%</mark>, compared with <mark>60.2%</mark> for a row-split baseline. It reaches an average of <mark>98.2%</mark> on one-row Chinese plates. The decoder is projected to run for only <mark>10.5%</mark> of the plates, so FADR adds about <mark>5.2%</mark> CPU latency to CTC-only recognition. The accuracy on unseen formats stays at <mark>91.4%</mark>, compared with <mark>61.9%</mark> when the formats are used as hard rules.

**Keywords:** automatic license plate recognition; Chinese license plates; two-row license plates; rotated license plates; Connectionist Temporal Classification; reading-order queries; parallel decoding; plate format; visual and linguistic context; SVTRv2; CPPD; edge inference.

## Contents

**Introduction**

**Chapter 1. Literature Review of License Plate Recognition Before 2024**\
1.1. License Plate Detection and End-to-End Recognition Frameworks\
1.2. Character Detection, CTC, Attention-Based Recognition, and Their Combination\
1.3. Multinational Datasets, Two-Row Layouts, Plate Formats, Degradation, and Research Gaps

**Chapter 2. Efficient CTC-Based Recognition for One-Row and Two-Row Plates**\
2.1. Conventional CTC Recognition and Its Limitations\
2.2. SVTRv2: Multi-Size Resizing, Feature Rearrangement, and Semantic Guidance\
2.3. Proposed CTC Branch: Reading-Order Queries and Format Knowledge Without a Format Classifier

**Chapter 3. Context-Aware Parallel Decoding Based on CPPD**\
3.1. Limitations of Autoregressive and Conventional Parallel Decoders\
3.2. Context Perception Parallel Decoding Through Character Counting and Ordering\
3.3. Proposed Context-Aware Parallel Decoder

**Chapter 4. Combining CTC and Parallel Decoding: The Format-Aware Draft-and-Refine Framework**\
4.1. Architecture and Joint Training\
4.2. Confidence-Gated Inference and Joint Scoring\
4.3. Recognition of Degraded Plates\
4.4. Computational Cost, Deployment, and Safeguards

**Chapter 5. Experiments (Projected Results) and Discussion**\
5.1. Datasets, Evaluation Protocol, and Implementation\
5.2. Main Results on One-Row and Two-Row Plates\
5.3. Format Awareness, Ablation Study, and Efficiency\
5.4. Degraded Plates, Error Analysis, Limitations, and Conclusion

**References**

**Appendix A. Format Templates of Chinese Plate Types**\
**Appendix B. Planned Training and Decoding Settings**\
**Appendix C. Replacing the Projected Results**\
**Appendix D. Notation**\
**Appendix E. Worked Example of the Gate and the Joint Score**\
**Appendix F. Template File Used in the Experiments**

## Terminology and scope

This paper uses the following terms in a fixed sense.

- A **plate crop** is an image region that a detector or a human annotator has already located. An **end-to-end ALPR system** also includes plate detection, optional geometric correction and, for video, tracking.
- A **one-row plate** has all characters in one row. A **two-row plate** has two rows of characters. The reading order of a two-row plate is the whole upper row, followed by the whole lower row.
- A **format template** is the official arrangement of characters for one plate type. It is an ordered list of **slots**. Each slot has a **slot type**. The slot type is the set of characters that are allowed in that position, for example a provincial character, a letter, or a digit.
- The **open format** stands for every string that fits no known template. It represents plates whose template is not known to the system, and it has a lower prior than the known templates.
- A **draft** is the string that the CTC branch produces. **Refinement** is the second reading of an uncertain plate by the parallel decoder, followed by the joint scoring of the candidates of both readers.
- A **reading-order query** is a learned vector that attends to the whole feature map. The output of query number $t$ is time step number $t$ of CTC.
- The **gate** is the test that decides whether a draft is accepted without the decoder.
- A **format shift** is a new arrangement of known characters. A **script shift** is the appearance of characters that the system has never seen.
- The **recognition rate (RR)** is the percentage of plates whose complete string is correct.
- A **projected result** is a placeholder number that is used to plan the experiments. It is not a measurement.

The main examples in this paper are Chinese plates, because one Chinese plate can contain a Chinese provincial character, Latin letters and digits, and because China uses both one-row and two-row plates. All plate images in the figures are illustrative drawings with fictional strings. They are not photographs of real vehicles.

![Figure 1](figs/fig01_plate_formats.png)

*Figure 1. Illustrative Chinese-style plates: a blue one-row plate, a green new-energy plate, a yellow two-row plate and a yellow one-row plate. The figure shows variation in characters, colour and layout. The plates are drawings, not official registration samples.*

## Introduction

A license plate is a small field of structured text inside an unconstrained scene. Its small size does not make it easy to read. A plate can contain characters from several scripts. The order of letters and digits is different between countries and between vehicle types. The characters can be arranged in one row or in two rows. In traffic images, the plate is also affected by perspective distortion, defocus, motion blur, reflections, compression and low resolution. These factors interact. A recognizer that reads a clear one-row plate correctly can fail on a clear two-row plate because it reads the rows in the wrong order. A recognizer that understands the layout can still fail when the strokes that separate two similar characters are lost [11,20,27,29].

Two families of sequence recognizers are used in practice. CTC-based recognizers predict one class distribution for each position of an ordered feature sequence. They then merge repeated symbols and remove blank symbols to obtain the output string [11,12]. They are fast and easy to deploy. However, they assume that the feature sequence already follows the reading order, and their final classifier does not model dependencies between characters. Encoder–decoder recognizers use attention to connect each output position with image regions. They can read irregular layouts and use the context of other characters. However, autoregressive decoding is sequential, and even parallel decoders add computation [33,36,37]. SVTRv2 and CPPD are strong recent members of the two families. SVTRv2, presented by Du and colleagues at ICCV 2025, makes a CTC recognizer robust to irregular text with multi-size resizing, feature rearrangement and semantic guidance during training [50]. CPPD, published by Du and colleagues in IEEE TPAMI in 2025, predicts all characters in one parallel pass and builds context with two auxiliary tasks: character counting and character ordering [51].

License plates have a source of linguistic context that ordinary scene text does not have: the plate formats that the issuing authorities define. For example, a slot that may contain only a digit cannot contain the letter B. A Chinese provincial character can appear only in the first slot of a civilian plate. Earlier systems used this knowledge mainly as heuristic post-processing after a layout classifier [26]. As a hard rule, format knowledge improves familiar plates. However, it changes unfamiliar plates, such as a new plate series, a foreign vehicle or a special plate, into confident errors, and a wrong classification of the plate type applies the wrong rule.

Two-row plates add a geometric problem. The usual solution separates the upper row from the lower row and reads the rows one after the other. This works for a plate that is seen from the front. It fails when the plate is rotated, when the crop is shifted, or when perspective bends the rows, because then no simple cut separates the rows. A motorcycle that leans in a curve and a truck plate that is seen from a steep angle are ordinary cases, not rare exceptions. A recognizer for real traffic should therefore read a two-row plate without first deciding where its rows are, how many rows it has, or which plate type it is.

This paper proposes **Format-Aware Draft-and-Refine recognition (FADR)**. Figure 2 gives an overview. A shared hierarchical vision-transformer encoder in the style of SVTRv2 feeds two heads. The **CTC branch** replaces the column-wise selection of SVTRv2 with learned **reading-order queries**. Each query attends to the whole two-dimensional feature map, and the output of query number $t$ is CTC time step number $t$. The queries learn to visit the characters in reading order, so one-row, two-row and rotated plates are read by the same mechanism. The **context-aware parallel decoder**, built on CPPD, is a second reader. It reads the plate independently in one parallel pass, and it can score any candidate string with the context of its other characters. A **gate** accepts the CTC result when every character is confident and the string fits a known plate format. Only the remaining plates reach the decoder. If the decoder reads the same string, the plate is accepted. Otherwise, the candidates of both readers are scored jointly with CTC evidence, decoder evidence and a format score, and the best candidate is the output. The format score is a finite value that is computed from the string alone, so the plate type is never classified, and a string outside all known formats is never removed.

![Figure 2](figs/fig02_framework.png)

*Figure 2. Overview of the proposed Format-Aware Draft-and-Refine (FADR) recognizer. One shared encoder feeds a CTC branch with reading-order queries and a context-aware parallel decoder. Clear plates leave at the gate. The other plates are read a second time, and a joint score selects the final string.*

The work is motivated by deployment. Many ALPR systems run on small computers at road sides, at gates or in vehicles, where the recognizer must process every plate within a few milliseconds on a CPU or a small accelerator. In such systems, most plates are clear one-row plates, and a fast CTC recognizer reads them correctly. The difficult minority, such as two-row plates, rotated plates, blurred plates and plates with confusable characters, causes most of the errors. A design that spends extra computation only on this minority can increase accuracy without increasing the average cost much. China is a demanding test case for this design. Its plates contain more than thirty provincial characters, Latin letters and digits. It uses blue, green, yellow, white and black plates. It uses one-row plates on most cars and two-row plates on the rear of large vehicles, on trailers and on motorcycles.

The paper is deliberately built around few ideas. Its contributions are as follows.

1. **Reading-order queries for CTC.** The vertical selection step of the feature rearrangement module of SVTRv2 is replaced by a fixed number of learned queries that attend to the whole feature map. A two-row plate becomes a CTC sequence in the correct order without a row split, a row count or a rectified image, also when the plate is rotated or shifted. CTC inference stays fully parallel, and a training-only guidance signal from synthetic data supports the reading order.
2. **A context-aware parallel decoder that is used only when needed.** The CPPD decoder is extended with a character-context attention, so that it can read a plate independently and can score candidate strings with linguistic and visual context. A calibrated gate sends only uncertain plates to the decoder. A joint score lets the two readers repair and veto each other, and the average cost stays close to the cost of CTC-only recognition.
3. **Format knowledge without a format classifier.** The official plate formats are compiled into automata and applied to candidate strings as a finite score, with a lower prior for strings outside all templates. The plate type is never predicted from the image, and unseen formats stay readable.

An evaluation protocol accompanies these contributions. It separates one-row and two-row plates, upright and rotated plates, known and unseen formats, and single-frame and multi-frame low-resolution recognition. This draft reports projected results for this protocol. They will be replaced by measurements.

SVTRv2 and CPPD are the published starting points of this work. Their original components are described as such, and the new elements are the three items above. The paper has five chapters. Chapter 1 reviews research published before 2024. Chapter 2 develops the CTC side, from conventional CTC and SVTRv2 to the proposed reading-order queries and the format score. Chapter 3 develops the decoder side, from CPPD to the proposed context-aware decoder. Chapter 4 combines the two parts into the FADR framework and discusses synthetic data, degraded plates and deployment. Chapter 5 describes the evaluation protocol and presents the projected results, the ablation study, the efficiency estimates and the limitations.


# Chapter 1. Literature Review of License Plate Recognition Before 2024

This chapter reviews research that was formally published before 1 January 2024. Later work, including SVTRv2 and CPPD, is discussed in Chapters 2 to 5. The synthesis and the research questions at the end of the chapter are the analysis of the author of this paper. The chapter has three parts. Section 1.1 describes how ALPR systems are built and why the recognition stage should be studied separately. Section 1.2 reviews the recognition methods: CTC, attention decoders, parallel decoders and their combinations. Section 1.3 reviews datasets, two-row layouts, plate formats and degradation, and it defines the research gap.

## 1.1. License Plate Detection and End-to-End Recognition Frameworks

### 1.1.1. From constrained traffic imaging to recognition in the wild

Automatic license plate recognition (ALPR) developed from traffic engineering, image processing and optical character recognition. Its objective is to transform a camera image of a vehicle into the sequence of symbols on its registration plate. This objective is simple to state but difficult to achieve. The system must classify characters, but it must also find a small and often oblique object in a large image and decide which visual evidence belongs to the identifier. Early installations used fixed camera positions, nearly frontal views and one regional plate style. Under these conditions, hand-designed image-processing rules worked well. The conditions change when cameras are mounted on vehicles, installed at different heights or used in several regions. The plate then occupies a variable number of pixels, its angle changes, and the reflective material of the plate produces local overexposure. A system that works well for one camera or one plate style can therefore work poorly for another.

A conventional ALPR system has several stages. First, a detector finds candidate plate regions in the camera image. Second, a geometric normalization step produces a crop that is easier to read. Third, a recognizer returns a character string and a confidence value. Fourth, an optional post-processing step checks the string against known formats. In video, detection and recognition are combined with tracking and temporal fusion. This decomposition is useful because it shows where an error comes from. A recognition error can be caused by the recognizer. It can also be caused by a detector that cut off the first character, by a correction step that stretched a short row, or by a frame-selection step that chose a blurred image (Figure 3). If every error is attributed to the recognizer, the conclusions about recognition methods are wrong.

![Figure 3](figs/fig03_end_to_end.png)

*Figure 3. The detector, the geometric normalization step and the recognizer are separate subsystems. A recognition rate measured on plate crops cannot be compared directly with an end-to-end ALPR rate.*

### 1.1.2. Detection by learned visual features

Learned detectors replaced most hand-designed localization rules. YOLO showed that object localization and classification can be obtained in a single network evaluation [47]. Later designs such as YOLOv4 improved the balance between localization quality and real-time speed [48]. For license plates, a rectangular box is not always sufficient. A plate that is seen at an oblique angle becomes a quadrilateral in the image. A rectangle around it contains background and can cut characters after resizing. Silva and Jung therefore detected and corrected strongly distorted plates in unconstrained scenes [23]. Xu and colleagues released the Chinese City Parking Dataset (CCPD) with annotations of the four plate corners, which support corner-based correction [22]. These works also showed that the quality of the detector limits every recognizer that follows it. A perfect recognizer cannot restore a character that the crop has removed.

ALPR systems can be one-stage or two-stage. A one-stage system shares features between localization and transcription. A two-stage system separates detection from recognition, so that each stage can be developed and replaced independently. Xu and colleagues demonstrated a joint detection and recognition baseline on CCPD [22]. A joint design can avoid repeated feature extraction. However, it makes it harder to change the recognized alphabet, to add a stronger geometric correction step, or to analyze whether an error comes from localization or from reading. A modular pipeline is more convenient for research on recognition, because the detector can stay fixed while several recognizers are compared on the same crops. This paper uses the modular view.

### 1.1.3. Corner estimation, rectification, and their trade-offs

Geometric normalization has two forms. Explicit rectification uses the detected corners of the plate to compute a projective transform that maps the quadrilateral to a rectangle. Learned rectification, such as a Spatial Transformer Network, predicts the transformation inside the recognition network [15]. STAR-Net used a spatial transformer together with residual feature extraction for scene text [17]. Explicit rectification depends on accurate corners and on the assumption that the plate is planar. Learned rectification depends on the transformation model and on the training data. Strong distortions can sometimes be corrected. Other transformations can compress strokes or remove useful border features.

Rectification must also be judged by the real geometry of the plate. The border can surround two rows of text, an emblem can occupy part of the plate, and the rows can have different lengths. A projective transform straightens the plate surface, but it does not turn two rows of text into one row. In addition, resizing the crop to a fixed size changes the width-to-height ratio of the characters. A Chinese provincial character, a Latin letter and a digit have different stroke densities, so the same distortion can damage one class more than another. Preprocessing should therefore be evaluated by its effect on the recognition rate and on the character errors, not by the visual regularity of the corrected crop.

### 1.1.4. Chinese plates as an example of a multinational problem

Chinese registration plates are a useful case study, because one plate combines a Chinese provincial character, Latin letters and Arabic digits (Figure 4). The national standard GA 36 defines the plate types, sizes, colours and character rules.[^ga36] On a civilian plate, the first symbol is the abbreviation of the province, autonomous region or municipality. The second symbol is a letter that identifies the issuing authority. The remaining symbols form the serial. The letters I and O are not used in the serial, so that they cannot be confused with the digits 1 and 0. Small cars use a blue plate with seven characters. Small new-energy vehicles use a green plate with eight characters, in which the third character is D or F. Large new-energy vehicles use a yellow-and-green plate, in which the eighth character is D or F. Large vehicles carry a yellow one-row plate at the front and a yellow two-row plate at the rear. Trailers and motorcycles also use two-row plates. Some plates end with a special character, such as 挂 for trailers, 学 for driving-school vehicles and 警 for police vehicles, and plates of vehicles from Hong Kong and Macau end with 港 or 澳.

[^ga36]: Ministry of Public Security of the People's Republic of China, GA 36-2018, *License plates of motor vehicles of the People's Republic of China*, issued 20 April 2018 and implemented 1 May 2018. The format templates in this paper are simplified illustrations. A deployed system must follow the current official text.

![Figure 4](figs/fig_cn_plate_gallery.png)

*Figure 4. Chinese plate types and layouts that are used as examples in this paper. The plates differ in colour, length, number of rows and special characters. All plates are illustrative drawings with fictional strings.*

These rules show that one Chinese template does not cover every legal plate. A recognizer must learn the shape of each character, the script, the layout and the reading order. These properties are related, but they are not the same. The CCPD study supported experiments on localization and recognition under realistic distortions [22]. LPRNet then showed that a compact convolutional network can read Chinese plate crops without character segmentation, which made CTC-style recognizers attractive for embedded devices [21]. These results were obtained on particular data distributions and alphabets, mostly blue one-row plates. They do not show robustness to other layouts or to two-row plates. The value of Chinese plates for this paper is that they make mixed scripts, several colours, two layouts and explicit format rules visible in one country.

### 1.1.5. Character detection as an alternative to sequence recognition

Another family of methods detects each character separately and then builds the string from the character positions. For two-row plates, this approach has a conceptual advantage. The detector returns two-dimensional character coordinates, so the characters can be grouped into rows and sorted inside each row. The row structure is therefore explicit. The cost is that every small character must be detected and classified reliably. This becomes difficult at long distance, under reflections, and when characters touch each other. The ordering step also needs rules for row separation, separators and uneven character spacing.

Laroca and colleagues built real-time ALPR systems around learned character detection and showed practical operation on images from moving vehicles [24]. They later combined plate detection with layout classification, so that layout-specific rules could correct the recognized string [26]. Such systems are transparent, because missing characters can be seen directly, and they remain strong baselines. However, they add their own errors: a character can be missed, detected twice, assigned to the wrong row or confused with an emblem. When character detection is compared with CTC or with an attention decoder, the same plate crops and the same target strings must be used. Otherwise, one method can be credited or penalized for a different localization problem.

### 1.1.6. Why a controlled comparison of recognizers is needed

Historical studies differed in detectors, training splits, image sizes, alphabets and hardware. Some studies reported recognition under the condition that the crop was correct. Other studies reported the accuracy of a complete video pipeline. A speed that is measured on one GPU cannot be transferred to a CPU. A crop-level recognition rate cannot be compared with a track-level recognition rate. Baek and colleagues showed that inconsistent datasets and experimental choices can change the apparent ranking of text recognizers [20]. They proposed a framework with four stages: transformation, feature extraction, sequence modeling and prediction. This framework separates the effect of the visual representation from the effect of the decoding method.

This paper follows the same principle. Plate detection supplies a standardized crop. A shared visual encoder extracts the same type of two-dimensional features for all recognition heads. All heads use the same vocabulary, the same label normalization, the same input size policy and the same hardware. Published numbers from models with different encoders remain informative, but they cannot replace a controlled comparison.

## 1.2. Character Detection, CTC, Attention-Based Recognition, and Their Combination

### 1.2.1. From segmentation to segmentation-free recognition

A traditional text-recognition pipeline isolates each symbol before it classifies the symbol. It usually needs binarization, extraction of connected components and rules that separate touching characters. Such pipelines are sensitive to image quality and to national differences in fonts, spacing and decoration. They are especially fragile when a Chinese character consists of several separate strokes, or when blur merges neighbouring characters. Segmentation-free recognition learns a direct mapping from the plate image to the character sequence. It still makes assumptions about alignment, but it does not need a precise box for every character in the training data.

Connectionist Temporal Classification (CTC) was introduced for sequence labelling when the alignment between input frames and output symbols is unknown [11]. In text recognition, the input frames are positions of the visual feature map instead of moments in a speech signal. CRNN combined convolutional features, recurrent sequence modeling and CTC in one network that is trained end to end [12]. The main benefit is that a label for the whole string is enough for training. The annotator does not need to mark the boundaries of each character. This matters for multinational data, in which character-level boxes are expensive and inconsistent.

### 1.2.2. Understanding CTC correctly

CTC adds a special blank symbol to the vocabulary and allows a symbol to be emitted at several consecutive time steps. A collapse operation first merges consecutive repeated symbols and then removes the blanks [11]. For example, the frame-level prediction *blank, A, A, blank, 1, blank, 1* represents the string *A11*, because a blank separates the two copies of the digit 1. CTC therefore does not forbid repeated characters. It needs enough time steps and a blank in the correct place. Recognition becomes difficult when two identical neighbouring characters receive too few time steps, or when the order of the visual features does not match the order of the label.

The alignment assumption of CTC concerns the relation between feature positions and output order. In a horizontal word, the features progress from the left edge to the right edge, which is the reading order. In a two-row plate, the correct reading order is the whole upper row followed by the whole lower row. A simple horizontal collapse of the two-dimensional feature map mixes the two rows (Figure 5). CTC itself does not prevent two-row recognition. Line segmentation, a row-aware serialization of the features or a learned rearrangement of the features can all produce a valid order. The limitation is in the way the visual grid becomes a sequence. Chapter 2 addresses exactly this point with learned reading-order queries.

![Figure 5](figs/fig04_row_interleaving.png)

*Figure 5. Correct row-by-row reading order compared with the mixing of rows that a single horizontal scan produces on a two-row plate. The plate string is fictional.*

### 1.2.3. STAR-Net, LPRNet and the CTC lineage

STAR-Net, introduced in 2016, is an informative historical example, because it combines a learned spatial transformation with a residual feature extractor [16,17]. The transformation corrects distorted text before recognition. Residual blocks extract fine features without the optimization problems of very deep plain networks. The broader line of work couples such features with recurrent sequence modeling and a CTC head. This gives a clear progression: normalize the crop, compute visual features, arrange the features as a sequence and transcribe the sequence without character segmentation.

The strengths of this progression are clear. Labels for whole strings are cheap, convolutional features are effective for small strokes, and the CTC head is highly parallel. The weaknesses are also structural. Recurrent layers add sequential computation. Fixed input sizes distort unusual plate shapes. A one-dimensional feature sequence loses the vertical order of the characters. LPRNet is an efficiency-oriented example of a different kind. It is a lightweight convolutional recognizer without recurrent layers, and it reads Chinese plates in real time [21]. A dedicated plate vocabulary and short strings allow simpler inference than general scene-text recognition. However, strong regularities in one national dataset do not show that a recognizer can separate two rows or read a new writing system. These two paths, STAR-Net with geometric correction and LPRNet with compact design, motivate an evaluation that considers both alignment robustness and computational cost.

### 1.2.4. Attention-based sequence decoding

Attention-based recognizers select the relevant regions of the visual representation for each output position. RARE and ASTER combined rectification with attention decoding for irregular words. SAR attended to a two-dimensional feature map, and MORAN combined a rectification network with an attention-based recognizer [18,19,31,32]. Attention gives a more flexible connection between an output position and its source pixels than a fixed horizontal scan. This is attractive for two-row plates, because a decoder can, in principle, attend to the upper row first and to the lower row second. This ability is not automatic. It depends on the training data, on whether the features keep vertical detail, and on whether the decoder learns the intended reading order.

An autoregressive decoder generates one symbol at a time, and each symbol is conditioned on the previous symbols. Transformer-based recognizers such as NRTR and SATRN applied this design to scene text [33,35]. The conditional structure lets the decoder use context and handle strings of variable length. It also makes decoding sequential: the decoder must wait for one prediction before it can form the next one. For six to eight characters, the absolute delay can be small. However, the number of sequential steps grows with the string length, and sequential decoding can be difficult to optimize on some embedded runtimes. An early wrong character can also influence the following steps and lead to a coherent but wrong continuation.

### 1.2.5. Parallel prediction and language context

Before 2024, SRN, ABINet, VisionLAN and PARSeq showed different ways to combine visual and linguistic information in scene-text recognition [30,36–38]. A character that is visually ambiguous is easier to identify when the neighbouring characters and the plausible word structures provide additional evidence. Words and license plates are different, however. A word recognizer benefits from vocabulary statistics. Plate identifiers are designed to be arbitrary within their format. The useful linguistic knowledge for plates is therefore structural: which character classes may appear in which slot of which format. It is not lexical knowledge about frequent words.

Parallel prediction computes all characters at the same time. However, predicting each output slot independently from a fixed position query does not model the relation between the number of characters, their order and their content. A decoder may recognize the correct set of symbols but place them in the wrong order, especially when the rows are offset. It may also fill one slot twice and leave another slot empty. Replacing autoregression with a set of classifiers is therefore not enough. The decoder needs structural information, so that each output slot corresponds to the correct visual evidence. This is the motivation for the context-perception methods that Chapter 3 discusses.

### 1.2.6. Vision Transformers and spatial representation

Vision Transformers encode an image as a sequence of patch tokens and use self-attention to model the relations between the tokens [40,41]. A recognizer that collapses the feature map into a horizontal sequence early loses the vertical structure. A ViT-style encoder can keep a two-dimensional grid of tokens until the prediction stage. Hierarchical designs such as the Swin Transformer combine local detail with wider context at several scales [43]. In text recognition, ViTSTR used a plain Transformer encoder for efficient recognition [34]. SVTR showed that a single visual model, built from local and global mixing blocks, can recognize scene text without a recurrent sequence model [39].

These works show that a ViT-style encoder is a suitable shared basis for a CTC head and an attention decoder. However, two recognizers are not equivalent only because both use attention. Patch size, positional encoding, input resizing, pooling and the shape of the feature grid decide what information reaches the prediction head. For license plates, the vertical resolution of the feature grid is especially important, because it decides whether two rows of characters remain separable.

### 1.2.7. Combining CTC with attention and with external knowledge

Speech recognition and text recognition already provide several ways to combine CTC with attention decoders and with external linguistic knowledge. CRNN supported lexicon-based transcription, in which the CTC output is matched against a lexicon [12]. EESEN decoded CTC outputs with weighted finite-state transducers, which add lexicons and language models to the search [44]. CTC prefix beam search is an efficient algorithm that can combine CTC probabilities with other scores during decoding [70]. The hybrid CTC/attention architecture trains one shared encoder with a CTC objective and an attention decoder, and it decodes with a joint score of both [13]. GTC uses an attention decoder only during training, to guide the feature alignment of a CTC text recognizer, and it keeps the fast CTC inference [42]. Mask CTC starts from the greedy CTC output, masks the tokens with low confidence and predicts them again in parallel with a conditional masked decoder [14].

These methods show that CTC and attention are complementary. CTC supplies an efficient monotonic alignment, and the attention decoder supplies context. Constrained search shows how external knowledge can enter CTC decoding without retraining. However, none of these methods was designed for two-row layouts or for the structured, country-specific formats of license plates. Their ideas are a starting point for the method of this paper, not a solution to the plate problem.

## 1.3. Multinational Datasets, Two-Row Layouts, Plate Formats, Degradation, and Research Gaps

### 1.3.1. Why the country of origin changes the recognition task

License plates are not one universal visual language. They differ in character inventory, character arrangement, colour, proportions, permitted symbols and official format rules. Some countries use only Latin letters and digits. Other countries combine local characters with Latin letters, or use non-Latin scripts. A model whose vocabulary does not contain a legitimate symbol cannot predict that symbol, however strong its encoder is. An ordering method that assumes one row reads a two-row plate incorrectly, even when it detects every character. These are design limitations, not only problems of image quality.

Henry and colleagues addressed multinational recognition with generalized character-sequence detection. They explicitly recognized that specialization to one national format limits deployment across borders [27]. Their work treats layout and characters as a problem of the whole system, not as a local classification problem. A robust multinational recognizer must not encode one national format as a universal rule. Format information can increase confidence after transcription, but the visual recognizer must remain able to read a string that does not follow the dominant format. This matters because new plate series appear and vehicles from other regions enter a deployment unexpectedly.

### 1.3.2. What the main pre-2024 datasets measure

The Taiwanese AOLP benchmark covers three imaging conditions: access control, law enforcement and road patrol [25]. CCPD provides a large collection of Chinese blue one-row plates with varied distortions and corner annotations [22]. UFPR-ALPR contains video frames of moving vehicles that several cameras recorded [24]. RodoSol-ALPR contains 20,000 images from toll booths, with Brazilian and Mercosur layouts. Half of its images show motorcycles, whose plates have two rows of characters [28]. The Chinese Road Plate Dataset (CRPD) provides road-surveillance images with plate-type labels. The labels distinguish blue plates, yellow one-row plates, yellow two-row plates and white plates [46].

These datasets do not cover the same vehicles, cameras, scripts or weather conditions. Their reported accuracies therefore cannot be placed in one ranking. Their annotation protocols also differ. Some datasets provide only plate strings. Others provide the plate corners or character boxes. Only some datasets provide the row structure that a two-row evaluation needs. A recognizer that is trained on plate crops needs text labels. A projective correction step needs corners. A multi-frame study needs a track identifier that proves that several frames show the same physical plate. Without this information, wrong grouping of images can produce an artificially strong agreement between frames. Dataset licences and privacy rules also matter, because images with registration numbers are often restricted to research use.

### 1.3.3. Two-row layouts and multi-line recognition methods

Two kinds of change are often confused. A *format shift* changes the sequence of allowed character classes. A *layout shift* changes the spatial arrangement of the characters. RodoSol-ALPR contains both kinds of change, because Brazilian and Mercosur plates differ in format and motorcycle plates differ in layout [28]. A recognizer can generalize to a new character order and still fail on two-row geometry. Another recognizer can follow both rows correctly and still impose an obsolete format. These failure modes should be measured separately. The same reasoning applies to Chinese plates. A blue one-row plate, a green new-energy plate and a yellow two-row plate differ in colour, length and spatial arrangement. Colour alone should not decide the reading. A model can learn that a blue background predicts one pattern and a green background predicts another, but this shortcut fails in unusual lighting or in images from another camera.

Dedicated multi-line plate recognizers existed before this paper. Cao and colleagues proposed an end-to-end network that reads both one-line and two-line plates without segmenting the image into lines [45]. Chen and colleagues proposed an end-to-end multi-line recognizer that cascades global type perception with parallel character perception, in order to improve both accuracy and inference speed [57]. The second design is the closest precedent to the present work: it predicts the plate type from global features and then reads all characters in parallel. However, it depends on a correct prediction of the plate type, it does not combine the parallel reader with a CTC branch, and it does not use the plate format as explicit, soft knowledge.

In document recognition, the same problem appears on a larger scale. OrigamiNet converts a single-line CTC recognizer into a multi-line recognizer for full pages without any line segmentation, by learning to unfold the two-dimensional feature map into one long sequence [49]. It shows that CTC itself is not limited to one line: the limit lies in how the features are arranged. A license plate is a much smaller case with at most two short rows, so a full unfolding of the feature map is not necessary, but the principle is the same.

### 1.3.4. Plate formats, layout classification, and the risk of overcorrection

National rules restrict which characters may appear in which positions. These restrictions are valuable when the plate type is known. Laroca and colleagues classified the plate layout together with detection and used layout-specific heuristic rules to correct the recognized string [26]. Such rules can reject impossible outputs and help to choose between several likely candidates. However, the same restrictions can create artificial accuracy when a test set contains almost only known templates. A misread character can be replaced by the only character that the rule permits, which produces a correct answer even though the visual reading was wrong. When the system later meets a new plate series or a foreign plate, the same rule becomes a source of systematic errors.

Three conclusions follow for the design of a format-aware recognizer. First, the raw recognition result and the format-corrected result should be reported separately, because the raw result shows visual generalization and the corrected result shows the benefit for a defined application. Second, format knowledge should be applied in a way that strong visual evidence can overrule. Third, the plate type should not be decided before the characters are read, neither from the deployment site nor by a separate classifier. Vehicles from other regions and new plate types appear at every site, and no classifier of plate types is correct for every plate. A wrong early decision applies the wrong rules and cannot be repaired later. Chapters 2 and 4 turn these conclusions into a soft use of format knowledge that needs no classification of the plate type.

### 1.3.5. Label normalization

An ALPR recognizer predicts a string, but a benchmark often evaluates a normalized version of that string. Depending on the dataset, separators, decorative marks, regional symbols and uncertain characters are kept, removed or merged. This changes both the character vocabulary and the definition of a correct prediction. A method that reads every visible character correctly can receive an error if its output contains a symbol that the ground truth omits. Another method can appear more accurate because its post-processing silently removes symbols that the test set ignores. Studies before 2024 already showed that such evaluation conventions can change conclusions substantially [20,28,29]. A defensible comparison must therefore keep the raw annotation, state the normalized form, and distinguish a reading error from a label-conversion error. For Chinese plates, this applies, for example, to the separator dot after the second character, which this paper does not include in the label.

### 1.3.6. Dataset bias, near-duplicates, and apparent generalization

Laroca and colleagues showed that license plate datasets contain identifiable signatures of their acquisition sources [29]. A recognizer can therefore score well partly because its test images resemble its training images in camera, compression, background or font. The same model can score much lower when these details change. The same group also showed that near-duplicate images, shared between the training and test splits of popular datasets, inflate the reported recognition rates [68]. A strong result on several datasets is more convincing when the evaluation includes held-out cameras, plate types or countries, and when the split is made at the level of the vehicle or the track instead of the image.

A useful evaluation trains on some formats and tests on others, with a realistic output alphabet. Holding out a format whose characters are already known tests composition and layout generalization. Holding out a script with unseen characters tests a different ability, which normally requires new labelled data or a larger vocabulary. These two questions must not be confused. For Chinese plates, a model that was trained in China knows the provincial characters, but it does not know the characters of unrelated scripts. A model is not multinational only because it reads Chinese characters and Latin letters.

### 1.3.7. Visual degradation and the information limit

Low-resolution plate recognition is not ordinary image classification. One wrong character makes the whole identifier wrong, and a character stroke can be only one or two pixels wide. Downsampling removes the separation between similar symbols. Motion blur merges neighbouring strokes. Compression creates block edges that look like strokes. Reflections can erase whole character regions. Some symbols in Chinese plates are particularly easy to confuse at low resolution (Figure 6). The letter B and the digit 8, the letter D and the digit 0, the letter Z and the digit 2, and the letter S and the digit 5 differ by a few pixels. Several provincial characters, such as 津, 沪, 渝, 湘 and 浙, share the same left component, so only the right part separates them. If different plate strings produce almost the same pixels, no recognizer can guarantee the correct string. Context can only choose the most plausible string, and this is different from observing the true characters.

![Figure 6](figs/fig_cn_confusable.png)

*Figure 6. Confusable symbols in Chinese plates. Each symbol is shown clean and at low resolution. Letter–digit pairs and provincial characters with the same left component become hard to separate when the resolution drops.*

The scene-text literature already identified low resolution, occlusion, unusual fonts and labelling problems as persistent challenges [20]. Super-resolution can make an image look sharper, but a sharper image does not prove that the character identity is preserved. A recognition-oriented study must ask whether an enhancement improves the exact transcription of unseen real images. Several frames of the same plate are another source of evidence. Neighbouring frames can show different unblurred strokes or different reflection patterns. They add real observations, although they do not guarantee a perfect result. These observations motivate the treatment of degraded plates in Chapter 4.

### 1.3.8. Research gap and questions addressed

The literature before 2024 established capable detectors, learned rectification, efficient CTC recognizers, attention decoders, ViT-style encoders, multi-line plate recognizers and datasets from several countries. Outside license plate recognition, it also showed that CTC and attention decoding can be trained together and combined at inference [13,14,42], and that CTC decoding can use external knowledge through constrained search [12,44,70]. Three questions remained open for license plates:

1. How can a recognizer read one-row and two-row plates with the efficiency of CTC, without separating the rows, also when the plate is rotated, shifted or warped?
2. How can a recognizer use the official plate formats as linguistic context, without a classifier of the plate type and without losing plates whose format is unseen?
3. How can a recognizer apply the visual and linguistic context of a decoder only to the plates that need it, so that the average cost stays low?

This paper answers these questions with three design decisions. Chapter 2 develops a CTC branch with reading-order queries and a format score for candidate strings. Chapter 3 develops a context-aware parallel decoder. Chapter 4 combines the two parts with a confidence gate, a joint score and explicit safeguards against overcorrection. Chapter 5 defines an evaluation that separates the effects of layout, format and degradation, and it reports projected results that will be replaced by measurements.


# Chapter 2. Efficient CTC-Based Recognition for One-Row and Two-Row Plates

This chapter develops the CTC side of the proposed recognizer. Section 2.1 explains what CTC computes and why its assumptions matter for license plates. Section 2.2 describes SVTRv2 as published by its authors [50], because SVTRv2 is the starting point of the proposed CTC branch. Section 2.3 presents the proposed extensions: reading-order queries, which replace the column-wise selection of SVTRv2, a training-only reading-order guidance, and a format score that applies the official plate formats without a classifier of the plate type. Sections 2.1 and 2.2 describe existing methods. Section 2.3 describes the new contributions of this paper.

## 2.1. Conventional CTC Recognition and Its Limitations

### 2.1.1. The task solved by CTC

In license plate recognition, the input is a rectangular array of pixel values and the output is an ordered string. Unlike ordinary classification, the model must predict several symbols and decide their order. The annotation normally records only the final registration string. It does not say which pixels correspond to the first character, to the second character or to a separator. CTC was created for this situation, in which a model produces a sequence of frame-wise probabilities while the correspondence between frames and labels is unknown [11]. The recognition network transforms the image into a feature sequence of length $T$. At each time step $t$, it predicts a probability distribution $P_t(c \mid x)$ over the vocabulary and an additional blank symbol. A collapse operation then produces the transcription.

Let $y=(y_1,\ldots,y_L)$ be the target string. A CTC *path* $\pi$ is a sequence of length $T$ over the vocabulary and the blank symbol. The collapse map $\mathcal{B}$ merges consecutive repeated symbols and then removes blanks. All paths that collapse to the same string are combined in the probability of that string:

$$P(y \mid x)=\sum_{\pi \in \mathcal{B}^{-1}(y)} \prod_{t=1}^{T} P_t(\pi_t \mid x). \qquad (1)$$

Dynamic programming computes this sum efficiently during training. CTC therefore needs no character boxes, and the classifier produces all frame probabilities in one forward pass. These two properties explain why CTC remains attractive for plates, whose strings are short and mostly regular. At inference, the simplest decoder takes the most likely symbol at every time step and collapses the result (greedy decoding). A beam search can recover from some local uncertainty, but it changes the speed of the system. Figure 7 shows a frame-level path for an illustrative Chinese plate string.

![Figure 7](figs/fig05_ctc_collapse.png)

*Figure 7. A frame-level CTC path for the illustrative plate string 京A88765. Repeated emissions are merged first, and blank symbols are removed second. The blank between the frames of the two copies of "8" keeps them as two characters. The path is illustrative, not the output of a trained model.*

### 2.1.2. Why output order is a question of visual representation

A CTC classifier does not know whether its time axis represents horizontal columns, a sequence of attended image regions, or the result of a learned spatial transformation. It only receives features at ordered positions. If these positions follow the characters in the same order as the label, CTC has a well-posed alignment problem. If the positions mix the upper and lower rows of a two-row plate, the training objective contradicts the representation. This distinction explains why a good CTC recognizer can fail on some two-row plates and succeed on others. The difficulty does not come from the blank symbol. It comes from a mismatch between the spatial evidence and the expected reading order.

Consider an illustrative two-row plate whose upper row is 京A and whose lower row is 8K723. A person reads 京A8K723. If the encoder merges the columns of both rows into one horizontal sequence, the evidence for 8 and for 京 can fall into the same column, and the following columns can mix K with A. CTC can still produce a sequence of seven symbols, but one feature frame cannot represent two glyphs that are visible at the same time as two separate output positions. The system must therefore keep enough time steps, map the spatial grid into the correct order, or receive separate crops of the two rows. This is the reason to examine the feature rearrangement of SVTRv2 in Section 2.2, and to extend it in Section 2.3.

### 2.1.3. Sequence capacity and repeated characters

CTC usually produces many more time steps than output characters. This redundancy is useful. The model can spread one character over several frames and use blanks to separate two neighbouring copies of the same symbol. Repeated characters are common on plates. Chinese serials such as 66888 or 11223 contain several repeated digits, and such "lucky number" plates are popular. Strong horizontal downsampling reduces the number of time steps. If a plate with eight symbols produces only eight time steps, the model cannot place a blank between repeated characters. In general, a string with $L$ characters and $r$ positions where a character repeats its predecessor needs at least $L+r$ time steps. The problem is not that CTC cannot output repeated characters. The problem is that a short time axis reduces the feasible alignments and puts pressure on the representation.

The number of time steps is therefore a property of the whole encoder and of the preprocessing, not only of the CTC head. A patch size that is economical for image classification can be too coarse for text with thin strokes. If one patch covers large parts of two neighbouring characters, no later stage can fully separate them. Resizing a plate to a fixed width also reduces the number of horizontal feature positions relative to the number of characters. In a fair comparison, the input size and the resolution of the feature grid must give enough capacity to every recognition head. The input sizes must be reported together with the results.

### 2.1.4. Aspect-ratio distortion as a source of errors

License plates have very different proportions. A Chinese blue plate is 440 mm wide and 140 mm high, so its aspect ratio is about 3.1. A yellow two-row rear plate is 440 mm by 220 mm, with an aspect ratio of 2.0. A motorcycle plate is 220 mm by 140 mm, with an aspect ratio of about 1.6. If all these crops are resized to the same width and height, some of them are strongly stretched or compressed. A digit can become unnaturally narrow, or a two-row plate can be flattened until the glyphs of the upper and lower rows overlap in the feature representation. This changes the geometry of the strokes before the recognizer can learn them. The effect is especially harmful for similar glyphs that differ only by a short bar, a diagonal or an internal gap, such as B and 8 or D and 0.

The effect is stronger when the image is already degraded. Downsampling a weak stroke and stretching it later cannot restore the original distinction. A model can still learn the dominant font of its training set, but this is fragile under new cameras or new plate types. Aspect-aware preprocessing is therefore not cosmetic. It changes which visual evidence remains observable. The SVTRv2 authors identify unsuitable fixed-size resizing as one source of poor performance on irregular text [50]. For plates, the value of aspect-aware resizing is largest when one service must read long one-row plates and short two-row plates.

### 2.1.5. Missing linguistic context and the danger of overcorrection

A plain CTC head classifies each frame independently, given the encoded features. This does not mean that the model has no context. A ViT-style encoder combines information from neighbouring characters before it produces the frame probabilities. Nevertheless, a plain CTC head does not explicitly model the dependencies between output characters. The SVTRv2 authors identify the weak use of linguistic information as a major reason why earlier CTC recognizers performed worse than encoder–decoder methods [50]. This is their motivation for semantic guidance during training.

License plates require care with linguistic context. Words in natural language have strongly constrained spellings, but plate identifiers are designed to be arbitrary combinations within a format. For a Chinese plate, the provincial character predicts the set of character classes that can follow, but each individual digit carries almost no information about its neighbours. A strong prior learned from a few dominant formats can improve familiar plates and harm unfamiliar plates. The most useful linguistic knowledge for plates is therefore the explicit format, not the statistics of frequent strings. Section 2.3 shows how the format can be used as a score for candidate strings without becoming a hard rule.

### 2.1.6. Inference cost is more than the CTC classifier

CTC is often described as inexpensive, because it needs only a linear classifier and a collapse operation. This comparison is meaningful only if the visual encoder is included. A large encoder can dominate the latency, whether its output goes to a CTC head or to a parallel decoder. CTC implementations also differ in input resizing, feature rearrangement, vocabulary size, greedy or beam decoding, and numerical precision. If the encoder processes a taller image for a two-row plate, the extra tokens can increase the cost of attention more than the final classifier does. In an end-to-end application, plate detection, rectification and multi-frame processing may cost even more. In this paper, efficiency therefore means the measured latency and memory of the whole recognition stage, under the same encoder and the same input sizes.

## 2.2. SVTRv2: Multi-Size Resizing, Feature Rearrangement, and Semantic Guidance

SVTRv2 improves a CTC recognizer in two directions [50]. First, it handles text irregularity with a multi-size resizing strategy (MSR) and a feature rearrangement module (FRM). Second, it adds linguistic context with a semantic guidance module (SGM), which is used only during training. The visual model is a hierarchical encoder with local and global mixing blocks. This section describes these components as published, and it explains what they do and do not solve for license plates.

### 2.2.1. Visual encoder

Let the resized plate image be $I \in \mathbb{R}^{H \times W \times 3}$. The encoder maps the pixels to a two-dimensional feature map $F \in \mathbb{R}^{H' \times W' \times D}$, where $H' = H/8$ and $W' = W/4$ in SVTRv2 [50]. Each spatial position of $F$ keeps its correspondence to a small region of the plate. The encoder has three stages of mixing blocks (Figure 8). A local mixing block uses two consecutive grouped convolutions to capture short-range structure such as edges and strokes. A global mixing block uses multi-head self-attention to relate distant regions, so that a symbol can be interpreted in the context of the whole plate [41,50]. In the published model variants, the first stage uses local blocks, the second stage uses local blocks followed by global blocks, and the third stage uses global blocks. Residual connections, layer normalization and channel-wise feed-forward networks stabilize the blocks (Figure 9).

![Figure 8](figs/fig06_encoder.png)

*Figure 8. The shared hierarchical visual encoder in the style of SVTRv2-T. The three stages are read in order. One height-only downsampling between stages reduces the height from H/4 to H/8, while the width resolution W/4 is kept for sequence decoding.*

![Figure 9](figs/fig07_mixing_block.png)

*Figure 9. A mixing block of the encoder. Each block uses either local mixing (two grouped convolutions) or global mixing (multi-head self-attention), followed by a residual connection and a feed-forward network.*

The output of the encoder is a spatial feature map, not a string. This distinction is central to this paper. The same feature at a given position can support a CTC alignment, a query of a parallel decoder or a layout classifier. FADR uses exactly this property: the three heads of the recognizer read the same feature map. The local mixing blocks help to separate the strokes of complex Chinese characters. The global blocks help when a shape is ambiguous in isolation, for example when two neighbouring strokes may belong to one Chinese character or to two Latin symbols. However, understanding the image at this level does not define the reading order of two rows. The recognition head must define how the feature positions are ordered.

### 2.2.2. Multi-size resizing (MSR)

Input normalization is not neutral. If a nearly square two-row crop is stretched to the same wide rectangle as a one-row plate, the geometry of the characters changes. The encoder then learns from distorted strokes, and the widths of the character regions may no longer suit sequence alignment. MSR makes the input size depend on the aspect ratio $R = W/H$ of the crop. SVTRv2 uses four predefined sizes: $64 \times 64$ for $R < 1.5$, $48 \times 96$ for $1.5 \le R < 2.5$, $40 \times 112$ for $2.5 \le R < 3.5$, and $32 \times \lfloor R \rfloor \cdot 32$ for $R \ge 3.5$ [50]. MSR keeps useful differences in height and width and still allows efficient batching. MSR is different from geometric rectification. MSR chooses a suitable tensor shape. Rectification corrects projective distortion in the image content.

Figure 10 shows how the main Chinese plate types fall into these buckets. Blue and green one-row plates, with aspect ratios of about 3.1 and 3.4, use the $40 \times 112$ bucket, which gives a feature grid of $5 \times 28$ positions. Yellow two-row rear plates and motorcycle plates, with aspect ratios of about 2.0 and 1.6, use the $48 \times 96$ bucket, which gives $6 \times 24$ positions. The two-row plates therefore receive more vertical resolution, which helps to keep the two rows separate in the feature map. Long one-row plates in other countries, for example European plates with an aspect ratio of about 4.7, use the widest bucket. The real aspect ratio of a crop also depends on the viewing angle and on the rotation of the plate, so the bucket of a plate type is not fixed. For example, the box around a two-row plate that is rotated by 15 degrees is almost square, and the crop falls into the $64 \times 64$ bucket. The bucket therefore cannot decide the number of rows, and the proposed method does not need this decision (Section 2.3.2).

![Figure 10](figs/fig_cn_msr_buckets.png)

*Figure 10. Multi-size resizing buckets of SVTRv2 applied to Chinese plate types. The bucket depends on the aspect ratio of the crop. Two-row plates receive more feature rows than one-row plates. Sizes are nominal; real crops vary with the viewing angle.*

### 2.2.3. Feature rearrangement module (FRM)

The FRM connects the two-dimensional feature map with the one-dimensional CTC label sequence (Figure 11). A simple recognizer could average the feature map over its height and treat the $W'$ columns as time steps. Such averaging discards vertical distinctions. The FRM instead computes an input-dependent rearrangement in two steps [50].

![Figure 11](figs/fig09_svtrv2_pipeline.png)

*Figure 11. Recognition process of SVTRv2. The inference path (solid arrows) consists of resizing, the hierarchical encoder, the horizontal and vertical steps of the FRM, the CTC classifier and the CTC collapse. The semantic guidance module (dashed arrows) receives the encoder features and is used only during training [50].*

The first step is a horizontal rearrangement inside each row of the feature map. For row $i$, with features $F_i \in \mathbb{R}^{W' \times D}$, a row-wise attention matrix reweights the features of that row, and a residual connection, layer normalization and a feed-forward network follow:

$$F^{h}_i=\mathrm{LN}\Big(F_i+\mathrm{softmax}\big(F_iW^{q}(F_iW^{k})^{\top}\big)F_i\Big),\qquad F'_i=\mathrm{LN}\big(F^{h}_i+\mathrm{MLP}(F^{h}_i)\big). \qquad (2)$$

The second step is a vertical selection. A single learnable *selecting token* $T^{s}$ attends to the $H'$ positions of each column $j$ of the horizontally rearranged features. The resulting weights pool the column into one feature vector:

$$a_j=\mathrm{softmax}\big(T^{s}(F'_{:,j}W^{k'})^{\top}\big),\qquad s_j=a_j\,F'_{:,j},\qquad j=1,\ldots,W'. \qquad (3)$$

The result is a sequence $S=(s_1,\ldots,s_{W'})$ of $W' = W/4$ feature vectors. A linear layer and a softmax then give the CTC probabilities at each of the $W'$ time steps (Figure 12). The same selecting token is shared by all columns, which the SVTRv2 authors report as helpful for generalization to longer text [50]. The mechanism keeps the parallel nature of CTC inference and makes the alignment more flexible than a fixed pooling rule. The SVTRv2 authors report that the FRM improves the recognition of multi-oriented text.

![Figure 12](figs/fig10_frm_softmap.png)

*Figure 12. Feature rearrangement as a soft mapping from a two-dimensional feature map to CTC time steps. The horizontal step mixes features inside each row. The vertical step pools each column into one time step, so seven columns give seven time steps.*

The extent of this flexibility must be stated clearly. The FRM was designed for irregular scene text, for example rotated or curved words, and the SVTRv2 paper does not evaluate two-row license plates. Equation 3 produces exactly one feature per column. In a two-row plate, each column of the feature map contains evidence from the upper row and from the lower row at the same horizontal position. The order "whole upper row, then whole lower row" is possible only if the horizontal step moves the features of the upper row to the left columns and the features of the lower row to the right columns, so that the selecting token can choose a different height in the two halves. Equation 2 allows such movements inside each row of the feature map, so the model may learn this behaviour from two-row training data. However, no part of the design encourages it, and it becomes harder when the plate is rotated, because a text row then crosses several rows of the feature map. Whether SVTRv2 reads two-row plates reliably is therefore an empirical question, and it is the first experiment of Chapter 5. The number of time steps is a second restriction: it equals the number of columns, so it depends on the width of the resized image and not on the length of the text. These two restrictions motivate the reading-order queries of Section 2.3.3.

### 2.2.4. Semantic guidance module (SGM)

CTC is sometimes described as having no context, but this description is not precise. The visual encoder already contains contextual interactions. The limitation is that the CTC objective does not explicitly model the dependencies between output characters, as an autoregressive decoder does. The SGM of SVTRv2 addresses this limitation during training. During training, the encoder features $F$ are fed into both the SGM and the FRM [50]. The SGM supervises the encoder with the left and right context of each character, so that the visual features learn relations between characters, not only local appearance (Figure 13). Because the SGM is not part of the inference path, the deployed model keeps the fast CTC classifier and the collapse rule.

![Figure 13](figs/fig11_sgm.png)

*Figure 13. Semantic guidance during training. The SGM receives the encoder features directly, in parallel with the FRM. It is removed at inference, but its effect remains in the encoder weights.*

The phrase "training only" needs a precise interpretation. Inference does not ignore all semantic context. The encoder parameters keep the effect of the semantic supervision, but the auxiliary module itself is absent. When a Chinese plate contains a provincial character that is visually ambiguous, semantic guidance may help the encoder to learn distinctions that are available in the surrounding appearance. However, no training-only module can reconstruct a stroke that is physically absent in the observation. A strong use of national syntax can also create confident but wrong corrections when plate formats change. Semantic guidance should therefore be understood as learned discriminative context, not as a guarantee that every output is a valid plate number.

### 2.2.5. CTC inference and the repeated-character case

The final CTC distribution covers the alphabet and the blank class. For a string that contains two successive copies of the same character, a valid path needs a blank between them (Figure 14). This detail matters for Chinese plates, because repeated digits are common in serials. The difficulty with repeated characters does not prove that CTC cannot learn such strings. It increases the sensitivity of CTC to the feature width, to the alignment and to the probability of the blank at the right positions. The FRM changes how the visual model builds the ordered sequence. It does not change the alignment rule of CTC.

![Figure 14](figs/fig12_ctc_repeated.png)

*Figure 14. CTC alignment for the illustrative plate string 京A11235, which contains a repeated digit. In path (a), a blank between the frames of the two copies of "1" keeps both copies after the collapse. In path (b), this blank is missing, the repeated frames merge, and one character is lost.*

### 2.2.6. What SVTRv2 does not solve for license plates

SVTRv2 is a strong and efficient starting point. Its encoder, MSR and FRM prepare an alignment-compatible sequence, and its SGM transfers context into the encoder. For the task of this paper, four limitations remain:

1. **Two-row order.** The FRM produces one time step per column. A two-row plate can be read only if the model learns to move the two rows into different columns, and nothing in the design supports this (Section 2.2.3).
2. **Geometric distortion of plates.** The link between time steps and columns assumes that the text runs along the width of the image. A rotated, shifted or warped two-row plate breaks this assumption, and the number of time steps changes with the size bucket of the crop.
3. **No use of plate formats.** The model can learn frequent patterns from data, but it cannot use the official format of a plate type as explicit knowledge. It has no mechanism to keep this knowledge soft for unseen formats.
4. **Uncalibrated confidence.** Greedy CTC decoding returns a string and frame probabilities. It does not provide a calibrated confidence for each character, which is needed to decide when a second reading is necessary.

Section 2.3 addresses these four points while keeping the published components of SVTRv2 unchanged where possible.

## 2.3. Proposed CTC Branch: Reading-Order Queries and Format Knowledge Without a Format Classifier

The proposed CTC branch changes one step of SVTRv2 and adds one kind of knowledge. The changed step is the vertical selection of the FRM, which is replaced by reading-order queries (Section 2.3.3) and trained with an additional guidance signal from synthetic data (Section 2.3.4). The added knowledge is the plate format, which is applied to strings and never to images, so that no classifier of the plate type is needed (Sections 2.3.5 and 2.3.6). The branch produces a draft string and a calibrated confidence for every character (Sections 2.3.7 and 2.3.8). Chapter 4 uses these outputs to decide whether the plate must also be read by the decoder of Chapter 3.

### 2.3.1. Four routes to the transcription of a two-row plate

Figure 15 compares four ways to read a two-row plate. The first route gives the whole crop to SVTRv2 and lets the FRM learn a sequence. It uses one recognizer call and no line detector, but the model must learn the row transition from data, and nothing in the design supports it. The second route separates the two rows, reads each row with the same CTC recognizer and concatenates the results. The rows can be separated in the image, by a splitter, or inside the network, by one selecting token for each row. This route is reliable when the rows are straight, horizontal and in the expected position. It needs to know that the plate has two rows, and it fails when the rows cannot be separated, which is discussed in Section 2.3.2. The third route uses a parallel decoder such as CPPD, whose position queries can attend to any region of the two-dimensional feature map. It handles any layout, but it costs more than CTC, and it must predict where the string ends. The fourth route is the proposed one. Learned reading-order queries attend to the whole feature map, and the outputs of the queries are the time steps of CTC. The route keeps one recognizer call and the cheap, parallel CTC head, and it needs neither a row count nor a row boundary.

![Figure 15](figs/fig13_two_row_routes.png)

*Figure 15. Four routes to the transcription of a two-row plate. Whole-image CTC must learn the row transition; row-split CTC needs straight rows and a row count; a parallel decoder attends to two-dimensional features at a higher cost; the proposed reading-order queries give CTC a sequence in reading order without any split.*

### 2.3.2. Why the rows cannot be separated reliably

Splitting a two-row plate into an upper part and a lower part looks simple, and it works for a plate that fills the crop and is seen from the front. Real crops are different. Figure 16 shows three common cases in which no simple split exists.

![Figure 16](figs/fig34_rot_problem.png)

*Figure 16. Why a two-row plate cannot always be split into rows. (a) On an upright plate, one horizontal cut separates the rows. (b) On a rotated plate, every horizontal cut crosses both rows. (c) When the crop is shifted or loose, the rows are not where a fixed cut expects them. (d) Under perspective, the rows are not parallel to the image border.*

The first case is rotation in the image plane. A camera that is rolled, a vehicle on a slope or a motorcycle that leans in a curve rotates the plate. If a plate of width $W_p$ is rotated by an angle $\theta$, the two ends of a text row differ in height by $W_p \sin\theta$. For a Chinese two-row plate with a width of 440 mm and a rotation of 15 degrees, this difference is about 114 mm, which is more than half of the plate height of 220 mm. The right end of the upper row is then lower than the left end of the lower row, and every horizontal cut crosses both rows. A column-wise selection has a related problem. A rotated character covers more columns than an upright one, because its height now contributes to its horizontal extent. Neighbouring characters of the same row then share columns, and one time step per column cannot keep them apart.

The second case is a shifted or loose crop. A detector does not return exact plate borders. The crop can contain a part of the bumper above the plate, or it can cut the upper border. A fixed cut at half of the crop height then crosses a row. The third case is perspective and warping. A plate that is seen from the side becomes a general quadrilateral, its rows are not parallel to the image border, and a bent plate has curved rows.

Rectification reduces some of these problems. A plate is flat, so four exact corners define a transformation that removes rotation and perspective. Rectification is therefore a useful pre-processing step, and it is a baseline in Chapter 5. It has three limits. It depends on accurate corners, and corner errors are largest on the small, blurred plates that are already difficult. It does not help when the detector gives only a box. It also does not decide the reading order: after a perfect rectification, the two rows still have to be read one after the other.

A further weak point is the decision itself. Every row-based method must first decide how many rows the plate has, and often which plate type it is. This decision is a classification, and no classifier is correct for every plate. A wrong decision cannot be repaired later, because the reading that follows depends on it. The design goal of this paper is therefore strict: the CTC branch must not need a row count, a row boundary, a rectified image or a plate type.

### 2.3.3. Reading-order queries (ROQ)

The reading-order queries keep the horizontal step of the FRM (Equation 2) and replace its vertical selection. SVTRv2 uses one selecting token, which looks only inside one column at a time, so the number of CTC time steps is the number of columns. The proposed module uses $T_q$ learned query vectors $q_1, \ldots, q_{T_q}$. Each query looks at the whole feature map, and the output of query $t$ is CTC time step $t$. Let $f'_i$ be the horizontally rearranged features at the $N = H'W'$ positions of the feature map, and let $p_i$ be a two-dimensional position encoding of position $i$. The query output is:

$$a_{t}=\underset{i}{\mathrm{softmax}}\Big(\frac{(q_tW^{q})\big((f'_i+p_i)W^{k}\big)^{\top}}{\sqrt{D}}\Big),\qquad s_t=\mathrm{LN}\Big(q_t+\sum_{i=1}^{N}a_{t,i}\,f'_iW^{v}\Big),\qquad t=1,\ldots,T_q. \qquad (4)$$

A feed-forward network with a residual connection follows, as in Equation 2. The sequence $S = (s_1, \ldots, s_{T_q})$ is the input of the CTC classifier, and the CTC loss and the collapse rule are unchanged. In practice, the attention of Equation 4 uses several heads, which is omitted from the equation for clarity. Figure 17 shows the module.

![Figure 17](figs/fig14_roq.png)

*Figure 17. Reading-order queries. Each query attends to the whole two-dimensional feature map, and query t gives CTC time step t. Early queries read the first characters in reading order and late queries read the last characters; unused queries emit blanks. The same module reads one-row plates, two-row plates and rotated plates.*

The module is a generalization of the published FRM. If every query were restricted to one column and all queries shared one vector, Equation 4 would become the vertical selection of Equation 3. The generalization removes three restrictions:

1. **A step is no longer tied to a column.** A query can collect its evidence from any region. Two characters that are stacked in one column are read by two different queries, and one character that covers several columns is read by one query.
2. **The number of steps no longer depends on the image width.** The crop of a rotated two-row plate is almost square, so MSR resizes it to $64 \times 64$ pixels, and the feature map has only 16 columns. The FRM would give 16 time steps. The queries always give $T_q$ steps. This paper uses $T_q = 24$, which is enough for the eight characters of the longest Chinese plate with a blank between all of them.
3. **Nothing in the module refers to rows.** A one-row plate and a two-row plate are read by the same queries with the same weights. The module has no layout input and no layout decision.

The order of the queries becomes the reading order through training. The CTC loss accepts only alignments in which the characters of the label appear in increasing order of the time step. Query 1 can therefore lower the loss only by reading a character near the start of the label, and query $T_q$ only by reading one near the end. For a two-row label, which lists the upper row first, the early queries learn to attend to the upper row and the later queries to the lower row. Unused queries learn to emit the blank symbol. The position encoding $p_i$ lets a query express where it looks, and the features $f'_i$, which come from an encoder with global mixing blocks, can express where a location lies along the text.

This reasoning also shows the limit of the module. The reading order is learned from the labels, as in a parallel decoder. It is not fixed by the architecture. If the training data contain no two-row plates, the queries will not read them correctly. The guidance signal of Section 2.3.4 and the synthetic data of Section 4.3.1 are therefore part of the method, not optional additions.

The module is different from the parallel decoder of route 3 in two ways. First, it has no character context and no stack of decoder layers. It is one attention step over the feature map. Second, it is trained with CTC. The blank symbol absorbs the unused queries, so the module does not predict an end symbol or a string length, and a small shift of the alignment between neighbouring queries costs nothing. It is also related to OrigamiNet, which turns a single-line CTC recognizer into a multi-line recognizer for full pages by learning to unfold the two-dimensional features into one long sequence [49]. OrigamiNet unfolds with convolutions and resampling. Its output length grows with the page, which is necessary for pages and is not needed for a plate with at most ten characters. The queries of this paper give a short sequence of fixed length, which keeps the cost of the CTC head independent of the image size.

### 2.3.4. Training: one CTC loss and reading-order guidance

The CTC branch is trained with the CTC loss of the complete string (Equation 1), computed on the $T_q$ query outputs. The label of a two-row plate is the upper row followed by the lower row. No row annotation is needed, neither in the label nor in the image. This is a practical advantage over the row-based route, because many datasets give only the string.

The CTC loss alone supervises the reading order indirectly, through the labels. Synthetic plates allow a direct signal. The renderer of Section 4.3.1 knows the box of every character and its index in the reading order, also after rotation, shift and perspective. From this knowledge, a target map is built on the feature grid. A feature position $i$ that lies inside the box of the $j$-th character of a string with $L$ characters receives the reading-order coordinate $r_i = (j - 0.5)/L$. The coordinate grows from 0 to 1 along the reading order: it is small for the first character of the upper row and large for the last character of the lower row. A linear layer with a sigmoid predicts this coordinate from the encoder features, and the loss is the mean absolute error over the set $\Omega$ of positions that lie inside a character box:

$$\mathcal{L}_{\text{ord}}=\frac{1}{|\Omega|}\sum_{i\in\Omega}\Big|\,\sigma\big(w^{\top}f_i\big)-r_i\Big|,\qquad r_i=\frac{j(i)-0.5}{L}. \qquad (5)$$

Figure 18 shows the target map for a rotated two-row plate. The loss is applied only to synthetic plates, because only they have character boxes. Like the semantic guidance of SVTRv2, the reading-order guidance is used only during training. The linear layer is removed at inference, and the deployed model is unchanged. The guidance makes the encoder features carry an explicit coordinate along the reading path, which is exactly the information that the queries need in order to select "the next character".

![Figure 18](figs/fig25_order_guidance.png)

*Figure 18. Reading-order guidance on a synthetic two-row plate that is rotated by 15 degrees. (a) The renderer knows the box and the reading index of every character, also after the rotation. (b) The target map assigns each character a coordinate that grows along the reading order. (c) The guidance is a training-only loss on the encoder features; the queries then find the characters in this order.*

The geometric variation of the training data matters as much as the loss. Real and synthetic training crops are rotated by up to 30 degrees in both directions, shifted, scaled and warped by a random perspective transformation. The label never changes under these transformations, so the CTC loss teaches the queries that the reading order follows the plate and not the image border.

### 2.3.5. Plate format templates and automata

A format template describes one plate type as a sequence of slots. Each slot has a slot type, that is, a set of allowed characters. Figure 19 shows simplified templates for the main Chinese plate types. The slot types are: P, a provincial character; L, a letter without I and O; A, a letter or a digit without I and O; N, a digit; E, the energy code D or F; and S, a special final character such as 挂, 学, 警, 港 or 澳. For example, the Chinese small-car plate has the template P L A A A A A, the small new-energy plate has P L E A N N N N, and the yellow two-row rear plate has P L in the upper row and A A A A A in the lower row.

![Figure 19](figs/fig_cn_format_templates.png)

*Figure 19. Simplified format templates of Chinese plate types. Each slot has a type. The templates are compiled into automata that check strings. A string that fits no template belongs to the open format, which receives a lower prior.*

Each template defines a set of valid strings: a string is valid for a template if it has the right length and each character belongs to the type of its slot. Some official rules cannot be expressed slot by slot. For example, the serial of a Chinese plate may contain at most two letters. This rule depends on several slots together. Both kinds of rules can be expressed by a finite automaton. The states of the automaton record the current slot and, where necessary, a small counter such as the number of letters used so far. Each template $k$ is compiled into a deterministic automaton $\mathcal{A}_k$ with a start state, transitions labelled with characters and one or more final states. A string is valid for template $k$ if the automaton reaches a final state after reading it.

The recognizer uses the templates only as sets of strings. The row structure of a template is used by the renderer of the synthetic data, which must draw the plate, but not by the recognizer, which reads the rows through its queries. The templates of a deployment are combined into one graph, in which templates with a common prefix share their first states, because all Chinese civilian templates begin with a provincial character and a letter. Checking a string of eight characters against all templates takes a few table look-ups. Building the graph is a one-time offline step, and adding a new plate type requires only a new template (Section 4.4.4).

### 2.3.6. Format knowledge without a format classifier

Earlier systems applied format rules after a classifier had decided the plate type [26]. This order creates the problem that Chapter 1 described. A classifier of plate types is never correct for every plate, and a format rule that is applied after a wrong classification changes a correct reading into a wrong one. The proposed method removes the classifier. The plate type is not predicted from the image at any point. A format is treated as a property of a candidate string, and a candidate string either fits a template or does not.

Each template $k$ has a prior $\pi_k$, which describes how common the plate type is at the site, for example the share of new-energy vehicles in a city. The *open format* stands for all strings that fit no known template, and it has a small prior $\pi_{\text{open}}$. The format score of a string $y$ is:

$$\phi(y)=\begin{cases}\log\,\max\big\{\pi_k : y\in\mathcal{L}(\mathcal{A}_k)\big\}, & \text{if } y \text{ fits at least one known template},\\ \log\,\pi_{\text{open}}, & \text{otherwise}.\end{cases} \qquad (6)$$

The score is used in three places. First, the gate of Chapter 4 checks whether the draft fits a known template. A draft that fits none is sent to the decoder, even when its characters are confident. Second, the joint score of Chapter 4 adds $\phi(y)$, with a weight, to the recognition scores of every candidate. Third, strings that win under the open format are logged, because many such strings with the same structure indicate a new plate series (Section 4.4.3).

Figure 20 illustrates the idea. Suppose that the CTC evidence for the second character of a blurred plate favours the digit 8 over the letter B. The candidate 粤8D12345 fits no template, because the second slot of every civilian template holds a letter. It receives the open-format prior. The candidate 粤BD12345 fits the template of the small new-energy plate and receives the prior of that template. The format score therefore supports the second candidate, and the B/8 confusion is resolved without any change to the network. The decision is still soft. If the plate really has an unusual format, and the recognition evidence for 粤8D12345 is strong, the open-format candidate can win.

![Figure 20](figs/fig15_format_automaton.png)

*Figure 20. Plate formats as automata that check candidate strings. Templates are sequences of slot types; each template becomes a chain automaton; a string that fits no automaton receives the open-format prior. In the example, the candidate with the letter B fits the small new-energy template, and the candidate with the digit 8 fits no template.*

Three properties follow from this design. First, there is no decision that can fail before the reading: candidates of different plate types compete only at the end, on the same evidence. Second, the format never removes a candidate. A hard rule deletes every string outside the known templates; the format score only lowers its score by a finite amount. Third, the knowledge is exact and readable. The templates are a small file that a domain expert can check against the official specification (Section 4.1.4).

The format score also has a clear limit. It can separate two candidates only when one of them fits a template and the other does not, or when they fit templates with different priors. It cannot decide between B and 8 in a serial slot of type A, which allows both. Such confusions need the context of the other characters and a second look at the image, which is the task of the decoder in Chapter 3.

### 2.3.7. Algorithm and worked example

Algorithm 1 summarizes the inference of the CTC branch. Most plates end at step 9. The beam search of step 10 is the standard CTC prefix beam search [70], and it runs only for the plates that fail the gate.

```text
Algorithm 1. Inference of the CTC branch for one plate crop

Input : plate crop x; automata A_k of the known templates;
        gate threshold tau_g; number of candidates N
Output: draft string g with character confidences, the gate decision,
        and, if the gate fails, the N best strings

1  F  <- encoder(MSR(x))                  # feature map, H' x W' x D
2  F' <- horizontal step of the FRM       # unchanged from SVTRv2
3  S  <- reading-order queries on F'      # always T_q vectors
4  P  <- CTC classifier(S)                # T_q distributions
5  g  <- greedy CTC decoding of P         # merge repeats, remove blanks
6  kappa_j <- calibrated confidence of every character of g
7  valid   <- g is accepted by at least one automaton A_k
8  if min_j kappa_j >= tau_g and valid:
9      return g as the final string       # the decoder is not used
10 H  <- N best strings of a CTC prefix beam search on P
11 return g, the confidences and H        # continue with Chapter 4
```

A worked example shows how the parts act together on a Chinese yellow two-row rear plate with the string 沪A / 12345, which is rotated by 15 degrees in the image. The box around the rotated plate is almost square, with an aspect ratio of about 1.48, so MSR resizes the crop to $64 \times 64$ pixels, and the encoder produces a feature map of $8 \times 16$ positions. The 24 queries attend to this map. The first queries attend to the upper left region and emit 沪 and A. The following queries move along the rotated lower row and emit 1, 2, 3, 4 and 5, with blanks between them. The last queries emit blanks. Greedy decoding gives the draft 沪A12345. No step of this process used the number of rows, the rotation angle or the plate type.

If the image is clear, every character has a high confidence, the draft fits the template of the yellow two-row plate, and the draft is the final result. If the image is blurred and the fourth character is read as Z, the draft 沪A1Z345 still fits the template, because the slot type A allows the letter Z. The format cannot detect this error. However, the confidence of Z is low, because the probabilities of Z and 2 are close. The gate fails, and the plate is passed to the decoder of Chapter 3.

### 2.3.8. Calibrated character confidence

The gate of Chapter 4 needs a confidence value for each character of the draft. The best CTC path assigns one or more query steps to each output character. The confidence $\kappa_j$ of character $j$ is the highest probability of that character over its steps. CTC probabilities are often peaked, and step probabilities are not calibrated probabilities of correctness. The confidences are therefore calibrated with temperature scaling on a validation set [69]. After calibration, a confidence of 0.95 means that, on validation data, about 95 percent of the characters with this confidence are correct. The calibrated confidences are used for two purposes: to accept or reject a draft at the gate, and to report a plate-level confidence with the final output.

Figure 21 applies this procedure to the blurred plate of the worked example in Section 2.3.7. The steps that emit 1, 3, 4 and 5 have high probabilities. The step that emits Z has a low probability, because the character 2 receives almost the same probability. After calibration, the confidence of the fourth character is below the gate threshold, so the plate is sent to the decoder. The example also shows why the confidence is needed per character and not only per plate: six of the seven characters are read with high confidence, and one uncertain character is enough to make the string unreliable.

![Figure 21](figs/fig26_slot_confidence.png)

*Figure 21. Calibrated character confidence of the draft 沪A1Z345. (a) The confidence of a character is its highest probability over its query steps; the step of Z is uncertain because 2 is a close second. (b) After temperature scaling, the confidence of the fourth character is below the gate threshold, so the plate is sent to the decoder. The values are illustrative.*

A confidence has a blind spot, which must be stated clearly. A character can be wrong and confident at the same time. The gate accepts such a draft when it also fits a template. Calibration reduces the number of these cases, and the format check catches the cases in which the wrong string fits no template, but neither removes them completely. Chapter 5 therefore reports the recognition rate of the plates that pass the gate as a separate number.

### 2.3.9. Computational cost of the CTC branch

The CTC branch changes the cost of SVTRv2 very little. The queries add $T_q$ vectors and one attention step between 24 queries and at most a few hundred feature positions. The CTC classifier now processes 24 vectors for every image size, which is the same number as for the $48 \times 96$ bucket of SVTRv2 and fewer than for wide plates. The format check and the calibration are table look-ups on the CPU. The prefix beam search is needed only for plates that fail the gate, and it processes 24 steps with a small beam. The reading-order guidance costs nothing at inference, because it is removed after training.

### 2.3.10. Summary of Chapter 2

This chapter described CTC, explained why the order of the visual features decides whether CTC can read a two-row plate, and described the published components of SVTRv2. It then proposed a CTC branch with two new elements. Reading-order queries replace the column-wise selection of the FRM. They give CTC a sequence of fixed length in reading order for one-row, two-row and rotated plates, without a row split, a row count or a plate type, and they are supported by a training-only guidance signal from synthetic data. The format score applies the official templates to candidate strings, with a lower prior for strings outside all templates, so that format knowledge needs no classifier and never removes a candidate. The branch returns a draft with calibrated character confidences. It resolves most plates on its own. Chapter 3 develops the decoder, which reads the plates that the CTC branch cannot resolve with enough confidence.


# Chapter 3. Context-Aware Parallel Decoding Based on CPPD

This chapter develops the decoder side of the proposed recognizer. Section 3.1 explains what a decoder adds to a CTC recognizer and why autoregressive and conventional parallel decoders are not ideal for license plates. Section 3.2 describes the Context Perception Parallel Decoder (CPPD) as published by its authors [51]. Section 3.3 presents the proposed context-aware parallel decoder (CAPD). The decoder keeps the parallel computation and the context tasks of CPPD. It adds one mechanism, a character-context attention, with which it can both read a plate independently and judge candidate strings with the context of their characters. Sections 3.1 and 3.2 describe existing methods. Section 3.3 describes the new contribution.

## 3.1. Limitations of Autoregressive and Conventional Parallel Decoders

### 3.1.1. Why a decoder is useful for license plates

A decoder maps visual features to an ordered sequence of symbols. The word "decoder" is used in different ways in OCR papers. A CTC system already has an inference procedure that collapses frame predictions, but its prediction head is not a trainable attention decoder. An encoder–decoder recognizer keeps the spatial visual features and uses queries to find the regions that support each output position. This makes recognition more flexible when the text is tilted, curved or arranged irregularly. On a license plate, this flexibility matters when the characters occupy two rows or when a special character is placed apart from the main sequence.

The essential difference between the two families is how the recognizer connects an output position with the visual evidence. A CTC system needs a monotonic or suitably rearranged feature sequence and learns an implicit alignment along that sequence. A spatial attention decoder uses a query for each output position and attends across the whole feature map. This helps when the next character is not simply to the right of the previous one. However, attention does not replace correct labels and representative training data. If all training images show one row, a decoder does not automatically infer that a new two-row design must be read upper row first. It must learn the rule from supervision. The decoder of Section 3.3 learns it from two-row training data, which includes synthetic plates with exact labels.

### 3.1.2. Autoregressive character generation

In an autoregressive system, the model predicts the characters one after another. The next output depends on the image and on the characters that the model has already generated. This conditional structure is familiar from machine translation and language modeling, and it makes context helpful. When the visual evidence for a digit is ambiguous, the characters generated so far can influence the next prediction. For plates, the context is partly structural, because some countries restrict positions to digits or to letters, and partly visual, because earlier decisions influence which image region the decoder attends to next.

The sequential dependence has two costs. First, the decoder needs a chain of decoding steps. Even when each step is cheap, the chain has more synchronization points than a parallel prediction. For short plate strings, the absolute difference can be small, but on small CPUs and in high-throughput systems it must be measured. Second, autoregressive decoding has a characteristic failure mode: an early wrong character influences the later queries and can lead to a coherent but wrong continuation. A strong learned prior can also prefer a familiar-looking plate to the unfamiliar plate that is actually visible.

### 3.1.3. What conventional parallel decoders gain and lose

Parallel decoders predict all output positions in one main forward pass. Instead of generating the first character and using it to condition the second, they define a set of position queries and ask the model to connect each query with the relevant image evidence. This is attractive for real-time OCR, because the computation is less sequential. However, standard position queries carry little information. If the model starts from a generic position embedding, it must at the same time determine how many characters exist, where they are, and which symbol belongs to each position. These questions depend on each other: uncertainty about whether a character exists changes the meaning of all later positions.

Consider a two-row plate with a short upper row and a longer lower row. A parallel decoder must infer that its first two output positions refer to the upper row and that the following positions refer to the lower row, even though the rows overlap horizontally. If its position queries were learned mainly from one-row examples, it may continue horizontally and assign a lower-row symbol too early. A parallel architecture can therefore be fast and still face a difficult problem of context estimation. The CPPD paper starts from this concern and argues that earlier fast decoders lacked a stable description of the visual context [51].

### 3.1.4. Language context versus visual context

An important conceptual contribution of CPPD is the distinction between linguistic context and visual context [51]. Linguistic context concerns which characters tend to occur together and in which order. Visual context concerns what the characters look like, how many there are, where they are and how the positions relate to the image. In English, the letter Q is usually followed by U. In a registration identifier, a weak prior of this kind can be dangerous. The visual position of a character is often the safer source of information. A decoder that understands the extent and the order of the visible glyphs can recognize an unusual registration without forcing it into a common pattern.

The CPPD authors studied autoregressive recognition and found that its advantage over simple parallel decoding does not come only from knowing the identities of the earlier characters. The autoregressive decoder also provides guidance on visual context perception, such as the appearance and the position of the characters that it has already decoded [51]. A decoder that has located the first character can use its position to find the next one. CPPD tries to capture these benefits in a parallel computation by providing two kinds of complementary information: character counts and character order.

For license plates, a third kind of context is available: the format. The format is linguistic knowledge, because it describes which character classes may follow each other. Unlike learned language statistics, it is explicit, exact for known plate types and independent of the frequencies in the training data. The method of this paper uses the format in two ways. The decoder of Section 3.3 learns format regularities from data through its character-context attention, and the format score of Section 2.3.6 applies the official templates explicitly to candidate strings.

### 3.1.5. Position queries, maximum length, and real plates

A parallel decoder has a predefined maximum number of output positions $L_{\max}$. The model learns to stop by predicting an end-of-sequence symbol or a padding class. This works when the longest plate of the deployment is shorter than $L_{\max}$. "Variable length" does not mean "unbounded length". If a country introduces registrations that are longer than the available positions, the decoder cannot transcribe them without a new configuration. This is a capacity decision, not a failure of attention. A comparison must give every method realistic capacity. The feature grid must contain enough spatial evidence for the longest one-row and two-row plates, and the decoder must have enough output positions. For Chinese plates, eight characters are the normal maximum; the decoder of this paper uses ten positions to allow for special plates and for plates from other countries.

## 3.2. Context Perception Parallel Decoding Through Character Counting and Ordering

CPPD predicts all characters in one decoding pass and builds context through two auxiliary tasks [51]. A character counting (CC) module infers how often each character occurs. A character ordering (CO) module infers the content-free reading order and the occupied positions. The character prediction task then associates the positions with characters. Experiments on English and Chinese benchmarks in the original paper showed accuracy competitive with autoregressive models while CPPD ran approximately eight times faster than its autoregressive counterparts [51]. This section describes the published method.

### 3.2.1. Visual representation and decoder inputs

The original CPPD models use SVTR as the visual encoder. The CPPD paper also tested its decoder with a ResNet-based encoder and with a ViT encoder [51]. This shows that the decoder does not depend on one particular encoder, which supports the use of a shared encoder in FADR. Let the encoder produce visual features $F$ with $N$ tokens. The decoder has two sets of learned embeddings. Character embeddings correspond to the entries of the vocabulary. Position embeddings correspond to the ordered output positions $1, \ldots, L_{\max}$. Cross-attention connects both sets with the visual tokens (Figure 22). In compact form, a cross-attention block computes $\mathrm{softmax}(QK^{\top}/\sqrt{d})V$, where the queries $Q$ come from the embeddings and the keys $K$ and values $V$ come from the visual tokens.

![Figure 22](figs/fig16_cppd.png)

*Figure 22. The CPPD decoder as published [51]. Character embeddings and position embeddings attend to the visual features in two parallel branches. Counting and ordering losses supervise the two branches during training. A fusion step and a parallel classifier predict all characters in one pass.*

### 3.2.2. Character counting (CC)

The CC task estimates the number of occurrences of each vocabulary symbol in the image. Consider the illustrative Chinese plate string 京A11025. Its inventory contains one 京, one A, two copies of 1, one 0, one 2 and one 5. A conventional position classifier makes a local choice at each position and does not represent this global inventory. The CC objective gives an explicit training signal that distinguishes one copy of 1 from two copies. Such supervision is useful for plates with repeated characters and for partial occlusion. Character counting is not a transcription, however. It does not depend on order, so the strings 京A11025 and 京A51201 have the same inventory (Figure 23).

In CPPD, each character embedding acts as a query that attends to the visual features. The model then predicts, for each character, how many times it occurs, and a counting loss supervises this prediction. The CPPD paper states that the CC module does not take part in inference [51]; its role is to shape the representation during training. The counting objective is different from a national regular expression. A character can appear in several positions, and the order of letters and digits can change without changing the definition of the counting task. There is also a limitation: a character that is absent from the training vocabulary does not become recognizable because a counting query exists for it.

### 3.2.3. Character ordering (CO)

Counting cannot say where a character belongs. The CO module therefore learns position placeholders that describe an ordered output sequence without character identities. For example, a string of seven characters occupies seven ordered positions, and the remaining positions up to $L_{\max}$ are empty. The CO queries attend to the visual features, so the model learns which image regions support each position. The objective is content-free: the first position is supervised as the first output position, without requiring it to be a particular letter or digit. This separates the concept of order from the concept of identity [51]. Figure 23 illustrates how the two objectives complement each other.

![Figure 23](figs/fig17_cc_co.png)

*Figure 23. Character counting and character ordering answer different questions. Counting describes the multiset of characters without their order; ordering describes the occupied positions without their identities. The final classifier combines both.*

The word "ordering" needs a careful interpretation. The position queries of CPPD do not discover an official reading convention by themselves. They learn positions relative to the order of the training labels. If the training examples always place all upper-row characters before all lower-row characters, and if enough visual information is available, the decoder can learn this mapping. No general model is guaranteed to infer the correct order for a completely unseen layout. The original CPPD study addresses scene text and reports English and Chinese benchmarks [51]; it does not report a multinational evaluation of two-row plates.

### 3.2.4. Context fusion and the parallel classifier

The two auxiliary tasks help transcription because they inform the representation that predicts the characters. In CPPD, the counting and ordering branches run in parallel on the visual features. A further cross-attention then fuses them: the order-aware position features act as queries, and the count-aware features act as keys and values [51]. The fused position features feed a linear classifier that predicts the character of every position in parallel. The recognition loss supervises the ordered transcription, while the counting and ordering losses reinforce its global content and its positional structure. At inference, the string is produced in one decoder pass instead of an autoregressive loop. The exact saving depends on the cost of the encoder, on the maximum length, on the vocabulary size and on the hardware.

### 3.2.5. What CPPD does not solve for license plates

CPPD gives a parallel decoder much of the context of an autoregressive decoder. For the task of this paper, four limitations remain:

1. **No character context.** The position queries of CPPD are content-free. The prediction of one position cannot use the characters of the other positions, so the decoder cannot use the fact that the characters of a plate are linked by its format.
2. **No judgement of a given string.** CPPD reads a plate from scratch. It has no mode in which it receives a candidate string and reports how well the string fits the image. A combination with a CTC branch needs such a mode.
3. **No use of a first reading.** When a cheaper recognizer has already read the plate, CPPD cannot compare its own reading with it in a principled way.
4. **Cost on every plate.** As a stand-alone recognizer, the decoder runs for every plate, including the clear majority that a CTC head reads correctly.

The decoder of Section 3.3 addresses the first two points. Chapter 4 addresses the third and fourth points with a joint score and a confidence gate.

## 3.3. Proposed Context-Aware Parallel Decoder

The context-aware parallel decoder (CAPD) is the second reader of the proposed recognizer. It is built on CPPD and adds one mechanism: a character-context attention, which lets every output position see the characters of the other positions. With this mechanism, the same decoder has two uses. It can read a plate on its own in one parallel pass, and it can judge a given candidate string with the context of all its characters (Figure 24). Chapter 4 calls the decoder only for the plates that fail the gate of the CTC branch.

![Figure 24](figs/fig18_capd.png)

*Figure 24. The context-aware parallel decoder. Position queries attend to context tokens of the other positions, to the two-dimensional visual features and to the count-aware features of CPPD. In reading mode, all context tokens are masks. In scoring mode, the context tokens carry the characters of a candidate string, and each position is judged from the characters of all other positions.*

### 3.3.1. Design goals

The decoder has four design goals. First, it must be able to read the plate independently of the CTC branch. A decoder that only re-scores the candidates of the CTC branch cannot repair an error when the correct string is not among them. Second, it must use linguistic context: the judgement of one character should depend on the other characters of the string, because the format of a plate links its characters. Third, it must not receive a template, a row count or a plate type as input. Such an input would have to come from a classifier, and Chapter 2 removed this classifier on purpose. Fourth, it must stay parallel and small. It runs only for a minority of plates, but every call must cost one or two parallel passes and no pass through the encoder.

### 3.3.2. Position queries and two-dimensional visual attention

The decoder has $L_{\max}$ output positions, with $L_{\max} = 10$ in this paper. Position $j$ has a learned position query $u_j$, as in the character ordering branch of CPPD (Section 3.2.3). Each query attends to the feature map $F$ of the shared encoder. The keys of this attention contain a two-dimensional position encoding, so a query can separate two regions that share the same columns and differ in height.

The position queries learn the reading order from the labels, supported by the ordering loss of CPPD. For a two-row plate, the first queries learn to attend to the upper row and the following queries to the lower row. The decoder needs no row index and no row boundary, for the same reason as the reading-order queries of Section 2.3.3: each query finds its character through attention, wherever the character lies. Figure 25 shows the intended behaviour on a rotated two-row plate.

![Figure 25](figs/fig_cn_two_row_attention.png)

*Figure 25. Schematic attention of the seven position queries on a two-row plate that is rotated by 12 degrees. The first two queries attend to the upper row and the other five to the lower row. The figure illustrates the intended behaviour; it is not the output of a trained model.*

The decoder and the CTC branch therefore read the same feature map with two different mechanisms. The CTC branch uses 24 queries, blanks and a monotonic alignment. The decoder uses one query per character and an end symbol. Their errors are related, because they share the encoder, but they are not identical. For example, a missing blank between two equal digits is a typical CTC error that the decoder cannot make, and a wrong string length is a typical decoder error that CTC cannot make. This difference is the reason why the two readers can check each other in Chapter 4.

### 3.3.3. Character-context attention

CPPD builds visual context: its counting and ordering tasks tell the decoder which characters exist and where they are. Its position queries are content-free, so the prediction of one position cannot use the characters of the other positions. The proposed character-context attention adds this linguistic context. For every position $j'$, a context token $c_{j'}$ is formed from the character at that position, or from a mask when the character is hidden:

$$c_{j'}=\begin{cases}E(y_{j'})+u'_{j'}, & \text{if position } j' \text{ is visible},\\ e_{\text{mask}}+u'_{j'}, & \text{if position } j' \text{ is hidden},\end{cases}\qquad \tilde h_j=h_j+\mathrm{Attn}\big(h_j;\,\{c_{j'}\}_{j'\neq j}\big). \qquad (7)$$

Here $E(\cdot)$ is the character embedding, $u'_{j'}$ is a position embedding for context tokens, $e_{\text{mask}}$ is a learned mask embedding, $h_j$ is the current state of position query $j$, and $\mathrm{Attn}$ is a multi-head attention in which $h_j$ is the query and the context tokens are the keys and values. Two details make the mechanism safe. First, position $j$ never attends to its own context token, so a prediction can never copy its own character. Second, the context tokens are inputs only. They are not updated between the decoder layers, so the character of position $j$ cannot reach its own prediction through another position.

The mechanism has two modes at inference. In *reading mode*, all positions are hidden. The decoder then behaves like CPPD and reads the plate from the image alone. In *scoring mode*, the context tokens carry a complete candidate string. Each position is then predicted from the image and from all other characters of the candidate. During training, a random subset of the positions is visible, which covers both modes and everything between them (Section 3.3.7).

### 3.3.4. Decoder layers

The decoder has two identical layers. Each layer applies four operations to the position queries:

1. **Character-context attention** (Equation 7). The query of each position attends to the context tokens of the other positions. This step supplies linguistic context.
2. **Visual cross-attention.** The query attends to the feature map $F$ with a two-dimensional position encoding. This step supplies the visual evidence of the character and finds it in its row.
3. **Fusion with count-aware features.** As in CPPD, the query attends to the features of the character counting branch, which describe which characters occur in the image and how often (Section 3.2.4).
4. **Feed-forward network** with a residual connection and layer normalization.

After the second layer, a linear classifier predicts a distribution over the vocabulary and the end symbol for every position. All positions are computed in parallel. The counting and ordering losses of CPPD are kept as auxiliary losses during training. The decoder therefore keeps the published context perception of CPPD and adds the character-context attention as the only new operation.

### 3.3.5. First use: reading a plate

In reading mode, one pass of the decoder gives a string $y^{d}$ and a probability for each of its characters. The string ends at the first position that predicts the end symbol. This reading is independent of the draft of the CTC branch: it does not see the draft, and it uses a different alignment mechanism. Chapter 4 compares the two readings. If they are equal, the plate is accepted. If they differ, both readings become candidates, together with the next best strings of the CTC branch.

Reading mode has no linguistic context, because all context tokens are masks. This is intended. A first reading that is free of character context cannot be led by a wrong neighbouring character, which is the typical failure of autoregressive decoding (Section 3.1.2). The linguistic context enters in the second use, where it is applied to complete candidates and where a wrong candidate has to compete with others.

### 3.3.6. Second use: scoring a candidate with context

In scoring mode, the decoder receives a candidate string $y$ and returns one number that describes how well the string fits the image and its own internal structure:

$$\ell_{\text{dec}}(y \mid x)=\sum_{j=1}^{|y|+1}\log P_{\text{dec}}\big(y_j \mid x,\;y_{\neg j}\big), \qquad (8)$$

where $y_{\neg j}$ denotes all characters of the candidate except the one at position $j$, and position $|y|+1$ holds the end symbol. One parallel pass computes all terms of the sum, and several candidates are scored as one batch. The end symbol is part of the score, so a candidate with a missing or an extra character is penalized at the position where the image and the string length disagree.

Figure 26 shows why the context matters. The two candidates 粤8D12345 and 粤BD12345 differ only in the second character. In reading mode, the decoder sees a blurred glyph that could be either. In scoring mode, the second position also sees that the third character is D and that the string has eight characters. In the training data, this pattern occurs only on new-energy plates, whose second character is always a letter. The decoder has learned this regularity, so it gives the letter B a high probability and the digit 8 a low one. The format knowledge that the decoder uses here is learned from data. It complements the explicit templates of Section 2.3.6: the templates are exact but limited to the listed plate types, while the learned context is approximate but also covers regularities that no template states, such as the letters that an issuing authority really uses.

![Figure 26](figs/fig35_ctx_scoring.png)

*Figure 26. Scoring two candidates with character context. Each position is judged from the image and from the other characters of the same candidate. The second position of the candidate with the digit 8 receives a low probability, because the other characters indicate a new-energy plate, whose second character is a letter. The values are illustrative.*

The sum in Equation 8 is used as a score, not as an exact probability of the string. Each term conditions on all other characters, so the terms are not the factors of one joint distribution. This is sufficient, because the score is used only to compare a few candidates of the same plate, and its weight in the joint score is tuned on validation data (Section 4.2.4).

### 3.3.7. Training the decoder

The decoder is trained together with the rest of the network (Chapter 4). For every training plate, a random set $V$ of positions is visible in the context, and the decoder predicts every position from the image and from the visible characters of the other positions:

$$\mathcal{L}_{\text{dec}}=-\sum_{j=1}^{|y|+1}\log P_{\text{dec}}\big(y_j \mid x,\;\tilde y_{V\setminus\{j\}}\big). \qquad (9)$$

The share of visible positions is drawn at random for every sample, between zero and one. With no visible position, the sample trains the reading mode. With all positions visible, it trains the scoring mode. This kind of training follows the mask-predict idea that Mask CTC uses in speech recognition [14], and it is related to the permutation training of PARSeq [37].

The context $\tilde y$ is not always the true string. A decoder that sees only correct context learns to trust the context completely, and it would then give a wrong candidate a high score at all positions except the wrong one. Two measures prevent this. With a small probability, a visible character is replaced by a visually similar wrong character, for example B by 8 or D by 0. In the last training phase, the context is also taken from the candidates of the CTC branch itself, which contain its real errors. The target at every position stays the true character. The decoder therefore learns that the context is evidence and not a fact.

The synthetic data of Section 4.3.1 has the same purpose on the level of formats. Format-open strings, which use valid characters in unusual orders, teach the decoder that strings outside the common formats exist. Without them, the learned context would become a hard format rule inside the network, which is exactly what the explicit format score avoids.

### 3.3.8. Two-row and rotated plates in the decoder

The decoder treats a two-row plate like any other plate. Its position queries follow the order of the label, upper row first, and its visual attention is two-dimensional. Rotation, shift and perspective change where a query must look, but not how it works. The same geometric augmentation as in Section 2.3.4 is applied, so the decoder sees rotated and warped plates during training.

There is one case that no recognizer can resolve from the image alone. If two plate types look identical but use different reading orders, the image does not determine the correct order. In this case, the order must come from the labels of the training data for the region. This is a limit of the task and not of the method.

### 3.3.9. Worked example

The worked example of Section 2.3.7 ended with a draft that the format could not correct: the Chinese yellow two-row plate 沪A / 12345 was read as 沪A1Z345 by the CTC branch, and the confidence of Z was low. The gate failed, so the decoder is called.

In reading mode, the fourth position query attends to the fourth glyph in the lower row. The decoder reads 2 with a probability of 0.71 and Z with 0.24, and its string is 沪A12345. The two readers disagree, so the candidates are pooled: the draft 沪A1Z345, the reading 沪A12345 and the next best strings of the CTC branch. In scoring mode, the fourth position of each candidate sees the other six characters. They indicate an ordinary serial, in which digits are much more common than letters. This context is weak, because a letter is allowed in this slot, but together with the visual evidence it gives the digit 2 a clear advantage. The CTC branch itself also assigns the string 沪A12345 almost the same probability as its draft. The joint score of Chapter 4 selects 沪A12345.

The example shows the division of work. The CTC branch reads the plate in the correct order at a low cost and marks its own uncertainty. The decoder gives a second reading with a different mechanism and judges the candidates with context. Neither reader decides alone when they disagree.

### 3.3.10. Cost of the decoder

The decoder is small. It has ten position queries and two layers. The context attention involves at most ten tokens and costs almost nothing. The visual cross-attention is the largest cost: ten queries attend to the feature map, which has 144 positions in the $48 \times 96$ bucket. A call for one plate needs one pass in reading mode and, when the readers disagree, one batched pass in scoring mode for about six candidates. The encoder is not run again. Chapter 4 shows that the decoder is called for a minority of plates, so its contribution to the average cost is small.

### 3.3.11. Relation to other designs

The decoder combines ideas from several earlier works, and it differs from each of them. Compared with CPPD [51], it keeps the parallel pass, the counting and ordering tasks and the fusion with count-aware features, and it adds the character-context attention and the scoring mode. Compared with PARSeq [37], it has no autoregressive decoding and no iterative refinement at inference: it reads once and scores once, and its context is applied to complete candidates. Compared with ABINet [36], it has no separate language model: the context attention is a part of the visual decoder, and it is trained with noisy context. Compared with Mask CTC [14], it does not fill masked positions of a CTC output; it reads independently and then lets the candidates of both readers compete. Compared with joint CTC/attention decoding in speech recognition [13], it replaces the sequential attention decoder with a parallel one, so that scoring a candidate costs one pass. Compared with the multi-line plate recognizer of Chen and colleagues [57], which predicts the plate type first and then reads the characters in parallel, it needs no type prediction, and it is combined with a CTC branch that resolves most plates alone. Recent work on multi-type plates, such as the global and contrastive learning approach of Liu and colleagues [56], shows that the recognition of several plate types with one model remains an active research topic.

### 3.3.12. Summary of Chapter 3

This chapter reviewed autoregressive and parallel decoders and described CPPD, which builds visual context for parallel decoding through character counting and character ordering. It then proposed the context-aware parallel decoder. The decoder adds a character-context attention to CPPD, in which every position sees the characters of the other positions but never its own. It reads a plate independently in one pass, and it scores candidate strings with linguistic and visual context in one batched pass. It needs no template, no row count and no plate type. Chapter 4 combines this decoder with the CTC branch of Chapter 2.


# Chapter 4. Combining CTC and Parallel Decoding: The Format-Aware Draft-and-Refine Framework

Chapters 2 and 3 developed two readers: a CTC branch that reads one-row and two-row plates efficiently through reading-order queries, and a parallel decoder that reads a plate independently and judges candidate strings with context. This chapter combines them into one recognizer, called Format-Aware Draft-and-Refine (FADR). Section 4.1 describes the architecture and the joint training. Section 4.2 describes the confidence-gated inference and the joint score that selects the final string. Section 4.3 discusses degraded plates: synthetic training data, training-only restoration guidance and multi-frame fusion. Section 4.4 discusses the computational cost, deployment and the safeguards against overcorrection.

## 4.1. Architecture and Joint Training

### 4.1.1. Overall architecture

FADR consists of one shared encoder, two heads and a small file of format templates (Figure 2). The encoder is a hierarchical vision-transformer encoder in the style of SVTRv2-T, with multi-size resizing at its input (Section 2.2). Its output is the feature map $F$ of size $H/8 \times W/4 \times D$. The two heads read this feature map:

1. The **CTC branch** applies the horizontal step of the FRM, the reading-order queries and the CTC classifier (Section 2.3). It produces a draft string and a calibrated confidence for each character. This branch runs for every plate.
2. The **context-aware parallel decoder** reads the plate with position queries and scores candidate strings with character context (Section 3.3). This head runs only for the plates that fail the gate.

The format templates are not a part of the network. They are compiled into automata that check strings (Section 2.3.5). They are used by the gate and by the joint score. No component predicts the plate type or the number of rows from the image.

The heads share the encoder, so the decoder needs no second pass through the encoder. The final output is the plate string, a confidence value, the raw draft of the CTC branch and, when the confidence is low, a review flag.

### 4.1.2. Training objective

All parts of FADR are trained together with one objective:

$$\mathcal{L}=\mathcal{L}_{\text{ctc}}+\lambda_{d}\,\mathcal{L}_{\text{dec}}+\lambda_{c}\,\big(\mathcal{L}_{\text{cc}}+\mathcal{L}_{\text{co}}\big)+\lambda_{s}\,\mathcal{L}_{\text{sgm}}+\lambda_{o}\,\mathcal{L}_{\text{ord}}, \qquad (10)$$

where $\mathcal{L}_{\text{ctc}}$ is the CTC loss of the complete string on the query outputs (Section 2.3.4), $\mathcal{L}_{\text{dec}}$ is the decoder loss of Equation 9, $\mathcal{L}_{\text{cc}}$ and $\mathcal{L}_{\text{co}}$ are the character counting and character ordering losses inherited from CPPD, $\mathcal{L}_{\text{sgm}}$ is the semantic guidance loss of SVTRv2, and $\mathcal{L}_{\text{ord}}$ is the reading-order guidance of Equation 5, which is applied only to synthetic plates. The weights $\lambda$ balance the terms. The CTC loss is the main term, because the CTC branch alone resolves most plates. Three of the terms belong to modules that are removed after training: the semantic guidance, the reading-order guidance and the counting classifier. When paired high-resolution and low-resolution images are available, a distillation term can be added (Section 4.3.3).

The joint objective has a useful side effect on the CTC branch. The gradients of the decoder flow into the shared encoder. They act as attention-based guidance for the encoder features, which is the mechanism that GTC uses to improve CTC recognizers [42]. The CTC branch therefore benefits from the decoder during training, even for plates for which the decoder is never used at inference. The hybrid CTC/attention architecture in speech recognition showed a similar benefit of joint training [13]. Because the decoder already transfers character context into the encoder, the semantic guidance module of SVTRv2 may become less important in the joint model; the ablation study of Chapter 5 tests this. An optional mutual-learning term, in which the character posteriors of the two heads are encouraged to agree, is also possible [67]. It is not used in the default configuration, because the two readers are more useful to each other when their errors differ.

### 4.1.3. Training schedule

The training proceeds in three phases. In the first phase, the encoder, the reading-order queries, the CTC classifier and the two guidance modules are trained on one-row and two-row plates, real and synthetic. This phase gives a complete CTC recognizer. The encoder can be initialized from a published SVTRv2 model; the queries are new and are trained from random values. In the second phase, the decoder is added and trained with random context masks and noisy context (Section 3.3.7), while the rest of the network continues to train. In the third phase, the context of the decoder is also taken from the candidate lists of the CTC branch, so that the decoder learns to judge the real errors of the draft. After the training, the temperatures of the CTC logits and of the decoder logits are calibrated on a validation set [69], and the gate threshold and the weights of the joint score are selected (Section 4.2.6).

Figure 27 summarizes the three phases and the parts of the model that become active in each of them.

![Figure 27](figs/fig27_training_schedule.png)

*Figure 27. The three training phases of FADR. Each phase adds components to a working model. After training, the logits are calibrated, and the gate threshold and the weights of the joint score are chosen on a validation set.*

This schedule has two practical advantages. First, every phase starts from a working model, so problems are easy to locate. Second, the result of the first phase is a complete recognizer, the CTC branch, which can be evaluated and deployed on its own.

### 4.1.4. Specification of the format templates

The format knowledge of FADR is stored outside the network, in a small template file. This separation has a practical purpose: a domain expert can read and correct the templates without knowledge of the network. The listing below shows a simplified example for three Chinese plate types and the open format. The character classes are defined once and then used in the templates. Each template lists its rows, the slot type of every slot, optional rules that involve several slots, and a site prior.

```yaml
# Simplified template file (illustrative, not an official specification)
classes:
  P: [京, 津, 沪, 渝, 冀, 豫, 云, 辽, 黑, 湘, 皖, 鲁, 新, 苏, 浙, 赣,
      鄂, 桂, 甘, 晋, 蒙, 陕, 吉, 闽, 贵, 粤, 青, 藏, 川, 宁, 琼]
  L: [A-H, J-N, P-Z]          # letters without I and O
  N: [0-9]                    # digits
  A: [L, N]                   # letter or digit
  E: [D, F]                   # energy code of new-energy plates
templates:
  cn_small_car:               # blue plate, one row, 7 characters
    rows: [[P, L, A, A, A, A, A]]
    rules: [serial_max_letters: 2]
    prior: 0.80
  cn_small_new_energy:        # green plate, one row, 8 characters
    rows: [[P, L, E, A, N, N, N, N]]
    prior: 0.12
  cn_large_rear:              # yellow plate, two rows, 2 + 5 characters
    rows: [[P, L], [A, A, A, A, A]]
    rules: [serial_max_letters: 2]
    prior: 0.05
open_format:                  # any other string, lower prior
  max_length: 10
  prior: 0.01
```

A small compiler reads this file and builds the automata of Section 2.3.5. A rule such as "serial_max_letters: 2" adds a counter to the states of the automaton. The priors are site parameters; they can be estimated from the traffic of the site or left uniform. The file has two users. The recognizer uses the templates as sets of strings: for the format check of the gate and for the format score. It ignores the row structure. The renderer of the synthetic data (Section 4.3.1) uses the complete templates, including the rows, to draw plates of every type. Adding or changing a template therefore changes the format score at once and requires no change to the network.

### 4.1.5. Why the branches share one encoder

A shared encoder has three advantages. First, it saves computation: the decoder reuses the features that the CTC branch has already computed, so a call of the decoder costs only the decoder layers. Second, it saves memory and simplifies deployment: one model file contains both heads. Third, the joint training gives the encoder richer supervision, as discussed above.

The disadvantage is that the errors of the two readers are correlated, because both read the same features. A plate whose features have lost a stroke is difficult for both. The two heads still differ in a useful way. The CTC branch aligns 24 steps with blanks and has no character context. The decoder uses one query per character, an end symbol and the context of the other characters. A missing blank, a merged repetition or a wrong row transition affects one reader and not the other. The value of the second reader therefore depends on how often the two readers are wrong in the same way. Chapter 5 reports this share as a separate number, the shared-error rate. Evidence that is independent in a stronger sense comes from other sources, such as additional video frames (Section 4.3.4).

## 4.2. Confidence-Gated Inference and Joint Scoring

At inference, FADR processes each plate in up to three stages (Figure 28). Every plate passes through stage 1, which is the CTC branch and the gate. A plate that fails the gate is read by the decoder in stage 2. If the two readings differ, stage 3 pools their candidates and selects one with the joint score. Most clear plates leave the system after the cheapest stage.

![Figure 28](figs/fig19_cascade.png)

*Figure 28. Confidence-gated inference of FADR. Stage 1 always runs. A plate is read by the decoder only if its draft fails the gate. If the decoder agrees with the draft, the plate is accepted. Otherwise, the candidates of both readers are scored jointly. A review flag marks plates with low confidence.*

### 4.2.1. Stage 1: the CTC draft and the gate

Stage 1 runs the encoder, the reading-order queries and the CTC classifier, and it decodes the output greedily (Algorithm 1). Greedy decoding is the cheapest possible decoding: it takes the most probable symbol at each step and collapses the result. The gate accepts the draft if two conditions hold:

1. The calibrated confidence of every character of the draft is at least the gate threshold $\tau_g$.
2. The draft fits at least one known format template.

If both conditions hold, the draft is the output. The first condition ensures that no single character is doubtful. The second condition is a free consistency check: it costs a few table look-ups, and it catches drafts whose characters are confident but whose string is impossible for every known plate type. A clear blue Chinese plate typically satisfies both conditions.

The second condition does not use the format as a rule. A draft that fits no template is not rejected and not changed. It is only read a second time. A plate with a truly unknown format therefore always reaches the decoder, where it can still win under the open format. This costs computation for such plates, but it costs no accuracy.

### 4.2.2. Stage 2: the decoder reads the plate

Stage 2 runs the decoder once in reading mode (Section 3.3.5). The decoder does not see the draft. If its reading is equal to the draft, the plate is accepted with this string. Two readers with different alignment mechanisms have then produced the same string, which is strong evidence, and no further computation is needed. This case is common: many drafts fail the gate only because one character has a moderate confidence, and the second reading confirms them.

The agreement is accepted even when the string fits no known template. In this case, both readers support a string of the open format, and the plate is logged as an open-format result (Section 4.4.3).

### 4.2.3. Stage 3: the candidate pool

If the two readings differ, neither is trusted alone. Stage 3 builds a pool of candidates from both readers. From the CTC branch, it takes the $N$ best strings of a prefix beam search on the query outputs [70], with $N = 5$ in this paper. The draft is the first of them. From the decoder, it takes the reading of stage 2. The pool has at most $N + 1$ strings.

The pool is the reason why the decoder can repair errors that a pure re-scoring could not repair. If the CTC branch has read the rows in a wrong order, or has lost a character, the correct string is usually not among its best strings. The independent reading of the decoder adds it to the pool. In the other direction, if the decoder has predicted a wrong length, the correct string is usually among the best strings of the CTC branch.

### 4.2.4. Joint scoring of candidates

Every candidate $y$ of the pool is scored with three kinds of evidence:

$$S(y)=\alpha\,\bar{\ell}_{\text{ctc}}(y \mid x)+(1-\alpha)\,\bar{\ell}_{\text{dec}}(y \mid x)+\beta\,\phi(y). \qquad (11)$$

The first term is the CTC log-probability of the string (Equation 1), divided by the string length. It is computed with the CTC forward algorithm on the 24 query outputs. The forward algorithm works for any string, so the reading of the decoder receives a CTC score even though the CTC branch did not propose it. The second term is the context score of the decoder (Equation 8), divided by the number of positions. All candidates are scored in one batched pass of the decoder in scoring mode. The third term is the format score of Equation 6: the prior of the best template that the string fits, or the lower prior of the open format. The weights $\alpha$ and $\beta$ are tuned on a validation set. The candidate with the highest score is the output.

The joint score follows the logic of joint CTC/attention decoding in speech recognition [13], adapted to plates. The CTC term rewards strings that fit the evidence along the reading order. The decoder term rewards strings whose characters fit the image and each other. The format term rewards strings that fit a plausible template. No term can force the result alone. In particular, each reader can veto the other. A string that the decoder likes but that the CTC evidence does not support receives a low CTC score, and the reverse holds as well. A string outside all known templates can still win through the open format when both recognition terms support it strongly.

The plate type never appears in Equation 11. Candidates that belong to different plate types, for example a seven-character string of a small car and an eight-character string of a new-energy vehicle, compete directly on the same three terms. The type of the plate follows from the winning string and is not decided before it.

### 4.2.5. Output, confidence and review flag

FADR returns four items for each plate: the final string, a plate-level confidence, the stage at which the plate left the system, and the raw draft of the CTC branch. For a plate that is accepted at the gate, the confidence is the lowest calibrated character confidence. For a plate that is accepted by agreement, it is the lowest character confidence of the two readers, taken per character as the higher of the two values. For a plate that is decided by the joint score, it is the softmax of the joint scores over the pool, so it reflects the competition between candidates. When the confidence is below a threshold $\tau_{\text{rej}}$, FADR sets a review flag. In a traffic application, a flagged plate can be sent to a human operator, matched against a database with a tolerance, or combined with more video frames. The raw draft is kept because it shows the reading before any second reader or format knowledge was applied. Reporting both strings follows the recommendation of Chapter 1 to separate raw and format-assisted recognition.

### 4.2.6. Choosing the thresholds, and the blind spot of the gate

The gate threshold $\tau_g$ controls the trade-off between accuracy and cost. It is selected on a validation set so that the plates accepted at the gate have a very high recognition rate, for example at least 99.5 percent. The weights $\alpha$ and $\beta$ and the prior of the open format are then tuned on the validation plates that reach stage 3. The review threshold $\tau_{\text{rej}}$ is set by the operating requirements. A deployment with a strict latency budget can lower $\tau_g$ so that fewer plates reach the decoder. A deployment for law enforcement can raise it. Chapter 5 reports the projected relation between the gate threshold, the accuracy and the share of plates that reach the decoder.

The gate has a blind spot. A draft that is wrong, confident and valid for a known template passes the gate, and the decoder never sees it. Three measures limit this risk. The calibration of Section 2.3.8 makes a high confidence mean a high probability of being correct. The format check catches the wrong drafts that fit no template. The reading-order queries reduce the errors that are typically confident, such as a wrong row order. The risk cannot be removed completely, so the recognition rate of the plates that pass the gate is reported as a separate number in Chapter 5, and the gate threshold is chosen from this number and not from the average accuracy.

### 4.2.7. Worked examples on Chinese plates

Figure 29 shows three illustrative examples, one for each exit. The first plate is a clear blue small-car plate. Its draft fits the small-car template, and every character is confident, so it leaves at the gate. The second plate is a yellow two-row plate, rotated and with low contrast. Its draft is correct and fits a template, but one character of the lower row has a moderate confidence, so the gate fails. The decoder reads the same string, and the plate is accepted by agreement. The third plate is a blurred small new-energy plate. The draft reads the issuing-authority letter B as the digit 8. The draft fits no template, so it fails the gate, although its other characters are confident. The decoder reads the letter B. The two readings differ, so the candidates are pooled and scored. The candidate with B has a slightly lower CTC score, a much higher decoder score and a much higher format score, and it is the output.

![Figure 29](figs/fig_cn_cascade_examples.png)

*Figure 29. Illustrative examples of the three exits on Chinese plates. A clear plate leaves at the gate; an uncertain two-row plate is confirmed by the decoder; a B/8 confusion is resolved by the joint score of the two readers and the format.*

### 4.2.8. Inference algorithm

Algorithm 2 summarizes the complete inference for one plate crop. Steps 1 to 4 form stage 1, steps 5 to 7 form stage 2, and steps 8 to 12 form stage 3. Every plate returns the same items, independent of the stage at which it leaves.

```text
Algorithm 2. FADR inference for one plate crop

Input : plate crop x; thresholds tau_g, tau_rej; weights alpha, beta
Output: string, confidence, review flag, exit stage, raw draft

1  F <- encoder(MSR(x))                            # shared features
2  g, kappa, P <- CTC branch(F)                    # draft, confidences
3  if min(kappa) >= tau_g and g fits a known template:
4      return g, min(kappa), no flag, stage 1, g   # exit at the gate
5  d <- decoder(F) in reading mode                 # independent reading
6  if d equals g:
7      return g, confidence, flag if low, stage 2, g   # agreement
8  C <- N best strings of the CTC beam search on P, and d
9  for each candidate y in C (one batched decoder pass):
10     S(y) <- alpha * CTC score + (1 - alpha) * decoder score
11             + beta * format score
12 return the best y, its confidence, the flag, stage 3, g
```

The algorithm has three properties that are important for deployment. First, the encoder runs exactly once per plate, whatever the stage. Second, the decoder runs at most twice, once in reading mode and once in scoring mode, and both runs are parallel. Third, the output has the same form for every stage, so the systems that receive the result do not need to know which stage produced it.

## 4.3. Recognition of Degraded Plates

The recognition head is only one factor in the recognition of degraded plates. Training data, restoration guidance and additional observations often matter more. This section describes how FADR uses these three factors. They are independent of the choice between CTC and decoding, so they are evaluated separately in Chapter 5.

### 4.3.1. Synthetic data with format-faithful and format-open strings

Training a multinational recognizer is not only a matter of collecting many images. The training set must cover different scripts, current and historical formats, vehicle types, fonts, aspect ratios, two-row layouts and imaging conditions. If most images come from passenger cars in one country, more such images teach little about motorcycle plates or new scripts. Annotation is expensive, and images with registration numbers can be restricted for privacy reasons. Some plate types will therefore have very little real data.

Synthetic data is a practical answer. A renderer places artificial strings on plausible plate backgrounds with chosen fonts, spacing, borders, colours and layouts, and it simulates acquisition effects (Figure 30). Rendered text has a long history in text recognition [58,59]. For license plates, Laroca and colleagues evaluated 16 OCR models on 12 public datasets and studied three ways to generate synthetic plates: template-based rendering, character permutation and image-to-image translation with a generative adversarial network [52]. Their results show the value of synthetic data when real data is scarce. With only 1 percent of the real training data, STAR-Net and TRBA reached 0.0 percent without synthetic data, but 86.4 and 87.9 percent when synthetic data was added [52]. These values belong to their protocol and are not expected accuracies for other formats, but they show that coverage can matter more than the choice of the recognition head.

![Figure 30](figs/fig20_synthetic_pipeline.png)

*Figure 30. A modular synthesis pipeline. Templates supply labels and layouts, rendering supplies appearance and exact character boxes, degradation supplies acquisition effects, and a validation step protects the character identity.*

For FADR, the synthetic data has three special roles. The first role concerns the formats. Two kinds of strings are rendered (Figure 31). **Format-faithful strings** follow the templates of the deployment. They teach the visual appearance of every plate type and every slot type, including rare types such as trailer and police plates. **Format-open strings** use valid characters in unusual orders and lengths. They teach both readers to read what they see, and they teach the decoder that strings outside the known templates exist. Without format-open data, the decoder would learn the formats as a hard rule from the visual data, and the soft format score would lose its purpose.

The second role concerns the reading order. The renderer draws every character itself, so it knows the box and the reading index of each character. These labels are exact for one-row and two-row plates, and they stay exact after rotation, shift and perspective, because the renderer applies these transformations to the boxes as well. The reading-order guidance of Section 2.3.4 uses these labels. Real datasets rarely contain character boxes, so the synthetic data is the only practical source of this signal.

The third role concerns geometry. Two-row plates that are strongly rotated, shifted or warped are rare in public datasets, but they occur in practice, for example on motorcycles and at steep camera angles. The renderer produces such plates in any number. Each synthetic plate is rendered upright and then transformed with a random rotation of up to 30 degrees, a random shift and scale of the crop, and a random perspective. The same transformations are applied to the real training crops as augmentation, so that the model does not learn to separate real and synthetic plates by their geometry.

![Figure 31](figs/fig_cn_synthetic_samples.png)

*Figure 31. Synthetic Chinese plates rendered from templates. Format-faithful strings follow the official templates; format-open strings use valid characters in unusual orders; degraded copies simulate acquisition effects.*

The synthetic data must not create shortcuts. If a particular font, background or compression setting appears only for one plate type, the model can learn the type from this artefact instead of from the plate. The same generated pool must therefore serve all plate types, and the validation set must contain real images from cameras that were not used in training. Large real collections such as the Global License Plate Dataset, which reports more than five million images from 74 countries [55], can complement synthetic data for multinational coverage, subject to their licences.

### 4.3.2. Realistic degradation instead of random filters

An image of a distant plate is not the same as a clear plate blurred with a standard Gaussian kernel. The image is shaped by the optical blur of the camera, the sensor sampling, the exposure time, the motion of the vehicle, the sensor noise, geometric resampling and video compression. A compression artefact interacts with character edges. Rolling-shutter motion can distort only some rows. A reflection can erase a local part of a character. If synthetic images use unrealistic degradations, the model learns to recognize these artificial effects and does not improve on real surveillance video (Figure 32).

![Figure 32](figs/fig21_degradations.png)

*Figure 32. Examples of blur, down- and up-sampling and contrast reduction applied to the same illustrative Chinese plate. The effects show categories of degradation; they are not samples from a real benchmark.*

Synthetic degradation should therefore follow a plausible sequence of operations: perspective projection, mild optical blur, low-resolution sampling, brightness change, sensor noise and compression, in this order. The parameters should be estimated from the target cameras when possible. At the same time, very strong degradation destroys the relation between the label and the image. When a digit becomes indistinguishable from another digit, the training target is effectively uncertain. Such samples should be excluded from normal supervised training or handled with an explicit uncertainty policy. A model should not be rewarded for inventing a character that the image no longer contains.

### 4.3.3. Training-only restoration guidance

Super-resolution reconstructs a higher-resolution image from a low-resolution observation. SRGAN, ESRGAN, Real-ESRGAN and degradation-aware networks show several ways to synthesize or restore fine details [60–64]. For license plates, a sharper image is not necessarily a more accurate image. A restoration network can create a plausible but wrong stroke and turn a 3 into an 8, or make a blurred provincial character look like another provincial character. Visual realism and exact transcription are different objectives.

The ICPR 2026 Competition on Low-Resolution License Plate Recognition illustrates this point [53]. Its dataset, LRLPR-26, contains 20,000 training tracks and 3,000 test tracks, and each training track contains five low-resolution and five high-resolution images of the same plate. The winning team reached a recognition rate of 82.13 percent with a teacher–student framework that trains super-resolution and recognition jointly, an ensemble of three models and the summation of logits over the five frames. The second team reached 81.73 percent with a CTC-based recognizer and a learned attention module that weights the frames, and the third team, with members from the SVTRv2 group, reached 80.17 percent by feeding each low-resolution frame directly to an SVTRv2-based recognizer and voting at the character level. The organizers concluded that no single design dominated, while the effective use of the five frames was common to the strongest entries [53]. Explicit super-resolution at inference is therefore one effective option, not a necessary condition.

FADR follows this evidence with a training-only guidance scheme (Figure 33). When paired high-resolution and low-resolution images are available, a teacher encoder processes the high-resolution image and the FADR encoder processes the low-resolution image. A distillation term encourages the features or the output distributions of the student to match those of the teacher [65,66]. At inference, the teacher is removed, so the deployed recognizer and its latency are unchanged. Feature matching requires care, because the feature maps of the two images can differ in size. The matching is therefore applied to the outputs of the 24 reading-order queries and of the ten decoder positions, which have the same size for both images.

![Figure 33](figs/fig22_training_only_restoration.png)

*Figure 33. Training-only restoration guidance. A high-resolution teacher guides the features of the low-resolution student during training; only the student is deployed.*

Training-only guidance has a clear information limit. If a high-resolution stroke leaves no signal in the low-resolution image, the student cannot recover it by imitating the teacher. It may learn to output the most common plausible character instead. Guidance is therefore expected to help most when the degradation is moderate, the teacher is correct, and the training pairs truly show the same plate. It also reduces a practical risk: because the deployed system returns a string and a confidence, but no enhanced image, nobody can mistake a generated image for evidence.

### 4.3.4. Position-aligned multi-frame fusion

A moving vehicle is usually observed in several frames. Each frame differs in distance, viewing angle, lighting, motion blur, compression and occlusion. Even if every frame is imperfect, their errors can be complementary. One frame can show the upper stroke of a digit, another frame its lower loop, and a third frame can avoid a short headlight reflection. Nascimento and colleagues introduced UFPR-SR-Plates, with 10,000 tracks and 100,000 paired low-resolution and high-resolution images captured on a Brazilian road [54]. In their benchmark, the recognition rate of LCDNet rose from 1.7 percent on the original low-resolution images to 31.1 percent after super-resolution, and to 44.7 percent when the outputs for five super-resolved images were combined by majority voting at each character position [54]. These values belong to their complete pipeline, but they show that several observations can improve exact recognition substantially.

Fusing CTC outputs across frames is delicate. A CTC model produces distributions over time steps, not over characters. Two frames of the same plate can have different alignments and blank positions, so the fourth step of one frame may correspond to the second character, while the fourth step of another frame is a blank. Averaging the probabilities at the same step index can therefore mix different characters. Fusion at the level of decoded strings avoids this problem, but it discards the uncertainty of each character.

FADR fuses at the level of character positions (Figure 34). Every frame of a track is processed by Algorithm 2. Each frame then has a string and a distribution over characters for every position of that string. For a frame that reached the decoder, the distributions come from the decoder in scoring mode. For a frame that left at the gate, they come from the calibrated CTC probabilities of the steps that the best path assigns to each character. The fusion has three steps. First, the length of the track string is chosen by a weighted vote over the string lengths of the frames. Second, the frames whose string has this length are combined position by position:

$$P_{\text{track}}(c \mid j)\propto \exp\Big(\sum_{n=1}^{N_f} w_n \log P_n(c \mid j)\Big), \qquad (12)$$

where $P_n(c \mid j)$ is the distribution of position $j$ in frame $n$, $N_f$ is the number of frames, and $w_n$ is a weight that reflects the quality of frame $n$, for example its plate-level confidence. Frames with another string length receive the weight zero. Third, the fused string takes the most probable character of every position, and, when two characters of a position have similar fused probabilities, both variants are compared with the format score of Equation 6.

![Figure 34](figs/fig23_slot_fusion.png)

*Figure 34. Position-aligned multi-frame fusion. Frames whose strings have the same length share the same character positions. A weighted sum of log-probabilities per position combines complementary evidence across frames.*

The alignment by position needs no template and no plate type. It works for one-row and two-row plates in the same way, because both readers already return the characters in reading order.

More frames do not always mean more information. If all frames come from a short period of strong motion blur, their errors are nearly identical, and fusion repeats the same mistake with higher confidence. If the tracker mixes two vehicles, fusion is harmful. The weights $w_n$ reduce the influence of poor frames, and the tracking must ensure that all frames show the same plate. The fusion stage should also report the agreement between frames, because a strong consensus of identical errors and a strong consensus of correct readings look the same in the final confidence.

### 4.3.5. Information limit and honest uncertainty

The three strategies of this section act on different parts of the problem. Synthetic data changes what the model sees during training. Restoration guidance transfers useful information from clean images into the deployed recognizer. Multi-frame fusion adds real observations at inference. None of them can recover information that is absent from every observation. When the evidence is insufficient, the correct behaviour is to report the uncertainty, not to output the most familiar string. FADR therefore treats the review flag as a regular output, and Chapter 5 evaluates the reliability of its confidence values together with its accuracy.

## 4.4. Computational Cost, Deployment, and Safeguards

### 4.4.1. Cost model

Let $T_1$, $T_2$ and $T_3$ be the times of the three stages for one plate, and let $\rho_2$ and $\rho_3$ be the shares of plates that reach stages 2 and 3. The expected time per plate is:

$$\mathbb{E}[T]=T_1+\rho_2\,T_2+\rho_3\,T_3. \qquad (13)$$

Stage 1 contains the encoder, which dominates the cost, plus the queries, the CTC classifier, the greedy decoding and the gate. Stage 2 is one pass of the decoder in reading mode. Stage 3 is the prefix beam search, the CTC scoring of the candidates and one batched pass of the decoder in scoring mode. Because $\rho_2$ and $\rho_3$ are small for typical traffic, the expected time is close to $T_1$, that is, close to the time of a CTC-only recognizer with the same encoder. The worst-case time per plate is $T_1 + T_2 + T_3$. This value matters for systems with hard real-time limits. It is still much smaller than the time of an autoregressive decoder, because both passes of the decoder are parallel. Equation 13 also shows how to trade accuracy for speed: a higher gate threshold increases $\rho_2$ and the accuracy, and a lower threshold decreases both.

A parallel decoder is not slow in absolute terms. Its two layers with ten queries cost much less than the encoder. The gate is still useful, for two reasons. On a small CPU, every pass counts when hundreds of plates arrive per second. And the plates that pass the gate gain almost nothing from a second reading, so the computation is better spent elsewhere.

### 4.4.2. Deployment on edge devices

Many ALPR systems run on small computers. The design of FADR suits this setting. The encoder and the two heads form one network that can be exported to a standard inference runtime. The greedy decoding, the gate, the beam search, the CTC scoring and the joint score are small CPU routines. The automata are compiled once from the templates and loaded as data. Changing the templates for a new region, or adding a new plate type, requires only a new template file. The priors $\pi_k$ can be set per site, for example to reflect a high share of trucks at a logistics centre or a high share of new-energy vehicles in a city centre.

Figure 35 shows a typical deployment. The camera and the plate detector belong to the existing system. The exported network runs the encoder and the CTC branch for every plate, and the decoder only when the CPU routines request it. The template file, the site priors and the thresholds are data files. They are loaded at start-up and can be replaced on site, for example when a new plate type is introduced or when the latency budget changes.

![Figure 35](figs/fig33_deployment.png)

*Figure 35. Deployment of FADR on an edge device. The network is exported once; the decoding, the gate and the joint score are small CPU routines; templates, site priors and thresholds are data files that can be replaced without retraining.*

The cost of each stage should be measured on the target device. Attention, grouped convolutions and small matrix products have different costs on a GPU, on a desktop CPU and on an ARM processor. Quantization of the encoder to 8-bit integers usually reduces the cost of stage 1 substantially. The decoder can stay in a higher precision if its accuracy is sensitive, because it runs for few plates. The gate threshold can be adjusted after deployment without retraining, which allows the operator to adapt the system to a new latency budget.

### 4.4.3. Safeguards against overcorrection

Format knowledge is powerful, and therefore dangerous when it is wrong. FADR uses six safeguards:

1. **No hard rule.** The format is a finite score. A string outside all known templates receives the lower prior of the open format, but it is never removed from the candidates (Section 2.3.6).
2. **No classifier of the plate type.** The plate type is never predicted from the image, so no early decision can force a template on a plate. Candidates of all types compete on the same evidence (Section 4.2.4).
3. **Two readers that can veto each other.** A string must be supported by the CTC evidence and by the decoder. A plausible string that the image does not support receives a low score from at least one reader.
4. **Training against overconfidence.** Format-open synthetic strings and noisy context teach the decoder that the format and the context are evidence, not certainties (Sections 3.3.7 and 4.3.1).
5. **Two outputs.** FADR reports the raw draft of the CTC branch together with the final string, so that the effect of the second reader and of the format can always be checked.
6. **Monitoring of open-format results.** Plates whose final string fits no template are logged. A cluster of such plates with the same structure indicates a new plate series or a missing template, which the operator can then add.

These safeguards follow from the analysis of Chapter 1: format rules improve familiar plates, but used as hard rules they turn unfamiliar plates into confident errors. Chapter 5 measures the effect of the safeguards on a test set with withheld formats.

Figure 36 illustrates the six safeguards with Chinese examples. The black cross-border plate in the first and second panels has no template in the deployment of the example. It is still read correctly, because its string stays among the candidates and because both readers support it.

![Figure 36](figs/fig28_safeguards.png)

*Figure 36. The six safeguards against overcorrection, illustrated with fictional Chinese plate strings.*

### 4.4.4. Adding a new plate type

Plate systems change. China introduced new-energy plates with eight characters, and other countries introduce new series and new layouts. FADR handles such changes in four steps. First, before any change to the system, plates of the new type are read under the open format. Their strings fit no template, so they always reach the decoder, and they remain readable, although without the benefit of the format score. The monitoring of open-format results (Section 4.4.3) shows that a new structure has appeared. Second, the operator adds a template for the new type to the template file and sets a small prior. The gate and the format score use the new template immediately, because the automata are compiled from the file. No part of the network changes. Third, synthetic plates of the new type are rendered from the template (Section 4.3.1), with exact reading-order labels. Fourth, when convenient, the model is fine-tuned with these synthetic plates and with the first real examples, so that both readers learn the appearance of the new type, and the gate threshold is checked on a validation set that includes the new type.

Figure 37 illustrates the procedure with the large new-energy plate, whose template ends with the energy code D or F. Before step 2, a plate such as 苏E12345D is read under the open format. After step 2, a candidate in which the blurred final D is read as the digit 0 fits no template and receives the open-format prior, while the candidate with D receives the prior of the new template.

![Figure 37](figs/fig29_new_type.png)

*Figure 37. Adding a new plate type, illustrated with the large new-energy plate. The new plates are readable under the open format from the start; the template adds format knowledge at once and without any change to the network; the visual models are adapted later with synthetic and real examples.*

This procedure separates two kinds of knowledge. The template file contains exact, human-readable knowledge that can change quickly. The network contains visual knowledge that needs data. A purely learned recognizer must learn the new format from data alone, which takes time and can cause errors on the new plates in the meantime. A recognizer with hard rules rejects or corrupts the new plates until the rules are changed. FADR avoids both problems, because the open format keeps the new plates readable and the template file makes the new format usable as soon as it is written.

### 4.4.5. Privacy and transparency

ALPR systems process personal data, because a registration number identifies a vehicle and often its owner. Synthetic training data with fictional strings reduces the need for real images, although real images remain necessary for validation. The deployed system keeps the original images as evidence and does not generate enhanced images that could be mistaken for observations. Every output carries a confidence, the template under which it was read and, when needed, a review flag. These measures do not remove the obligations of data protection law, but they make the behaviour of the recognizer transparent to operators and auditors.

### 4.4.6. Summary of Chapter 4

FADR combines the CTC branch and the parallel decoder on one shared encoder with one joint training objective. At inference, a gate with a confidence condition and a format check sends clear plates directly to the output. The decoder reads only the remaining plates. When the two readers agree, the plate is accepted; when they differ, a joint score of CTC, decoder and format evidence selects the final string from the candidates of both. The plate type is never classified, and the open format keeps unseen plates readable. The average cost stays close to the cost of CTC recognition. For degraded plates, synthetic data with exact reading-order labels, training-only restoration guidance and position-aligned multi-frame fusion add information in different ways. Chapter 5 defines the experiments that test these claims and presents projected results.


# Chapter 5. Experiments (Projected Results) and Discussion

> **All numbers in the tables of this chapter, and every highlighted number in the text, are PROJECTED placeholders. They describe the expected size and direction of the effects so that the paper and the experiments can be planned. They are not measurements. The protocol, the datasets and the analysis are final; the numbers must be replaced with measured values.**

This chapter defines the evaluation of FADR and reports projected results. Section 5.1 describes the datasets, the splits, the label normalization, the metrics, the baselines and the planned implementation. Section 5.2 reports the main results on one-row and two-row plates, including a stress test with rotated, shifted and warped two-row plates. Section 5.3 studies the use of format knowledge, the contribution of each component, the computational cost and the behaviour of the gate. Section 5.4 studies degraded plates, analyzes the errors, lists the limitations and concludes the paper.

## 5.1. Datasets, Evaluation Protocol, and Implementation

### 5.1.1. Datasets

The evaluation uses four groups of data. Each group tests a different property of the recognizer.

**One-row Chinese plates.** CCPD contains a large number of images of Chinese blue one-row plates from parking scenes, with corner annotations and plate strings [22]. Its test images are divided into subsets with specific difficulties: Base (normal images), DB (dark or very bright images), FN (plates far from or near the camera), Rotate (horizontal rotation), Tilt (horizontal and vertical tilt), Weather (rain, snow and fog) and Challenge (the most difficult images). A later version of CCPD adds green new-energy plates with eight characters. These data test the recognition of the most common Chinese plate type under different conditions, and the recognition of the eight-character new-energy format.

Figure 38 illustrates the conditions of the CCPD subsets with a fictional plate. The images only show what each subset tests; they are drawings, not samples from the dataset.

![Figure 38](figs/fig30_ccpd_conditions.png)

*Figure 38. Conditions of the CCPD test subsets, illustrated with a fictional plate. The images are drawings for orientation; they are not samples from the dataset.*

**Mixed one-row and two-row plates.** CRPD contains road-surveillance images with plate-type labels for blue plates, yellow one-row plates, yellow two-row plates and white plates [46]. RodoSol-ALPR contains 20,000 toll-booth images with Brazilian and Mercosur layouts; half of the images show motorcycles with two-row plates [28]. Together, these datasets test two-row recognition in two countries, with Chinese and Latin characters, and with two different format systems.

**Unseen formats.** Two test sets measure the behaviour of the recognizer on formats that it has not seen during training. The first set uses real data: in a separate training run, all Mercosur plates of RodoSol-ALPR are removed from the training data, and the Mercosur test plates are used as the unseen-format test. The characters of Mercosur plates are known from the Brazilian plates, but their order is different. The second set uses synthetic data: Chinese plates of templates that are withheld from training, namely large new-energy plates, trailer plates and plates of vehicles from Hong Kong and Macau, are rendered with the renderer of Section 4.3.1.

**Low-resolution tracks.** UFPR-SR-Plates contains 10,000 tracks with five low-resolution and five high-resolution images each, captured on a Brazilian road [54]. It tests single-frame and multi-frame recognition of real low-resolution plates and allows training-only guidance with the high-resolution images.

**Training data.** All models are trained on the training splits of CCPD, CRPD and RodoSol-ALPR, together with synthetic Chinese and Brazilian plates. The synthetic set contains format-faithful and format-open strings in one-row and two-row layouts, with the character boxes that the reading-order guidance needs (Section 4.3.1). The same training data, the same vocabulary and the same augmentation are used for all methods; only FADR uses the character boxes.

### 5.1.2. Splits and leakage control

The standard splits of the datasets are used where they exist [22,28,46]. Near-duplicate images inflate recognition rates when they appear in both the training and the test split [68]. The splits are therefore checked for near-duplicates, and the validation set used for the thresholds and the calibration is separated from the training data at the level of the vehicle or the track. For UFPR-SR-Plates, all frames of a track are in the same split. The synthetic test set of withheld templates uses fonts and backgrounds that do not appear in the synthetic training set, so that the test does not reward the memorization of renderer artefacts.

Figure 39 summarizes the protocol, from the data sources to the metrics and the statistical tests.

![Figure 39](figs/fig31_protocol.png)

*Figure 39. The evaluation protocol: data sources, leakage control, test suites, metrics and statistics. All methods use the same training data, vocabulary and augmentation.*

### 5.1.3. Label normalization and vocabulary

The labels contain only the characters of the registration string. Separators, such as the dot after the second character of a Chinese one-row plate, and decorative marks are not part of the label. The label of a two-row plate is one string: the characters of the upper row followed by the characters of the lower row. No row index, no row boundary and no plate type are stored with the label, and no method of this chapter receives such information at test time, with one exception: the two line-split baselines of Section 5.1.5 need a row splitter, and this splitter is trained with row annotations. The synthetic training plates additionally carry the character boxes that the renderer knows; these boxes are used only by the reading-order guidance of Section 2.3.4 and only during training.

The vocabulary contains the Chinese provincial characters, the Latin letters, the digits and the special characters 挂, 学, 警, 港 and 澳. All methods use this vocabulary. The string that each method outputs is evaluated as it is, without any correction by a format rule after recognition. For FADR, two strings are stored for every plate, the draft of the CTC branch and the final string; the tables report the final string, and the row FADR-CTC reports the draft.

### 5.1.4. Metrics

The main metric is the **recognition rate (RR)**: the percentage of plates whose complete string is correct. It is reported separately for one-row and two-row plates. The other metrics are:

- the **unseen-format RR**, measured on the two unseen-format test sets;
- the **overcorrection rate**: the percentage of unseen-format plates whose output is a wrong string that fits a known template;
- the **invalid-output rate**: the percentage of outputs on known-format test sets that fit no known template;
- the **error composition**: the numbers of substitutions, deletions, insertions and row-order errors, where a row-order error is a string whose characters are correct but appear in a wrong order across the rows;
- the **robustness to geometry**: the RR on two-row plates after an additional rotation, shift or perspective change of the test crop;
- the **latency** per plate on three devices, and the **share of plates** that leave FADR at each of its three exits;
- the **shared-error rate**: among the wrong drafts that fail the gate, the percentage for which the decoder reads the same wrong string;
- for low-resolution data, the **track-level RR**, which counts a track as correct when its fused string is correct.

The calibration of the confidence is evaluated with the expected calibration error and with reliability diagrams, because the gate and the review flag depend on it [69].

### 5.1.5. Baselines

Seven baselines represent the main families of recognizers. CRNN [12] and LPRNet [21] are CTC recognizers with convolutional features; LPRNet is designed for license plates. SVTRv2-T [50] is the strongest CTC baseline and the starting point of the CTC branch of FADR. Two baselines add an application-level treatment of two-row plates to SVTRv2-T. *SVTRv2-T with line split* applies a row splitter to the crop, reads each row with SVTRv2-T and joins the two results; it is the common solution in deployed systems. *SVTRv2-T with rectification and line split* first maps the plate to an upright rectangle and then applies the line split; the rectification uses a small network that predicts the four corners of the plate, in the spirit of spatial transformer networks [15]. This baseline is the strongest version of the row-separation route of Section 2.3.1, and it is included so that the comparison with reading-order queries is fair. PARSeq-S [37] is a strong recognizer with a permuted autoregressive language model and iterative refinement. CPPD [51] is the parallel decoder from which the decoder of FADR is derived.

Two reduced versions of the proposed method show the contribution of its parts. **FADR-CTC** is the CTC branch alone: the encoder, the reading-order queries and greedy decoding, with no decoder and no format knowledge at inference. **FADR-Dec** runs the decoder and the joint score on every plate, without the gate. FADR-CTC is therefore the lower end of the cost range of the method, and FADR-Dec is the upper end.

### 5.1.6. Implementation details

The planned implementation uses the following settings; they are part of the protocol and may be adjusted during the experiments. The encoder follows SVTRv2-T and is initialized from a model pre-trained on scene text. All models are trained with the AdamW optimizer, a one-cycle learning-rate schedule and mixed precision. The input sizes follow the four MSR buckets. Data augmentation includes rotation of up to 30 degrees, shift, scale and perspective changes, followed by blur, noise, brightness changes and compression in the order described in Section 4.3.2. The same augmentation is used for all methods, so that no method is tested on a geometric change that it has not seen during training.

The CTC branch of FADR uses 24 reading-order queries. The decoder has ten position queries and two layers. Training follows the three phases of Section 4.1.3. The number of CTC candidates in stage 3 is five. The character confidences are calibrated with temperature scaling on the validation set [69]. The gate threshold is then selected on the validation set so that the plates accepted at the gate have a recognition rate of at least 99.5 percent; the projections of this chapter assume that this rule gives a threshold of 0.90. The weights of the joint score and the prior of the open format are tuned on the validation set after the gate threshold is fixed. Appendix B lists all settings.

Latency is measured with a batch size of one, after warm-up, as the median of repeated runs, on three devices: a desktop GPU, a desktop CPU with four threads and an ARM edge board with four threads. Plate detection is not included in the latency. For FADR, the latency is the mean over all test plates, so it includes the plates that stop at the gate and the plates that use the decoder.

### 5.1.7. Statistical testing

Differences between recognizers on clear plates are often a fraction of a percentage point. Such differences can be caused by chance, especially on small test sets. Every comparison of recognition rates in the final version of this chapter will therefore be accompanied by a statistical test. Because all methods are evaluated on the same test plates, the comparisons are paired. The McNemar test compares two recognizers on the plates where exactly one of them is correct. Confidence intervals for the recognition rate are computed with a paired bootstrap over plates, or over tracks for the multi-frame experiments. Each training configuration is repeated with three random seeds, and the mean and the standard deviation are reported. A difference is called significant only when the test rejects equality at the 5 percent level and the direction is the same for all seeds. These rules prevent the most common error in recognition benchmarks: the interpretation of a small, random difference as a property of a method.

## 5.2. Main Results on One-Row and Two-Row Plates

### 5.2.1. One-row Chinese plates

Table 1 reports the projected recognition rates on the CCPD test subsets and on green new-energy plates. On clear one-row plates (the Base subset), all modern recognizers are projected to be close to each other, and the differences are within the range that the statistical test of Section 5.1.7 may not confirm. This is expected: when the image is clear and the layout is simple, the encoder already contains everything that is needed, and the head that reads it matters little.

*Table 1. Exact-match recognition rate (%) on single-row Chinese plates (CCPD test subsets and green new-energy plates). Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Method | Base | DB | FN | Rotate | Tilt | Weather | Challenge | Green (NEV) | Avg. |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| CRNN [12] | 98.4 | 93.6 | 94.7 | 95.8 | 94.3 | 97.5 | 86.9 | 96.2 | 94.7 |
| LPRNet [21] | 98.7 | 94.2 | 95.1 | 96.4 | 94.9 | 97.8 | 87.8 | 96.8 | 95.2 |
| SVTRv2-T [50] | 99.4 | 96.6 | 97.3 | 98.4 | 97.5 | 98.9 | 92.4 | 98.3 | 97.4 |
| PARSeq-S [37] | 99.4 | 96.8 | 97.4 | 98.3 | 97.3 | 99.0 | 92.7 | 98.4 | 97.4 |
| CPPD [51] | 99.4 | 96.5 | 97.2 | 98.3 | 97.4 | 98.8 | 92.3 | 98.2 | 97.3 |
| FADR-CTC (ours) | 99.4 | 96.8 | 97.4 | 98.6 | 97.9 | 98.9 | 92.9 | 98.4 | 97.5 |
| FADR (ours) | 99.6 | 97.6 | 98.1 | 98.9 | 98.3 | 99.2 | 94.5 | 99.0 | 98.2 |

The row FADR-CTC is projected to be almost equal to SVTRv2-T on one-row plates (<mark>97.5%</mark> against <mark>97.4%</mark> on average). This is the intended result. Reading-order queries are not designed to improve one-row plates; the requirement is that they do not make them worse. A small projected gain appears only on the Rotate and Tilt subsets, where a query that is free to follow a tilted line has an advantage over a selection inside vertical columns.

The complete FADR is projected to reach <mark>98.2%</mark> on average, <mark>0.8 percentage points</mark> above SVTRv2-T. The gain is concentrated in the difficult subsets. On the Challenge subset, the projected recognition rate rises from <mark>92.4%</mark> to <mark>94.5%</mark>. Two mechanisms are expected to produce this gain. First, the decoder sees the other characters of the string and learns which characters are likely at each position; a blurred character that could be B or 8 is then read as a letter in a position where the visible context makes a letter likely. Second, the format score separates candidates that the two readers rate almost equally. Neither mechanism is active for the plates that pass the gate, which is why the Base subset changes little.

### 5.2.2. Two-row and mixed-layout plates

Table 2 reports the projected results on CRPD and RodoSol-ALPR, separated by layout. The two-row plates are the main target of this paper. All projected one-row results are close to each other, as in Table 1; the differences appear in the three two-row columns.

*Table 2. Exact-match recognition rate (%) on mixed one-row (1R) and two-row (2R) plates. BR = Brazilian layout, MS = Mercosur layout. Line split is applied only to two-row plates. Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Method | CRPD blue (1R) | CRPD yellow (1R) | CRPD yellow (2R) | RodoSol car BR (1R) | RodoSol car MS (1R) | RodoSol moto BR (2R) | RodoSol moto MS (2R) | Avg. 1R | Avg. 2R |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| CRNN [12] | 95.1 | 93.0 | 71.4 | 97.2 | 96.8 | 78.5 | 76.9 | 95.5 | 75.6 |
| LPRNet [21] | 95.6 | 93.6 | 74.2 | 97.5 | 97.0 | 80.3 | 79.1 | 95.9 | 77.9 |
| SVTRv2-T [50] | 97.6 | 96.4 | 86.1 | 98.8 | 98.5 | 90.4 | 89.6 | 97.8 | 88.7 |
| SVTRv2-T + line split [50] | 97.6 | 96.4 | 93.0 | 98.8 | 98.5 | 95.2 | 94.7 | 97.8 | 94.3 |
| PARSeq-S [37] | 97.7 | 96.6 | 93.4 | 98.9 | 98.6 | 95.6 | 95.0 | 98.0 | 94.7 |
| CPPD [51] | 97.5 | 96.3 | 93.1 | 98.7 | 98.4 | 95.3 | 94.8 | 97.7 | 94.4 |
| FADR-CTC (ours) | 97.8 | 96.7 | 95.0 | 98.9 | 98.6 | 96.6 | 96.1 | 98.0 | 95.9 |
| FADR (ours) | 98.3 | 97.4 | 96.5 | 99.2 | 99.0 | 97.7 | 97.2 | 98.5 | 97.1 |

SVTRv2-T is projected to reach <mark>88.7%</mark> on two-row plates. This projection is the most uncertain number of the chapter, and the reason should be stated clearly. Section 2.2.3 explained that the FRM of SVTRv2 is designed for text lines: its vertical step selects one token per column, so a column that contains one character of each row must serve two characters. Section 2.2.3 also explained that the horizontal step can, in principle, move information between columns, so the FRM is not strictly unable to read two rows. How well it does so after training on two-row plates is an empirical question. The projection assumes a clear but not catastrophic loss. If the measured value is much higher, the gain of the reading-order queries on upright plates will be smaller than projected here, and the argument for them will rest mainly on the rotated plates of Section 5.2.3. The first experiment of the plan is therefore the measurement of this baseline.

The application-level line split is projected to raise SVTRv2-T to <mark>94.3%</mark> on two-row plates. CPPD and PARSeq-S, whose decoders attend to the two-dimensional feature map, are projected to reach <mark>94.4%</mark> and <mark>94.7%</mark>. FADR-CTC is projected to reach <mark>95.9%</mark>, which is <mark>7.2 percentage points</mark> above SVTRv2-T, with the same encoder and with a CTC head of almost the same cost. This comparison isolates the first contribution of the paper: the two models differ only in the last step of the CTC branch and in the training-only guidance.

The complete FADR is projected to reach <mark>97.1%</mark> on two-row plates, <mark>2.7 percentage points</mark> above CPPD and <mark>2.8 percentage points</mark> above the line split. The step from FADR-CTC to FADR on two-row plates is projected to be larger than on one-row plates. Two-row plates are smaller in the image, their upper row is short and often partly hidden by the plate frame, and their drafts are therefore less certain; more of them fail the gate, and the decoder has more errors to repair.

The projected results also show a difference between the two countries. Chinese two-row plates have a provincial character in the upper row, which is a complex symbol that occupies few pixels; errors on this character are expected to remain the largest group on CRPD. Brazilian and Mercosur motorcycle plates contain only letters and digits, but the split between the rows differs between the two layouts, and the two layouts are mixed in the same test set. A recognizer that learns the reading order from the complete string, without a rule about the rows, handles both layouts with the same mechanism.

### 5.2.3. Robustness to rotation, shift and perspective

The reading-order queries were introduced because the rows of a rotated or warped plate cannot be separated reliably (Section 2.3.2). Tables 1 and 2 do not test this claim directly, because the test crops of the public datasets are mostly close to upright. A stress test is therefore added. The crops of the three two-row test sets are changed in a controlled way before recognition: they are rotated in the image plane by 10, 20 or 30 degrees, they are shifted and enlarged so that the plate is not centred and part of the background enters the crop, or they are warped by a random perspective that imitates a camera at the side of the road. The direction of the rotation is random. All models have seen changes of the same range during training (Section 5.1.6). Table 3 and Figure 40 report the projected results.

*Table 3. Geometric stress test on two-row plates: mean recognition rate (%) over the three two-row test sets of Table 2. The test crops are used as captured, rotated in the image plane, shifted and enlarged, or warped by a random perspective. All models are trained with the same geometric augmentation. Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Method | As captured | Rotated 10° | Rotated 20° | Rotated 30° | Shifted crop | Perspective |
|:--|--:|--:|--:|--:|--:|--:|
| SVTRv2-T [50] | 88.7 | 84.9 | 76.3 | 63.8 | 85.2 | 83.6 |
| SVTRv2-T + line split [50] | 94.3 | 89.6 | 77.4 | 60.2 | 86.9 | 87.5 |
| SVTRv2-T + rectification + line split [15,50] | 94.6 | 93.8 | 92.5 | 90.4 | 92.9 | 93.1 |
| PARSeq-S [37] | 94.7 | 93.9 | 92.4 | 89.6 | 93.5 | 93.2 |
| CPPD [51] | 94.4 | 93.5 | 91.8 | 88.7 | 93.1 | 92.8 |
| FADR-CTC (ours) | 95.9 | 95.2 | 94.0 | 91.8 | 95.0 | 94.7 |
| FADR (ours) | 97.1 | 96.6 | 95.7 | 94.0 | 96.4 | 96.2 |

![Figure 40](figs/fig_projected_rotation.png)

*Figure 40. Recognition rate on two-row plates under additional in-plane rotation of the test crop (PROJECTED). Values from the geometric stress test; placeholders for planning.*

Three groups of methods are expected. The first group contains SVTRv2-T and the line split on the raw crop. Both depend on the image axes: the FRM selects inside columns, and the splitter cuts along a horizontal line. Both are projected to lose most of their accuracy at 30 degrees; the line split falls from <mark>94.3%</mark> to <mark>60.2%</mark>, because a horizontal cut through a plate that is rotated by 30 degrees crosses the characters of both rows. At small angles the line split is still better than plain SVTRv2-T, and at large angles it is projected to be worse, because a wrong cut destroys characters that the plain model could at least see.

The second group contains the methods that do not depend on the image axes at test time: the rectified line split, CPPD and PARSeq-S. They are projected to lose between four and six percentage points at 30 degrees. For the rectified line split, the loss comes from errors of the corner prediction, which grow with the angle, and every such error is passed to the splitter and to the recognizer.

The third group contains FADR-CTC and FADR. FADR-CTC is projected to lose <mark>4.1 percentage points</mark> at 30 degrees and to stay above the rectified line split at every angle, without a rectification network and without a splitter. The complete FADR is projected to reach <mark>94.0%</mark> at 30 degrees. The shifted crops and the perspective changes are projected to cost FADR less than one percentage point.

These projections express the central expectation of this paper, and they are the ones that the experiments must confirm or reject. The comparison between FADR-CTC and the rectified line split deserves particular attention. If the measured difference between them is small, rectification followed by a line split remains a valid alternative for sites where a corner detector is already available; the advantage of the reading-order queries would then be the lower cost (<mark>7.1 ms</mark> against <mark>13.9 ms</mark> per plate on the CPU, Table 7) and the absence of a second model that must be trained and maintained.

### 5.2.4. Results by Chinese plate type

Table 4 groups the projected results by Chinese plate type. The table repeats some values of Tables 1 and 2, but it shows two additional facts: the result on white police plates, which do not appear as a separate column elsewhere, and the share of plates of each type that FADR sends to the decoder.

*Table 4. Recognition rate (%) by Chinese plate type, and share of plates that FADR sends to the decoder (%). Rows that overlap Tables 1 and 2 repeat their values. Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Plate type (test data) | SVTRv2-T | CPPD | FADR | Sent to decoder |
|:--|--:|--:|--:|--:|
| Blue small-car plate, 1 row (CRPD) | 97.6 | 97.5 | 98.3 | 9.6 |
| Green small new-energy plate, 1 row (CCPD) | 98.3 | 98.2 | 99.0 | 6.2 |
| Yellow plate, 1 row (CRPD) | 96.4 | 96.3 | 97.4 | 13.8 |
| Yellow plate, 2 rows (CRPD) | 86.1 | 93.1 | 96.5 | 21.4 |
| White police plate, 1 row (CRPD) | 94.8 | 95.0 | 96.6 | 18.9 |

The last column follows the difficulty of the plate type. Green new-energy plates are projected to need the decoder least often (<mark>6.2%</mark>): they are recent, clean and captured at short distance in CCPD. Yellow two-row plates are projected to need it most often (<mark>21.4%</mark>), for the reasons given in Section 5.2.2. For this type, the projected recognition rate rises from <mark>86.1%</mark> with SVTRv2-T to <mark>96.5%</mark> with FADR. White police plates end with the character 警, which is printed in red and is small in the image; the projection assumes that it is the main source of errors for this type (<mark>94.8%</mark> with SVTRv2-T and <mark>96.6%</mark> with FADR). The decoder is expected to help here in a specific way: once the other six characters are visible as context, the last position of a seven-character string on a white plate is almost always 警, and the decoder can learn this from data without any rule.

The table also shows that the share of plates sent to the decoder is not a constant of the method. It depends on the plate types and on the image quality at a site. A site with many trucks and motorcycles will have a higher share, and therefore a higher mean latency, than a car park. Section 5.3.3 gives the latency as a function of this share.

### 5.2.5. Qualitative examples

Figure 41 shows projected qualitative examples on Chinese plates. They are illustrations of the expected behaviour, and they are not outputs of a trained model. The examples are chosen to show the three typical cases: a clear plate on which all methods agree, a two-row plate on which the reading order decides, and a degraded plate on which the context and the format decide between confusable characters.

![Figure 41](figs/fig_projected_qualitative.png)

*Figure 41. Qualitative examples on Chinese plates (PROJECTED). The outputs are placeholders for planning and are not outputs of a trained model. Red marks wrong characters.*

The figure also contains one failure of FADR, because a selection of successes alone would be misleading. In this case the draft is wrong, the confidence is high, and the wrong string fits a known template. Such a plate passes the gate, and the decoder never sees it. Section 5.3.4 measures how often this case is expected.

## 5.3. Format Awareness, Ablation Study, and Efficiency

### 5.3.1. Format knowledge and unseen formats

Table 5 isolates the effect of format knowledge. All rows use models trained without Mercosur plates and without the withheld Chinese templates (Section 5.1.1), and the template file contains only the templates of the training formats. The rows differ only in the way the formats are used at inference.

*Table 5. Effect of format knowledge (same trained model, different use of the formats). Known = known-format test sets; Unseen-real = Mercosur plates withheld from training; Unseen-syn = synthetic plates from withheld templates; Overcorr. = share of unseen-format plates whose output is a wrong string of a known template; Invalid = share of outputs matching no known template on the known-format sets (all in %). Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Use of the formats | Known | Unseen-real | Unseen-syn | Unseen avg. | Overcorr. | Invalid |
|:--|--:|--:|--:|--:|--:|--:|
| CTC branch only, no format knowledge | 98.0 | 93.6 | 89.2 | 91.4 | 0.6 | 1.9 |
| CTC branch + regular-expression filter (nearest valid string) | 98.2 | 61.8 | 65.2 | 63.5 | 30.4 | 0.0 |
| FADR with formats as hard rules (other candidates removed) | 98.9 | 60.3 | 63.5 | 61.9 | 33.1 | 0.0 |
| FADR without the format score and the format check | 98.5 | 94.1 | 90.0 | 92.1 | 0.5 | 0.9 |
| FADR (format score with open-format prior) | 98.8 | 93.5 | 89.3 | 91.4 | 1.0 | 0.3 |

The first row is the CTC branch without any format knowledge. It is projected to read <mark>91.4%</mark> of the unseen-format plates correctly, which shows that a recognizer that reads characters, and does not classify plate types, already transfers well to new arrangements of known characters. Its weakness is on the other side: <mark>1.9%</mark> of its outputs on known formats fit no template, and each of these outputs is an error that could have been detected.

The second and third rows use the formats as hard rules. The regular-expression filter replaces every output that fits no template with the nearest valid string. The third row is FADR with the open format removed, so that every candidate outside the known templates is deleted from the pool. Both are projected to improve the known formats slightly and to fail on unseen formats: the recognition rate on unseen formats falls to about <mark>61.9%</mark>, and about one third of the unseen-format plates are turned into wrong strings of known templates (overcorrection of <mark>30.4%</mark> and <mark>33.1%</mark>). These errors are the most harmful kind for an ALPR system, because the output looks like a normal plate of a known type and no later check can detect it. The remaining correct plates in these rows are plates whose strings fit a known template by coincidence.

The fourth row is FADR without the format score and without the format check in the gate. It is the best row on unseen formats (<mark>92.1%</mark>), because nothing in it prefers a known format. The last row is the complete FADR. On known formats it is projected to gain <mark>98.8%</mark> against <mark>98.5%</mark>, and the invalid-output rate falls to <mark>0.3%</mark>. On unseen formats it is projected to fall from <mark>92.1%</mark> to <mark>91.4%</mark>, a loss of less than one percentage point, with an overcorrection rate of <mark>1.0%</mark>. This small loss is the price of the format score: a finite bonus for known templates must sometimes prefer a wrong known-format string to a correct unknown-format string. The prior of the open format controls this price, and a site that expects many foreign plates can raise it.

The behaviour of the gate on unseen formats follows from its definition. A correct draft of an unseen-format plate fits no known template, so it fails the format check, and the plate is sent to the decoder (<mark>99.4%</mark> of the unseen-format plates in Table 8). In most cases the decoder reads the same string, and the plate leaves at the second exit as an open-format result. Unseen formats are therefore not rejected and not forced into a template; they are read, they cost one decoder pass, and they are logged for the monitoring of Section 4.4.3.

### 5.3.2. Ablation study

Table 6 adds the components of FADR one by one to the SVTRv2-T baseline (rows A to F) and then removes or changes single components of the full model (rows G to L).

*Table 6. Ablation study. Avg. 1R and Avg. 2R follow Table 2; Unseen is the mean of the two unseen-format sets of Table 5; CPU latency in ms per plate. Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| ID | Configuration | Avg. 1R | Avg. 2R | Unseen | CPU (ms) |
|:-:|:--|--:|--:|--:|--:|
| A | SVTRv2-T baseline (FRM, greedy CTC) | 97.8 | 88.7 | 90.7 | 6.9 |
| B | + reading-order queries in place of the vertical FRM step | 97.9 | 94.8 | 91.0 | 7.1 |
| C | + reading-order guidance on synthetic data (= FADR-CTC) | 98.0 | 95.9 | 91.4 | 7.1 |
| D | + decoder on every plate, joint score without the format | 98.4 | 96.9 | 92.2 | 10.1 |
| E | + format score in the joint score | 98.6 | 97.2 | 91.5 | 10.1 |
| F | + gate with confidence and format check (= FADR) | 98.5 | 97.1 | 91.4 | 7.3 |
| G | F, gate without the format check | 98.3 | 96.8 | 91.6 | 7.3 |
| H | F, decoder only re-scores the CTC candidates | 98.4 | 96.4 | 91.0 | 7.3 |
| I | F, decoder without character-context attention | 98.4 | 96.8 | 91.1 | 7.3 |
| J | F without the counting and ordering losses | 98.5 | 96.9 | 91.3 | 7.3 |
| K | F without SGM | 98.5 | 97.0 | 91.3 | 7.3 |
| L | F with formats as hard rules | 98.7 | 97.3 | 61.9 | 7.3 |

**Rows A to C: the CTC branch.** Replacing the vertical step of the FRM with reading-order queries (row B) is projected to give the largest single gain of the table: <mark>6.1 percentage points</mark> on two-row plates, with almost no change on one-row plates and <mark>7.1 ms</mark> instead of <mark>6.9 ms</mark> on the CPU. The reading-order guidance on synthetic plates (row C) is projected to add <mark>1.1 percentage points</mark> on two-row plates. Its role is to tell the queries early in training in which order the positions of a two-row plate are read; without it, the order must be found from the CTC loss alone, which is slower and less stable for the rare plate types.

**Rows D to F: the decoder, the format and the gate.** Running the decoder on every plate with a joint score of the two readers (row D) is projected to add about one percentage point on two-row plates. Adding the format score (row E) improves the known formats again and costs a little on unseen formats, as discussed in Section 5.3.1. Row E is the most accurate configuration of this group on known formats, and it is also the most expensive: <mark>10.1 ms</mark> per plate. The gate (row F, the complete FADR) is projected to reduce the cost to <mark>7.3 ms</mark> while losing only one tenth of a percentage point. This is the second contribution of the paper in one line of the table: the decoder is worth its cost only on the plates where the CTC branch is uncertain.

**Row G: the format check in the gate.** If the gate uses the confidence alone, drafts that are confident but fit no template are accepted. The projection assumes that this costs a few tenths of a percentage point on known formats. On unseen formats, row G is slightly better than row F, for the reason given above. The format check is a cheap test, a few table lookups per plate, and its value is that it catches errors that the confidence does not see.

**Row H: re-scoring only.** In row H the decoder does not read the plate itself; it only re-scores the five candidates of the CTC branch. The projected loss is largest on two-row plates (<mark>96.4%</mark> against <mark>97.1%</mark>). The reason is the one given in Section 4.2.3: when the correct string is not among the CTC candidates, re-scoring cannot produce it. Two-row plates have more such cases, because an error in the reading order changes several characters at once and the beam search does not recover from it. This row is the experimental answer to the question of whether the decoder can repair an error of the CTC branch or only confirm it.

**Rows I to K: the decoder and the training-only modules.** Without the character-context attention (row I) the decoder is close to CPPD: it can read, but it cannot use the visible characters, and its scores for complete strings are weaker. Removing the counting and ordering losses of CPPD (row J) or the SGM of SVTRv2 (row K) is projected to cost one or two tenths of a percentage point each. These modules were designed for scene text, and their benefit on license plates is uncertain; the differences in rows J and K are small enough that the statistical test may not confirm them. If the test does not confirm them, the modules will be removed, which simplifies training.

**Row L: hard rules.** With hard format rules, the known formats are projected to gain one or two tenths of a percentage point, and the unseen formats fall to <mark>61.9%</mark>. The comparison of rows F and L summarizes the argument of Section 2.3.6: almost all the benefit of format knowledge can be obtained without making the format a rule.

### 5.3.3. Efficiency

Table 7 reports the projected model sizes and latencies. The encoder dominates the cost of all SVTRv2-based models. FADR-CTC adds only the attention of 24 queries to the encoder features; it is projected to need <mark>7.1 ms</mark> on the CPU against <mark>6.9 ms</mark> for SVTRv2-T. The decoder adds parameters (<mark>7.1 M</mark> against <mark>5.3 M</mark>), but it runs only for a part of the plates.

*Table 7. Model size and recognition latency per plate (batch size 1; detection excluded). FADR latencies include the projected share of plates that reach stages 2 and 3; FADR-Dec is also the worst case of FADR for a single plate. ‡ Two-row plates only (splitter and two recognizer calls; the rectified version adds a corner network). Parameter counts of published models must be taken from their papers or measured. Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Method | Params (M) | GFLOPs | GPU (ms) | CPU (ms) | Edge ARM (ms) |
|:--|--:|--:|--:|--:|--:|
| CRNN [12] | 8.3 | 0.9 | 1.3 | 5.5 | 24.0 |
| LPRNet [21] | 0.5 | 0.3 | 0.6 | 1.2 | 5.1 |
| SVTRv2-T [50] | 5.1 | 1.3 | 2.0 | 6.9 | 30.0 |
| SVTRv2-T + line split [50] ‡ | 5.1 | 2.1 | 3.6 | 12.3 | 52.0 |
| SVTRv2-T + rectification + line split [15,50] ‡ | 5.6 | 2.3 | 4.2 | 13.9 | 58.5 |
| PARSeq-S [37] | 23.8 | 3.1 | 6.5 | 19.4 | 96.0 |
| CPPD [51] | 6.8 | 1.6 | 2.6 | 8.9 | 39.0 |
| FADR-CTC (ours) | 5.3 | 1.4 | 2.1 | 7.1 | 30.6 |
| FADR-Dec (decoder on every plate) | 7.1 | 1.8 | 3.2 | 10.1 | 43.3 |
| FADR (ours) | 7.1 | 1.4 | 2.2 | 7.3 | 31.5 |

With the projected shares of Table 8, the mean latency of FADR on the CPU is <mark>7.3 ms</mark>, which is <mark>5.2%</mark> above SVTRv2-T. Without the gate (FADR-Dec), the latency would be <mark>10.1 ms</mark>, <mark>45.7%</mark> above SVTRv2-T. The two line-split baselines need a splitter and two recognition passes for two-row plates, and the rectified version needs a corner network in addition; both are projected to be slower than FADR-Dec on two-row plates. PARSeq-S is the slowest method because of its larger model and its iterative refinement.

The latency of FADR is a mean, and the latency of a single plate takes one of three values: the cost of stage 1 for plates that pass the gate, plus the cost of one decoder pass for plates that leave at the second exit, plus the cost of the beam search and the scoring pass for plates that reach the third exit (Equation 13). The worst case is the latency of FADR-Dec. A system with a hard real-time limit must be dimensioned for this worst case, or it must limit the number of plates per second that may enter stage 3; in a video system, a plate that is not refined in one frame can be refined in the next frame of the same track.

Figure 42 places the methods in the plane of accuracy and CPU latency. LPRNet is the fastest model, but it is projected to be the least accurate on two-row plates. PARSeq-S is accurate and slow. FADR is projected to lie above and to the left of CPPD and PARSeq-S: higher accuracy at a latency close to that of the CTC baseline.

![Figure 42](figs/fig_projected_tradeoff.png)

*Figure 42. Accuracy against CPU latency (PROJECTED). Accuracy is the mean recognition rate over the fifteen test sets of the two main result tables. The values are placeholders for planning.*

### 5.3.4. Behaviour of the gate and of the two readers

Table 8 shows where plates are projected to leave FADR. On the known-format test sets, <mark>89.5%</mark> of the plates are projected to pass the gate, so that <mark>10.5%</mark> are read by the decoder and <mark>4.5%</mark> reach the joint score. The shares differ between the data groups: <mark>5.4%</mark> of the car plates of RodoSol-ALPR need the decoder, against <mark>15.3%</mark> of the motorcycle plates. The plates that pass the gate are projected to have a recognition rate of at least <mark>99.5%</mark>, which is the condition used to select the threshold.

*Table 8. Where plates leave FADR (% of plates): at the gate (exit 1), by agreement of the two readers (exit 2) or by the joint score (exit 3), and the recognition rate of the plates accepted at the gate. No value is given for the unseen-format test, because a draft that passes the format check there is wrong by definition. Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Test group | Exit 1 | Exit 2 | Exit 3 | RR at exit 1 |
|:--|--:|--:|--:|--:|
| CCPD (all subsets) | 91.6 | 5.1 | 3.3 | 99.8 |
| CRPD (all types) | 87.1 | 7.4 | 5.5 | 99.6 |
| RodoSol cars | 94.6 | 3.4 | 2.0 | 99.9 |
| RodoSol motorcycles | 84.7 | 8.1 | 7.2 | 99.5 |
| Unseen-format test | 0.6 | 72.1 | 27.3 | – |

Figure 43 shows the projected effect of the gate threshold. A low threshold accepts more drafts, which saves time but accepts more wrong drafts. A high threshold sends more plates to the decoder; the accuracy then rises slowly and saturates, because the additional plates are mostly plates that the CTC branch had already read correctly. The default threshold lies at the point where the curve becomes flat.

![Figure 43](figs/fig_projected_threshold.png)

*Figure 43. Effect of the gate threshold on the recognition rate and on the share of plates sent to the decoder (PROJECTED). The dashed line is the CTC branch alone. Placeholder values for planning.*

The curve does not reach 100 percent of the possible gain, and the reason is the blind spot of the gate described in Section 2.3.8. A draft that is wrong, confident and valid passes the gate. Under the projection, such drafts are <mark>0.26%</mark> of all plates. This is a small number, but it is <mark>9.8%</mark> of all errors of the CTC branch and <mark>13.3%</mark> of all remaining errors of FADR. No setting of the threshold below one removes these errors completely. They can be reduced only by a better calibration, by the training against overconfidence of Section 4.4.3, or, in a video system, by the fusion of several frames.

Table 9 looks inside the plates that fail the gate. For each of them, the draft and the reading of the decoder are compared with the label.

*Table 9. The two readers on the plates that fail the gate (known-format test sets, pooled): share of these plates in each case, and recognition rate of the final output of FADR in each case (all in %). Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Case | Share of gated plates | RR of the final output |
|:--|--:|--:|
| Readers agree, string correct | 54.1 | 100.0 |
| Readers agree, string wrong (shared error) | 3.0 | 0.0 |
| Draft wrong, decoder reading correct | 16.5 | 70.0 |
| Draft correct, decoder reading wrong | 23.0 | 77.5 |
| Both wrong, different strings | 3.4 | 10.0 |

Four observations are expected. First, the gate selects the right plates: only <mark>77.1%</mark> of the drafts that fail the gate are projected to be correct, against more than <mark>99.5%</mark> of the drafts that pass it. Second, the decoder alone is not better than the CTC branch on these plates (<mark>70.6%</mark>). In reading mode it has no visible characters, so it is close to CPPD, and the plates are difficult for any reader. Third, the combination is better than each reader: the final output is projected to be correct for <mark>83.8%</mark> of these plates. The two readers make different errors, and the joint score with the format score selects the correct string in most cases where exactly one reader is correct. Fourth, the combination is not free of errors. In <mark>3.0%</mark> of the gated plates both readers produce the same wrong string, and the plate leaves at the second exit with an error that agreement cannot detect. The shared-error rate, the share of wrong drafts that the decoder repeats, is projected to be <mark>13.1%</mark>. It measures how independent the two readers are. Both readers use the same encoder, so a value of zero cannot be expected; a measured value much higher than the projection would mean that the decoder adds little, and that a second encoder or a different input resolution for the decoder should be considered.

The table also shows the cost of the joint score in the other direction. When the draft is correct and the decoder reads a different string, the joint score is projected to keep the correct draft in <mark>77.5%</mark> of the cases; in the other cases a correct draft is replaced by a wrong string. FADR therefore stores both strings for every plate (Section 4.4.3), so that these cases can be found and counted in operation.

### 5.3.5. Reliability of the confidence and the review flag

An ALPR system is judged not only by how often it is right, but also by how well it knows when it is wrong. Table 10 reports the projected reliability of the plate-level confidence. In this experiment, the two percent of the plates with the lowest confidence are flagged for review, and the table reports how many of the errors are among the flagged plates.

*Table 10. Reliability of the plate-level confidence on the known-format test sets. ECE = expected calibration error. Errors flagged = share of all wrong outputs that fall into the 2 % of plates with the lowest confidence. RR kept = recognition rate of the 98 % of plates that are not flagged (all in %). Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Confidence source | ECE | Errors flagged | RR (all) | RR kept |
|:--|--:|--:|--:|--:|
| SVTRv2-T (product of frame maxima) | 3.9 | 41.0 | 95.7 | 97.4 |
| CPPD (product of slot maxima) | 3.1 | 46.5 | 96.8 | 98.3 |
| FADR without calibration | 2.6 | 58.0 | 98.0 | 99.2 |
| FADR with temperature scaling | 0.8 | 67.5 | 98.0 | 99.3 |

The confidence of a CTC recognizer, computed as the product of the maxima of its steps, is projected to be overconfident (ECE of <mark>3.9%</mark>), and only <mark>41.0%</mark> of its errors are projected to be among the flagged plates. The confidence of CPPD is slightly better. FADR has more information for its confidence: the calibrated character confidences, the agreement or disagreement of two readers, and the distance between the best and the second-best candidate of the joint score. With temperature scaling, its ECE is projected to fall to <mark>0.8%</mark>, and <mark>67.5%</mark> of its errors are projected to be flagged. The recognition rate of the plates that are not flagged then rises to <mark>99.3%</mark>. For an operator, this means that a review of two percent of the plates removes about two thirds of the errors.

### 5.3.6. Sensitivity to the template file

The benefit of format knowledge depends on the quality of the templates. Table 11 reports projected results under four kinds of errors in the template file.

*Table 11. Sensitivity of FADR to errors in the template set and in the site priors. Same protocol as Table 5; the last column is the share of plates of the known-format sets that are sent to the decoder (all in %). Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Template setting | Known | Unseen avg. | Overcorr. | Sent to decoder |
|:--|--:|--:|--:|--:|
| Correct templates and site priors (default) | 98.8 | 91.4 | 1.0 | 10.5 |
| Small new-energy template missing | 98.6 | 91.3 | 0.9 | 13.9 |
| Small-car template with a wrong slot type (serial: digits only) | 98.3 | 91.2 | 1.2 | 24.8 |
| Uniform template priors (no site prior) | 98.7 | 91.5 | 0.8 | 10.5 |
| Strongly wrong site priors | 98.6 | 91.1 | 1.4 | 10.5 |

A missing template does not make its plates unreadable. Their drafts fail the format check, the plates are sent to the decoder (the share rises to <mark>13.9%</mark>), and they are read under the open format; the cost is latency and a small loss of accuracy, because these plates no longer receive the format bonus. A wrong template is more harmful than a missing one. If the serial of the small-car template is declared as digits only, every correct string with a letter in the serial fails the format check, the share of plates sent to the decoder is projected to rise to <mark>24.8%</mark>, and the format score now works against the correct strings. Even then the projected loss on known formats is about half a percentage point, because the format is a finite score and the two readers can outvote it. With a hard rule, the same error in the template would make every such plate wrong.

Wrong priors have a smaller effect than wrong templates. Uniform priors are projected to cost almost nothing, so a site without statistics can start with them.

One kind of template error that was important in row-based designs has no effect here. The templates of this paper also record how the characters are arranged in rows, but only the renderer of synthetic plates reads this part (Section 2.3.5). The recognizer uses only the sequence of slot types. A wrong row arrangement in a template therefore produces wrong synthetic plates for that type, which matters at the next training, but it does not change the recognition of real plates by a trained model.

The results support two practical recommendations. The templates should be checked against the official standard before deployment, and a wrong slot type is the error to look for. The share of plates sent to the decoder and the share of open-format results should be monitored per site, because both rise when a template is wrong or missing, long before anyone inspects single plates.

## 5.4. Degraded Plates, Error Analysis, Limitations, and Conclusion

### 5.4.1. Low-resolution and multi-frame recognition

Table 12 reports projected track-level results on the low-resolution tracks of UFPR-SR-Plates. All models are trained on the low-resolution images of the training tracks. This test is far more difficult than the others: a single low-resolution frame is projected to be read correctly in about half of the cases.

*Table 12. Track-level recognition rate (%) on low-resolution UFPR-SR-Plates tracks (models trained on the low-resolution images; no super-resolution at inference). CPU time in ms per track. Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Configuration | LR frames | RR (%) | CPU (ms/track) |
|:--|:-:|--:|--:|
| SVTRv2-T, single LR frame | 1 | 50.8 | 6.9 |
| FADR, single LR frame | 1 | 55.1 | 8.4 |
| + training-only HR→LR distillation | 1 | 58.9 | 8.4 |
| SVTRv2-T, 5-frame string vote | 5 | 60.9 | 34.6 |
| FADR + distillation, 5-frame string vote | 5 | 64.7 | 41.9 |
| FADR + distillation, 5-frame position-aligned fusion | 5 | 67.9 | 41.9 |

On a single frame, FADR is projected to reach <mark>55.1%</mark> against <mark>50.8%</mark> for SVTRv2-T. On these images most drafts fail the gate, so the decoder runs for more than half of the frames, and the latency per frame rises to <mark>8.4 ms</mark>. The training-only distillation from high-resolution images (Section 4.3.3) is projected to add <mark>3.8 percentage points</mark> without any cost at inference. With five frames, the position-aligned fusion of Section 4.3.4 is projected to add <mark>3.2 percentage points</mark> over a vote between the five strings.

The projected gain of the fusion over string voting comes from the use of character probabilities. String voting needs a majority of frames that are completely correct. Position-aligned fusion needs only that, for every position, the correct character has the highest combined probability over the frames; the frames may be wrong at different positions. The fusion needs no plate type and no template: the positions are aligned by the length of the string, and frames with a different length receive no weight. This is also its limit, and it is stated here because the simplification has a price. A frame that misses one character is not used at all, although most of its characters are correct. An alignment by edit distance would use such frames; it is left for future work.

### 5.4.2. Error analysis

Table 13 decomposes the projected errors on the three two-row test sets. For SVTRv2-T with the published FRM, row-order errors and deletions are projected to be large groups: <mark>34</mark> and <mark>29</mark> of <mark>113</mark> errors per 1,000 plates. Deletions are typical for a head that must place two characters in one column. The line split and CPPD remove most of these errors. FADR is projected to leave <mark>4</mark> row-order errors and <mark>29</mark> errors in total per 1,000 plates.

*Table 13. Error composition on the three two-row test sets (errors per 1,000 plates, pooled). Row-order errors are strings whose characters are correct but placed in the wrong row order. Highlighted values are PROJECTED placeholders for planning; they are not measurements and must be replaced with measured results.*

| Method | Substitution | Deletion | Insertion | Row order | Total |
|:--|--:|--:|--:|--:|--:|
| SVTRv2-T [50] | 41 | 29 | 9 | 34 | 113 |
| SVTRv2-T + line split [50] | 30 | 12 | 5 | 10 | 57 |
| CPPD [51] | 28 | 11 | 6 | 11 | 56 |
| FADR (ours) | 18 | 5 | 2 | 4 | 29 |

The remaining errors of FADR are expected to be mostly substitutions. They concern three kinds of characters. The first kind is the provincial character, a complex symbol on few pixels, for which no format and no context helps, because every province is valid at this position. The second kind is the confusable pairs inside one slot type, such as B and 8 or D and 0 in a serial that allows both letters and digits (Figure 6). The format helps only when the template allows one of the two. The third kind is the pairs of digits, such as 3 and 8, for which the format never helps. For these errors only better images, more frames or a better encoder can help.

Figure 44 shows one example of each error category and of two special cases. A confusion between provincial characters counts as a substitution. An overcorrection is counted separately on the unseen-format sets.

![Figure 44](figs/fig32_error_types.png)

*Figure 44. Error types of the error analysis, with fictional Chinese examples. Red marks the wrong part of each output.*

The row-order errors that are projected to remain for FADR deserve a closer look in the real experiments, because they test the main assumption of the reading-order queries: that the order can be learned from the complete string. The expected cases are plates whose upper row is cut by the crop, so that the queries of the first positions find no clear target, and plates rotated by more than the range seen in training. If such errors appear on upright, complete plates, the guidance of Section 2.3.4 is too weak, and its weight or the share of synthetic two-row plates must be raised.

### 5.4.3. Limitations

This paper has seven limitations.

1. **Projected results.** The most important limitation of this draft is that all results in this chapter are projected. The method, the protocol and the analysis are specified, but no number has been measured. The projections are estimates based on published results of the underlying methods [50,51] and on the expected effect of each component; real experiments may change both the size and the order of the effects. The most uncertain projections are the two-row result of the SVTRv2-T baseline (Section 5.2.2) and the difference between FADR-CTC and the rectified line split (Section 5.2.3).
2. **The reading order is learned, not guaranteed.** The reading-order queries learn the order of the characters from the labels, with the help of synthetic plates. Nothing in the design forces a correct order. For a layout that is rare in the training data, or for a rotation outside the training range, the order may be wrong, and the CTC branch gives no signal of this error other than a low confidence.
3. **The blind spot of the gate.** A draft that is wrong, confident and valid is accepted without a second reading. The projection puts these cases at <mark>0.26%</mark> of all plates. They are the errors that the method cannot repair by design.
4. **Correlated readers.** The CTC branch and the decoder share the encoder, so their errors are correlated. Agreement between them is good evidence, but it is not independent confirmation; the shared-error rate of Table 9 must be measured and reported.
5. **Template dependence.** The format score depends on correct templates. Templates must follow the official specification of each region [60–64] and must be updated when regulations change. The sensitivity test of Section 5.3.6 limits the damage of a wrong template, but it does not remove it. FADR also does not recognize characters that are absent from its vocabulary; a plate in a new script requires new training data.
6. **Dependence on detection.** The evaluation uses plate crops. In an end-to-end system, detection errors, cut plates and wrong tracks add errors that this evaluation does not measure [65,66]. The stress test of Section 5.2.3 covers rotated, shifted and warped crops, but not crops that miss a part of the plate.
7. **Data coverage.** Two-row Chinese plates are less common in public datasets than blue one-row plates, and strongly rotated two-row plates are rare. Part of the two-row evaluation, and all of the stress test, therefore relies on synthetic plates or on artificial changes of real crops. Synthetic rotation is not the same as a camera that is mounted at an angle, where rotation appears together with perspective and motion blur. A set of real, strongly rotated two-row plates should be collected before strong claims are made.

### 5.4.4. Conclusion

This paper addressed the efficient recognition of one-row and two-row license plates with visual and linguistic context, using the officially defined formats of plate numbers. It first described the two published recognizers on which the work is built. SVTRv2 shows that a CTC model can be accurate when the encoder is strong, when the input shape follows the aspect ratio of the text and when a training-only module supplies linguistic context. CPPD shows that a parallel decoder can read a string in one pass when it is trained to count and to order the characters. The analysis also showed what each of them lacks for license plates: the CTC head of SVTRv2 assumes one text line, the decoder of CPPD does not use the characters that are already known, and neither uses the formats.

The proposed Format-Aware Draft-and-Refine recognizer is built around three ideas. First, **reading-order queries** replace the column-wise step of the CTC head. Each CTC step is produced by a learned query that attends to the whole feature map, so the same head reads one-row and two-row plates, upright or rotated, without a row splitter, without row labels and without a decision about the layout. Second, a **context-aware parallel decoder** reads the plates on which the CTC branch is uncertain. It can read a plate independently, so it can repair an error of the CTC branch and not only confirm a reading, and it can score any complete string by looking at each character in the context of the others. A gate based on calibrated confidence sends only the uncertain plates to the decoder, and a joint score of both readers decides when they disagree. Third, the **formats are used without a format classifier**. No component predicts the plate type. The templates only answer the question of whether a given string fits a known format, and the answer enters the gate and the joint score as a finite score, so that a plate of an unknown format is still read.

The projected results indicate the expected pattern: almost no change on clear one-row plates, the largest gains on two-row plates and on rotated plates, a further gain on difficult plates from the decoder, and a mean latency close to that of the CTC baseline because about nine plates in ten stop at the gate. Whether the real numbers follow this pattern must be shown by the experiments. The value of the present draft is the design, which keeps the number of new components small, and an evaluation protocol that tests each of the three ideas with its own experiment: the rotation stress test for the reading-order queries, the comparison of the two readers on the gated plates for the decoder, and the unseen-format test for the use of the formats.

### 5.4.5. Future work

The next steps are, first, to implement FADR on top of the published SVTRv2 and CPPD code and to measure every number of this chapter, beginning with the two-row result of the SVTRv2-T baseline and with the rotation stress test. Second, a set of real two-row plates with strong rotation and perspective should be collected, because the central claim of the paper concerns such plates. Third, the template file should be extended to more regions, and the unseen-format test should be repeated with real plates of regions that are completely absent from training [43,48]. Fourth, the position-aligned fusion should be replaced by an alignment that can use frames with a missing character, and the decision about which frame of a track enters stage 3 should be made at the level of the track. Fifth, the shared-error rate should be reduced; a decoder that reads a higher-resolution crop than the CTC branch is one direction, and mutual learning between the two readers during training is another [67]. Finally, the complete system, including detection and tracking, should be evaluated on an embedded device under a fixed time limit per frame.


# References

*Entries [1]–[10] are reserved for later insertion.*

**[1]**

**[2]**

**[3]**

**[4]**

**[5]**

**[6]**

**[7]**

**[8]**

**[9]**

**[10]**

**[11]** Graves, A., Fernández, S., Gomez, F., and Schmidhuber, J. (2006). "Connectionist Temporal Classification: Labelling Unsegmented Sequence Data with Recurrent Neural Networks." *Proceedings of the 23rd International Conference on Machine Learning (ICML)*, 369–376. https://doi.org/10.1145/1143844.1143891

**[12]** Shi, B., Bai, X., and Yao, C. (2017). "An End-to-End Trainable Neural Network for Image-Based Sequence Recognition and Its Application to Scene Text Recognition." *IEEE Transactions on Pattern Analysis and Machine Intelligence*, 39(11), 2298–2304. https://doi.org/10.1109/TPAMI.2016.2646371

**[13]** Watanabe, S., Hori, T., Kim, S., Hershey, J. R., and Hayashi, T. (2017). "Hybrid CTC/Attention Architecture for End-to-End Speech Recognition." *IEEE Journal of Selected Topics in Signal Processing*, 11(8), 1240–1253. https://doi.org/10.1109/JSTSP.2017.2763455

**[14]** Higuchi, Y., Watanabe, S., Chen, N., Ogawa, T., and Kobayashi, T. (2020). "Mask CTC: Non-Autoregressive End-to-End ASR with CTC and Mask Predict." *Proceedings of Interspeech 2020*. https://arxiv.org/abs/2005.08700

**[15]** Jaderberg, M., Simonyan, K., Zisserman, A., and Kavukcuoglu, K. (2015). "Spatial Transformer Networks." *Advances in Neural Information Processing Systems (NeurIPS)*. https://arxiv.org/abs/1506.02025

**[16]** He, K., Zhang, X., Ren, S., and Sun, J. (2016). "Deep Residual Learning for Image Recognition." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/1512.03385

**[17]** Liu, W., Chen, C., Wong, K.-Y. K., Su, Z., and Han, J. (2016). "STAR-Net: A SpaTial Attention Residue Network for Scene Text Recognition." *British Machine Vision Conference (BMVC)*. https://www.bmva-archive.org.uk/bmvc/2016/papers/paper043/index.html

**[18]** Shi, B., Wang, X., Lyu, P., Yao, C., and Bai, X. (2016). "Robust Scene Text Recognition with Automatic Rectification." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/1603.03915

**[19]** Shi, B., Yang, M., Wang, X., Lyu, P., Yao, C., and Bai, X. (2019). "ASTER: An Attentional Scene Text Recognizer with Flexible Rectification." *IEEE Transactions on Pattern Analysis and Machine Intelligence*, 41(9), 2035–2048. https://doi.org/10.1109/TPAMI.2018.2848939

**[20]** Baek, J., Kim, G., Lee, J., Park, S., Han, D., Yun, S., Oh, S. J., and Lee, H. (2019). "What Is Wrong with Scene Text Recognition Model Comparisons? Dataset and Model Analysis." *IEEE/CVF International Conference on Computer Vision (ICCV)*. https://arxiv.org/abs/1904.01906

**[21]** Zherzdev, S., and Gruzdev, A. (2018). "LPRNet: License Plate Recognition via Deep Neural Networks." *arXiv* preprint arXiv:1806.10447. https://arxiv.org/abs/1806.10447

**[22]** Xu, Z., Yang, W., Meng, A., Lu, N., Huang, H., Ying, C., and Huang, L. (2018). "Towards End-to-End License Plate Detection and Recognition: A Large Dataset and Baseline." *European Conference on Computer Vision (ECCV)*. https://openaccess.thecvf.com/content_ECCV_2018/html/Zhenbo_Xu_Towards_End-to-End_License_ECCV_2018_paper.html

**[23]** Silva, S. M., and Jung, C. R. (2018). "License Plate Detection and Recognition in Unconstrained Scenarios." *European Conference on Computer Vision (ECCV)*. https://openaccess.thecvf.com/content_ECCV_2018/html/Sergio_Silva_License_Plate_Detection_ECCV_2018_paper.html

**[24]** Laroca, R., Severo, E., Zanlorensi, L. A., Oliveira, L. S., Gonçalves, G. R., Schwartz, W. R., and Menotti, D. (2018). "A Robust Real-Time Automatic License Plate Recognition Based on the YOLO Detector." *International Joint Conference on Neural Networks (IJCNN)*. https://doi.org/10.1109/IJCNN.2018.8489629

**[25]** Hsu, G.-S., Chen, J.-C., and Chung, Y.-Z. (2013). "Application-Oriented License Plate Recognition." *IEEE Transactions on Vehicular Technology*, 62(2), 552–561. https://doi.org/10.1109/TVT.2012.2226218

**[26]** Laroca, R., Zanlorensi, L. A., Gonçalves, G. R., Todt, E., Schwartz, W. R., and Menotti, D. (2021). "An Efficient and Layout-Independent Automatic License Plate Recognition System Based on the YOLO Detector." *IET Intelligent Transport Systems*, 15(4), 483–503. https://doi.org/10.1049/itr2.12030

**[27]** Henry, C., Ahn, S. Y., and Lee, S.-W. (2020). "Multinational License Plate Recognition Using Generalized Character Sequence Detection." *IEEE Access*, 8, 35185–35199. https://doi.org/10.1109/ACCESS.2020.2974973

**[28]** Laroca, R., Cardoso, E. V., Lucio, D. R., Estevam, V., and Menotti, D. (2022). "On the Cross-dataset Generalization in License Plate Recognition." *International Conference on Computer Vision Theory and Applications (VISAPP)*, 166–178. (Introduces RodoSol-ALPR.) https://doi.org/10.5220/0010846800003124

**[29]** Laroca, R., Santos, M., Estevam, V., Luz, E., and Menotti, D. (2022). "A First Look at Dataset Bias in License Plate Recognition." *35th SIBGRAPI Conference on Graphics, Patterns and Images*, 234–239. https://doi.org/10.1109/SIBGRAPI55357.2022.9991768

**[30]** Yu, D., Li, X., Zhang, C., Liu, T., Han, J., Liu, J., and Ding, E. (2020). "Towards Accurate Scene Text Recognition with Semantic Reasoning Networks." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://openaccess.thecvf.com/content_CVPR_2020/html/Yu_Towards_Accurate_Scene_Text_Recognition_With_Semantic_Reasoning_Networks_CVPR_2020_paper.html

**[31]** Luo, C., Jin, L., and Sun, Z. (2019). "MORAN: A Multi-Object Rectified Attention Network for Scene Text Recognition." *Pattern Recognition*, 90, 109–118. https://arxiv.org/abs/1901.03003

**[32]** Li, H., Wang, P., Shen, C., and Zhang, G. (2019). "Show, Attend and Read: A Simple and Strong Baseline for Irregular Text Recognition." *AAAI Conference on Artificial Intelligence*. https://arxiv.org/abs/1811.00751

**[33]** Sheng, F., Chen, Z., and Xu, B. (2019). "NRTR: A No-Recurrence Sequence-to-Sequence Model for Scene Text Recognition." *International Conference on Document Analysis and Recognition (ICDAR)*. https://arxiv.org/abs/1806.00926

**[34]** Atienza, R. (2021). "Vision Transformer for Fast and Efficient Scene Text Recognition." *International Conference on Document Analysis and Recognition (ICDAR)*. https://arxiv.org/abs/2105.08582

**[35]** Lee, J., Park, S., Baek, J., Oh, S. J., Kim, S., and Lee, H. (2020). "On Recognizing Texts of Arbitrary Shapes with 2D Self-Attention." *CVPR Workshops*. https://openaccess.thecvf.com/content_CVPRW_2020/html/w34/Lee_On_Recognizing_Texts_of_Arbitrary_Shapes_With_2D_Self-Attention_CVPRW_2020_paper.html

**[36]** Fang, S., Xie, H., Wang, Y., Mao, Z., and Zhang, Y. (2021). "Read Like Humans: Autonomous, Bidirectional and Iterative Language Modeling for Scene Text Recognition." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/2103.06495

**[37]** Bautista, D., and Atienza, R. (2022). "Scene Text Recognition with Permuted Autoregressive Sequence Models." *European Conference on Computer Vision (ECCV)*. https://arxiv.org/abs/2207.06966

**[38]** Wang, Y., Xie, H., Fang, S., Wang, J., Zhu, S., and Zhang, Y. (2021). "From Two to One: A New Scene Text Recognizer with Visual Language Modeling Network." *IEEE/CVF International Conference on Computer Vision (ICCV)*. https://openaccess.thecvf.com/content/ICCV2021/html/Wang_From_Two_to_One_A_New_Scene_Text_Recognizer_With_ICCV_2021_paper.html

**[39]** Du, Y., Chen, Z., Jia, C., Yin, X., Zheng, T., Li, C., Du, Y., and Jiang, Y.-G. (2022). "SVTR: Scene Text Recognition with a Single Visual Model." *International Joint Conference on Artificial Intelligence (IJCAI)*. https://doi.org/10.24963/ijcai.2022/124

**[40]** Dosovitskiy, A., et al. (2021). "An Image Is Worth 16x16 Words: Transformers for Image Recognition at Scale." *International Conference on Learning Representations (ICLR)*. https://arxiv.org/abs/2010.11929

**[41]** Vaswani, A., et al. (2017). "Attention Is All You Need." *Advances in Neural Information Processing Systems (NeurIPS)*. https://arxiv.org/abs/1706.03762

**[42]** Hu, W., Cai, X., Hou, J., Yi, S., and Lin, Z. (2020). "GTC: Guided Training of CTC Towards Efficient and Accurate Scene Text Recognition." *Proceedings of the AAAI Conference on Artificial Intelligence*, 34(07), 11005–11012. https://doi.org/10.1609/aaai.v34i07.6735

**[43]** Liu, Z., et al. (2021). "Swin Transformer: Hierarchical Vision Transformer Using Shifted Windows." *IEEE/CVF International Conference on Computer Vision (ICCV)*. https://arxiv.org/abs/2103.14030

**[44]** Miao, Y., Gowayyed, M., and Metze, F. (2015). "EESEN: End-to-End Speech Recognition Using Deep RNN Models and WFST-Based Decoding." *IEEE Workshop on Automatic Speech Recognition and Understanding (ASRU)*, 167–174. https://arxiv.org/abs/1507.08240

**[45]** Cao, Y., Fu, H., and Ma, H. (2018). "An End-to-End Neural Network for Multi-Line License Plate Recognition." *24th International Conference on Pattern Recognition (ICPR)*, 3698–3703.

**[46]** Gong, Y., Deng, L., Tao, S., Lu, X., Wu, P., Xie, Z., Ma, Z., and Xie, M. (2022). "Unified Chinese License Plate Detection and Recognition with High Efficiency." *arXiv* preprint arXiv:2205.03582. (Introduces the Chinese Road Plate Dataset, CRPD.) https://arxiv.org/abs/2205.03582

**[47]** Redmon, J., Divvala, S., Girshick, R., and Farhadi, A. (2016). "You Only Look Once: Unified, Real-Time Object Detection." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/1506.02640

**[48]** Bochkovskiy, A., Wang, C.-Y., and Liao, H.-Y. M. (2020). "YOLOv4: Optimal Speed and Accuracy of Object Detection." *arXiv* preprint arXiv:2004.10934. https://arxiv.org/abs/2004.10934

**[49]** Yousef, M., and Bishop, T. E. (2020). "OrigamiNet: Weakly-Supervised, Segmentation-Free, One-Step, Full Page Text Recognition by Learning to Unfold." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/2006.07491

**[50]** Du, Y., Chen, Z., Xie, H., Jia, C., and Jiang, Y.-G. (2025). "SVTRv2: CTC Beats Encoder-Decoder Models in Scene Text Recognition." *Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV)*, 20147–20156. https://doi.org/10.1109/ICCV51701.2025.01874

**[51]** Du, Y., Chen, Z., Jia, C., Yin, X., Li, C., Du, Y., and Jiang, Y.-G. (2025). "Context Perception Parallel Decoder for Scene Text Recognition." *IEEE Transactions on Pattern Analysis and Machine Intelligence*, 47(6), 4668–4683. https://doi.org/10.1109/TPAMI.2025.3545453

**[52]** Laroca, R., Estevam, V., Moreira, G. J. P., Minetto, R., and Menotti, D. (2025). "Advancing Multinational License Plate Recognition Through Synthetic and Real Data Fusion: A Comprehensive Evaluation." *IET Intelligent Transport Systems*, 19(1), e70086. https://doi.org/10.1049/itr2.70086

**[53]** Laroca, R., Nascimento, V., Kim, D., et al. (2026). "ICPR 2026 Competition on Low-Resolution License Plate Recognition." *arXiv* preprint arXiv:2604.22506. https://arxiv.org/abs/2604.22506

**[54]** Nascimento, V., Lima, G. E., Ribeiro, R. O., Schwartz, W. R., Laroca, R., and Menotti, D. (2025). "Toward Advancing License Plate Super-Resolution in Real-World Scenarios: A Dataset and Benchmark." *Journal of the Brazilian Computer Society*, 31(1), 435–448. https://doi.org/10.5753/jbcs.2025.5159

**[55]** Agrawal, S. (2024). "Global License Plate Dataset." *arXiv* preprint arXiv:2405.10949. https://arxiv.org/abs/2405.10949

**[56]** Liu, Q., Liu, Y., Chen, S.-L., et al. (2024). "Improving Multi-Type License Plate Recognition via Learning Globally and Contrastively." *IEEE Transactions on Intelligent Transportation Systems*, 25(9), 11092–11102. https://doi.org/10.1109/TITS.2024.3365537

**[57]** Chen, S.-L., Liu, Q., Chen, F., and Yin, X.-C. (2023). "End-to-End Multi-line License Plate Recognition with Cascaded Perception." *Document Analysis and Recognition – ICDAR 2023*, Lecture Notes in Computer Science, vol. 14191. Springer. https://doi.org/10.1007/978-3-031-41734-4_17

**[58]** Gupta, A., Vedaldi, A., and Zisserman, A. (2016). "Synthetic Data for Text Localisation in Natural Images." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/1604.06646

**[59]** Jaderberg, M., Simonyan, K., Vedaldi, A., and Zisserman, A. (2014). "Synthetic Data and Artificial Neural Networks for Natural Scene Text Recognition." *arXiv* preprint arXiv:1406.2227. https://arxiv.org/abs/1406.2227

**[60]** Wang, X., Xie, L., Dong, C., and Shan, Y. (2021). "Real-ESRGAN: Training Real-World Blind Super-Resolution with Pure Synthetic Data." *IEEE/CVF International Conference on Computer Vision Workshops*. https://arxiv.org/abs/2107.10833

**[61]** Ledig, C., et al. (2017). "Photo-Realistic Single Image Super-Resolution Using a Generative Adversarial Network." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/1609.04802

**[62]** Zhang, K., Zuo, W., and Zhang, L. (2018). "Learning a Single Convolutional Super-Resolution Network for Multiple Degradations." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/1711.05778

**[63]** Zhang, K., Liang, J., Van Gool, L., and Timofte, R. (2021). "Designing a Practical Degradation Model for Deep Blind Image Super-Resolution." *IEEE/CVF International Conference on Computer Vision (ICCV)*. https://arxiv.org/abs/2103.14006

**[64]** Wang, X., Yu, K., Wu, S., Gu, J., Liu, Y., Dong, C., Qiao, Y., and Loy, C. C. (2018). "ESRGAN: Enhanced Super-Resolution Generative Adversarial Networks." *ECCV Workshops*. https://arxiv.org/abs/1809.00219

**[65]** Hinton, G., Vinyals, O., and Dean, J. (2015). "Distilling the Knowledge in a Neural Network." *arXiv* preprint arXiv:1503.02531. https://arxiv.org/abs/1503.02531

**[66]** Romero, A., et al. (2015). "FitNets: Hints for Thin Deep Nets." *International Conference on Learning Representations (ICLR)*. https://arxiv.org/abs/1412.6550

**[67]** Zhang, Y., Xiang, T., Hospedales, T. M., and Lu, H. (2018). "Deep Mutual Learning." *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*. https://arxiv.org/abs/1706.00384

**[68]** Laroca, R., Estevam, V., Britto Jr., A. S., Minetto, R., and Menotti, D. (2023). "Do We Train on Test Data? The Impact of Near-Duplicates on License Plate Recognition." *International Joint Conference on Neural Networks (IJCNN)*, 1–8.

**[69]** Guo, C., Pleiss, G., Sun, Y., and Weinberger, K. Q. (2017). "On Calibration of Modern Neural Networks." *Proceedings of the 34th International Conference on Machine Learning (ICML)*, PMLR 70, 1321–1330. https://arxiv.org/abs/1706.04599

**[70]** Hannun, A. Y., Maas, A. L., Jurafsky, D., and Ng, A. Y. (2014). "First-Pass Large Vocabulary Continuous Speech Recognition Using Bi-Directional Recurrent DNNs." *arXiv* preprint arXiv:1408.2873. https://arxiv.org/abs/1408.2873


# Appendix A. Format Templates of Chinese Plate Types

This appendix lists the simplified format templates of the Chinese plate types that are used in the experiments and in the figures of this paper. The templates are a working specification for the recognizer. They follow the national standard GA 36-2018 that is cited in Section 1.1.4, but they are not a legal or complete description of that standard. Rare plate types, such as embassy, consulate, military and temporary plates, are not part of the template file. Such plates are read under the open format, like any other unknown plate.

The slot types are the same as in Section 2.3.5:

- **P**: a provincial character, for example 京, 沪, 粤 or 皖;
- **L**: a Latin letter without I and O, which is the code of the issuing authority;
- **A**: a Latin letter without I and O, or a digit;
- **N**: a digit;
- **E**: the energy code of a new-energy plate, D or F;
- **S**: a special final character, such as 挂, 学, 警, 港 or 澳.

Two rules apply to the serial, that is, to all slots after the issuing-authority letter. The letters I and O are never used, so that they cannot be confused with the digits 1 and 0. A serial of a civilian plate contains at most two letters. The automaton of a template counts the letters of the serial in its states (Section 2.3.5).

*Table A1. Simplified templates of the Chinese plate types used in this paper. The examples are fictional strings. The column "Rows" is used only by the renderer of synthetic plates; the recognizer uses the template as one sequence of slots. "Withheld" marks the templates that are removed from the template file and from the training data in the unseen-format experiment of Section 5.3.1.*

| Plate type | Colour | Rows | Template | Special rule | Example | Unseen-format run |
|:--|:--|:--|:--|:--|:--|:--|
| Small car | blue, white characters | 1 | P L A A A A A | none | 京A12345 | kept |
| Small new-energy vehicle | green gradient, black characters | 1 | P L E A N N N N | third slot is D or F | 粤BD12345 | kept |
| Large new-energy vehicle | yellow and green, black characters | 1 | P L N N N N N E | last slot is D or F | 苏E12345D | withheld |
| Large vehicle, front | yellow, black characters | 1 | P L A A A A A | none | 浙C6Z8B3 | kept |
| Large vehicle, rear | yellow, black characters | 2 | P L / A A A A A | none | 沪A / 12345 | kept |
| Trailer | yellow, black characters | 2 | P L / A A A A S | S is 挂 | 鲁B / 2071挂 | withheld |
| Driving-school vehicle | yellow, black characters | 1 | P L A A A A S | S is 学 | 川A3721学 | kept |
| Police | white, black characters and red 警 | 1 | P L A A A A S | S is 警 | 渝A0516警 | kept |
| Ordinary motorcycle | yellow, black characters | 2 | P L / A A A A A | none | 湘D / 3B157 | kept |
| Hong Kong or Macau cross-border | black, white characters | 1 | P L A A A A S | P is 粤, L is Z, S is 港 or 澳 | 粤Z1234港 | withheld |
| Open format | any | any | any symbols, at most ten | receives the open-format prior | none | kept |

The slash in the template column separates the upper row from the lower row. For the recognizer, the slash has no meaning: the rear plate of a large vehicle, the motorcycle plate, the front plate of a large vehicle and the blue small-car plate all have the slot sequence P L A A A A A, and they form one automaton. They differ in colour, in size and in the arrangement of the rows, which matters for the renderer, but not in the set of valid strings. This is the reason why FADR does not need to know the plate type: a string that fits this sequence receives the same format score on every one of these plates.

The template file is written in the format of Section 4.1.4. Each entry contains the name of the plate type, the slot sequence with its rows, the special rules and the deployment prior. A compiler reads the file once at start-up and builds the automata. The open format is not an automaton; it is the case "no known template fits", and it has its own prior. A deployment in a city with many new-energy vehicles can raise the prior of the new-energy templates without any other change.

Three properties of the Chinese templates are important for the experiments. First, the slot types L and N never overlap, so the format score can separate every candidate pair that differs by a letter–digit confusion in the second slot, for example B and 8. Second, most serial slots have the type A, which allows both letters and digits. The format cannot separate a confusion such as Z and 2 in these slots; only the image and the learned context of the decoder can. Third, the new-energy templates have slots of type E and N that are much more restrictive than A. The format score is therefore expected to help most on new-energy plates, and least on the serial of ordinary seven-character plates.

# Appendix B. Planned Training and Decoding Settings

This appendix lists the planned settings of the experiments. The settings are part of the protocol of Chapter 5. They are initial values, not results. The values of the thresholds and of the weights of the joint score are selected on the validation set, and the final values must be reported together with the measured results.

*Table B1. Planned settings of the encoder, the two heads, the training and the decision. The values are initial choices of the protocol; values marked "tuned" are selected on the validation set.*

| Group | Setting | Planned value |
|:--|:--|:--|
| Input | multi-size resizing buckets | 64 × 64, 48 × 96, 40 × 112 and 32 × ⌊R⌋·32 |
| Encoder | architecture | SVTRv2-T style, three stages |
| Encoder | blocks and channel widths | 3, 6 and 3 blocks; 64, 128 and 256 channels |
| Encoder | initialization | pre-trained on scene text |
| Vocabulary | symbols | 31 provincial characters, 24 letters, 10 digits, 5 special characters |
| CTC branch | reading-order queries | 24 learned queries, one attention layer with 4 heads |
| CTC branch | position encoding | two-dimensional, added to the keys only |
| CTC branch | decoding in stage 1 | greedy |
| CTC branch | candidates in stage 3 | 5 best strings of a prefix beam search |
| Decoder | position queries | 10 |
| Decoder | layers | 2 |
| Decoder | share of visible characters in training | random between 0 and 100 percent |
| Decoder | noisy context | visible characters replaced by confusable characters with a small probability, for example 0.1 |
| Training | optimizer | AdamW with a one-cycle schedule and mixed precision |
| Training | phases | three phases as in Section 4.1.3 |
| Training | loss weights | tuned; the guidance weights are small compared with the CTC and decoder losses |
| Training | reading-order guidance | synthetic plates only; removed at inference |
| Training | geometric augmentation | rotation up to 30 degrees, shift, scale, perspective |
| Training | random seeds | 3 for every configuration |
| Synthetic data | strings | format-faithful and format-open, one row and two rows |
| Calibration | temperatures | one for the CTC character confidences, one for the decoder, one for the softmax over the candidate pool |
| Gate | threshold | tuned so that accepted plates reach at least 99.5% recognition rate; 0.90 assumed in the projections |
| Gate | format check | draft must fit at least one known template |
| Joint score | weight of the CTC term and of the format term | tuned |
| Joint score | prior of the open format | smaller than the priors of the known templates |
| Review flag | threshold | tuned to the operating requirements; 2% of the plates flagged in Section 5.3.5 |
| Latency | measurement | batch size 1, after warm-up, median of repeated runs |
| Latency | devices | desktop GPU, desktop CPU with four threads, ARM board with four threads |

Three settings need special care. The first is the prior of the open format together with the weight of the format term. A very small prior or a very large weight makes the system behave like a hard format rule, and the opposite removes the benefit of the templates. Both are tuned on the validation set, and the unseen-format test is used only once, for the final evaluation. Because the two recognition terms of the joint score are divided by the string length and the format term is not, the weight of the format term must be small; Appendix E shows the sizes of the three terms on an example. The second is the gate threshold. It decides both the accuracy and the mean latency, and it must be selected again whenever the model or the calibration changes. The third is the share of format-open strings in the synthetic data. Too few format-open strings let the decoder learn the formats as if they were rules; too many make its learned context weak. The planned value is a moderate share, and a short sensitivity study is part of the experiments.

All baselines are trained with the same data, the same vocabulary and the same augmentation as FADR. When a baseline has its own recommended settings, such as the learning rate of PARSeq, these settings are used. The input size of every baseline follows its original paper, except that all CTC baselines also receive the MSR buckets in a separate run, so that the effect of the input size can be separated from the effect of the recognition head.

# Appendix C. Replacing the Projected Results

All numbers in the tables of Chapter 5, and every highlighted number in the text, are projected placeholders. This appendix maps each projected element to the experiment that will replace it and lists the checks that are needed after the replacement. The mapping is intended as a plan for the experimental work.

*Table C1. Projected elements of the paper and the experiments that replace them.*

| Projected element | Experiment | Data | Section |
|:--|:--|:--|:--|
| Table 1 | one-row recognition of all methods | CCPD test subsets and green plates | 5.2.1 |
| Table 2 | mixed one-row and two-row recognition | CRPD and RodoSol-ALPR | 5.2.2 |
| Table 3 and Figure 40 | geometric stress test | two-row test sets with controlled changes | 5.2.3 |
| Table 4 | results by Chinese plate type | CCPD and CRPD | 5.2.4 |
| Figure 41 | qualitative examples | selected test plates | 5.2.5 |
| Table 5 | use of the formats on known and unseen formats | separate training run | 5.3.1 |
| Table 6 | ablation of the components | all two-row and unseen sets | 5.3.2 |
| Table 7 and Figure 42 | model size and latency | three devices | 5.3.3 |
| Table 8 and Figure 43 | exits of FADR and sweep of the gate threshold | validation and test sets | 5.3.4 |
| Table 9 | the two readers on the plates that fail the gate | known-format test sets | 5.3.4 |
| Table 10 | calibration and review flag | all test sets | 5.3.5 |
| Table 11 | sensitivity to the template file | modified template files | 5.3.6 |
| Table 12 | single-frame and multi-frame recognition | UFPR-SR-Plates tracks | 5.4.1 |
| Table 13 | error composition | two-row test sets | 5.4.2 |
| Highlighted numbers in the Abstract, the Introduction and Chapter 5 | summary of the measured results | as above | whole paper |

The projected numbers are not independent. They were generated so that averages, shares and latencies agree with each other. Three relations are used. The mean latency of FADR follows from the cost model of Section 4.4.1 and from the projected shares of plates at the three exits. The error rate of the CTC branch equals the wrong drafts that pass the gate plus the wrong drafts among the plates that fail it. The error rate of FADR equals the wrong drafts that pass the gate plus the wrong final strings among the plates that fail it. When measured values replace the projected values, these relations hold by construction for the measured data, but the text that interprets them must be checked again.

Several statements in the text depend on the projected numbers. Examples are the statement that the reading-order queries give the largest single gain (Section 5.3.2), the statement that the line split fails under rotation while the reading-order queries do not (Section 5.2.3), the statement that about nine plates in ten stop at the gate (Section 5.3.4), and the statement that the combination of the two readers is better than each reader alone (Section 5.3.4). Each such statement must be confirmed, changed or removed after the measurement.

The experiments should be run in the following order, so that the most uncertain assumptions are tested first and with the least effort:

1. SVTRv2-T on the two-row test sets, trained with the shared data and augmentation. This gives the true size of the problem that the reading-order queries address.
2. FADR-CTC (phase 1 of the training only) on the same sets and on the rotation stress test, together with the two line-split baselines. This tests the first contribution without the decoder.
3. The complete FADR after phases 2 and 3, with the gate threshold selected on the validation set. This gives the main tables, the exits and the comparison of the two readers.
4. The separate training run for the unseen formats, the ablation rows, the sensitivity to the template file and the low-resolution tracks.

The following checklist summarizes the reporting rules of the protocol:

1. Report the version, the licence and the split files of every dataset, and the result of the near-duplicate check.
2. Report the mean and the standard deviation over three seeds for every recognition rate.
3. Report the McNemar test for every comparison that the text interprets, and the bootstrap confidence intervals of the main results.
4. Select every threshold and every weight on the validation set only, and report the selected values in Table B1.
5. Run the unseen-format experiment as a separate training run, without the withheld formats in the training data or in the template file, and use its test sets only once.
6. Report the draft of the CTC branch together with the final string, so that the effect of the decoder and of the format knowledge is visible.
7. Measure the latency with the protocol of Section 5.1.6, and report the device, the runtime, the precision and the number of threads. Report the mean and the worst case for FADR.
8. Report the share of plates that leave FADR at each exit, separately for one-row and two-row plates, and the shared-error rate.
9. Report the stress test for every angle and for both directions of rotation, and state the range of the geometric augmentation used in training.
10. Remove the highlights, the word "PROJECTED" and the notice boxes only after every number in the affected table or paragraph has been replaced.
11. Re-read the abstract, the introduction and the conclusion, and change every claim that the measured results do not support.

The last rule is the most important. A projected result describes what the method is designed to achieve. A measured result describes what it achieves. If the two differ, the paper must follow the measurement, and the analysis of Chapter 5 should explain the difference. A negative or mixed result is still useful: for example, if the decoder does not improve two-row plates beyond the CTC branch, the paper can still report the reading-order queries as an efficient solution and discuss why the second reader did not help.

# Appendix D. Notation

This appendix collects the main symbols of the paper. Symbols that appear in only one equation are explained next to that equation.

*Table D1. Main symbols of the paper.*

| Symbol | Meaning | Section |
|:--|:--|:--|
| $x$ | plate crop given to the recognizer | 2.1 |
| $H \times W$ | height and width of the resized crop | 2.2.2 |
| $R$ | aspect ratio $W/H$ of the crop | 2.2.2 |
| $F$ | feature map of the encoder, of size $H/8 \times W/4 \times D$ | 2.2.1 |
| $H'$, $W'$ | number of feature rows ($H/8$) and columns ($W/4$) | 2.2.1 |
| $N$ | number of positions of the feature map, $H'W'$ | 2.3.3 |
| $T$ | number of CTC time steps | 2.1.1 |
| $P_t(c \mid x)$ | CTC probability of symbol $c$ at time step $t$ | 2.1.1 |
| $y$ | plate string; $y_j$ is its character at position $j$ | 2.1.1 |
| $\mathcal{B}$ | CTC collapse: merge repeats, then remove blanks | 2.1.1 |
| $T^{s}$ | selecting token of the FRM | 2.2.3 |
| $q_t$ | reading-order query of CTC step $t$ | 2.3.3 |
| $T_q$ | number of reading-order queries (24) | 2.3.3 |
| $p_i$ | two-dimensional position encoding of feature position $i$ | 2.3.3 |
| $r_i$ | reading-order coordinate of feature position $i$ (training only) | 2.3.4 |
| $k$ | format template; $\mathcal{A}_k$ is its automaton | 2.3.5 |
| $\pi_k$ | deployment prior of template $k$; $\pi_{\text{open}}$ for the open format | 2.3.6 |
| $\phi(y)$ | format score of the string $y$ | 2.3.6 |
| $\kappa_j$ | calibrated confidence of character $j$ of the draft | 2.3.8 |
| $\tau_g$ | gate threshold | 2.3.8 |
| $u_j$ | position query $j$ of the decoder | 3.3.2 |
| $c_j$ | context token of position $j$ (character embedding or mask embedding) | 3.3.3 |
| $V$ | set of visible positions during the training of the decoder | 3.3.7 |
| $\ell_{\text{dec}}(y \mid x)$ | context score of the decoder for the string $y$ | 3.3.6 |
| $\bar{\ell}_{\text{ctc}}$, $\bar{\ell}_{\text{dec}}$ | length-normalized scores of the two readers | 4.2.4 |
| $S(y)$ | joint score of a candidate | 4.2.4 |
| $\alpha$, $\beta$ | weights of the CTC term and of the format term in the joint score | 4.2.4 |
| $\tau_{\text{rej}}$ | threshold of the review flag | 4.2.5 |
| $\lambda_d$, $\lambda_c$, $\lambda_s$, $\lambda_o$ | weights of the losses in the training objective | 4.1.2 |
| $T_1$, $T_2$, $T_3$ | costs of the three stages | 4.4.1 |
| $\rho_2$, $\rho_3$ | shares of plates that reach stages 2 and 3 | 4.4.1 |
| $w_n$ | weight of frame $n$ in multi-frame fusion | 4.3.4 |

The letters P, L, A, N, E and S denote slot types (Appendix A). They are written in upright capital letters to distinguish them from mathematical symbols. The words *draft* and *final string* denote the output of the CTC branch and the output of the complete system; *reading* denotes the output of the decoder in reading mode.

# Appendix E. Worked Example of the Gate and the Joint Score

This appendix follows one plate through the three stages of FADR (Section 4.2). The plate is a small new-energy plate with the string 粤BD12345. The image is blurred, and the second character could be the letter B or the digit 8. All numbers are illustrative; they are chosen to show the sizes of the terms, and they are not outputs of a trained model. The weights are $\alpha = 0.5$ and $\beta = 0.05$. The template file gives the small new-energy template a prior of 0.12 and the open format a prior of 0.01.

**Stage 1: draft and gate.** The CTC branch produces the draft 粤8D12345. Its character confidences are 0.97, 0.55, 0.90, 0.95, 0.96, 0.94, 0.95 and 0.93. The second character has the lowest confidence: the digit 8 receives 0.55 and the letter B receives 0.40. The gate checks two conditions. The lowest confidence, 0.55, is below the gate threshold of 0.90. The draft also fits no known template, because the second slot of every template is a letter. Each of the two conditions alone would send the plate to the decoder.

**Stage 2: second reading.** The decoder reads the plate in reading mode, with all positions hidden. It reads 粤BD12345, with a probability of 0.62 for B and 0.33 for 8 at the second position. The two readers disagree, so neither string is accepted, and the plate goes to stage 3.

**Stage 3: candidate pool and joint score.** The prefix beam search on the outputs of the reading-order queries gives the five best strings of the CTC branch. The reading of the decoder, 粤BD12345, is already among them, so the pool has five candidates. Table E1 lists their scores. The CTC score is the log-probability of the string divided by its eight characters. The decoder score is the context score of Equation 8 divided by its nine positions (eight characters and the end symbol).

*Table E1. Candidates and scores of the worked example (illustrative values; natural logarithms).*

| Candidate | Fits | CTC score | Decoder score | Format score | Joint score |
|:--|:--|--:|--:|--:|--:|
| 粤BD12345 | small new-energy template | −0.166 | −0.046 | −2.12 | **−0.212** |
| 粤8D12345 | no template (open format) | −0.126 | −0.315 | −4.61 | −0.451 |
| 粤B012345 | no template (open format) | −0.469 | −0.379 | −4.61 | −0.654 |
| 粤8012345 | no template (open format) | −0.429 | −0.495 | −4.61 | −0.692 |
| 粤8D12346 | no template (open format) | −0.520 | −0.697 | −4.61 | −0.839 |

The three terms tell different stories about the first two candidates. The CTC score slightly prefers the draft 粤8D12345 (−0.126 against −0.166), because the CTC branch read 8. The decoder score clearly prefers 粤BD12345 (−0.046 against −0.315). In scoring mode, the second position sees that the third character is D and that the string has eight characters, and with this context the decoder gives B a probability of 0.90 and 8 a probability of 0.08. The format score also prefers 粤BD12345, because it fits a template with a prior of 0.12, while the draft receives the open-format prior of 0.01. The joint scores are

- 粤BD12345: 0.5 × (−0.166) + 0.5 × (−0.046) + 0.05 × (−2.12) = −0.212;
- 粤8D12345: 0.5 × (−0.126) + 0.5 × (−0.315) + 0.05 × (−4.61) = −0.451.

The correct string wins. The calibrated softmax over the five joint scores gives it a confidence of about 0.90, which is above the review threshold, so the plate is reported without a flag. The output of FADR for this plate contains the final string 粤BD12345, the confidence, the exit (3) and the draft 粤8D12345. This is the third case of Figure 29.

Two details of the example are worth noting. First, the decoder decided mainly through its context score, not through its first reading: in reading mode it preferred B only with 0.62, and in scoring mode with 0.90. The scoring pass is the place where the linguistic context enters. Second, the format term is small in absolute size (a difference of 0.124 between the two candidates) compared with the difference of the decoder term (0.135). The format does not decide alone; it adds to the evidence of the readers.

**When the open format wins.** Suppose now that the plate really carried the unusual string 粤8D12345 and that the image were clear. The CTC branch would read 8 with a confidence of 0.97, and all other characters would be confident as well. The draft would still fail the gate, because it fits no template. The decoder would read the same string, the two readers would agree, and the plate would leave at the second exit as an open-format result, without any use of the joint score. Even if the decoder read B and the plate reached stage 3, the open-format candidate would win: the CTC scores would be −0.056 for 粤8D12345 and −0.541 for 粤BD12345, the decoder scores −0.091 and −0.151, and the joint scores −0.303 and −0.452. A clear image outweighs the format bonus. With a hard format rule, the string 粤8D12345 could never be returned.

The example also shows why the weight of the format term must be chosen with care. If $\beta$ were 0.3 and not 0.05, the format bonus of the new-energy template would be 0.75, larger than any difference that a single character can produce in the length-normalized scores of the readers. The clear plate 粤8D12345 of the last paragraph would then be changed to 粤BD12345. The overcorrection rate of Section 5.1.4 measures this failure, and it is the quantity to watch when $\beta$ and the open-format prior are tuned.

# Appendix F. Template File Used in the Experiments

This appendix gives the complete template file of the experiments in the format of Section 4.1.4. It contains the plate types of Table A1. Compared with the simplified example of Section 4.1.4, the file adds one feature: single characters can be defined as classes, so that a template can fix a slot to one character, as in the cross-border plates. Plate types with the same slot sequence appear twice when their rows differ, because the renderer needs both arrangements; the compiler merges them into one automaton for the recognizer.

```yaml
# Template file of the experiments (illustrative, not an official specification)
classes:
  P: [京, 津, 沪, 渝, 冀, 豫, 云, 辽, 黑, 湘, 皖, 鲁, 新, 苏, 浙, 赣,
      鄂, 桂, 甘, 晋, 蒙, 陕, 吉, 闽, 贵, 粤, 青, 藏, 川, 宁, 琼]
  L: [A-H, J-N, P-Z]            # letters without I and O
  N: [0-9]                      # digits
  A: [L, N]                     # letter or digit
  E: [D, F]                     # energy code of new-energy plates
  S_trailer: [挂]
  S_school: [学]
  S_police: [警]
  S_cross_border: [港, 澳]
  P_guangdong: [粤]
  L_z: [Z]
templates:
  cn_one_row_7:                 # blue small car, yellow front plate of a large vehicle
    rows: [[P, L, A, A, A, A, A]]
    rules: [serial_max_letters: 2]
    prior: 0.72
  cn_small_new_energy:          # green gradient plate, one row, 8 characters
    rows: [[P, L, E, A, N, N, N, N]]
    prior: 0.12
  cn_large_new_energy:          # yellow-green plate; withheld in the unseen-format run
    rows: [[P, L, N, N, N, N, N, E]]
    prior: 0.02
  cn_two_row_7:                 # rear plate of a large vehicle, motorcycle plate
    rows: [[P, L], [A, A, A, A, A]]
    rules: [serial_max_letters: 2]
    prior: 0.06
  cn_trailer:                   # two rows, ends with 挂; withheld in the unseen-format run
    rows: [[P, L], [A, A, A, A, S_trailer]]
    rules: [serial_max_letters: 2]
    prior: 0.02
  cn_driving_school:            # yellow plate, ends with 学
    rows: [[P, L, A, A, A, A, S_school]]
    rules: [serial_max_letters: 2]
    prior: 0.02
  cn_police:                    # white plate, red 警
    rows: [[P, L, A, A, A, A, S_police]]
    rules: [serial_max_letters: 2]
    prior: 0.01
  cn_cross_border:              # black plate; withheld in the unseen-format run
    rows: [[P_guangdong, L_z, A, A, A, A, S_cross_border]]
    prior: 0.01
open_format:                    # any other string, lower prior
  max_length: 10
  prior: 0.01
```

The priors in this file describe a mixed urban site and are placeholders. They are relative weights; the compiler normalizes them. In the unseen-format run of Section 5.3.1, the three entries marked "withheld" are deleted from the file, and plates of these types are removed from the real and synthetic training data. The rest of the file stays the same, so that the run measures only the effect of the missing templates.

Three checks are applied when the file is compiled. First, every class must be defined, and every character must belong to the recognition vocabulary. Second, templates with the same slot sequence and the same rules are merged into one automaton, and their priors are added; in this file, the entries cn_one_row_7 and cn_two_row_7 are merged, because the recognizer does not use the rows. The format score of a string is therefore the same whether the plate has one row or two. Third, the compiler reports templates that accept a common string. Such overlaps are allowed. The format score uses the highest prior among the templates that a string fits (Equation 6), and the overlaps are listed in the log so that the priors can be checked.
