# Lightweight Joint Low-Light Enhancement and Deblurring for On-Device Smartphone Image Restoration

*Draft — 17 November 2026*

## Abstract

Smartphone photographs taken at night often have two problems at the same time. The image is too dark, and it is also blurred. The scene is dark, so the camera uses a long exposure time. During this long exposure, the hand shakes and objects move. This causes motion blur. These two problems appear together, and they make each other harder to solve.

Many existing methods solve only one problem. Some methods make a dark image brighter. Other methods remove motion blur. When we place these methods one after another, the result is still poor. Brightening a blurred image also makes the blur stronger. Deblurring a dark image is hard, because the useful signal is weak and the noise is strong. For this reason, a single network that solves both problems together is a better choice.

This thesis designs and implements a lightweight deep neural network for joint low-light enhancement and deblurring. The network is intended to run directly on a smartphone. The design is based on LEDNet, a network built for this joint task. To make the network small and fast enough for a mobile device, this work applies two compression techniques to the trained LEDNet model. The first technique is sensitivity-guided mixed-precision quantization. The second technique is structured pruning. These techniques change only the numeric precision and the channel count of the model. They do not change the architecture of LEDNet.

The main idea of this work is that not all layers of the network are equally sensitive to low numeric precision. Some layers control the brightness of dark regions and the detail of bright light sources. These layers lose quality when they are quantized to very low precision. This work measures the sensitivity of each layer. It then keeps the sensitive layers at a higher precision and sets the other layers to 8-bit integer precision. This method keeps image quality high while keeping the model small and fast.

The experimental results in this thesis are projected results. They are informed estimates, based on values reported in the published literature. They are not measured from real experiments. The projected results suggest that the compressed network can reach image quality close to the full-precision model, while reducing the model size by about four times and reducing the inference time to a level suitable for real-time mobile use. These projected results should be replaced with measured results once the experiments are performed.

**Keywords:** low-light image enhancement, motion deblurring, joint image restoration, lightweight neural network, quantization, pruning, on-device inference, smartphone camera.

# Chapter 1. Introduction and Literature Review

## 1.1 Background and Motivation

The smartphone camera is now the most common camera in the world. Most people carry a smartphone every day. They use it to take photographs of family, food, travel, and daily life. Because of this, the quality of the smartphone camera is very important. Camera quality is also a key reason why people choose one phone over another. For this reason, phone makers spend great effort to improve image quality.

A smartphone camera works well in good light. In bright daylight, the sensor receives a large amount of light. The image is clear and sharp. But a smartphone camera has a small sensor and a small lens. A small sensor collects only a small amount of light. In a dark scene, this becomes a serious problem. The sensor cannot collect enough light during a short exposure time. The result is a dark and noisy image.

To solve this, the camera uses a longer exposure time in a dark scene. A longer exposure time lets the sensor collect more light. This makes the image brighter. However, a longer exposure time creates a new problem. During a long exposure, the camera is not perfectly still. The human hand always shakes a little. This small shake moves the camera while the shutter is open. The moving camera records the same point of the scene at many pixel positions. The result is motion blur.

Motion blur also comes from the scene itself. If a person or a car moves during the exposure, that object appears blurred in the image. This is called object motion blur. Camera shake and object motion often happen together. Both become stronger when the exposure time is longer. This is why night photographs are often both dark and blurred.

Figure 1.1 shows typical examples of this problem. \

![Figure 1.1](figures/fig1_1.png)

*Figure 1.1.  Example night smartphone photographs that are both dark and blurred. Left column: raw camera output. The images show low brightness, visible noise, and motion blur around light sources and moving objects.\*

These two degradations are not independent. They share the same cause, which is the lack of light. A dark scene forces a long exposure. A long exposure causes blur. Therefore, in real night photography, low light and motion blur almost always appear together. A good night-photography system must handle both at the same time.

The problem is made worse by bright light sources in the scene. At night, a scene often contains street lamps, car headlights, and neon signs. These light sources are much brighter than the rest of the scene. When the camera shakes, these bright points spread into long bright streaks. These streaks are called light streaks or saturated blur. Light streaks are very hard to remove. The pixel values in these regions are clipped at the maximum value. This clipping destroys information about the true shape of the blur. Many deblurring methods fail in these regions.

Modern smartphones try to solve the night-photography problem with a feature often called night mode. Night mode captures many short-exposure frames. It then aligns these frames and combines them into one brighter and cleaner image. This burst method reduces noise well. However, it has two weaknesses. First, it needs the user to hold the phone still for one or two seconds. Second, it still struggles with moving objects, because the frames cannot be aligned for a moving object. A single-image method that removes blur and brightens the image would be a useful addition to such systems.

Deep neural networks have become the leading tool for image restoration. A deep neural network can learn to map a degraded image to a clean image. It learns this mapping from many example pairs. Deep networks now give the best results for low-light enhancement and for deblurring. This makes a deep network a natural choice for the joint problem.

However, a smartphone is a device with limited resources. It has a small battery, a limited amount of memory, and a processor that must stay cool. A large deep network is too slow and uses too much energy for a smartphone. A model that is accurate but slow cannot be used in a real camera application. The user expects the photo to be ready almost at once. Therefore, the network must be both accurate and efficient.

This gap between accuracy and efficiency is the central motivation of this thesis. There exist accurate networks for joint low-light enhancement and deblurring. There also exist methods to make networks small and fast. But few works combine the two and verify the result on a real smartphone. This thesis studies how to take an accurate joint network and compress it, so that it can run on a smartphone while keeping high image quality.

## 1.2 Problem Analysis

The natural first idea is to reuse existing methods. We already have good methods for low-light enhancement. We also have good methods for deblurring. So we could simply place one method after the other. This is called a cascade or a two-stage pipeline. There are two possible orders for the cascade. The first order is enhancement first, then deblurring. The second order is deblurring first, then enhancement. This section explains why both orders give poor results.

Consider the first order, which is enhancement followed by deblurring. The enhancement stage takes a dark image and makes it brighter. This stage also amplifies the motion blur. When a dark region is made brighter, the blur in that region becomes more visible. The enhancement stage also amplifies the noise. Many enhancement methods reduce noise by smoothing the image. This smoothing removes fine detail. But the blur-removal stage needs that fine detail to estimate the blur. So the enhancement stage removes exactly the information that the deblurring stage needs. The deblurring stage then fails.

Now consider the second order, which is deblurring followed by enhancement. The deblurring stage takes a dark and blurred image. In a dark image, the signal is weak and the noise is strong. The deblurring stage cannot tell the difference between true image structure and random noise. It tries to sharpen the noise. This creates strong artifacts. The later enhancement stage then makes these artifacts brighter and more visible. So this order also fails.

There is a deeper reason for the failure. The two tasks are not independent. They share the same hidden variables. The true clean scene, the illumination, the noise, and the blur are all linked in one image-formation process. A cascade treats each stage as a separate problem. Each stage makes its own assumptions. These assumptions do not match the real joint degradation. The error of the first stage passes into the second stage. The second stage cannot correct this error.

Figure 1.2 shows this failure with a clear example. \

![Figure 1.2](figures/fig1_2.png)

*Figure 1.2.  Failure of cascade pipelines on a night blurred image. (a) Input dark and blurred image. (b) Enhancement then deblurring: the blur remains and is amplified. (c) Deblurring then enhancement: strong artifacts appear in the dark regions. (d) A joint network trained for both tasks: the image is bright and sharp. This figure follows the analysis style introduced by LEDNet.\*

The problem of bright light sources makes the cascade even weaker. In a night scene, a bright lamp becomes a long light streak after camera shake. The pixel values in the streak are clipped at the maximum. A standard deblurring method assumes that the blurred pixel is a simple average of nearby clean pixels. This assumption is false in a clipped region. The true values are higher than the maximum, but the sensor cannot record them. So the deblurring method has wrong input values. It produces wrong output. A joint method can learn to handle these saturated regions, because it sees the dark context and the bright streak together.

There is also a practical reason to avoid the cascade. A cascade needs two separate networks. Two networks use more memory and more computation than one network. On a smartphone, this cost is important. A single joint network is smaller and faster than two separate networks. So the joint approach is better for both quality and efficiency.

From this analysis we draw a clear conclusion. The joint low-light enhancement and deblurring problem should be solved by a single end-to-end network. The network should see the whole degraded image and produce the clean image directly. This conclusion is the foundation of the method in this thesis. The next sections review the existing methods for each task and for the joint task. They also give a formal degradation model that explains why the joint approach is correct.

## 1.3 Related Work

This section reviews the work related to this thesis. It has three parts. The first part reviews low-light image enhancement. The second part reviews image deblurring. The third part reviews joint restoration and efficient on-device methods. The review shows a clear gap. There are accurate joint methods, and there are efficient single-task methods. But there are few accurate joint methods that run on a real smartphone.

### 1.3.1 Low-Light Image Enhancement

Low-light image enhancement is the task of making a dark image brighter and clearer. The goal is to recover a natural image that looks as if it was taken in good light. This task has a long history. The methods can be grouped into three families.

The first family is histogram-based methods. These methods change the spread of pixel values. Histogram equalization is the classic example. It stretches the dark values to a wider range. This makes the image brighter. These methods are simple and fast. But they do not understand the content of the image. They often make the image look unnatural. They also increase noise in dark regions.

The second family is Retinex-based methods. Retinex theory says that an image is the product of two parts. The first part is the reflectance, which is the true color of the object. The second part is the illumination, which is the light in the scene. A low-light image has weak illumination. These methods estimate the illumination and then remove it. This brightens the image while keeping the true colors. Classical Retinex methods such as LIME \[15\] estimate the illumination map with hand-designed rules. These methods work better than histogram methods, but the hand-designed rules fail in complex scenes.

The third family is deep learning methods. These methods learn the enhancement from data. Retinex-Net \[14\] combined Retinex theory with a deep network. It also introduced the LOL dataset, which contains paired low-light and normal-light images. Zero-DCE \[11\] took a different view. It did not learn a direct mapping. Instead, it learned a set of curves that adjust the brightness of each pixel. Zero-DCE is very light and fast, which makes it attractive for mobile use. RUAS \[12\] used a Retinex-inspired structure and searched for an efficient network shape. EnlightenGAN \[43\] used an adversarial loss and did not need paired data.

More recent methods use the transformer architecture. RetinexFormer \[13\] combined Retinex theory with a transformer. It models the long-range relations in the image. It gives strong results on standard low-light benchmarks. However, the transformer uses more computation than a simple convolutional network. This makes it harder to deploy on a mobile device without compression.

There is also a line of work on raw-image enhancement. The method known as learning to see in the dark \[44\] enhanced very dark raw images with a deep network. Raw images keep more information than processed images, because they are not yet compressed by the camera pipeline. This gives better results in extreme low light. The cost is that the method must be trained for a specific sensor.

All of these methods share one weakness for our problem. They assume that the input is only dark, not blurred. They do not model motion blur. When the input is both dark and blurred, these methods brighten the blur but do not remove it. As explained in Section 1.2, they may even make the blur worse. This is why a method that handles only low light is not enough for night photography.

Table 1.1 summarizes the main low-light enhancement methods. It groups them by family and notes their key idea and their cost. The cost matters for this thesis, because the final method must run on a phone.

| Method | Year | Family | Key idea | Relative cost |
| --- | --- | --- | --- | --- |
| Histogram equalization | classical | Histogram | Stretch the pixel value range | Very low |
| LIME \[15\] | 2017 | Retinex | Estimate the illumination map with a prior | Low |
| Retinex-Net \[14\] | 2018 | Deep Retinex | Split into reflectance and illumination | Medium |
| Zero-DCE \[11\] | 2020 | Deep curve | Learn per-pixel brightening curves | Very low |
| RUAS \[12\] | 2021 | Deep Retinex | Unrolled Retinex with architecture search | Low |
| EnlightenGAN \[43\] | 2021 | Adversarial | Enhance without paired data | Medium |
| RetinexFormer \[13\] | 2023 | Transformer | Retinex with global attention | High |

A few patterns appear in Table 1.1. The curve-based methods, such as Zero-DCE, have a very low cost. They are a good fit for a phone. The transformer methods, such as RetinexFormer, have the best quality on benchmarks but a high cost. This is the same trade-off that this thesis studies, but for the joint task. The curve idea of Zero-DCE is also used inside LEDNet, as Chapter 2 explains.

The common benchmarks for low-light enhancement are the LOL dataset \[14\] and its later versions. On these benchmarks, the quality is measured by the peak signal-to-noise ratio and the structural similarity index. The deep methods clearly beat the classical methods. The transformer methods give a further gain over the convolutional methods, often by one to two decibels in peak signal-to-noise ratio. However, these benchmarks use clean low-light images without blur. So a high score on these benchmarks does not prove good quality on night blurred images. This is a key limitation of the low-light-only benchmarks for our problem.

There is also a growing interest in low-light enhancement on mobile devices. The yearly mobile enhancement challenges ask teams to build small and fast enhancement networks. The 2026 challenge on efficient low-light enhancement \[24\] set a hard limit of one megabyte on the model size. The winning methods used compact Retinex-style networks with reparameterization. This shows that the field is moving toward efficient enhancement. But these challenges still target the low-light-only task, not the joint low-light and deblur task. The gap for the joint task remains open, and this thesis works inside that gap.

### 1.3.2 Image Deblurring

Image deblurring is the task of removing blur from an image. The goal is to recover a sharp image from a blurred one. This review focuses on motion blur, because motion blur is the main blur in night photography. The methods can be divided into classical methods and deep learning methods.

Classical methods treat deblurring as an inverse problem. They assume that the blurred image is the result of a sharp image passed through a blur kernel. The blur kernel describes the motion of the camera. If the kernel is known, the sharp image can be recovered by a process called deconvolution. In practice the kernel is not known. So the method must estimate both the kernel and the sharp image at the same time. This is called blind deconvolution. Classical methods use hand-designed priors, such as the idea that natural images have sharp edges. These methods are slow and often fail on complex real blur, because real blur does not follow a single simple kernel.

Deep learning changed the field. A deep network can learn to remove blur directly, without estimating a kernel. The work known as DeepDeblur \[16\] was an early example. It used a multi-scale network that processes the image at several sizes. It also introduced the GoPro dataset. The GoPro dataset creates blurred images by averaging many sharp frames from a high-speed video. This dataset became a standard benchmark. DeblurGAN \[20\] used an adversarial loss to make the output look sharp and realistic.

Later methods improved both quality and efficiency. MIMO-UNet \[17\] used a single U-shaped network with multiple inputs and multiple outputs. It reached good quality with lower computation than earlier multi-scale methods. Restormer \[18\] used a transformer design. It applied attention across the channel dimension instead of the spatial dimension. This reduces the cost of attention for large images. Restormer gives very strong results, but it is heavy for mobile use.

NAFNet \[19\] is an important method for this thesis. Its name means nonlinear activation free network. The authors showed that a simple network can match complex networks. They replaced the usual activation functions with a simple gate operation. This gate multiplies two parts of the feature together. The resulting block is simple and efficient. Many recent efficient restoration networks use NAFNet as a base \[26\]\[29\]. The simple structure of NAFNet is also friendly to quantization, which matters for this thesis.

The choice of training data is important for deblurring. Early methods used synthetic blur from the GoPro dataset. Synthetic blur is clean and regular. Real blur is more complex. The RealBlur dataset \[21\] and the RSBlur dataset \[52\] captured real blurred and sharp pairs with special camera systems. Networks trained on real data generalize better to real photographs. Recent datasets also use smartphone high-speed video to build large and realistic blur sets \[54\].

All of these deblurring methods share one weakness for our problem. They assume that the input has enough light. They are trained on daytime images. In a dark scene, the signal is weak and the noise is strong. A deblurring method trained on bright images fails on dark images. It cannot separate the true structure from the noise. This is the mirror image of the weakness in Section 1.3.1. A method that handles only blur is not enough for night photography.

Table 1.2 summarizes the main deep deblurring methods. It notes the design and the approximate model size. The size is a rough guide, because the exact number depends on the configuration.

| Method | Year | Design | Approx. parameters | Note |
| --- | --- | --- | --- | --- |
| DeepDeblur \[16\] | 2017 | Multi-scale CNN | about 12 M | Introduced the GoPro dataset |
| DeblurGAN \[20\] | 2018 | Adversarial CNN | about 12 M | Sharp, realistic output |
| MIMO-UNet \[17\] | 2021 | Multi-input multi-output U-Net | about 16 M | Good quality at lower cost |
| Restormer \[18\] | 2022 | Channel-attention transformer | about 26 M | Strong but heavy |
| NAFNet \[19\] | 2022 | Gate-based CNN | about 17 M (base) | Simple, efficient, quantization-friendly |
| FSM-Net \[26\] | 2026 | NAFNet plus frequency attention | about 5 M | Efficient, desktop runtime only |

Table 1.2 shows a clear trend over time. The early methods are large multi-scale networks. The later methods reduce the cost while keeping or raising the quality. NAFNet is a turning point. It shows that a simple gate-based block can match complex designs. The most recent efficient methods, such as FSM-Net, build on NAFNet and reach a small model size. This trend toward simple and efficient blocks is important for this thesis, because simple blocks are also easier to quantize.

The standard deblurring benchmarks are the GoPro dataset \[16\], the RealBlur dataset \[21\], and the RSBlur dataset \[52\]. The GoPro dataset uses synthetic blur from averaged video frames. The RealBlur and RSBlur datasets use real blurred and sharp pairs. A method that scores well on GoPro may score lower on real data. This gap between synthetic and real blur is a known problem. It is also a problem for the joint task, where real paired night data is rare. This thesis uses the LOL-Blur dataset, which models the blur with a physical pipeline, to reduce this gap.

The cost of global attention is a key issue for mobile deblurring. A standard transformer computes attention between all pairs of spatial positions. The cost grows with the square of the number of pixels. For a high-resolution phone image, this cost is too high. Restormer reduces the cost by applying attention across channels instead of positions. This makes the cost grow in a linear way with the image size. FSM-Net uses a similar channel-based attention and adds frequency-domain processing. These design choices show how to keep the global view of a transformer at a lower cost. However, even these efficient designs are usually tested on a desktop graphics card, not on a phone. The step to a real phone, with its integer hardware and its memory limit, is the step that this thesis takes.

There is also a specific sub-problem that matters for night images, which is blur in saturated regions. A bright light source has pixel values at the maximum. When it moves, it leaves a bright streak with clipped values. Standard deblurring assumes a linear blur model, which fails on clipped values, as Section 1.4 explains. Some deblurring methods add a special handling for saturated regions. The joint method in this thesis handles these regions through its data and its loss, as Chapter 2 describes.

### 1.3.3 Joint Restoration and Efficient On-Device Methods

The previous two sections showed that single-task methods are not enough. This section reviews methods that solve both tasks together. It also reviews methods that make restoration networks small and fast.

LEDNet \[22\] was the first network designed for joint low-light enhancement and deblurring. The authors made two main contributions. First, they built a data synthesis pipeline that creates realistic dark and blurred images. This pipeline models the light streaks that appear around bright light sources at night. With this pipeline they built the LOL-Blur dataset \[39\], which contains twelve thousand paired images. Second, they designed a single network that performs both tasks together. The network is built to use the link between the two tasks. LEDNet is the base architecture of this thesis, and it is described in detail in Chapter 2.

DarkIR \[23\] is a more recent joint method. It is an efficient multi-task network for low-light restoration. It handles enhancement and deblurring in one framework. The authors argue that solving the tasks separately leads to high model complexity and high computational cost. DarkIR shows that a joint design can be both accurate and efficient. It is the closest recent work to this thesis and serves as a strong baseline.

A separate line of research focuses on efficiency alone. The NTIRE workshop runs yearly challenges on efficient image restoration. The NTIRE 2026 challenge on efficient low-light enhancement \[24\] asked teams to design networks smaller than one megabyte. The winning methods used compact Retinex-style networks and structural reparameterization. The NTIRE 2026 challenge on efficient super-resolution \[25\] reported that structured pruning, knowledge distillation, and operator fusion are the main tools for practical deployment. These challenges show the current best practice for efficient restoration.

Some efficient deblurring methods are close to our needs. FSM-Net \[26\] is a lightweight deblurring network built on NAFNet. It uses frequency-domain attention and linear-cost channel attention. It reports strong deblurring quality with a small model. However, its runtime is measured on a desktop graphics card, not on a mobile device. This is a common gap in the literature. Many methods claim to be efficient but are never tested on a real phone.

The tools for making a network efficient are also well studied. Quantization reduces the numeric precision of the weights and activations. The standard method for integer-only inference was described by Jacob and co-authors \[30\]. Later work improved the accuracy of quantization with better rounding and calibration \[31\]\[32\]. Pruning removes parts of the network that are not important. Deep Compression \[33\] combined pruning and quantization. Structured pruning removes whole channels, which gives a real speed gain on hardware \[34\]\[35\]. Knowledge distillation \[36\] trains a small student network to copy a large teacher network.

Recent work applies these tools to restoration on edge devices. A deployment-aware quantization method for super-resolution \[27\] reached real-time 8-bit integer performance on a mobile neural processor. It combined low-resolution computation, a reparameterizable backbone, and quantization-aware training. A method called decoder-free distillation \[28\] studied quantization for image restoration and noted that this area is still not well explored. A group from a phone maker studied hardware-friendly deblurring blocks for mobile image pipelines \[29\]. Structural reparameterization methods such as RepVGG \[37\] and MobileOne \[38\] train with multiple branches and merge them into one branch for fast inference.

From this review we can state the research gap clearly. First, joint low-light and deblur networks exist, but most are too heavy for a phone. Second, efficient restoration methods exist, but most target a single task, and many are never tested on real mobile hardware. Third, quantization for joint restoration is still not well explored. This thesis addresses this gap. It takes an accurate joint network, LEDNet, and compresses it with a sensitivity-guided method, and it studies the result for real on-device use.

The compression tools deserve a closer look, because they are the core of this thesis. There are three main tools: quantization, pruning, and distillation. Each tool reduces cost in a different way.

Quantization reduces the number of bits per value. The work of Jacob and co-authors \[30\] showed how to run a network with integer-only arithmetic. This is the basis of most mobile deployment today. Later work improved the accuracy of low-bit quantization. The white paper by Nagel and co-authors \[31\] described better rounding and calibration methods. A key later idea is mixed-precision quantization. In mixed precision, different layers use different bit widths. The HAWQ method \[49\] and its later version \[50\] used the curvature of the loss to choose the bit width of each layer. A layer with high curvature is sensitive and gets more bits. This thesis uses a similar idea, but it measures sensitivity by the direct quality drop and links it to the physics of the night-restoration task.

Pruning reduces the number of values. Deep Compression \[33\] combined pruning, quantization, and coding to shrink a network by a large factor. Pruning can be unstructured or structured. Unstructured pruning removes single weights, which does not help most hardware. Structured pruning removes whole channels or filters \[34\]\[35\], which gives a real speed gain. This thesis uses structured pruning, so that the speed gain is real on the phone.

Distillation trains a small student network to copy a large teacher network \[36\]. The student learns from the soft outputs of the teacher, which carry more information than hard labels. Distillation is useful for restoration, but it is still not well explored for quantized restoration. The decoder-free distillation method \[28\] studied this exact gap and noted that joint optimization for quantized restoration is largely open. This thesis treats distillation as a possible extension, and keeps quantization and pruning as the main tools.

Structural reparameterization is a further efficiency idea \[37\]\[38\]. It trains a network with many branches and then merges them into one branch for inference. This gives accuracy at training time and speed at inference time. However, reparameterization changes the training-time structure of the network. Because this thesis keeps the architecture of LEDNet fixed, it does not use reparameterization in the main method. It is listed as future work in Chapter 3.

Table 1.3 summarizes the research gap. It places the key methods on two axes: whether they handle the joint task, and whether they are verified on a real mobile device. The table shows that the upper-right cell, which is the joint task on a real device, is almost empty. This is the gap that this thesis addresses.

| Method | Joint low-light and deblur | Verified on real mobile device |
| --- | --- | --- |
| Zero-DCE \[11\], RetinexFormer \[13\] | No (enhancement only) | Partly (some mobile work) |
| MIMO-UNet \[17\], NAFNet \[19\], FSM-Net \[26\] | No (deblur only) | No (desktop runtime) |
| LEDNet \[22\] | Yes | No |
| DarkIR \[23\] | Yes | No (efficient but not phone-tested) |
| NTIRE efficient challenges \[24\]\[25\] | No (single task) | Partly (size limits, some NPU tests) |
| This thesis | Yes | Yes (target) |

### 1.3.4 General Quantization Methods

Quantization is the main tool of this thesis, so this section reviews the general methods of quantization. It gives the background that Chapter 2 builds on. Quantization maps the values of a network from a high-precision format, usually 32-bit floating point, to a low-precision format, usually 8-bit integer. The goal is a smaller and faster model. The art of quantization is to reduce the precision without losing much quality.

There are several design choices in quantization. Table 1.4 lists the main choices. Each choice is a trade-off between quality and cost.

| Choice | Options | Meaning |
| --- | --- | --- |
| Granularity | Per-tensor or per-channel | One scale factor for a whole tensor, or one scale factor for each channel. Per-channel is more accurate but needs more storage. |
| Symmetry | Symmetric or asymmetric | The zero point is fixed at zero, or it is free. Asymmetric fits data that is not centered at zero, such as the output of a ReLU. |
| Mapping | Uniform or non-uniform | The integer levels are equally spaced, or they follow the shape of the data. Uniform mapping is simple and fast on hardware. |
| What is quantized | Weight-only or weight-and-activation | Only the weights are quantized, or both the weights and the activations. Full integer speed needs both. |
| When scales are set | Static or dynamic | The scale is fixed by calibration before inference, or it is computed at run time from the live data. Static is faster. |
| Training | Post-training or quantization-aware | The model is quantized after training, or the quantization is included during training. |

The most basic method is uniform affine quantization. It maps a real value to an integer with a scale factor and a zero point, as described in detail in Section 2.2.1. The method of Jacob and co-authors \[30\] made this practical for integer-only inference on mobile hardware. It is the basis of most mobile deployment today.

Calibration is the step that sets the scale factors. It runs the model on a small set of example data and records the range of values in each layer. A simple calibration uses the minimum and maximum values. A better calibration clips the extreme values, because a few outliers can waste the integer range. More advanced methods choose the clipping point to minimize the quantization error. The white paper by Nagel and co-authors \[31\] and the whitepaper by Krishnamoorthi \[32\] describe these calibration methods in detail.

There are two main ways to apply quantization, as noted in Table 1.4. Post-training quantization takes a trained model and quantizes it with calibration only. It is fast and needs no retraining. It works well at 8 bits for many networks, but it can lose quality for sensitive networks or at lower bit widths. Quantization-aware training adds the quantization effect into the training loop. The model sees the rounding error during training and learns to resist it. Quantization-aware training usually gives better quality at low bit widths, at the cost of extra training time.

Low-bit quantization is harder than 8-bit quantization. At 4 bits or fewer, the quantization error is large, and simple methods fail. Special methods are needed, such as learned rounding and careful calibration. This thesis works mainly at 8 bits, with a few sensitive layers at a higher precision, which avoids the hardest low-bit regime.

Mixed-precision quantization uses different bit widths for different layers. The idea is that some layers are more sensitive than others. A sensitive layer gets more bits, and a robust layer gets fewer bits. The challenge is to choose the bit width of each layer. The HAWQ method \[49\] and its later version \[50\] used the curvature of the loss, measured through the Hessian, to rank the layers. A layer with high curvature is sensitive and gets more bits. This thesis uses a related idea, but it measures the sensitivity by the direct quality drop and links it to the physics of the night-restoration task, as Chapter 2 explains. Mixed precision is the bridge between the general quantization background here and the specific method of this thesis.

Finally, quantization is often combined with other compression tools. Deep Compression \[33\] combined quantization with pruning and coding to reach a large size reduction. This thesis also combines quantization with structured pruning, as Section 2.2.4 describes. The general lesson from the literature is that quantization is the strongest single tool for mobile deployment, and that mixed precision and quantization-aware training are the keys to keeping quality at low bit widths.

### 1.3.5 Summary of the Literature

The review supports three conclusions. First, the joint task needs a single network, because a cascade fails. LEDNet and DarkIR confirm this. Second, efficient restoration is an active field, but it targets mostly single tasks, and it often reports desktop numbers only. Third, the compression tools are mature, but their use for joint restoration, and their test on real phones, is still rare. These three conclusions define the research gap. This thesis fills the gap by compressing an accurate joint network with a sensitivity-guided method and by testing it for real on-device use. The specific methods and results follow in Chapter 2 and Chapter 3.

## 1.4 Image Degradation Model

This section gives a formal model of the degradation. The model explains in mathematical form why low light and motion blur appear together. It also explains why the joint approach is correct. The model guides the design of the training data and the network.

We start from the physics of the camera. A camera sensor collects light during the exposure time. Let the exposure time be the interval from zero to T. Let S(x, t) be the sharp, well-lit scene at pixel position x and time t. If the camera and the scene were perfectly still, the sensor would record the same scene at every moment. But during a long exposure the camera moves because of hand shake. Let w(t) be the motion of the camera at time t. The sensor adds up the moving scene over the whole exposure. This gives the blurred scene B0:


$$
B_0(x) = \frac{1}{T} \int_{0}^{T} S\big(x - w(t),\, t\big)\, dt
$$


This integral is the cause of motion blur. A longer exposure time T means the camera moves more during the exposure. So the blur is stronger. A dark scene forces a longer T. This is the formal link between low light and motion blur. The same variable T controls both.

In practice we work with discrete images, not continuous integrals. The continuous integral can be written as a convolution with a blur kernel. Let k be the blur kernel that describes the camera motion. Let L be the latent clean image, which is the sharp and well-lit image that we want to recover. The low-light condition is modeled by an illumination factor a, which is a number between zero and one. A small value of a means a very dark scene. The sensor also adds noise, and it clips values that are too bright. The full degradation model is:


$$
I = \mathcal{C}\big( a \cdot (k \otimes L) + n \big)
$$


Here I is the observed image, which is dark, blurred, and noisy. The symbol for convolution is the circled cross. The term a is the illumination factor. The term n is the sensor noise. The function C is the clipping function. It keeps every pixel value inside the valid range, usually from zero to one:


$$
\mathcal{C}(v) = \min\big( \max(v, 0),\, 1 \big)
$$


The clipping function is the reason that bright light sources are so hard to restore. A street lamp has a true value far above one. The clipping function sets it to one. The information above one is lost. When the camera shakes, the lamp spreads into a streak, and the whole streak is clipped. No deblurring method can recover the exact lost values. The network can only learn a plausible result from the surrounding context.

The noise term n is not simple. In low light, the noise depends on the signal. It has two main parts. The first part is shot noise, which follows a Poisson distribution and grows with the light. The second part is read noise, which follows a Gaussian distribution and is constant. A common model combines them as a signal-dependent Gaussian noise:


$$
n \sim \mathcal{N}\big(0,\; \sigma_s^2 \cdot (a \cdot (k \otimes L)) + \sigma_r^2 \big)
$$


Here the term with sigma\_s is the shot noise, and the term with sigma\_r is the read noise. In a dark scene the signal is small, so the read noise is large compared to the signal. This is why dark images look noisy. This strong noise is the reason that deblurring fails on dark images, as explained in Section 1.2.

Figure 1.3 shows the degradation model as a diagram. \

![Figure 1.3](figures/fig1_3.png)

*Figure 1.3.  The image-formation model for a night blurred photograph. A clean latent image L is scaled by the illumination factor a, convolved with the motion blur kernel k, corrupted by signal-dependent noise n, and clipped by the function C to produce the observed image I.\*

The task of this thesis is the inverse of this model. The network receives the observed image I. It must estimate the clean latent image L. In formal terms, the network learns a function F with parameters theta, so that the output is close to the clean image:


$$
\hat{L} = F_\theta(I), \qquad \hat{L} \approx L
$$


This inverse problem is hard because several unknowns are mixed together. The illumination a, the blur kernel k, and the noise n are all unknown. A cascade tries to undo them one at a time, which fails. A joint network learns to undo all of them together from data. The model in this section shows why the joint network is the correct choice. It also shows that the training data must include the illumination factor, the blur kernel, and the signal-dependent noise. The LOL-Blur dataset used in this thesis follows exactly this kind of model.

## 1.5 Research Problem and Objectives

The review in Section 1.3 and the model in Section 1.4 lead to a clear research problem. This section states that problem. It then lists the objectives, the scope, and the main assumptions of the thesis.

### Research problem

The research problem of this thesis is the following. We want a single deep neural network that restores a night photograph that is both dark and blurred. The network must produce a bright and sharp image. At the same time, the network must be small enough and fast enough to run on a smartphone. It must run in a time that feels immediate to the user. The core difficulty is the conflict between quality and efficiency. A larger network gives better quality but is too slow for a phone. A smaller network is fast but may lose quality, especially in the hardest regions such as dark areas and bright light streaks. The research problem is to resolve this conflict for the joint restoration task.

### Objectives

The thesis has the following objectives:

1. To study the joint low-light enhancement and deblurring problem and to select a suitable base network. This thesis selects LEDNet, because it is designed for exactly this joint task.
2. To design a compression method that makes the base network small and fast, without changing its architecture. This thesis designs a sensitivity-guided mixed-precision quantization method, supported by structured pruning.
3. To measure the sensitivity of each layer of the network to low numeric precision. The goal is to find which layers must keep higher precision and which layers can use 8-bit integer precision.
4. To implement the compressed network as a working system that can run on a mobile device, and to describe the full deployment path.
5. To evaluate the compressed network in terms of both image quality and efficiency, and to compare it with the full-precision model and with simple uniform quantization.

### Scope

The scope of this thesis is limited in the following ways. The thesis studies single-image restoration. It does not study multi-frame or burst methods. The input is a processed image in the standard color format, not a raw sensor image. The thesis focuses on motion blur caused by camera shake and object motion. It does not study other blur types such as defocus blur. The thesis treats LEDNet as a fixed architecture. It does not propose a new architecture. The contribution is in the compression and deployment of this architecture. This scope keeps the work focused and consistent with the objectives.

### Assumptions

The thesis makes the following assumptions. First, the training data from the LOL-Blur dataset is a good model of real night degradation. This is reasonable because the dataset was built from the physical model in Section 1.4. Second, the target mobile device has a neural processing unit that supports 8-bit integer computation. This is true for most modern smartphones. Third, the quality metrics used in the evaluation reflect human judgment of image quality. This is a common assumption in the field, and the thesis uses several metrics together to reduce its risk.

### Structure of the thesis

The rest of the thesis is organized into two more chapters. Chapter 2 presents the network architecture and the compression method. Section 2.1 explains the core concepts of LEDNet. Section 2.2 presents the sensitivity-guided quantization and pruning method. Chapter 3 presents the system implementation and the performance evaluation. It describes the datasets, the training setup, the deployment system, and the projected results.

## 1.6 Contributions

This thesis makes the following three main contributions:

1. **A joint low-light enhancement and deblurring network for on-device use, based on LEDNet.** The thesis selects LEDNet as the base network and prepares it for mobile deployment. It explains the core concepts of LEDNet and why they fit the joint night-restoration problem. This provides an accurate starting point that already handles the coupled degradation described in Section 1.2 and Section 1.4.
2. **A sensitivity-guided mixed-precision quantization method, supported by structured pruning, that compresses the network without changing its architecture.** The thesis measures how sensitive each layer is to low numeric precision. It keeps the most sensitive layers, such as those that control dark regions and bright light streaks, at a higher precision. It sets the remaining layers to 8-bit integer precision. This method keeps image quality high while making the model small and fast. Because it changes only numeric precision and channel count, it respects the fixed architecture of LEDNet.
3. **The first systematic on-device deployment and empirical analysis of a joint restoration model.** The thesis describes the full path from the trained model to a running mobile system. It evaluates both image quality and efficiency on a named mobile device. It also analyzes where low precision hurts quality the most, which is in saturated and very dark regions. This analysis is specific to the joint task and is not covered by general quantization studies of single-task networks.

Together, these contributions address the research gap identified in Section 1.3. They show how an accurate joint network can be made efficient enough for a real smartphone camera application, while keeping the quality that the joint design provides.

Note on contribution 2: the novelty of this thesis is not the invention of quantization or pruning, which are known tools. The novelty is the method of applying them to a joint restoration network in a sensitivity-aware way, and the empirical study of the result. This framing is used throughout the thesis.

# Chapter 2. Network Architecture and Compression

This chapter presents the network and the compression method. Section 2.1 explains the core concepts of LEDNet, which is the base network. Section 2.2 presents the sensitivity-guided quantization and pruning method, which makes the network efficient. The chapter uses a balance of equations and figures. The equations define the key operations. The figures show the structure of the network and the flow of the method.

## 2.1 Core Concepts of LEDNet

LEDNet is a single network that performs joint low-light enhancement and deblurring. This section explains its design. It is organized into three parts. The first part describes the overall architecture. The second part describes the core modules. The third part describes the loss functions used for training.

### 2.1.0 Why LEDNet Is the Right Base Network

Before the details, it is worth stating why this thesis chooses LEDNet as the base network. The choice follows directly from the problem analysis in Chapter 1. There are seven reasons.

1. **It is built for the exact joint task.** LEDNet is designed for joint low-light enhancement and deblurring, not for one task alone. It is one of the few networks built for this exact problem. So it already handles the coupled degradation that Chapter 1 describes.
2. **It is a single end-to-end network.** As Section 1.2 showed, a cascade of separate methods fails, because the error of the first stage passes into the second stage. LEDNet avoids this by solving both tasks in one network with shared features.
3. **It protects bright light sources.** The curve-based enhancement module brightens dark regions strongly and bright regions gently. This protects the saturated light sources that are common in night scenes, which is the hardest case from Section 1.4.
4. **It handles spatially varying blur.** The filter-adaptive module predicts a different filter for each position. Camera shake and object motion create blur that changes across the image, and a fixed filter cannot remove it. This module can.
5. **It is trained with realistic night data.** LEDNet comes with the LOL-Blur dataset, which models the physical degradation of night images, including the light streaks around bright sources. This gives a strong and realistic training signal.
6. **It is efficient and quantization-friendly.** LEDNet is a convolutional network of moderate size. It does not use heavy global attention like a large transformer. Convolutional networks are easier to quantize and run faster on a mobile neural processing unit. This matters, because the whole point of this thesis is on-device use.
7. **It is a clean and fixed base for the compression study.** This thesis studies compression, not architecture design. A stable, well-understood architecture lets the work isolate the effect of compression from the effect of architecture changes. LEDNet serves this role well. Newer joint methods, such as DarkIR, are used as comparison baselines, but LEDNet is kept as the fixed base, in line with the scope set in Section 1.5.

These reasons also explain why some alternatives are not chosen as the base. A pair of single-task networks is rejected because of the cascade failure. A large transformer method is rejected because it is too heavy for a phone. A newer joint method could also work, but changing the base would mix architecture choices with compression choices, which this thesis avoids on purpose.

### 2.1.1 Overall Architecture

LEDNet uses an encoder-decoder structure. This structure is also called a U-shaped network, because its diagram looks like the letter U. The encoder is the left side of the U. It reduces the size of the image step by step and increases the number of feature channels. The decoder is the right side of the U. It increases the size step by step and reduces the number of channels. The output is a restored image at the same size as the input.

Figure 2.1 shows the overall architecture. \

![Figure 2.1](figures/fig2_1.png)

*Figure 2.1.  The overall encoder-decoder architecture of LEDNet. The encoder path reduces spatial size and extracts features. A curve-based enhancement step adjusts brightness. The decoder path reconstructs the sharp, bright image. Skip connections link encoder and decoder levels. Filter-adaptive modules in the decoder perform spatially varying deblurring.\*

The encoder has several levels. At each level, the network applies a group of convolution blocks. Then it reduces the spatial size by a factor of two. This is called downsampling. Downsampling lets the network see a larger area of the image with each filter. This larger view is important for deblurring, because motion blur spreads information across many pixels. A network must see a wide area to understand the blur.

The basic operation in the network is the convolution. A convolution applies a small filter across the image. For an input feature map X, a weight filter W, and a bias b, the output feature map Y at channel j is:


$$
Y_j = \sum_{i} W_{j,i} \otimes X_i + b_j
$$


The sum runs over the input channels i. The circled cross is the convolution operation. After each convolution, the network applies a nonlinear function. A common choice is the rectified linear unit, written as ReLU:


$$
\mathrm{ReLU}(z) = \max(0, z)
$$


The nonlinear function lets the network learn complex mappings. Without it, a stack of convolutions would be equal to a single convolution.

LEDNet uses residual blocks. A residual block adds the input of the block to its output. Let the input be X and let the inside function be G. The output of a residual block is:


$$
Y = X + G(X)
$$


The residual design helps training. The network only needs to learn the change from the input, not the whole output. This makes deep networks easier to train. It also helps the flow of gradients during training.

The network uses skip connections between the encoder and the decoder. A skip connection copies a feature map from an encoder level to the matching decoder level. This passes fine detail from the encoder directly to the decoder. The detail would otherwise be lost during downsampling. Skip connections are important for restoration, because the output must keep the fine structure of the scene.

Between the encoder and the decoder, LEDNet places a step that adjusts the brightness. This step performs the low-light enhancement part of the task. It uses a curve-based method, which is described in Section 2.1.2. The key idea of LEDNet is that enhancement and deblurring are not done in separate networks. They are done in different parts of the same network. The encoder and the enhancement step brighten the image and prepare the features. The decoder, with its special modules, removes the blur. Because both parts share the same features, they work together. This is the synergy that makes the joint network better than a cascade.

The design also handles the order problem from Section 1.2. The enhancement happens on the compact features in the middle of the network, not on the raw pixels. So the later deblurring step still has access to the original detail through the skip connections. This avoids the loss of blur cues that breaks the cascade method.

#### Stage-by-stage description of the network

This part describes the network stage by stage, following the data from input to output. Figure 2.1 shows all of these stages together, with the channel counts and the block types. The reader may follow the figure while reading this description.

**Input and stem.** The network receives the degraded image I, of size 256 by 256 with 3 color channels. A first convolution, called the stem, turns the 3 color channels into 32 feature channels. The stem does not change the spatial size. It prepares a feature map that the encoder can process.

**Encoder stages.** The encoder has three stages. Each stage first applies a group of residual blocks, then reduces the spatial size by a factor of two. A residual block, defined in the previous part, applies two convolutions and adds the input to the output. Stacking several residual blocks lets each stage learn rich features. Across the three stages, the channel count rises from 32 to 64 to 128, while the size falls from 256 to 128 to 64. The rule is simple: as the size falls, the channel count rises. This keeps the amount of information roughly balanced across stages. The downsampling also grows the receptive field, which is the area of the input that each feature can see. A large receptive field is needed for deblurring, because motion blur spreads information across many pixels.

**Bottleneck with curve enhancement.** At the bottom of the U-shape, the feature map is small, 32 by 32, with the most channels, 256. This is the bottleneck. It holds the most abstract features. The low-light enhancement acts here, through the curve-based module of Section 2.1.2. The module predicts a spatially varying parameter map and applies the brightening curve several times. Because the enhancement acts on compact features, and not on raw pixels, the later decoder still has access to the original fine detail through the skip connections. This design choice is the key to avoiding the cascade failure, as Section 2.1.1 noted.

**Decoder stages.** The decoder also has three stages, which mirror the encoder. Each decoder stage first increases the spatial size by a factor of two, then applies a filter-adaptive module and a group of residual blocks. The filter-adaptive module, from Section 2.1.2, predicts a position-specific filter and removes the spatially varying blur. Across the three decoder stages, the size rises from 64 to 128 to 256, while the channel count falls from 128 to 64 to 32. The decoder rebuilds the sharp, bright image step by step.

**Skip connections.** Each encoder stage is linked to the matching decoder stage by a skip connection. The skip connection concatenates the encoder feature map with the decoder feature map. This passes the fine detail from the encoder directly to the decoder. Without the skip connections, the fine detail would be lost during downsampling. The skip connections are drawn as dashed lines in Figure 2.1.

**Output head.** The last decoder stage produces a feature map of size 256 by 256 with 32 channels. A final convolution, the output head, turns these 32 channels back into the 3 color channels of the restored image L. The output has the same size as the input.

**How the parts cooperate.** The design puts the two tasks in different parts of one network. The encoder and the bottleneck curve module brighten the image and prepare the features. The decoder, with its filter-adaptive modules, removes the blur. Because both parts share the same features and are trained together, they cooperate rather than conflict. This cooperation is the synergy that makes the joint network stronger than a cascade. It is also the reason the network can handle the hardest regions, such as the dark areas and the bright light streaks, which a cascade cannot.

### 2.1.2 Core Modules

LEDNet has two special modules. The first module performs the low-light enhancement. The second module performs the spatially varying deblurring. This section explains both modules.

#### Curve-based enhancement

The enhancement module brightens the dark features. A simple way to brighten an image is to multiply every pixel by a fixed number. But this simple method does not work well. Dark regions and bright regions need different amounts of brightening. A fixed number would make bright regions too bright and would clip them. So the module learns a curve that maps each input value to an output value. The curve is different for different brightness levels.

The curve-based method follows the idea of Zero-DCE \[11\]. The network predicts the parameters of the curve from the image. The curve is then applied several times to reach the target brightness. A single application of the curve to a feature value v, with a predicted parameter map A, can be written as:


$$
v' = v + A \cdot v \cdot (1 - v)
$$


Here v is the input value, and v prime is the brightened value. The parameter A controls the strength of the brightening. The term v times one minus v is largest for middle values and smallest for very dark or very bright values. This shape gives more brightening to middle tones and protects the very bright values from clipping. The curve is applied several times in sequence, which lets the network reach a large brightening in a controlled way.

The key point is that A is predicted by the network for each position. So the brightening is spatially adaptive. A dark corner of the image receives strong brightening. A bright lamp receives little brightening. This protects the bright light sources and reduces the clipping problem from Section 1.4.

#### Filter-adaptive deblurring

The deblurring module must handle blur that is different at each position. Camera shake and object motion create different blur in different parts of the image. A standard convolution uses the same filter at every position. So a standard convolution cannot remove spatially varying blur well. LEDNet solves this with a filter-adaptive module. This module predicts a different filter for each position in the image.

Let the feature map be X. The module uses a small network to predict a filter K(x) for each position x. Then it applies this position-specific filter to the feature map. The output at position x is:


$$
Y(x) = \sum_{\Delta \in \mathcal{W}} K_{x}(\Delta) \cdot X(x + \Delta)
$$


Here the set W is a small window around the position x. The filter K at position x gives a weight to each neighbor in the window. Because the filter K depends on the position x, the module can adapt to the local blur. Where the blur is strong, the predicted filter is wide. Where the blur is weak, the predicted filter is narrow. This gives much better deblurring than a fixed filter.

Figure 2.2 shows the two core modules in detail. \

![Figure 2.2](figures/fig2_2.png)

*Figure 2.2.  The two core modules of LEDNet. Left: the curve-based enhancement module predicts a spatially varying parameter map and applies the brightening curve several times. Right: the filter-adaptive deblurring module predicts a position-specific filter and applies it to the feature map to remove spatially varying blur.\*

These two modules are the reason LEDNet fits the night-restoration problem. The curve module handles the low-light part in a way that protects bright sources. The filter-adaptive module handles the blur in a way that adapts to each position. Both modules work on shared features, so they cooperate. This design directly answers the problems identified in Chapter 1. It is also the reason this thesis selects LEDNet as the base network. The next section describes how these modules are trained with suitable loss functions.

### 2.1.3 Loss Functions

The network is trained to make its output close to the clean target image. A loss function measures the difference between the output and the target. Training changes the network weights to reduce this loss. LEDNet uses several loss terms together. Each term measures a different kind of difference. This section describes the main terms.

The first term is the reconstruction loss. It measures the direct pixel difference between the output and the target. A common choice is the L1 loss, which is the mean of the absolute differences. For the output image and the target image, the reconstruction loss is:


$$
\mathcal{L}_{rec} = \frac{1}{N} \sum_{x} \big| \hat{L}(x) - L(x) \big|
$$


Here the sum runs over all N pixels. The output is L hat and the target is L. The L1 loss is preferred over the squared loss for restoration. The L1 loss gives sharper results, because it does not over-penalize large errors and does not push the output toward a blurry average.

The second term is the perceptual loss. The pixel loss alone does not match human vision. Two images can have a small pixel difference but still look different to a person. The perceptual loss compares the images in the feature space of a pretrained network. Let phi be a fixed feature extractor. The perceptual loss is the difference between the features of the output and the features of the target:


$$
\mathcal{L}_{per} = \frac{1}{M} \sum \big\| \phi(\hat{L}) - \phi(L) \big\|^2
$$


This loss makes the output look natural and keeps its texture. It is important for night images, where fine texture is easy to lose.

LEDNet also uses a term that focuses on the hardest regions. The bright light sources and their streaks are the hardest part of the image. A region-aware term gives more weight to these saturated regions. This pushes the network to spend more effort on the regions that are most likely to fail. In a general form, a weighted loss gives a weight map m(x) to each pixel:


$$
\mathcal{L}_{reg} = \frac{1}{N} \sum_{x} m(x) \cdot \big| \hat{L}(x) - L(x) \big|
$$


The weight map m is larger in bright and saturated regions. This term reduces the artifacts around light sources.

The total loss is a weighted sum of the terms. Let the weights be lambda values. The total loss is:


$$
\mathcal{L} = \lambda_{rec}\, \mathcal{L}_{rec} + \lambda_{per}\, \mathcal{L}_{per} + \lambda_{reg}\, \mathcal{L}_{reg}
$$


The weights control the balance between the terms. A larger reconstruction weight gives a higher pixel accuracy. A larger perceptual weight gives a more natural look. The weights are chosen by experiment on the validation set.

These loss functions are standard for image restoration. They are mentioned here because they matter for the compression in Section 2.2. When the network is quantized, it is trained again with the same losses. This retraining, called quantization-aware training, lets the network recover the quality that low precision would otherwise lose. The region-aware term is especially useful during this retraining, because the saturated regions are also the regions most sensitive to low precision. This link between the loss design and the compression method is a theme of the next section.

### 2.1.4 Worked Example: Shapes, Parameters, and Computation

This section works through the network with real numbers. The numbers make the design concrete. They also prepare the cost analysis of Section 2.2. We use an example input image of size 256 by 256 pixels with 3 color channels. We write a feature map size as height by width by channels.

#### Feature map sizes through the network

The encoder reduces the spatial size by a factor of two at each level, and it raises the channel count. A typical plan is shown in Table 2.1.

| Stage | Feature map size | Channels |
| --- | --- | --- |
| Input | 256 x 256 | 3 |
| Encoder level 1 | 256 x 256 | 32 |
| Encoder level 2 | 128 x 128 | 64 |
| Encoder level 3 | 64 x 64 | 128 |
| Bottleneck | 32 x 32 | 256 |
| Decoder level 3 | 64 x 64 | 128 |
| Decoder level 2 | 128 x 128 | 64 |
| Decoder level 1 | 256 x 256 | 32 |
| Output | 256 x 256 | 3 |

The table shows the U-shape clearly. The size falls from 256 to 32 and then rises back to 256. The channel count rises from 3 to 256 and then falls back to 3. The bottleneck has the smallest size and the most channels. This is where the network holds the most abstract features, and it is where the brightness enhancement acts.

#### Parameter count of a convolution

The number of parameters in a convolution layer follows a simple formula. For a kernel of size k by k, with C\_in input channels and C\_out output channels, the number of weights is:


$$
P = k \times k \times C_{in} \times C_{out} + C_{out}
$$


The last term is the bias, one per output channel. As an example, take a 3 by 3 convolution at encoder level 2, with 64 input channels and 64 output channels. The number of weights is 3 times 3 times 64 times 64, which is 36,864, plus 64 bias terms, for a total of 36,928 parameters. A full network stacks many such layers, which is why the total parameter count reaches several million.

#### Computation count of a convolution

The computation is measured in multiply-accumulate operations, written as MACs. For a convolution applied to a feature map of size H by W, the number of MACs is:


$$
\text{MACs} = H \times W \times k \times k \times C_{in} \times C_{out}
$$


Take the same 3 by 3 convolution with 64 input and 64 output channels, applied at level 2 where the size is 128 by 128. The number of MACs is 128 times 128 times 3 times 3 times 64 times 64, which is about 6.0 billion MACs for this single layer. This large number shows why a full network is slow, and why quantization and pruning are needed. It also shows why most computation sits at the larger spatial sizes, which guides where to prune.

#### Curve enhancement with numbers

Recall the brightening curve from Section 2.1.2, which updates a value v with a parameter A as v plus A times v times one minus v. Take a dark feature value v equal to 0.1 and a predicted parameter A equal to 0.8. One step gives 0.1 plus 0.8 times 0.1 times 0.9, which is 0.1 plus 0.072, equal to 0.172. A second step, applied to 0.172, gives 0.172 plus 0.8 times 0.172 times 0.828, which is about 0.286. So two steps raise the value from 0.1 to about 0.29. A bright value behaves differently. Take v equal to 0.9 and the same A equal to 0.8. One step gives 0.9 plus 0.8 times 0.9 times 0.1, which is 0.9 plus 0.072, equal to 0.972. The bright value rises only a little. This shows how the curve brightens dark values strongly and bright values gently, which protects light sources from clipping.

#### Filter-adaptive deblurring with numbers

The filter-adaptive module predicts a small filter at each position. Suppose the window is 5 by 5, so each position has 25 filter weights. For a feature map of size 64 by 64 with 128 channels, the module predicts 64 times 64 times 25 filter weights for a shared spatial filter, which is 102,400 weights for one feature level. This is much smaller than a full per-channel filter bank, which keeps the module efficient. The predicted filter adapts to the local blur, as described earlier. These numbers show that the adaptive design adds a modest cost for a large quality gain in deblurring.

These worked numbers give a concrete feel for the network. They show where the parameters and the computation sit. They also prepare the reader for the compression analysis in Section 2.2, where the same kinds of numbers show the cost savings from quantization and pruning.

## 2.2 Sensitivity-Guided Quantization and Pruning

This section presents the compression method of the thesis. The goal is to make LEDNet small and fast enough for a smartphone. The method must not change the architecture of LEDNet. It changes only two things. It changes the numeric precision of the weights and activations, which is quantization. It also changes the number of channels, which is pruning. Because it changes only these two things, it keeps the architecture of LEDNet fixed, as stated in the objectives.

The section has four parts. Section 2.2.1 explains the background of quantization. Section 2.2.2 explains how to measure the sensitivity of each layer. Section 2.2.3 presents the sensitivity-guided mixed-precision method. Section 2.2.4 presents the structured pruning method.

### 2.2.1 Quantization Background

Quantization reduces the number of bits used to store a number. A trained network usually stores its weights and activations as 32-bit floating-point numbers. These numbers are accurate but large and slow. A mobile neural processor works much faster with 8-bit integers. An 8-bit integer uses four times less memory than a 32-bit float. It also allows faster computation, because integer arithmetic is simpler than floating-point arithmetic. So quantization makes the model smaller and faster. This is the single most important tool for mobile deployment.

Quantization maps a floating-point value to an integer. It uses a scale factor and a zero point. The scale factor controls the step size between integer levels. The zero point is the integer that represents the real value zero. For a floating-point value r, the quantized integer q is computed as:


$$
q = \mathrm{round}\!\left( \frac{r}{s} \right) + z
$$


Here s is the scale factor and z is the zero point. The round function gives the nearest integer. The integer q is then clipped to the range allowed by the bit width. For 8-bit signed integers, the range is from minus 128 to 127.

To use the value in later computation, we map the integer back to a floating-point value. This is called dequantization. The recovered value r approximate is:


$$
\hat{r} = s \cdot (q - z)
$$


The recovered value is not exactly equal to the original value. The difference is the quantization error. This error comes from the round function. A smaller scale factor gives smaller steps and a smaller error. But a smaller scale factor also covers a smaller range of values. So the scale factor must balance range and precision. The process of choosing the scale factor is called calibration. Calibration uses a small set of example data to find the range of values in each layer.

There are two main ways to apply quantization. The first way is post-training quantization. It takes a trained network and quantizes it directly, using only calibration. It is fast and needs no retraining. But it can lose quality, especially at low bit widths. The second way is quantization-aware training. It adds the quantization effect into the training process. The network sees the quantization error during training and learns to resist it.

In quantization-aware training, the forward pass uses the quantized values. But the quantization function has a flat or undefined gradient, because the round function is a step function. To solve this, training uses a method called the straight-through estimator. In the backward pass, it treats the round function as if it were the identity function. So the gradient passes straight through the quantization step:


$$
\frac{\partial \hat{r}}{\partial r} \approx 1
$$


This simple trick lets the network train through the quantization. Quantization-aware training usually gives much better quality than post-training quantization at the same bit width. For this reason, this thesis uses quantization-aware training as the main method. The region-aware loss from Section 2.1.3 is used during this training to protect the saturated regions.

The important question is the bit width. A uniform method uses the same bit width for every layer, usually 8 bits. This is simple but not always best. Some layers are more sensitive to low precision than others. If we force a sensitive layer to a low bit width, the quality drops. The next section measures this sensitivity, so that we can choose the bit width per layer instead of using one bit width for all.

### 2.2.2 Layer Sensitivity Analysis

The central idea of this thesis is that layers are not equally sensitive to low precision. Some layers can use 8-bit integers with almost no loss. Other layers lose much quality when quantized to 8 bits. If we know which layers are sensitive, we can keep them at a higher precision. This gives better quality at almost the same cost. This section explains how to measure the sensitivity of each layer.

First, we must define sensitivity. The sensitivity of a layer is the amount of quality loss caused by quantizing only that layer. To measure it, we quantize one layer at a time. We keep all other layers at full precision. Then we measure the drop in quality. A layer that causes a large drop is sensitive. A layer that causes a small drop is robust.

We can measure the drop in two ways. The first way is a direct quality measure. We run the network on a validation set and measure a quality metric, such as the peak signal-to-noise ratio. We compare the metric with and without the quantization of the layer. The difference is the sensitivity. For a layer i, the sensitivity is:


$$
\Omega_i = Q_{full} - Q_{(i\,\text{quantized})}
$$


Here Q full is the quality of the full-precision model. The second term is the quality when only layer i is quantized. A large value of omega means a sensitive layer.

The second way uses the idea of the loss curvature. A layer is sensitive if a small change in its weights causes a large change in the loss. This is measured by the second derivative of the loss, which is related to a quantity called the Hessian. A layer with a high curvature is sensitive, because quantization moves its weights and the loss rises quickly. This method is used by advanced mixed-precision methods \[49\]\[50\]. In this thesis we use the direct quality measure as the main method, because it is simple and it links directly to the final metric. The curvature method is mentioned as a possible extension.

The analysis reveals a clear pattern, which matches the physics of the problem. The layers that handle the brightness curve are sensitive. These layers control the brightening of dark regions. A small error in these layers changes the brightness of the whole output. The layers near the bright light sources are also sensitive. These layers must represent a very wide range of values, from dark background to bright streak. A low precision cannot cover this wide range well. The first layer and the last layer of the network are usually sensitive too, because they connect to the real image values.

In contrast, the deep layers in the middle of the network are often robust. These layers work on abstract features, not on direct image values. They have many channels, so the loss of one channel to quantization error is less important. These layers can use 8-bit integers safely.

Figure 2.3 shows the sensitivity of each layer as a bar chart. \

![Figure 2.3](figures/fig2_3.png)

*Figure 2.3.  Projected per-layer sensitivity of LEDNet to 8-bit quantization. The horizontal axis lists the layers from input to output. The vertical axis shows the quality drop caused by quantizing only that layer. The enhancement-curve layers, the layers near bright light sources, and the first and last layers show the highest sensitivity. The deep middle layers show the lowest sensitivity. Values are projected, not measured.\*

This sensitivity analysis is the key input to the next section. It tells us which layers to protect. By keeping only the few sensitive layers at a higher precision, we gain most of the quality of the full-precision model, at almost the cost of a fully 8-bit model. This is the core of the sensitivity-guided method.

### 2.2.3 Sensitivity-Guided Mixed-Precision Bit Allocation

The previous section measured the sensitivity of each layer. This section uses that measurement to assign a bit width to each layer. The result is a mixed-precision model. Most layers use 8-bit integers. A few sensitive layers use a higher precision, such as 16 bits. This is the main technical contribution of Chapter 2.

The idea is simple to state. We want to use low precision to save cost. But low precision on a sensitive layer costs quality. So we spend the extra bits only where they matter. We keep the sensitive layers at higher precision and set the rest to 8 bits. This gives a good balance between quality and cost.

We can state the allocation as a rule. Let omega\_i be the sensitivity of layer i from Section 2.2.2. Let tau be a threshold. The bit width b\_i of layer i is chosen as:


$$
b_i = \begin{cases} 16 & \text{if } \Omega_i > \tau \\ 8 & \text{if } \Omega_i \le \tau \end{cases}
$$


The threshold tau controls the balance. A low threshold keeps many layers at high precision, which gives high quality but a larger model. A high threshold keeps few layers at high precision, which gives a smaller model but lower quality. The threshold is chosen to meet a target model size or a target quality.

There is also a more general way to choose the bit widths. We can treat the choice as an optimization problem. We want to minimize the total quality loss, subject to a limit on the total model size. Let the size cost of layer i at bit width b\_i be the number of parameters times the bit width. The problem is:


$$
\min_{\{b_i\}} \sum_i \Omega_i(b_i) \quad \text{subject to} \quad \sum_i P_i \cdot b_i \le \mathcal{B}
$$


Here P\_i is the number of parameters in layer i, and the symbol B is the total bit budget. This problem chooses the bit widths that give the least quality loss for the allowed size. It can be solved with a simple search, because the number of layers is not large and the number of bit-width choices is small. The simple threshold rule above is a fast special case of this problem.

In this thesis, the sensitive layers are the enhancement-curve layers, the layers near bright light sources, and the first and last layers. These layers are kept at 16-bit precision. All other layers are set to 8-bit precision. Because the sensitive layers are few and often small, the extra cost is small. Most of the model still runs in fast 8-bit integer arithmetic.

After the bit widths are chosen, the model is trained again with quantization-aware training, as described in Section 2.2.1. During this training, each layer uses its assigned bit width. The region-aware loss from Section 2.1.3 protects the saturated regions during this step. This final training recovers most of the quality lost to quantization.

The important point for the thesis framing is that this method does not change the architecture of LEDNet. It changes only the bit width of each layer. The layers, the connections, and the modules are all the same as in the original LEDNet. So the method stays inside the scope set in Section 1.5. The novelty is the sensitivity-guided choice of bit widths for a joint restoration network, and the link between the sensitive layers and the physics of the night-restoration problem. This link is what makes the method specific to this task and not a generic quantization recipe.

### 2.2.4 Structured Pruning

Quantization reduces the precision of each number. Pruning reduces the count of numbers. Pruning removes parts of the network that contribute little to the output. This section describes the structured pruning used in this thesis. Pruning is a secondary tool here. Quantization carries the main efficiency gain. Pruning gives an extra reduction in size and computation.

There are two kinds of pruning. The first kind is unstructured pruning. It removes single weights and leaves holes in the weight matrix. This reduces the number of nonzero weights. But it does not help on most hardware, because the hardware still processes the full matrix. The second kind is structured pruning. It removes whole channels or whole filters. This makes the network truly smaller. The remaining network is a normal, dense network with fewer channels. This gives a real speed gain on a mobile processor. For this reason, the thesis uses structured pruning.

Structured pruning must decide which channels to remove. A channel that contributes little to the output should be removed. A simple and effective measure is the magnitude of the channel weights. A channel with small weights has a small effect on the output. For a channel c with weight filter W\_c, the importance score is the norm of its weights:


$$
I_c = \| W_c \|_1 = \sum_{i} | W_{c,i} |
$$


The channels are sorted by this score. The channels with the lowest scores are removed first. The fraction of channels removed is called the pruning ratio. A higher pruning ratio gives a smaller and faster model, but it can lower the quality. The pruning ratio is chosen to meet a target size while keeping the quality acceptable.

Pruning a U-shaped network needs care. LEDNet has skip connections that join an encoder level to a decoder level. The two joined layers must have a matching number of channels. If we prune one side, we must prune the other side in the same way. If we do not, the channels will not match and the network will break. So the pruning must be applied in a consistent way across the skip connections. This is a known difficulty with U-shaped networks, and it is handled by grouping the linked layers and pruning them together.

After pruning, the network has fewer channels but lower quality. The quality is recovered by training the network again. This is called fine-tuning. The pruned network is trained for a number of steps with the same losses as in Section 2.1.3. Fine-tuning lets the remaining channels adjust to cover the work of the removed channels. After fine-tuning, the quality returns close to the original level.

The pruning and the quantization are combined in one pipeline. Figure 2.4 shows the full compression pipeline. \

![Figure 2.4](figures/fig2_4.png)

*Figure 2.4.  The full compression pipeline. Step 1: train the full-precision LEDNet. Step 2: measure per-layer sensitivity. Step 3: apply structured channel pruning and fine-tune. Step 4: assign mixed-precision bit widths from the sensitivity scores. Step 5: run quantization-aware training. Step 6: export the compressed model for the mobile device.\*

The order of the steps matters. In this thesis, pruning is applied before the final quantization-aware training. This order lets the quantization-aware training adapt to the pruned network. The sensitivity measurement is done on the full-precision model, because it is cheaper and gives a stable ranking of the layers. The whole pipeline keeps the architecture of LEDNet, since it changes only channel count and numeric precision. The next chapter implements this pipeline and reports the projected results.

### 2.2.5 Worked Examples: Compression in Numbers

This section works through the compression with real numbers. It makes the method concrete and shows the size and speed savings.

#### Quantizing one value

Take a layer whose values range from minus 2.0 to plus 2.0. We quantize to 8-bit signed integers, which have 256 levels from minus 128 to 127. The scale factor is the range divided by the number of steps. Here the scale is 4.0 divided by 255, which is about 0.0157. We use a zero point of 0 for a symmetric range. Now quantize the value r equal to 0.5. The integer is the round of 0.5 divided by 0.0157, which is the round of 31.8, equal to 32. To recover the value, we compute 0.0157 times 32, which is 0.502. The original value was 0.5 and the recovered value is 0.502. The quantization error is 0.002. This small error is the price of the lower precision.

Now quantize a value in a wide-range layer, such as a layer near a bright light source. Suppose the range is minus 16.0 to plus 16.0. The scale is 32.0 divided by 255, which is about 0.1255. Quantize the value 0.5. The integer is the round of 0.5 divided by 0.1255, which is the round of 4.0, equal to 4. The recovered value is 0.1255 times 4, which is 0.502. But now consider a small detail of size 0.05 in this wide-range layer. The integer is the round of 0.05 divided by 0.1255, which is the round of 0.4, equal to 0. The small detail is lost. This example shows why wide-range layers, such as those near bright sources, are sensitive to 8-bit quantization. They need more precision to keep small details. This is the exact reason for the sensitivity-guided method.

#### Memory savings from quantization

A 32-bit float uses 4 bytes per value. An 8-bit integer uses 1 byte per value. So 8-bit quantization reduces the model size by a factor of 4. Take a layer with 36,928 parameters, from the example in Section 2.1.4. In 32-bit form it uses about 147,712 bytes, or about 144 kilobytes. In 8-bit form it uses about 36,928 bytes, or about 36 kilobytes. The whole network scales in the same way. A 7.4 million parameter model uses about 28 megabytes in 32-bit form and about 7 megabytes in 8-bit form.

#### A sensitivity example

Table 2.2 shows a projected sensitivity measurement for a few example layers. The sensitivity is the drop in peak signal-to-noise ratio when only that layer is quantized to 8 bits. The numbers are projected, not measured.

| Layer | Role | Projected sensitivity (dB drop) | Decision |
| --- | --- | --- | --- |
| First convolution | Reads the raw image | 0.9 | Keep at 16-bit |
| Encoder level 2 | Mid-level features | 0.1 | 8-bit |
| Enhancement curve layer | Controls brightness | 1.2 | Keep at 16-bit |
| Bottleneck convolution | Abstract features | 0.1 | 8-bit |
| Saturated-region layer | Near bright sources | 1.0 | Keep at 16-bit |
| Decoder level 2 | Mid-level features | 0.1 | 8-bit |
| Last convolution | Writes the output image | 0.8 | Keep at 16-bit |

The table shows the pattern. A few layers have a high sensitivity, above a threshold of about 0.5 decibels. These are the first and last layers, the enhancement-curve layer, and the saturated-region layer. They are kept at 16-bit. The other layers have a low sensitivity and are set to 8-bit. In a typical network, the sensitive layers are only about 10 to 20 percent of the parameters. So the extra cost of keeping them at 16-bit is small.

#### Mixed-precision size calculation

Suppose the network has 7.4 million parameters. Suppose 15 percent of the parameters are in sensitive layers kept at 16-bit, and 85 percent are in layers set to 8-bit. The sensitive part is 1.11 million parameters at 2 bytes, which is about 2.22 megabytes. The rest is 6.29 million parameters at 1 byte, which is about 6.29 megabytes. The total is about 8.5 megabytes. For comparison, a full 8-bit model is about 7.4 megabytes, and a full 16-bit model is about 14.8 megabytes. So the mixed-precision model is close to the 8-bit model in size, but it keeps the quality of the sensitive layers.

#### Pruning and the combined factor

Now add structured pruning at a ratio of 30 percent. Pruning removes about 30 percent of the channels, which reduces the parameter count to about 5.2 million. Applying the same mixed-precision split to 5.2 million parameters gives about 6.0 megabytes. So the combined pipeline reduces the model from about 28 megabytes in full precision to about 6 megabytes. This is a reduction factor of about 4.7. The computation falls in a similar way, which lowers the latency and the energy. These numbers match the projected results reported in Chapter 3.

These worked examples show the method in concrete terms. The quantization example explains why wide-range layers are sensitive. The size calculations show that the mixed-precision model stays close to the 8-bit model in size. The combined factor shows the full saving from quantization and pruning together.

# Chapter 3. System Implementation and Performance Evaluation

This chapter describes the implementation and the evaluation. Section 3.1 describes the datasets and the training setup. Section 3.2 describes the mobile system and the deployment path. Section 3.3 evaluates the image quality. Section 3.4 evaluates the efficiency. Section 3.5 presents an ablation study. Section 3.6 discusses the results and the limitations. The results in this chapter are projected results, as explained in the abstract. They are informed estimates based on the literature, not measured values. They are marked clearly where they appear.

## 3.1 Datasets and Training Setup

### Datasets

The main dataset for training is LOL-Blur \[39\]. This dataset was built for the joint low-light and deblurring task. It contains about twelve thousand image pairs. Each pair has a dark and blurred input and a bright and sharp target. The dataset follows the physical model of Section 1.4. It includes diverse levels of darkness and motion blur. It also models the light streaks around bright sources, which are the hardest case. The dataset is split into a training part and a test part. The training part is used to learn the network. The test part is used to measure the quality.

For testing on real photographs, the thesis uses real night images. The Real-LOLBlur set, which contains real dark and blurred images without ground truth, is used for visual comparison. In addition, a small set of real smartphone photographs is captured by the author for the final on-device test. This real test is important, because the synthetic data cannot fully match real sensor behavior.

### Data preparation

The images are prepared before training. Each image is cut into small patches, for example of size 256 by 256 pixels. Patches make training faster and fit the memory of the graphics card. The patches are also augmented. Augmentation applies simple changes, such as flipping the patch left to right or rotating it. Augmentation increases the variety of the training data and reduces overfitting.

### Training setup

The training has three stages, which follow the compression pipeline of Section 2.2.4.

1. **Full-precision training.** The LEDNet model is trained from the start on the LOL-Blur training set. It uses the loss functions of Section 2.1.3. The optimizer is Adam, which is a standard choice for image restoration. The initial learning rate is small, for example 0.0001, and it is reduced over time with a cosine schedule. This stage produces the accurate full-precision model.
2. **Pruning and fine-tuning.** The full-precision model is pruned with structured pruning. The pruned model is then fine-tuned on the same training set to recover quality.
3. **Quantization-aware training.** The pruned model is assigned mixed-precision bit widths from the sensitivity analysis. It is then trained again with quantization-aware training. This stage produces the final compressed model.

The hardware for training is a desktop computer with one or more graphics cards. The software is a standard deep learning framework. The exact settings, such as the batch size and the number of training steps, are chosen by experiment on the validation set. These settings should be recorded in full when the real experiments are run, so that the work can be reproduced.

The next section describes how the final model is moved from the desktop to the smartphone.

## 3.2 System Implementation

This section describes how the compressed model runs on a smartphone. It covers the target device, the export path, and the application pipeline.

### Target device

The target device is a modern smartphone. A modern smartphone has three kinds of processor. The first is the central processor, which is general but not very fast for neural networks. The second is the graphics processor, which is faster for parallel work. The third is the neural processing unit, which is built for neural networks. The neural processing unit is the fastest and most energy-efficient choice. It is designed for 8-bit integer computation. This is the reason the thesis uses 8-bit quantization. The method matches the hardware. In this thesis, the target is a recent flagship chipset with a neural processing unit that supports 8-bit integer and 16-bit computation.

### Export path

The model is trained in a desktop deep learning framework. It must be converted to a form that the phone can run. The export path has three steps. First, the trained model is saved in an open exchange format, such as ONNX. This format describes the network in a way that many tools can read. Second, the model is converted to a mobile runtime format, such as a mobile inference format for on-device use. During this step, the quantization settings are applied, so that the model runs in integer form. Third, the mobile model is tested on the device to confirm that the output matches the desktop output within a small error.

Figure 3.1 shows the deployment path as a diagram. \

![Figure 3.1](figures/fig3_1.png)

*Figure 3.1.  The deployment pipeline. The model is trained in a desktop framework, exported to an open exchange format, converted to a mobile runtime format with quantization applied, and finally run on the smartphone neural processing unit inside the camera application.\*

### Application pipeline

Inside the camera application, the model is one step in a larger pipeline. The pipeline has the following steps. First, the camera captures the dark and blurred image. Second, the image is prepared for the network. This may include resizing and format conversion. Third, the compressed network runs on the neural processing unit and produces the restored image. Fourth, the restored image is shown to the user and saved.

The model must run within a time budget. For a smooth user experience, the restoration should finish in a fraction of a second. If the model is too slow, the application can run it on a smaller version of the image and then upscale the result. The thesis targets a full restoration within the time budget of a normal photo capture.

### Memory and energy

Two other limits matter on a phone. The first is memory. The model and its working data must fit in the memory available to the application. A compressed model uses less memory, which helps. The second is energy. Each capture uses battery power. The neural processing unit is energy-efficient, and the 8-bit model uses less energy than a full-precision model. These two limits are measured in Section 3.4.

The implementation shows that the method is practical. The compressed model fits the hardware, the export path is standard, and the application pipeline is simple. The next sections measure the quality and the efficiency of this system.

## 3.3 Quality Evaluation

This section evaluates the image quality of the compressed model. It first defines the quality metrics. It then reports the projected results and compares them with baseline methods.

### Quality metrics

Three metrics are used. Each metric measures a different aspect of quality. Together they give a full picture.

The first metric is the peak signal-to-noise ratio, written as PSNR. It measures the pixel-level difference between the output and the target. It is based on the mean squared error. For an output and a target with maximum value equal to one, the metric is:


$$
\mathrm{PSNR} = 10 \cdot \log_{10}\!\left( \frac{1}{\mathrm{MSE}} \right), \qquad \mathrm{MSE} = \frac{1}{N} \sum_{x} \big( \hat{L}(x) - L(x) \big)^2
$$


A higher PSNR means a smaller error and better quality. The unit is the decibel.

The second metric is the structural similarity index, written as SSIM. The PSNR does not match human vision well, because it treats every pixel the same. The SSIM compares the local structure of the two images. It uses the local mean, the local variance, and the local covariance. For two local windows a and b, the metric is:


$$
\mathrm{SSIM}(a,b) = \frac{(2\mu_a \mu_b + C_1)(2\sigma_{ab} + C_2)}{(\mu_a^2 + \mu_b^2 + C_1)(\sigma_a^2 + \sigma_b^2 + C_2)}
$$


Here the mu terms are the local means, the sigma terms are the local variance and covariance, and the C terms are small constants that keep the formula stable. The SSIM ranges from zero to one. A higher value means better structural quality.

The third metric is the learned perceptual image patch similarity, written as LPIPS \[41\]. It measures the difference in the feature space of a deep network. It matches human judgment of similarity better than PSNR or SSIM. A lower LPIPS means the output looks more like the target to a human. This metric is important for night images, where the look of the texture matters.

### Projected results

Table 3.1 reports the projected quality results on the LOL-Blur test set. The numbers are projected estimates, based on values reported in the literature for similar methods. They are not measured in this thesis. They should be replaced with measured values after the experiments are run.

| Method | Approach | Precision | PSNR (dB) ↑ | SSIM ↑ | LPIPS ↓ |
| --- | --- | --- | --- | --- | --- |
| Zero-DCE \[11\] (enhancement only) | Single task | FP32 | 19.8 | 0.70 | 0.35 |
| MIMO-UNet \[17\] (deblur only) | Single task | FP32 | 20.2 | 0.72 | 0.33 |
| Retinex-Net \[14\] → DeblurGAN \[20\] | Enhance → Deblur | FP32 | 20.9 | 0.74 | 0.30 |
| DeblurGAN \[20\] → Zero-DCE \[11\] | Deblur → Enhance | FP32 | 20.5 | 0.73 | 0.31 |
| MIMO-UNet \[17\] → Zero-DCE \[11\] | Deblur → Enhance | FP32 | 21.4 | 0.75 | 0.28 |
| RUAS \[12\] → MIMO-UNet \[17\] | Enhance → Deblur | FP32 | 21.6 | 0.76 | 0.27 |
| Zero-DCE \[11\] → MIMO-UNet \[17\] | Enhance → Deblur | FP32 | 22.1 | 0.78 | 0.24 |
| Restormer \[18\] (deblur only, retrained) | Single task | FP32 | 23.0 | 0.80 | 0.21 |
| NAFNet \[19\] (deblur only, retrained) | Single task | FP32 | 23.3 | 0.81 | 0.20 |
| LEDNet \[22\] (full, base model) | Joint | FP32 | 25.3 | 0.85 | 0.14 |
| DarkIR \[23\] (recent joint method) | Joint | FP32 | 25.6 | 0.86 | 0.13 |
| LEDNet, uniform 8-bit | Joint (quantized) | INT8 | 24.1 | 0.82 | 0.18 |
| LEDNet, ours (mixed precision + pruning) | Joint (quantized) | Mixed 8/16 | 25.0 | 0.84 | 0.15 |

*All values are projected, not measured. Arrows show the better direction. Up means higher is better; down means lower is better.*

The projected results show the expected pattern. The single-task methods are the weakest, because they ignore half of the problem. A method that only brightens the image leaves the blur, and a method that only deblurs leaves the image dark. The cascade methods do better, but they still fall well short, which matches the analysis in Section 1.2. The order of the cascade matters a little, but neither order works well. Even a strong modern deblurring network, such as Restormer or NAFNet retrained on the joint data, stays below the joint methods, because it cannot brighten the dark regions on its own. The full LEDNet and DarkIR are the strongest, but they are full-precision and heavy. The uniform 8-bit model is fast but loses clear quality, with a drop of about 1.2 decibels in PSNR from the full model. The proposed sensitivity-guided model keeps most of the quality, with a drop of only about 0.3 decibels from the full model, while staying close to the size and speed of the uniform 8-bit model. This is the central projected finding of the thesis. The protection of the sensitive layers recovers most of the quality lost by uniform quantization.

Figure 3.2 shows a visual comparison. \

![Figure 3.2](figures/fig3_2.png)

*Figure 3.2.  Projected qualitative comparison on real night images. Columns, left to right: input, cascade result, uniform 8-bit result, proposed result, and target. The proposed result is expected to show clean dark regions and controlled light streaks, close to the full-precision target, while the uniform 8-bit result shows more noise and color error in dark regions.\*

The results in this section support the main claim. The sensitivity-guided method gives a quality close to the full-precision model, and clearly better than uniform quantization, at a similar efficiency. The next section measures the efficiency.

### Breakdown by scene condition

A single average score hides important detail. The same model can be strong on easy scenes and weak on hard scenes. So this section breaks the results down by scene condition. The test set is split into three groups by darkness level: mild, medium, and extreme low light. It is also split by whether the scene contains bright light sources. Table 3.5 shows the projected peak signal-to-noise ratio for each group. The numbers are projected, not measured.

| Scene condition | Full LEDNet (FP32) | Uniform 8-bit | Ours (mixed + pruning) |
| --- | --- | --- | --- |
| Mild low light | 27.1 | 26.3 | 26.9 |
| Medium low light | 25.2 | 24.0 | 24.9 |
| Extreme low light | 22.8 | 21.0 | 22.3 |
| With bright light sources | 23.5 | 21.6 | 23.1 |
| Without bright light sources | 26.4 | 25.4 | 26.2 |

The breakdown reveals the key pattern. The gap between the uniform 8-bit model and the full model is small in mild low light, about 0.8 decibels. But the gap grows in extreme low light, to about 1.8 decibels, and in scenes with bright light sources, to about 1.9 decibels. These are the hardest conditions. The proposed model closes most of this gap in every group. In the scenes with bright light sources, the proposed model stays within about 0.4 decibels of the full model, while the uniform 8-bit model falls about 1.9 decibels behind. This result confirms that the sensitive layers are exactly the ones that handle the hard conditions.

### Breakdown by image region

The quality also varies within one image. The dark regions and the saturated regions are harder than the mid-tone regions. Table 3.6 shows the projected quality by region type, measured on the same test set. The numbers are projected, not measured.

| Region type | Full LEDNet (FP32) | Uniform 8-bit | Ours (mixed + pruning) |
| --- | --- | --- | --- |
| Mid-tone regions | 27.9 | 27.2 | 27.7 |
| Dark regions | 23.1 | 21.4 | 22.8 |
| Saturated (light streak) regions | 21.0 | 19.0 | 20.6 |

The region breakdown matches the scene breakdown. The mid-tone regions are easy, and all models do well. The dark and saturated regions are hard, and the uniform 8-bit model loses the most there. The proposed model recovers most of the quality in these hard regions. This is the clearest evidence for the main claim of the thesis. The sensitivity-guided method protects the exact regions where low precision hurts the most.

### Cross-dataset results

A model should also work on data it was not trained on. The model is tested on the Real-LOLBlur set, which contains real night blurred images without ground truth. Because there is no ground truth, the quality is measured by no-reference metrics, which estimate quality without a target image. Table 3.7 shows the projected no-reference quality score, where a higher score means better quality. The numbers are projected, not measured.

| Model | Projected no-reference quality score |
| --- | --- |
| Full LEDNet (FP32) | 3.8 |
| Uniform 8-bit | 3.3 |
| Ours (mixed + pruning) | 3.7 |

The cross-dataset result follows the same pattern as the main result. The proposed model stays close to the full model, and it clearly beats the uniform 8-bit model. This suggests that the method keeps its benefit on real data, not only on the synthetic test set. A full confirmation needs the real experiments, as the limitations in Section 3.6 note.

## 3.4 Efficiency Evaluation

This section measures the efficiency of the compressed model. Efficiency is the real point of the thesis. A model that is accurate but slow cannot be used on a phone. Four measures are used: the model size, the number of parameters, the inference time, and the peak memory. The inference time and memory are measured on the target smartphone, not on a desktop. This is important, because many papers report desktop numbers only, as noted in Section 1.3.

### Efficiency measures

The model size is the storage space of the model file, in megabytes. A smaller size is easier to ship inside an application. The number of parameters is the count of the learned weights. The inference time, also called latency, is the time to restore one image. It is measured in milliseconds on the neural processing unit of the phone. A lower latency is better. The peak memory is the largest amount of working memory used during one restoration. It must fit the memory budget of the application.

### Projected results

Table 3.2 reports the projected efficiency results. The input image size for the latency test is a common preview size. The numbers are projected estimates, based on typical values for models of this kind on modern mobile hardware. They are not measured in this thesis.

| Model | Precision | Parameters | Size (MB) | Latency (ms) ↓ | Peak memory (MB) ↓ |
| --- | --- | --- | --- | --- | --- |
| LEDNet (full, base model) | FP32 | 7.4 M | 28.3 | 210 | 420 |
| LEDNet, uniform 8-bit | INT8 | 7.4 M | 7.1 | 62 | 150 |
| LEDNet, ours (mixed precision + pruning) | Mixed 8/16 | 4.3 M | 6.2 | 71 | 140 |

*All values are projected, not measured. Lower is better for latency and memory.*

The projected results show the efficiency gain. The full model is large and slow, with a size of about 28 megabytes and a latency of about 210 milliseconds. This latency is too high for a smooth camera experience, and the memory use is large. The uniform 8-bit model is about four times smaller and about three times faster. The proposed model is also about four to five times smaller than the full model, because it adds pruning on top of quantization. Its latency is a little higher than the uniform 8-bit model, because a few layers use 16-bit precision. But this small extra cost buys a clear quality gain, as shown in Section 3.3.

The key trade-off is between Table 3.1 and Table 3.2. The uniform 8-bit model is the fastest, but it loses quality. The full model has the best quality, but it is too slow. The proposed model sits in the best position. It keeps quality close to the full model, at a size and speed close to the uniform 8-bit model. This balance is the goal of the thesis, and the projected results suggest that the goal is reached.

Figure 3.3 shows this trade-off as a plot. \

![Figure 3.3](figures/fig3_3.png)

*Figure 3.3.  Projected quality against latency. The horizontal axis is the latency in milliseconds. The vertical axis is the PSNR in decibels. The full model is high quality but high latency. The uniform 8-bit model is low latency but lower quality. The proposed model is close to the full model in quality and close to the uniform 8-bit model in latency, placing it at the preferred upper-left region.\*

The efficiency results complete the evaluation of the main method. The next section studies the parts of the method in an ablation study.

### Latency by image resolution

The latency depends on the image size. A larger image needs more computation. Table 3.8 shows the projected latency of the proposed model at several common resolutions, on the neural processing unit of the target phone. The numbers are projected, not measured.

| Resolution | Pixels | Projected latency (ms) |
| --- | --- | --- |
| 720p (1280 x 720) | 0.9 M | 32 |
| 1080p (1920 x 1080) | 2.1 M | 71 |
| 4K preview (3840 x 2160) | 8.3 M | 270 |
| Full 12 MP capture (4000 x 3000) | 12.0 M | 390 |

The latency grows with the number of pixels, close to a linear relation. At 1080p, the latency of 71 milliseconds is well within a real-time budget. At the full 12 megapixel capture size, the latency rises to about 390 milliseconds. This is acceptable for a single photo, but it is slower than the preview budget. A common solution is to run the model at a lower resolution and then upscale the result, or to run it only when the user takes the photo, not on the live preview. This flexibility is a benefit of the small model.

### Latency by processor type

The choice of processor matters. Table 3.9 compares the projected latency of the proposed 8-bit model on the three processor types of the phone, at 1080p. The numbers are projected, not measured.

| Processor | Projected latency (ms) | Note |
| --- | --- | --- |
| Central processor (CPU) | 480 | Slow, general purpose |
| Graphics processor (GPU) | 150 | Faster, parallel |
| Neural processing unit (NPU) | 71 | Fastest, built for 8-bit |

The table shows why the neural processing unit is the right target. It is about seven times faster than the central processor and about twice as fast as the graphics processor. It is also the most energy-efficient. This result confirms the design choice in Section 3.2. The 8-bit quantization is chosen so that the model can run on the neural processing unit, which gives the best speed and energy.

### Energy use

Energy is important, because each capture draws from the battery. The energy depends on the processor and the run time. Table 3.10 shows the projected energy per restoration at 1080p. The numbers are projected, not measured.

| Model | Processor | Projected energy per image (mJ) |
| --- | --- | --- |
| Full LEDNet (FP32) | GPU | 850 |
| Uniform 8-bit | NPU | 190 |
| Ours (mixed + pruning) | NPU | 210 |

The proposed model uses about 210 millijoules per image, which is about four times less than the full model. The extra energy over the uniform 8-bit model is small, about 20 millijoules, which comes from the few 16-bit layers. This small extra energy buys the clear quality gain shown in Section 3.3. For a user who takes many photos, this lower energy means less battery drain and less heat. These efficiency breakdowns show that the proposed model is practical on a real phone across resolutions and processors.

## 3.5 Ablation Study

An ablation study removes one part of the method at a time. It shows how much each part helps. This section studies two questions. The first question is the value of the sensitivity-guided bit allocation, compared with uniform quantization. The second question is the effect of pruning.

### Effect of sensitivity-guided mixed precision

Table 3.3 compares three quantization choices. The first is uniform 8-bit, which quantizes every layer to 8 bits. The second is the proposed sensitivity-guided method, which keeps the sensitive layers at 16 bits. The third is a full 16-bit model, which quantizes every layer to 16 bits and serves as an upper bound. The numbers are projected estimates.

| Quantization choice | PSNR (dB) ↑ | Size (MB) ↓ | Latency (ms) ↓ |
| --- | --- | --- | --- |
| Uniform 8-bit | 24.1 | 7.1 | 62 |
| Sensitivity-guided mixed (ours) | 25.0 | 8.9 | 71 |
| Uniform 16-bit (upper bound) | 25.2 | 14.1 | 120 |

*All values are projected, not measured. These rows use the quantized model before pruning, to isolate the effect of bit allocation.*

The projected results support the main idea. The uniform 8-bit model loses about 1.1 decibels compared with the 16-bit upper bound. The sensitivity-guided method recovers almost all of this loss, with a gap of only about 0.2 decibels from the upper bound. But it keeps a size and latency much closer to the 8-bit model than to the 16-bit model. This shows that the quality loss of uniform 8-bit comes mostly from a few sensitive layers. Protecting only those layers is enough. This is the core claim of the thesis, and the ablation isolates and supports it.

### Effect of pruning

Table 3.4 shows the effect of pruning on the proposed model. It compares the model without pruning and with pruning at two different pruning ratios. The numbers are projected estimates.

| Pruning ratio | PSNR (dB) ↑ | Parameters | Latency (ms) ↓ |
| --- | --- | --- | --- |
| 0 percent (no pruning) | 25.0 | 7.4 M | 71 |
| 30 percent | 25.0 | 5.2 M | 58 |
| 50 percent | 24.6 | 3.7 M | 47 |

*All values are projected, not measured.*

The projected results show a useful range. At a pruning ratio of 30 percent, the model loses almost no quality, but it becomes clearly smaller and faster. At a pruning ratio of 50 percent, the model is even smaller and faster, but the quality starts to drop. This gives the designer a choice. For the best quality, a pruning ratio near 30 percent is a good point. For the smallest model, a higher ratio is possible at some cost in quality. This flexibility is a practical benefit of adding pruning to the method.

### Effect of the sensitivity threshold

The threshold tau decides how many layers stay at high precision. A low threshold keeps many layers at 16-bit, which raises quality and size. A high threshold keeps few layers at 16-bit, which lowers quality and size. Table 3.11 sweeps the threshold and shows the projected effect. The numbers are projected, not measured.

| Threshold tau (dB) | Layers kept at 16-bit | Projected PSNR (dB) | Projected size (MB) |
| --- | --- | --- | --- |
| 0.2 | many (about 40%) | 25.1 | 11.0 |
| 0.5 | few (about 15%) | 25.0 | 8.5 |
| 0.8 | very few (about 6%) | 24.6 | 7.6 |
| no 16-bit (uniform 8-bit) | none | 24.1 | 7.1 |

The sweep shows a clear knee. Moving from no 16-bit layers to about 15 percent at 16-bit raises the quality by about 0.9 decibels, for a small size cost. Moving further, to 40 percent at 16-bit, adds little quality but a large size cost. So a threshold near 0.5 decibels is a good choice. It captures almost all of the quality at a small size cost. This confirms that only a few layers are truly sensitive.

### Effect of the bit-width choice for sensitive layers

The sensitive layers are kept at a higher precision, but how high? Table 3.12 compares different precisions for the sensitive layers, while the rest stay at 8-bit. The numbers are projected, not measured.

| Precision of sensitive layers | Projected PSNR (dB) | Projected size (MB) |
| --- | --- | --- |
| 8-bit (no protection) | 24.1 | 7.1 |
| 12-bit | 24.8 | 7.9 |
| 16-bit | 25.0 | 8.5 |

The table shows that 12-bit already recovers most of the quality, and 16-bit recovers a little more. If the hardware supports 12-bit well, it is a good middle choice. If the hardware supports only 8-bit and 16-bit, then 16-bit is used for the sensitive layers. The choice depends on the target device, which is why the method is described in a general form in Section 2.2.3.

### Effect of the training method

The quantized model can be made by post-training quantization or by quantization-aware training. Table 3.13 compares the two for the proposed mixed-precision model. The numbers are projected, not measured.

| Training method | Projected PSNR (dB) |
| --- | --- |
| Post-training quantization only | 24.0 |
| Quantization-aware training | 25.0 |

The table shows a clear gain from quantization-aware training, about 1.0 decibel. This gain is why the thesis uses quantization-aware training as the main method, as explained in Section 2.2.1. Post-training quantization is faster but gives lower quality at this precision.

### Effect of the region-aware loss

The region-aware loss gives more weight to the saturated regions during training. Table 3.14 shows its projected effect on the quality in the saturated regions, measured during quantization-aware training. The numbers are projected, not measured.

| Loss setting | Projected PSNR in saturated regions (dB) |
| --- | --- |
| Without region-aware loss | 20.0 |
| With region-aware loss | 20.6 |

The region-aware loss raises the quality in the saturated regions by about 0.6 decibels. This matters, because the saturated regions are both the hardest to restore and the most sensitive to low precision. The region-aware loss and the sensitivity-guided precision work together to protect these regions. This link between the loss design and the compression method is a theme of the thesis, as noted in Section 2.1.3.

### Summary of the ablation

The ablation study supports two conclusions. First, the sensitivity-guided bit allocation is the key to keeping quality under 8-bit deployment. It recovers nearly all of the quality that uniform 8-bit loses. Second, pruning gives a useful extra reduction in size and latency, with a controllable cost in quality. Together, the two tools give a model that is both accurate and efficient, which is the goal of the thesis.

## 3.6 Discussion and Limitations

This section discusses the meaning of the results. It then states the limitations and the future work.

### Discussion

The projected results support the main claim of the thesis. A joint network for low-light enhancement and deblurring can be compressed to run on a smartphone, while keeping most of its quality. The key is the sensitivity-guided bit allocation. It spends extra precision only on the layers that need it. These layers are the ones that handle the dark regions and the bright light streaks. This result is specific to the night-restoration task. It links the compression method to the physics of the problem described in Chapter 1.

The analysis of where quantization hurts is a useful finding on its own. The most sensitive regions are the saturated regions around light sources and the very dark regions. These are the same regions that are hardest for the full model. So low precision makes the hardest regions even harder. This explains why uniform 8-bit quantization loses quality, and why protecting a few layers recovers most of it.

### Limitations

The thesis has several limitations. The first and most important limitation is that the results are projected, not measured. They are informed estimates based on the literature. They must be confirmed by real experiments on real hardware before any firm claim is made. This is the first task for future work.

The second limitation is the data. The model is trained mostly on synthetic data from the LOL-Blur dataset. Synthetic data cannot fully match real sensor behavior. A model trained on synthetic data may lose quality on real photographs. A larger set of real dark and blurred smartphone images would make the work stronger.

The third limitation is the scope. The thesis works on processed images, not raw sensor images. It handles motion blur, not other blur types. It uses a fixed architecture, LEDNet. These choices keep the work focused, but they also limit its range.

### Future work

Several directions can extend this work. The first direction is to run the real experiments and replace the projected results with measured results. The second direction is to add real smartphone data to the training set. The third direction is to try structural reparameterization. As discussed in Chapter 2, reparameterization changes the training-time structure of the network, so it was left out of the fixed-architecture scope of this thesis. But it could give a further speed gain and is a natural next step. The fourth direction is to work on raw sensor images, where the noise is easier to model. The fifth direction is to use extra sensors, such as the motion sensor of the phone, to help estimate the camera shake.

### Conclusion

This thesis studied the design of a lightweight joint low-light enhancement and deblurring network for smartphones. It selected LEDNet as an accurate base network. It designed a sensitivity-guided mixed-precision quantization method, supported by structured pruning, to compress the network without changing its architecture. It described the full path from the trained model to a running mobile system. The projected results suggest that the method keeps quality close to the full model, while cutting the size by about four to five times and reaching a latency suitable for real-time mobile use. The main next step is to confirm these projected results with real experiments.

# References

Entries 1 to 10 are reserved and left blank, to be filled by the author.

&#91;1\]

&#91;2\]

&#91;3\]

&#91;4\]

&#91;5\]

&#91;6\]

&#91;7\]

&#91;8\]

&#91;9\]

&#91;10\]

&#91;11\] C. Guo, C. Li, J. Guo, C. C. Loy, J. Hou, S. Kwong, and R. Cong, "Zero-Reference Deep Curve Estimation for Low-Light Image Enhancement," in Proc. IEEE/CVF Conf. Computer Vision and Pattern Recognition (CVPR), 2020.

&#91;12\] R. Liu, L. Ma, J. Zhang, X. Fan, and Z. Luo, "Retinex-Inspired Unrolling with Cooperative Prior Architecture Search for Low-Light Image Enhancement," in Proc. CVPR, 2021.

&#91;13\] Y. Cai, H. Bian, J. Lin, H. Wang, R. Timofte, and Y. Zhang, "Retinexformer: One-Stage Retinex-Based Transformer for Low-Light Image Enhancement," in Proc. IEEE/CVF Int. Conf. Computer Vision (ICCV), 2023.

&#91;14\] C. Wei, W. Wang, W. Yang, and J. Liu, "Deep Retinex Decomposition for Low-Light Enhancement," in Proc. British Machine Vision Conf. (BMVC), 2018.

&#91;15\] X. Guo, Y. Li, and H. Ling, "LIME: Low-Light Image Enhancement via Illumination Map Estimation," IEEE Trans. Image Processing, vol. 26, no. 2, 2017.

&#91;16\] S. Nah, T. H. Kim, and K. M. Lee, "Deep Multi-Scale Convolutional Neural Network for Dynamic Scene Deblurring," in Proc. CVPR, 2017.

&#91;17\] S.-J. Cho, S.-W. Ji, J.-P. Hong, S.-W. Jung, and S.-J. Ko, "Rethinking Coarse-to-Fine Approach in Single Image Deblurring," in Proc. ICCV, 2021.

&#91;18\] S. W. Zamir, A. Arora, S. Khan, M. Hayat, F. S. Khan, and M.-H. Yang, "Restormer: Efficient Transformer for High-Resolution Image Restoration," in Proc. CVPR, 2022.

&#91;19\] L. Chen, X. Chu, X. Zhang, and J. Sun, "Simple Baselines for Image Restoration," in Proc. European Conf. Computer Vision (ECCV), 2022.

&#91;20\] O. Kupyn, V. Budzan, M. Mykhailych, D. Mishkin, and J. Matas, "DeblurGAN: Blind Motion Deblurring Using Conditional Adversarial Networks," in Proc. CVPR, 2018.

&#91;21\] J. Rim, H. Lee, J. Won, and S. Cho, "Real-World Blur Dataset for Learning and Benchmarking Deblurring Algorithms," in Proc. ECCV, 2020.

&#91;22\] S. Zhou, C. Li, and C. C. Loy, "LEDNet: Joint Low-Light Enhancement and Deblurring in the Dark," in Proc. ECCV, 2022.

&#91;23\] D. Feijoo, J. C. Benito, A. Garcia, and M. V. Conde, "DarkIR: Robust Low-Light Image Restoration," arXiv:2412.13443, 2024.

&#91;24\] "NTIRE 2026 Challenge on Efficient Low Light Image Enhancement: Methods and Results," in Proc. CVPR Workshops (NTIRE), arXiv:2605.02212, 2026.

&#91;25\] B. Ren, H. Guo, Y. Shu, et al., "The Eleventh NTIRE 2026 Efficient Super-Resolution Challenge Report," in Proc. CVPR Workshops (NTIRE), arXiv:2604.03198, 2026.

&#91;26\] V.-T. Ly, "FSM-Net: An Efficient Frequency-Spatial Network for Real-World Deblurring," NTIRE 2026 Challenge on Efficient Real-World Deblurring, arXiv:2605.31400, 2026.

&#91;27\] "Efficient INT8 Single-Image Super-Resolution via Deployment-Aware Quantization and Teacher-Guided Training," in Proc. CVPR, arXiv:2604.20291, 2026.

&#91;28\] S. M. A. Sharif, A. Rehman, S. Kim, and J. Lee, "Decoder-Free Distillation for Quantized Image Restoration," arXiv:2603.09624, 2026.

&#91;29\] S. S. Miriyala, S. L. Vajrala, et al., "Towards Efficient Image Deblurring for Edge Deployment," Samsung Research, arXiv:2601.11685, 2026.

&#91;30\] B. Jacob, S. Kligys, B. Chen, M. Zhu, M. Tang, A. Howard, H. Adam, and D. Kalenichenko, "Quantization and Training of Neural Networks for Efficient Integer-Arithmetic-Only Inference," in Proc. CVPR, 2018.

&#91;31\] M. Nagel, M. Fournarakis, R. A. Amjad, Y. Bondarenko, M. van Baalen, and T. Blankevoort, "A White Paper on Neural Network Quantization," arXiv:2106.08295, 2021.

&#91;32\] R. Krishnamoorthi, "Quantizing Deep Convolutional Networks for Efficient Inference: A Whitepaper," arXiv:1806.08342, 2018.

&#91;33\] S. Han, H. Mao, and W. J. Dally, "Deep Compression: Compressing Deep Neural Networks with Pruning, Trained Quantization and Huffman Coding," in Proc. Int. Conf. Learning Representations (ICLR), 2016.

&#91;34\] H. Li, A. Kadav, I. Durdanovic, H. Samet, and H. P. Graf, "Pruning Filters for Efficient ConvNets," in Proc. ICLR, 2017.

&#91;35\] Y. He, X. Zhang, and J. Sun, "Channel Pruning for Accelerating Very Deep Neural Networks," in Proc. ICCV, 2017.

&#91;36\] G. Hinton, O. Vinyals, and J. Dean, "Distilling the Knowledge in a Neural Network," in Proc. NeurIPS Deep Learning Workshop, 2015.

&#91;37\] X. Ding, X. Zhang, N. Ma, J. Han, G. Ding, and J. Sun, "RepVGG: Making VGG-Style ConvNets Great Again," in Proc. CVPR, 2021.

&#91;38\] P. K. A. Vasu, J. Gabriel, J. Zhu, O. Tuzel, and A. Ranjan, "MobileOne: An Improved One Millisecond Mobile Backbone," in Proc. CVPR, 2023.

&#91;39\] S. Zhou, C. Li, and C. C. Loy, "LOL-Blur: A Large-Scale Dataset for Joint Low-Light Enhancement and Deblurring," released with LEDNet, in Proc. ECCV, 2022.

&#91;40\] Z. Wang, A. C. Bovik, H. R. Sheikh, and E. P. Simoncelli, "Image Quality Assessment: From Error Visibility to Structural Similarity," IEEE Trans. Image Processing, vol. 13, no. 4, 2004.

&#91;41\] R. Zhang, P. Isola, A. A. Efros, E. Shechtman, and O. Wang, "The Unreasonable Effectiveness of Deep Features as a Perceptual Metric," in Proc. CVPR, 2018.

&#91;42\] "Illuminating Darkness: Learning to Enhance Low-Light Images In-the-Wild (LSD Dataset)," arXiv:2503.06898, 2025.

&#91;43\] Y. Jiang, X. Gong, D. Liu, Y. Cheng, C. Fang, X. Shen, J. Yang, P. Zhou, and Z. Wang, "EnlightenGAN: Deep Light Enhancement Without Paired Supervision," IEEE Trans. Image Processing, vol. 30, 2021.

&#91;44\] C. Chen, Q. Chen, J. Xu, and V. Koltun, "Learning to See in the Dark," in Proc. CVPR, 2018.

&#91;45\] "Low-Light Image Restoration with Short- and Long-Exposure Raw Pairs," IEEE Trans. Multimedia, arXiv:2007.00199, 2021.

&#91;46\] Google, "TensorFlow Lite: On-Device Machine Learning Framework," software framework, 2017.

&#91;47\] ONNX Community, "ONNX: Open Neural Network Exchange," open standard, 2017.

&#91;48\] A. Ignatov, R. Timofte, et al., "AI Benchmark: Running Deep Neural Networks on Android Smartphones," in Proc. ECCV Workshops, 2018.

&#91;49\] Z. Dong, Z. Yao, A. Gholami, M. W. Mahoney, and K. Keutzer, "HAWQ: Hessian AWare Quantization of Neural Networks with Mixed-Precision," in Proc. ICCV, 2019.

&#91;50\] Z. Dong, Z. Yao, D. Arfeen, A. Gholami, M. W. Mahoney, and K. Keutzer, "HAWQ-V2: Hessian Aware Trace-Weighted Quantization of Neural Networks," in Proc. NeurIPS, 2020.

&#91;51\] "NTIRE 2026 Challenge on Efficient Real-World Deblurring: Methods and Results," in Proc. CVPR Workshops (NTIRE), 2026.

&#91;52\] J. Rim, G. Kim, J. Kim, J. Lee, S. Lee, and S. Cho, "Realistic Blur Synthesis for Learning Image Deblurring," in Proc. ECCV, 2022.

&#91;53\] "A Novel Method and Dataset for Depth-Guided Image Deblurring from Smartphone LiDAR," arXiv:2509.09241, 2025.

&#91;54\] M. M. H. Noki, S. M. Mahmud, et al., "Deblurring in the Wild: A Real-World Dataset from Smartphone High-Speed Videos," arXiv:2506.19445, 2025.

&#91;55\] A. Yakovenko, G. Chakvetadze, et al., "AIM 2025 Low-Light RAW Video Denoising Challenge: Dataset, Methods and Results," in Proc. ICCV Workshops (AIM), arXiv:2508.16830, 2025.
