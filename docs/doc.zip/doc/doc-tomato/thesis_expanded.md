---
title: "A Two-Stage Deep-Learning Framework for Forecasting Pests and Diseases in Greenhouse Tomato Cultivation: Improved YOLOv8 Lesion Detection and Data-Efficient Vision-Transformer Pest Classification via Two-Phase Transfer Learning"
author: "[Author Name]  \n[Department / Laboratory]  \n[University]"
date: "[Month Year]"
abstract: |
  Greenhouse tomato production is chronically threatened by pests and foliar diseases whose early, accurate identification is essential for timely intervention and reduced agrochemical use. This thesis proposes a two-stage visual framework that mirrors how a human scout actually works: first locating suspicious regions across the canopy from a distance, then inspecting them closely to name the causal agent. In the first stage, an *improved YOLOv8* detector locates candidate diseased or infested regions in wide-field ("distant") canopy images. Because such regions are small and low-contrast at distance, the detector is augmented with a high-resolution P2 detection branch and a lightweight Coordinate Attention module, two changes targeted specifically at small-lesion sensitivity. In the second stage, the detected regions are re-imaged at close range and classified by a *Vision Transformer adapted through two-phase transfer learning*. To overcome the data-hungry nature of transformers on a modest agricultural dataset, the classifier is initialised from a strong pretrained model and adapted with a disciplined two-phase fine-tuning schedule—linear probing followed by layer-wise-decayed full fine-tuning—rather than trained from scratch. The detection and classification outputs are aggregated over space and time to drive a simple early-warning module. The proposed components are described in detail and evaluated against representative prior models for both stages, with ablation studies isolating the contribution of each modification. *(Experimental values reported here are illustrative placeholders pending the author's measured results.)*
---

\newpage

# Chapter 1 — Introduction and Review of Prior Studies

## 1.1 Background and Motivation

Tomato (*Solanum lycopersicum*) is among the most economically important greenhouse vegetables worldwide, valued for its yield density, year-round production potential, and nutritional importance. Protected cultivation—greenhouses and plastic tunnels—raises productivity per unit area but also creates a warm, humid, and densely planted micro-environment in which pests and pathogens spread rapidly. Outbreaks of whitefly, aphids, leafminers, spider mites, and thrips, together with foliar diseases such as early blight, late blight, leaf mould, and bacterial spot, can each cause substantial yield loss when detected late. Because pest and disease pressure compounds over time, the practical value of any monitoring system lies less in a single snapshot diagnosis than in the ability to detect emerging problems early and to forecast their development so that growers can intervene before damage becomes severe.

Conventional monitoring relies on periodic manual scouting, in which trained personnel walk the rows and visually inspect plants. This approach is labour-intensive, subjective, and difficult to scale; symptoms are easily missed in their early stages, and the interval between inspections allows infestations to escalate. These limitations have motivated a long line of research into automated, image-based detection and classification of plant pests and diseases [27], and more recently into systems that close the loop between sensing and decision-making for sustainable, reduced-chemical crop protection [33].

The central premise of this thesis is that effective forecasting of greenhouse pests and diseases requires two complementary visual capabilities operating at different spatial scales. At the canopy scale, the system must *locate* where something is wrong—efficiently scanning large areas and flagging candidate regions even when symptoms are small and inconspicuous. At the organ scale, the system must *identify* what the problem is—distinguishing among visually similar pests and diseases from close-up imagery. These two tasks have different statistical structures, different failure modes, and are best served by different model families: a fast one-stage object detector for the first, and a high-capacity fine-grained classifier for the second.

## 1.2 Limitations of Traditional Detection and Classification Methods

Early computer-vision approaches to plant protection relied on hand-crafted features—colour histograms, texture descriptors such as the grey-level co-occurrence matrix, and keypoint descriptors such as SIFT and SURF—coupled with classical classifiers such as support-vector machines, k-nearest neighbours, or random forests [13]. While these pipelines achieved reasonable accuracy under controlled laboratory conditions, their performance degraded sharply under the variable illumination, occlusion, cluttered backgrounds, and scale variation that characterise real greenhouse imagery. The features were brittle: a descriptor tuned for one lighting condition or one cultivar often failed to transfer, and the separation of feature engineering from classification prevented end-to-end optimisation.

The advent of deep convolutional neural networks (CNNs) addressed many of these problems by learning hierarchical features directly from data [30; 32; 18]. CNN-based classifiers trained on large image collections such as the PlantVillage repository [26] demonstrated that disease recognition could be automated at high accuracy [27]. However, two gaps remained for greenhouse deployment. First, image-level classifiers presuppose that the diseased region has already been isolated; they do not, by themselves, find lesions within a wide canopy view. Second, accuracy reported on curated, single-leaf datasets often overstated field performance, because real images contain multiple overlapping leaves, distant small symptoms, and confounding background [28].

### 1.2.1 Greenhouse-Specific Imaging Challenges

Several characteristics of the greenhouse environment make automated visual monitoring harder than the curated benchmarks on which many published models are tuned, and they shape the design decisions taken later in this thesis. Lighting is highly variable: natural daylight through glazing mixes with supplementary artificial lighting, producing strong gradients, specular highlights on glossy leaves, and shifting colour temperature over the day. The canopy is dense and self-occluding, so a symptom may be partly hidden behind overlapping leaves, and the same plant part appears at many orientations. Scale varies enormously between the wide-field view used to scan the canopy and the close-up view needed to read fine detail, which is precisely why a single fixed-scale model is poorly suited to the whole task. Physical factors—camera vibration, condensation, and dust on lenses—further degrade image quality. Finally, the data are intrinsically imbalanced and long-tailed: common pests dominate while economically important but rarer problems are scarce, and the distribution of a specific greenhouse differs from that of any public dataset, creating a domain-shift gap between training and deployment. Each of these factors is revisited in the methodology: scale variation motivates the two-stage design and the P2 branch (Chapter 2), lighting and clutter motivate Coordinate Attention, and data scarcity and imbalance motivate the transfer-learning-based classifier.

## 1.3 Evolution of Object Detection

Object detection—jointly localising and classifying objects—provides the missing capability of finding lesions within a scene. The modern literature divides into two broad families.

**Two-stage detectors.** The region-based CNN (R-CNN) family first generates candidate regions and then classifies each region. R-CNN [8] established the paradigm; Fast R-CNN [9] and Faster R-CNN [10] progressively integrated the stages and introduced a learnable region-proposal network, greatly improving speed and accuracy. Feature Pyramid Networks (FPN) [12] further improved multi-scale detection by fusing features across resolutions. Two-stage detectors remain accurate, particularly for small objects, but their computational cost limits real-time use.

**One-stage detectors.** Single-shot methods frame detection as direct regression over a dense set of locations, predicting boxes and class scores in one forward pass. SSD [11] and RetinaNet (with its focal-loss remedy for foreground–background imbalance [13]) are prominent examples. The You Only Look Once (YOLO) family [1] popularised real-time detection by reformulating the task as a single regression problem over a grid. Successive versions—YOLO9000 [2], YOLOv3 [3], YOLOv4 [4], YOLOv5 [5], YOLOv7 [6], and YOLOv8 [7]—steadily improved the speed–accuracy trade-off through better backbones, multi-scale feature aggregation, anchor-free heads, and refined training recipes [41; 42]. YOLOX [48] notably introduced the anchor-free, decoupled head that YOLOv8 later refined.

**Transformer-based detectors.** More recently, the Transformer architecture [14] has entered detection. DETR [25] reformulated detection as set prediction with a transformer encoder–decoder, removing hand-designed components such as non-maximum suppression, while hierarchical vision transformers such as Swin [24] provided strong detection backbones. These models are powerful but typically heavier and more data-hungry than the YOLO family, which remains the pragmatic choice for real-time, edge-deployable agricultural monitoring.

Within this landscape, **YOLOv8** is an attractive base detector for the first stage of our system. Released by Ultralytics in 2023, it is a single-stage, anchor-free, multi-scale detector built from a CSPDarknet-style backbone with C2f feature-aggregation modules, an SPPF block, a PAN-FPN neck, and a decoupled detection head trained with distribution-focal and CIoU losses [7; 26]. It offers an excellent speed–accuracy balance and a scalable family of model sizes suitable for edge hardware. Its principal weakness for our purpose is sensitivity to *small* objects: the default detection heads operate at strides of 8, 16, and 32 pixels, which is coarse for the tiny, low-contrast lesions seen in distant canopy images. This weakness directly motivates the improvements described in Chapter 2.

## 1.4 Image Classification and Vision Transformers for Fine-Grained Recognition

Once a candidate region is localised and re-imaged at close range, naming the specific pest or disease is a fine-grained classification problem, characterised by small inter-class differences (e.g., distinguishing whitefly from aphid damage) and large intra-class variation (e.g., the same pest at different life stages). CNNs such as ResNet [18], EfficientNet [19], and the mobile-efficient MobileNetV3 [20] are strong baselines for this task.

The Vision Transformer (ViT) [15] reframed image classification by splitting an image into fixed-size patches, embedding each patch as a token, prepending a learnable classification token, adding positional embeddings, and processing the sequence with a standard Transformer encoder [14]. ViT can match or exceed CNNs on large datasets and captures long-range dependencies that benefit fine-grained discrimination. Its weakness is a *lack of inductive bias*: because it does not assume locality or translation equivariance the way convolutions do, it requires very large training sets to reach its potential—an unrealistic requirement for a specialised agricultural dataset.

In practice this tension is resolved not by abandoning the transformer but by *transfer learning*: a model is first pre-trained on a large general-purpose corpus and then adapted to the target task with a comparatively small amount of in-domain data, so that the regularities ViT would otherwise have to learn from scratch are inherited from pre-training. The Data-efficient image Transformer (DeiT) [16] is a notable example of a transformer trained to be data-efficient, and it—or any strong pre-trained ViT—provides exactly the kind of initial weights a greenhouse pest classifier can build on. (Knowledge distillation [17], in which a compact student learns from a stronger teacher, is a further, complementary route to data efficiency; it is not pursued in this thesis but is noted as future work.) What matters most for a modest agricultural dataset is therefore *how* such a pre-trained model is fine-tuned, which directly motivates the classifier method in Chapter 2.

## 1.5 Related Work on Plant Pest and Disease Recognition

A large and growing body of work applies these architectures to plant protection. On the detection side, numerous studies adapt the YOLO family to tomato leaf disease. Improved YOLOv8 variants have been reported to raise mean average precision over the baseline by integrating attention mechanisms and better multi-scale fusion: examples include receptive-field-attention designs that replace the SPPF module and add adaptive spatial feature fusion [34], lightweight attention modules such as SimAM combined with dynamic convolution [35], and CBAM-style channel–spatial attention [21] integrated into YOLOv8 detection pipelines [36]. Comparative studies confirm that YOLOv8-based detectors outperform earlier YOLOv5 and Faster R-CNN baselines on tomato leaf datasets while sustaining real-time frame rates [36]. Multi-scale-fusion designs have specifically targeted the missed detection of small, densely clustered, or early-stage low-contrast symptoms [43], and optimisation-oriented studies have shown that careful choice of optimiser and training schedule yields consistent gains in precision, recall, and mAP for tomato leaf disease detection in sustainable-agriculture settings [33].

On the classification side, transformer and hybrid transformer–CNN models have become prominent. Vision transformers and refined ViT variants have been applied to plant-leaf disease classification with strong accuracy and the added benefit of attention-based localisation of infected regions [37]. Hybrid ViT–CNN designs and lightweight transformers have been proposed for real-time disease detection and pest classification, sometimes coupled with explainability methods such as Grad-CAM [44] and SHAP [45] to make predictions interpretable to growers [38]. Attention-score-based multi-transformer techniques have reported very high accuracy on apple, grape, and tomato leaf datasets, outperforming ResNet, VGG, and MobileNet baselines [39], and multi-stage transformer frameworks augmented with semantic knowledge have been used to scale classification across many disease categories [40]. For insect pests specifically, the large-scale IP102 benchmark [29]—over 75,000 images across 102 categories with a long-tailed distribution and roughly 19,000 detection-annotated images—has become a standard testbed for both classification and detection of agricultural pests.

## 1.6 Research Gap and Problem Statement

Three observations emerge from this review. First, most existing systems address *either* detection *or* classification in isolation, whereas effective greenhouse forecasting requires both, operating at different spatial scales. A single-stage classifier on whole-canopy images struggles with small symptoms and clutter; a detector alone produces coarse "diseased/not-diseased" boxes without the fine-grained pest identity needed to choose a treatment. Second, detectors applied to distant canopy imagery consistently under-perform on small, low-contrast lesions—the very symptoms that matter most for *early* warning. Third, transformer classifiers, although well suited to fine-grained pest identification, are data-hungry and tend to be trained from scratch or naively fine-tuned on small agricultural datasets, leaving their data-efficiency potential untapped.

The problem addressed by this thesis is therefore: *how to design a practical, accurate, and real-time-capable visual system that (i) reliably localises small, early-stage pest and disease symptoms across the greenhouse canopy, and (ii) identifies the specific causal agent from close-up imagery with high accuracy despite limited training data, in a form whose outputs can drive temporal forecasting and early warning.*

## 1.7 Purpose and Objectives

The purpose of this research is to develop and evaluate a two-stage detection-then-classification framework for forecasting pests and diseases in greenhouse tomatoes. The specific objectives are:

1. To design an improved YOLOv8 detector that increases sensitivity to small, low-contrast lesions in distant canopy images, through a high-resolution detection branch and a lightweight attention mechanism, while preserving real-time speed (Chapter 2, Section 1).
2. To design a data-efficient Vision Transformer classifier that achieves high fine-grained accuracy on a modest pest dataset, through transfer learning from a strong pre-trained model adapted with a principled two-phase fine-tuning schedule—linear probing followed by layer-wise-decayed full fine-tuning (Chapter 2, Section 2).
3. To integrate the two stages into a coherent system, with a sensing-to-decision data flow and a temporal aggregation module supporting early warning (Chapter 3).
4. To evaluate each stage rigorously against representative prior models, and to isolate the contribution of each proposed modification through ablation studies (Chapter 3).

## 1.8 Contributions

The principal contributions are: (1) a clearly motivated two-stage architecture matching model choice to spatial scale; (2) a small-lesion-oriented improvement of YOLOv8 combining a P2 detection branch with Coordinate Attention, described and ablated in detail; (3) a data-efficient ViT classifier obtained by transfer learning, using a two-phase linear-probe-then-fine-tune schedule with layer-wise learning-rate decay, analysed component by component; and (4) a comparative evaluation protocol against prior detection and classification models. The methodological emphasis throughout is on a small number of well-justified, clearly explained improvements rather than a large collection of incremental tricks.

## 1.9 Organisation of the Thesis

The remainder of the thesis is organised as follows. **Chapter 2** presents the methodology in two sections: Section 1 details the improved YOLOv8 lesion detector, and Section 2 details the transfer-learned ViT pest classifier. **Chapter 3** describes the system configuration, implementation, datasets, evaluation metrics, and the experimental comparison against prior models, including ablation studies, followed by discussion. The thesis closes with conclusions and directions for future work, and a list of references.

\newpage
# Chapter 2 — Methodology

This chapter presents the two-stage framework in detail. The overall pipeline is shown in Figure 1. A wide-field camera images the canopy; the improved YOLOv8 detector of Section 2.1 locates candidate diseased or infested regions. Each region guides the capture (or cropping) of a close-up image, which the transfer-learned Vision Transformer of Section 2.2 classifies into a specific pest or disease category. The classified detections are aggregated spatially and temporally to support forecasting, as described in Chapter 3.

![Two-stage greenhouse pest and disease forecasting pipeline. Stage 1 (detection) operates on distant canopy images; Stage 2 (classification) operates on close-up crops of the regions flagged by Stage 1.](figs/fig_pipeline.png)

A guiding design principle is restraint: rather than stacking many modifications, each stage introduces only a small number of changes, each chosen because it addresses a specific, well-understood weakness of the base model. Section 2.1 introduces two coupled changes to the detector (a high-resolution detection branch and a positional attention module) aimed at small-lesion sensitivity. Section 2.2 makes a single, well-justified change to the classifier—data-efficient transfer learning through a two-phase fine-tuning schedule—aimed at data efficiency. The reasoning behind each change is explained before its formulation.

## 2.1 Section 1 — Improved YOLOv8 for Lesion Detection in Distant Images

### 2.1.1 Base Detector and the Small-Object Problem

The base detector is YOLOv8 [7]. Architecturally it comprises three parts: a *backbone* (a CSPDarknet-derived network whose central building block is the C2f module, which splits the input, processes part of it through a series of lightweight bottlenecks, and concatenates all intermediate outputs to improve gradient flow and channel-information reuse); a *neck* (a path-aggregation feature-pyramid network, PAN-FPN, that fuses features top-down and bottom-up across scales); and a *decoupled, anchor-free head* that predicts, at each location, a class distribution and a bounding-box offset, the latter via a distribution-focal-loss (DFL) formulation, with CIoU used for box regression [7; 47]. Detection is performed at three pyramid levels, conventionally denoted P3, P4, and P5, corresponding to feature strides of 8, 16, and 32 pixels relative to the input.

The difficulty in our setting is one of *scale*. In a distant canopy image, an early-stage lesion or a small insect may occupy only a handful of pixels. The smallest YOLOv8 detection level, P3 at stride 8, assigns one feature-map cell to an 8×8 input region; objects smaller than this are poorly represented, because the spatial detail needed to localise and characterise them has already been pooled away by the time features reach P3. Empirically, this manifests as missed detections and imprecise boxes for exactly the small, early symptoms that an *early-warning* system most needs to catch. The two modifications below address this directly.

### 2.1.2 The YOLOv8 Network in Full

Before introducing the two targeted modifications, it is useful to see the complete detector as a single object, so that each change can be located precisely within it rather than described in isolation. Figure 2 shows the improved YOLOv8 network end to end, from the input image on the left to the four detection heads on the right; the standard YOLOv8 data path is drawn in one colour and the two additions of this thesis—the high-resolution P2 branch and the Coordinate Attention modules—are highlighted in two others. This subsection walks the signal through the three canonical parts of the network in turn—backbone, neck, and head—and ends by pointing to exactly where the improvements are inserted. The layer-by-layer specification of the backbone, which fixes the channel widths and feature-map sizes used throughout the rest of the chapter, is given in Table 1.

![Full architecture of the improved YOLOv8 detector. The CSPDarknet backbone (left) extracts features at strides 4, 8, 16, and 32; the PAN-FPN neck (centre) fuses them top-down and then bottom-up; and four decoupled, anchor-free heads (right) predict at the four scales. The high-resolution P2 branch at stride 4 and the Coordinate Attention module before each head are the two modifications introduced in this thesis.](figs/fig_yolo_full.png)

Table 1. Layer-by-layer specification of the YOLOv8-s backbone for a $640\times640$ input. Channel widths follow the "small" (s) scale; the rows marked ($\rightarrow$) export features to the neck. The stride-4 row (index 1–2) is the feature map that the standard detector leaves unused and that the P2 branch of Section 2.1.3 attaches a head to.

| Idx | Module | Output stride | Out channels | Feature map (640) | To neck |
|---|---|---|---|---|---|
| 0 | Conv $3\times3$, s2 | 2 (P1) | 32 | $320\times320$ | |
| 1 | Conv $3\times3$, s2 | 4 (P2) | 64 | $160\times160$ | |
| 2 | C2f ($\times1$) | 4 | 64 | $160\times160$ | $\rightarrow$ P2 |
| 3 | Conv $3\times3$, s2 | 8 (P3) | 128 | $80\times80$ | |
| 4 | C2f ($\times2$) | 8 | 128 | $80\times80$ | $\rightarrow$ P3 |
| 5 | Conv $3\times3$, s2 | 16 (P4) | 256 | $40\times40$ | |
| 6 | C2f ($\times2$) | 16 | 256 | $40\times40$ | $\rightarrow$ P4 |
| 7 | Conv $3\times3$, s2 | 32 (P5) | 512 | $20\times20$ | |
| 8 | C2f ($\times1$) | 32 | 512 | $20\times20$ | |
| 9 | SPPF | 32 | 512 | $20\times20$ | $\rightarrow$ P5 |

**The backbone.** The backbone is a CSPDarknet-style convolutional network whose job is to turn the raw $640\times640\times3$ image into a hierarchy of feature maps at progressively coarser spatial resolution and richer semantic content. It is built from three repeating elements. The first is the *Conv* unit—a $3\times3$ convolution (stride 2 at the down-sampling layers) followed by batch normalisation and a SiLU activation—which both halves the spatial resolution and doubles the channel width each time it is applied, producing the classical pyramid P1–P5 at strides 2, 4, 8, 16, and 32. The second, and the characteristic building block of YOLOv8, is the *C2f* (cross-stage-partial, "faster") module. C2f splits its input along the channel dimension into two halves: one half is carried forward untouched as a residual shortcut, while the other is passed through a sequence of $n$ lightweight bottleneck blocks—each a pair of $3\times3$ convolutions with an internal skip connection. Crucially, the outputs of *every* bottleneck in the sequence, not merely the last, are concatenated together with the carried-forward half and fused by a final $1\times1$ convolution. This dense reuse of intermediate features improves gradient flow during training and lets the module blend shallow and deep representations at the same stride, which is what makes YOLOv8 both accurate and cheap relative to the plain residual stacks of earlier detectors. The number of bottlenecks $n$ scales with the model size (one or two at the "small" scale used here). The third element, placed at the deepest level, is the *SPPF* (Spatial Pyramid Pooling–Fast) block: it applies three successive $5\times5$ max-pooling operations and concatenates the input with the three pooled results, so that each cell of the final P5 map aggregates information over a large effective receptive field at negligible computational cost. The backbone therefore emits four feature maps of interest—at strides 4, 8, 16, and 32 (Table 1)—that differ in exactly the way the two-stage design cares about: the shallow stride-4 map retains fine spatial detail but weak semantics, while the deep stride-32 map is semantically strong but spatially coarse.

**The neck.** On its own, no single backbone level is ideal for detecting objects of every size: small lesions need the spatial precision of the shallow levels, while larger symptoms benefit from the semantic context of the deep levels. The neck exists to reconcile this by mixing information across scales before detection. YOLOv8 uses a Path-Aggregation Feature-Pyramid Network (PAN-FPN), which fuses features in two passes. The *top-down* pass starts at the deepest level (P5, from the SPPF block), up-samples it by a factor of two, concatenates it with the backbone's P4 features, and fuses the result with a C2f module; this is repeated down to P3, so that every level is enriched with the strong semantics that previously existed only at P5. The *bottom-up* pass then reverses direction: starting from the finest fused level, it down-samples with a stride-2 convolution, concatenates with the level above, and fuses again with C2f, so that the precise localisation signal from the shallow levels is propagated back up to the coarser ones. The output of the neck is therefore a set of feature maps, one per detection scale, each of which carries both fine spatial detail and high-level semantic context. In the standard network this pyramid spans P3–P5; one of the two modifications of this thesis extends it by a further level to P2, as described below and visible as the lowest row of the neck in Figure 2.

**The head.** Detection is performed by a *decoupled, anchor-free* head attached to each level of the neck. "Decoupled" means that classification and localisation are handled by two parallel branches rather than a single shared layer: each branch is a small stack of $3\times3$ convolutions terminating in a $1\times1$ convolution. The classification branch outputs $n_{\text{cls}}$ channels—one score per class at every spatial location—trained with binary cross-entropy. The regression branch does not predict a box directly; instead it predicts, for each of the four box edges, a discrete probability distribution over $\text{reg\_max}=16$ candidate offsets, giving $4\times16=64$ output channels, and the Distribution-Focal-Loss (DFL) formulation recovers a continuous coordinate as the expectation of that distribution (the loss itself is detailed in Section 2.1.5). "Anchor-free" means that YOLOv8 dispenses with the pre-defined anchor boxes of earlier detectors and predicts object *centres* directly on the feature grid; a location is decoded into an image-space box using only the known stride of its level. Which locations are treated as positive examples during training is decided by a *task-aligned assigner*, which scores each candidate by a product of its classification confidence and its predicted-box IoU, so that a location is rewarded only when it is simultaneously confident and well-localised. This anchor-free design is what makes the proposed modifications inexpensive to add: a new detection level requires no re-design of anchor scales or aspect ratios, only a new head reading the finer feature map.

**A sampling-density view of the small-object problem.** The reason the full architecture matters for our application becomes concrete once the detection levels are read as sampling grids over the image. A detection level of stride $s$ tiles the input with one prediction cell per $s\times s$ pixels, and a cell can reliably represent an object only when the object spans at least a cell or two—below that, the pooling that produced the level has already averaged the object together with its background. Consider the shallowest *standard* level, P3 at stride 8. A conspicuous mid-stage lesion of roughly $24\times24$ pixels covers about $3\times3$ P3 cells and is comfortably detected; but an early lesion of $8\times8$ pixels maps to a single P3 cell, where its few distinctive pixels are diluted by the surrounding leaf, and one only $6\times6$ pixels falls *below* a single cell and is effectively invisible. Adding the P2 level at stride 4 quadruples the sampling density in area: that same $6\times6$ lesion now spans roughly $1.5$ cells per side and is covered by about $2\times2$ P2 cells, and the $8\times8$ lesion by $2\times2$ to $3\times3$ cells. The object has not changed; the grid has become fine enough to resolve it. For reference, the common convention that labels an object "small" below $32\times32$ pixels corresponds to only about four cells across at stride 8—already marginal—so the early, low-contrast symptoms that an early-warning system must catch sit squarely in the regime where a stride-4 level, and not merely a better-trained stride-8 one, is what the detector lacks.

**Receptive field and why context still matters.** The complementary quantity to sampling density is the *receptive field*—the extent of the input that influences a given feature cell—which grows with depth through the stacked convolutions and is enlarged sharply at P5 by the SPPF block's pooling pyramid. Deep levels therefore "see" a large neighbourhood and carry the context needed to tell a lesion from a lookalike texture, whereas the shallow P2 level, by design, sees little beyond the lesion itself. This is exactly why the P2 branch is not used in isolation: the top-down pass of the neck first injects the deep levels' semantic context down into the high-resolution features before any P2 prediction is made, and, at the system level, the padding factor $\rho$ of Section 2.1.7 deliberately re-admits surrounding leaf tissue into each crop. Fine sampling localises the symptom; borrowed context keeps the fine level from firing on every vein and water droplet.

**Design alternatives considered.** It is worth stating why the small-object deficit is addressed by a stride-4 detection level specifically, rather than by the more obvious alternatives. Simply raising the input resolution—say from $640$ to $1280$—multiplies the cost of *every* layer in the backbone and neck roughly fourfold while leaving the detector's coarsest-level-relative behaviour unchanged; it buys resolution everywhere, including where it is not needed, at a price an edge device cannot pay. Adding a *deeper* level, P6 at stride 64, would help only the largest objects and is irrelevant to small lesions. Swapping in a heavier backbone improves features generally but forfeits the real-time speed that motivated choosing YOLOv8 in the first place. The P2 branch, by contrast, spends computation precisely and only at the scale where the deficit arises, and—because YOLOv8 is anchor-free—it does so without any re-engineering of anchor scales or aspect ratios. This is the sense in which the modification is "targeted": it is the minimal structural change that addresses the specific failure mode identified above.

**Accounting for the cost of the extra level.** The same arithmetic that explains the P2 branch's benefit also explains its cost. Operating at stride 4 means a $160\times160$ feature map—four times as many spatial locations as P3's $80\times80$ and sixteen times as many as P4's—so the neck fusion and the detection head at this level dominate the detector's added computation and memory. Three measures, developed in Section 2.1.8, keep the full network within an edge budget: the P2 head is given a *reduced channel width* so that its many spatial locations are each cheaper to process; the backbone is held at the nano or small scale; and inference uses half precision with, where available, a TensorRT-optimised engine. The net effect, quantified in the ablation of Chapter 3, is a modest reduction in frame rate in exchange for a substantial gain in small-lesion recall—a trade that favours an early-warning system, where a missed emerging outbreak is far costlier than a few milliseconds of latency.

**Where the two improvements sit.** With the full network in view, the two changes of this thesis are easy to place, and both are marked in Figure 2. First, the standard detector attaches heads only at P3–P5 and simply discards the backbone's stride-4 features (Table 1, rows 1–2); the *P2 branch* of Section 2.1.3 continues the neck one level further down and attaches a fourth head to that stride-4 map, so that detection is performed over four levels, P2–P5, at strides $\{4, 8, 16, 32\}$ and resolutions $\{160, 80, 40, 20\}$ for a $640$-pixel input. Second, a *Coordinate Attention* module (Section 2.1.4) is inserted immediately before each of the four heads, re-weighting the feature map so that genuine lesion locations are emphasised and background clutter suppressed before the localisation decision is made. Everything else in Figure 2—the CSPDarknet backbone, the PAN-FPN neck, the decoupled anchor-free heads, and the DFL/CIoU training objective—is the unmodified YOLOv8. The deliberate restraint of changing only these two things, each aimed at a distinct facet of the small-lesion problem, is what the next two subsections develop in detail.

### 2.1.3 Improvement 1 — A High-Resolution P2 Detection Branch

The first modification adds a fourth detection level, **P2**, at stride 4. The backbone already computes a stride-4 feature map early in its hierarchy; the standard architecture simply does not attach a detector to it. We extend the neck so that the top-down pathway continues one level further, fusing the high-resolution stride-4 backbone features with up-sampled semantic features from P3, and we attach an additional decoupled head to the resulting P2 feature map. Detection is then performed over four levels, P2–P5, at strides {4, 8, 16, 32}.

Conceptually, the P2 branch quadruples the spatial sampling density relative to P3: each P2 cell corresponds to a 4×4 input region rather than 8×8, so a lesion only a few pixels across is now covered by several cells rather than falling between samples. Because YOLOv8 is anchor-free and predicts object centres directly, no anchor re-design is required; the new head simply predicts centres and box distributions at the finer resolution. The architecture is illustrated in Figure 3.

![Improved YOLOv8 detector. A high-resolution P2 detection branch (stride 4) is added to the standard P3–P5 levels, and a Coordinate Attention module is inserted before each detection head. The P2 branch increases sampling density for small lesions; Coordinate Attention preserves the positional information those lesions depend on.](figs/fig_yolo.png)

The cost of the P2 branch is additional computation and memory, because it operates on a large feature map. To keep the detector real-time on edge hardware, we (i) use a lightweight head for P2 with reduced channel width, and (ii) retain the nano/small backbone scale. The trade-off—modestly higher latency for substantially better small-object recall—is quantified in the ablation study of Chapter 3.

### 2.1.4 Improvement 2 — Coordinate Attention before the Detection Heads

Adding resolution is necessary but not sufficient: high-resolution feature maps also carry more background clutter (leaf veins, water droplets, lighting gradients) that can produce false positives. The second modification therefore inserts a lightweight attention module, **Coordinate Attention (CA)** [22], immediately before each detection head, so that the network learns to emphasise the channels and spatial locations that correspond to genuine lesions.

Unlike channel-only attention such as squeeze-and-excitation [23], or the spatial attention of CBAM [21] which pools positional information into a single map, Coordinate Attention preserves *directional* positional structure—important when a lesion's location within the field of view matters. Given an input feature map $X \in \mathbb{R}^{C\times H\times W}$, CA first applies two one-dimensional average-pooling operations, one along the width and one along the height, producing a pair of direction-aware descriptors:

$$
z_c^{h}(h) = \frac{1}{W}\sum_{w=1}^{W} x_c(h,w), \qquad
z_c^{w}(w) = \frac{1}{H}\sum_{h=1}^{H} x_c(h,w).
$$

These two descriptors are concatenated and passed through a shared $1\times1$ convolution with batch normalisation and a non-linear activation $\delta$ to produce an intermediate representation $f$:

$$
f = \delta\big(\mathrm{BN}(W_1\,[\,z^{h},\,z^{w}\,])\big).
$$

The intermediate $f$ is split back into a height branch and a width branch, each passed through its own $1\times1$ convolution and a sigmoid $\sigma$ to yield two attention weights:

$$
g^{h} = \sigma(W_h\, f^{h}), \qquad g^{w} = \sigma(W_w\, f^{w}).
$$

Finally, the input is re-weighted by the outer combination of the two directional gates:

$$
y_c(h,w) = x_c(h,w)\;\cdot\;g_c^{h}(h)\;\cdot\;g_c^{w}(w).
$$

The structure is shown in Figure 4. Intuitively, $g^h$ answers "which rows matter?" and $g^w$ answers "which columns matter?"; their product sharpens the response at lesion locations while suppressing clutter, at negligible parameter cost (two $1\times1$ convolutions). Placing CA before the heads—rather than throughout the backbone—keeps the overhead small and focuses the attention where the localisation decision is actually made.

![Coordinate Attention module. Factorised pooling along height and width yields two direction-aware descriptors that are fused and split into per-row and per-column gates, which re-weight the input feature map.](figs/fig_ca.png)

**Tensor-shape walkthrough.** Because Coordinate Attention is inserted *before* each detection head, it is worth tracing exactly how the size of the tensor changes as it flows through the module: this both clarifies the mechanism and accounts for the module's (small) overhead. Take a $640\times640$ input image at the YOLOv8-s scale; the four detection levels then carry the feature maps listed in Table 2. The spatial size at each level is the input size divided by the stride, and the channel width $C$ grows as the spatial size shrinks. A separate Coordinate Attention module is attached to each level, with an internal "reduced" channel width $d$ set by a reduction ratio $r$ (here $r=16$, lower-bounded at $8$ so that the bottleneck never becomes degenerate on the thinner levels).

Table 2. Feature-map dimensions at each detection level for a $640\times640$ input (YOLOv8-s scale; the P2 head deliberately uses a reduced channel width).

| Level | Stride | Spatial $H\times W$ | Channels $C$ | CA reduced width $d=\max(8,\,C/r)$ |
|---|---|---|---|---|
| P2 | 4 | $160\times160$ | 64 | 8 |
| P3 | 8 | $80\times80$ | 128 | 8 |
| P4 | 16 | $40\times40$ | 256 | 16 |
| P5 | 32 | $20\times20$ | 512 | 32 |

Consider the P3 level, whose input tensor has shape $C\times H\times W = 128\times80\times80$. Table 3 follows this tensor step by step through the module; shapes are written throughout as $C\times H\times W$.

Table 3. How the tensor size changes inside Coordinate Attention, traced on the P3 level ($C=128$, $H=W=80$, reduced width $d=8$).

| # | Operation | Symbol | Shape ($C\times H\times W$) |
|---|---|---|---|
| 1 | Input feature map | $X$ | $128\times80\times80$ |
| 2 | Average-pool along width (X-pool) | $z^{h}$ | $128\times80\times1$ |
| 3 | Average-pool along height (Y-pool) | $z^{w}$ | $128\times1\times80$ |
| 4 | Re-orient the width descriptor onto the height axis | $z^{w\top}$ | $128\times80\times1$ |
| 5 | Concatenate the two descriptors along the spatial axis | $[\,z^{h};z^{w\top}\,]$ | $128\times160\times1$ |
| 6 | Shared $1\times1$ conv ($128\!\to\!8$) + BN + $\delta$ | $f$ | $8\times160\times1$ |
| 7 | Split back into height and width parts | $f^{h}\,/\,f^{w}$ | $8\times80\times1\ /\ 8\times80\times1$ |
| 8 | Re-orient the width part onto the width axis | $f^{w}$ | $8\times1\times80$ |
| 9 | $1\times1$ conv $W_h$ ($8\!\to\!128$) + $\sigma$ | $g^{h}$ | $128\times80\times1$ |
| 10 | $1\times1$ conv $W_w$ ($8\!\to\!128$) + $\sigma$ | $g^{w}$ | $128\times1\times80$ |
| 11 | Broadcast re-weighting $X\cdot g^{h}\cdot g^{w}$ | $Y$ | $128\times80\times80$ |

Three transitions deserve comment. *(i) Pooling collapses one spatial axis at a time.* The X-pool of step 2 averages over the $W=80$ columns and so reduces the width to $1$, leaving a per-row descriptor of shape $128\times80\times1$; symmetrically, the Y-pool of step 3 leaves a per-column descriptor $128\times1\times80$. Unlike global average pooling—which would collapse *both* axes to a single $128\times1\times1$ vector and discard all positional information—this factorised pooling preserves one spatial coordinate intact in each branch. That retained coordinate is precisely what gives the module its name and what lets it remember *where* a lesion lies. *(ii) Concatenation, then a single shared convolution.* Re-orienting the width descriptor onto the height axis (step 4) lets the two length-$80$ descriptors be stacked into one length-$160$ tensor (step 5), so that a *single* $1\times1$ convolution (step 6) processes both directions at once while compressing the channel dimension from $C=128$ down to $d=8$. This $16\times$ channel reduction is where almost all of the (already tiny) parameter and compute saving comes from. *(iii) Channel restoration and broadcasting.* Steps 9–10 expand the channels back from $d=8$ to $C=128$ and apply a sigmoid, producing a per-row gate $g^{h}$ of shape $128\times80\times1$ and a per-column gate $g^{w}$ of shape $128\times1\times80$. In step 11 these are *broadcast* against the full feature map: $g^{h}$ is replicated across all $80$ columns and $g^{w}$ across all $80$ rows, so that element $(c,h,w)$ of the input is scaled by the product $g^{h}_c(h)\,g^{w}_c(w)$.

The key structural fact is that **the output $Y$ has exactly the same shape as the input $X$**, $128\times80\times80$. Coordinate Attention is therefore *shape-preserving*, which is what allows it to be dropped in immediately before a detection head without changing anything downstream. The head then consumes the unchanged $128\times80\times80$ tensor and, through its two decoupled $3\times3$-conv branches, maps it to a box-regression output of $4\cdot\text{reg\_max}=64$ channels (with $\text{reg\_max}=16$) and a classification output of $n_{\text{cls}}$ channels, both still at $80\times80$ resolution. The same module, with the per-level channel width $C$ and reduced width $d$ of Table 2, is applied independently at P2, P4, and P5; only the numbers in Table 3 change (for example, at P5 the trace reads $512\times20\times20 \to 512\times20\times1$ and $512\times1\times20 \to 512\times40\times1 \to 32\times40\times1 \to \dots \to 512\times20\times20$).

Finally, the cost is negligible. The module's learnable weights are dominated by its three $1\times1$ convolutions—one of size $C\times d$ and two of size $d\times C$—for roughly $3Cd$ parameters per level (at P3, $3\times128\times8\approx 3.1\text{k}$), which is three to four orders of magnitude smaller than the detection head it precedes. This is what justifies the earlier claim that Coordinate Attention buys clutter suppression at "negligible parameter cost".

### 2.1.5 Training Objective

Training uses the standard YOLOv8 multi-task loss, now summed over four detection levels rather than three. For each level the loss combines a classification term, a box-regression term, and a distribution-focal term:

$$
\mathcal{L}_{\text{det}} = \lambda_{\text{cls}}\,\mathcal{L}_{\text{cls}}
+ \lambda_{\text{box}}\,\mathcal{L}_{\text{CIoU}}
+ \lambda_{\text{dfl}}\,\mathcal{L}_{\text{DFL}},
$$

where $\mathcal{L}_{\text{cls}}$ is binary cross-entropy over classes, $\mathcal{L}_{\text{CIoU}}$ is the complete-IoU regression loss [47], and $\mathcal{L}_{\text{DFL}}$ is the distribution-focal loss that models each box coordinate as a discrete distribution. Positive samples are assigned by YOLOv8's task-aligned assigner, which scores candidates by a combination of classification confidence and IoU. The loss weights $\lambda_\ast$ follow the YOLOv8 defaults unless otherwise stated. No change to the loss form is required by our modifications; the P2 branch simply contributes additional terms at the finer scale, and Coordinate Attention is trained end-to-end with the rest of the network.

### 2.1.6 Summary of Section 1

In summary, the improved detector makes two targeted changes—a P2 high-resolution branch and a Coordinate Attention module before the heads—each addressing a distinct aspect of the small-lesion problem (sampling density and clutter suppression, respectively). Both are inexpensive, require no anchor re-engineering thanks to YOLOv8's anchor-free design, and are validated individually and jointly in the ablation study of Chapter 3.

### 2.1.7 Detection-to-Classification Interface

The two stages are coupled by a deterministic interface that converts detector outputs into classifier inputs. After the detector produces boxes, low-confidence predictions are removed by a confidence threshold $\tau_{\text{conf}}$ and duplicate boxes are merged by non-maximum suppression at IoU threshold $\tau_{\text{nms}}$. Each surviving box is then expanded by a padding factor $\rho$ to include diagnostic context around the lesion (the surrounding leaf tissue often carries information needed to distinguish causes), giving a crop region

$$
w' = (1+\rho)\,w, \qquad h' = (1+\rho)\,h,
$$

centred on the original box and clipped to the image bounds. In a PTZ configuration, the expanded box centre is mapped to pan/tilt angles and a zoom level so that the macro camera re-images the region at high resolution; in a fixed-camera configuration, the crop is taken directly from the high-resolution wide-field frame. Crops smaller than a minimum size are up-sampled to the classifier's input resolution, and multiple crops from one frame are batched for efficient classification. This interface deliberately keeps the two models decoupled, so that either can be retrained or replaced independently, and so that the confidence and padding parameters can be tuned to trade recall for precision at the system level.

### 2.1.8 Complexity and Real-Time Considerations

The principal cost of the proposed detector is the P2 branch, which operates on a stride-4 feature map four times larger in each spatial dimension than P3 and therefore dominates the added computation. Three measures keep the detector real-time on edge hardware: the P2 head uses a reduced channel width; Coordinate Attention adds only two $1\times1$ convolutions and is therefore negligible in cost; and inference uses half-precision and, where available, a TensorRT-optimised engine. The net effect, quantified in Chapter 3, is a modest reduction in frame rate relative to the baseline in exchange for a substantial gain in small-lesion recall—an exchange that is favourable for an early-warning application, where missing an emerging problem is more costly than a small latency increase.

## 2.2 Section 2 — Data-Efficient Vision Transformer for Pest Identification via Two-Phase Transfer Learning

### 2.2.1 Base Classifier and the Data-Efficiency Problem

The second stage classifies the close-up image of each detected region into a specific pest or disease category. The base classifier is a Vision Transformer (ViT-B/16) [15]: the input image is divided into non-overlapping $16\times16$ patches, each patch is linearly projected to a token embedding, a learnable class token is prepended, positional embeddings are added, and the resulting sequence is processed by a stack of Transformer encoder blocks, each consisting of multi-head self-attention (MSA) and a feed-forward MLP with residual connections and layer normalisation [14]. The final class-token representation is mapped to class scores by a linear head.

ViT's strength—global self-attention that relates distant image regions—is well matched to fine-grained pest identification, where the discriminative cue may be a wing pattern, an antenna, or the distribution of feeding damage across the leaf. Its weakness is that, lacking the convolutional priors of locality and translation equivariance, it must learn these regularities from data and therefore needs very large training sets to generalise [15]. A specialised greenhouse pest dataset is, by contrast, modest in size and long-tailed in class frequency [29]. Training a ViT from scratch on such data over-fits badly. The method described below—transfer learning from a strong pretrained model, adapted through a disciplined two-phase fine-tuning schedule—is what makes the transformer data-efficient on this modest dataset.

### 2.2.2 The ViT-B/16 Network in Full

As with the detector, it helps to see the whole classifier before examining the single modification that makes it data-efficient. Figure 5 shows the ViT-B/16 network end to end: a close-up crop enters on the left, is cut into patches and embedded as a sequence of tokens, is processed by a stack of twelve identical Transformer encoder blocks, and leaves as a class distribution over pest and disease categories on the lower left; an exploded view of a single encoder block is drawn on the right. This subsection walks through each stage in turn and fixes the configuration—summarised in Table 4—that the rest of the chapter refers to. The point to keep in mind throughout is that the architecture contains almost none of the built-in assumptions of a convolutional network: it learns how image regions relate to one another purely from data, which is the source of both its power on fine-grained problems and its appetite for training examples.

![Full architecture of the ViT-B/16 classifier. The $224\times224$ crop is divided into $16\times16$ patches, linearly projected into $768$-dimensional tokens, augmented with a learnable class token and positional embeddings, and processed by twelve Transformer encoder blocks; the final class-token representation is mapped to pest-class probabilities by an MLP head. Right: one encoder block, with pre-norm multi-head self-attention and an MLP, each wrapped in a residual connection.](figs/fig_vit_arch.png)

Table 4. Configuration of the ViT-B/16 classifier used in this thesis.

| Component | Specification |
|---|---|
| Input resolution | $224\times224\times3$ (optionally $384$ for high-resolution fine-tuning) |
| Patch size $P$ | $16\times16$ |
| Number of patches $N$ | $196$ (a $14\times14$ grid) |
| Sequence length | $197$ tokens (patches $+$ one class token) |
| Embedding dimension $D$ | $768$ |
| Encoder blocks $L$ | $12$ |
| Attention heads $h$ | $12$ (head dimension $d_h = 64$) |
| MLP hidden dimension | $3072$ (an expansion ratio of $4$) |
| Parameters | $\approx 86$ million |
| Classification head | LayerNorm $+$ Linear($768 \rightarrow n_{\text{cls}}$) |

**Patch embedding.** A Transformer consumes a sequence of vectors ("tokens"), so the first task is to turn a two-dimensional image into one. The $224\times224\times3$ crop is partitioned into a regular grid of non-overlapping $16\times16$ patches, yielding $N = (224/16)^2 = 196$ patches. Each patch is flattened into a vector of length $16\cdot 16\cdot 3 = 768$ and mapped to the embedding dimension $D=768$ by a single shared linear projection $\mathbf{E}$. Writing the flattened patches as rows of a matrix $\mathbf{x}_p \in \mathbb{R}^{N\times(P^2\cdot C)}$, the patch embeddings are

$$
\mathbf{z}^{\text{patch}} = \mathbf{x}_p\,\mathbf{E}, \qquad \mathbf{E}\in\mathbb{R}^{(P^2 C)\times D}.
$$

In practice this operation is implemented identically and more efficiently as a single convolution with a $16\times16$ kernel and a stride of $16$, which reads each patch exactly once; the two formulations are mathematically equivalent. The result is a set of $196$ token vectors, each a $768$-dimensional summary of one square of the image.

**Class token and positional embeddings.** Two pieces of information must be added before the sequence can be processed. First, a single learnable vector—the *class token* $\mathbf{z}_{\text{cls}}$—is prepended to the sequence; it owns no patch of the image and exists purely as a place for the network to accumulate a global, whole-image representation that will drive the final prediction. This brings the sequence length to $197$. Second, because self-attention is permutation-invariant—it treats its inputs as an unordered set and so, by itself, cannot tell a patch in the top-left from one in the bottom-right—a learnable *positional embedding* $\mathbf{E}_{\text{pos}}\in\mathbb{R}^{(N+1)\times D}$ is added elementwise to the tokens to re-inject spatial order. The input to the encoder stack is therefore

$$
\mathbf{z}_0 = [\,\mathbf{z}_{\text{cls}};\ \mathbf{x}_p\mathbf{E}\,] + \mathbf{E}_{\text{pos}}.
$$

When the input resolution is later increased (for example from $224$ to $384$ in high-resolution fine-tuning), the number of patches changes and the positional embeddings are bilinearly interpolated to the new grid, as noted in Section 2.2.3.

**The encoder block.** The heart of the network is a stack of $L=12$ identical encoder blocks, each with the two-sublayer structure shown on the right of Figure 5. YOLOv8's building block reuses features through convolution; the Transformer block instead lets every token exchange information with every other token through self-attention. Each block applies, in the pre-normalisation arrangement used by modern Vision Transformers,

$$
\mathbf{z}'_\ell = \mathrm{MSA}\big(\mathrm{LN}(\mathbf{z}_{\ell-1})\big) + \mathbf{z}_{\ell-1},
\qquad
\mathbf{z}_\ell = \mathrm{MLP}\big(\mathrm{LN}(\mathbf{z}'_\ell)\big) + \mathbf{z}'_\ell,
$$

where $\mathrm{LN}$ is layer normalisation, $\mathrm{MSA}$ is multi-head self-attention, and each sublayer is wrapped in a residual connection so that gradients flow unobstructed through the twelve-block stack and each sublayer need only learn a refinement of its input.

**Multi-head self-attention.** Within a block, self-attention is what lets a token describing, say, a patch of leaf margin attend to a distant patch bearing an insect, and thereby relate cues that a convolution of limited receptive field would struggle to connect. Each token is linearly projected into a *query*, a *key*, and a *value*; a token's output is a weighted average of all tokens' values, where the weight between two tokens is the softmax-normalised similarity of one's query with the other's key:

$$
\mathrm{Attention}(\mathbf{Q},\mathbf{K},\mathbf{V}) = \mathrm{softmax}\!\left(\frac{\mathbf{Q}\mathbf{K}^{\!\top}}{\sqrt{d_h}}\right)\mathbf{V},
$$

the scaling by $\sqrt{d_h}$ keeping the dot products in a range where the softmax gradients are well-behaved. "Multi-head" means this is done $h=12$ times in parallel in separate $d_h = D/h = 64$-dimensional subspaces, so that different heads can specialise in different kinds of relationship; their outputs are concatenated and mixed by a final linear projection $\mathbf{W}_O$:

$$
\mathrm{MSA}(\mathbf{z}) = \big[\,\mathrm{head}_1;\dots;\mathrm{head}_h\,\big]\,\mathbf{W}_O,
\qquad
\mathrm{head}_i = \mathrm{Attention}(\mathbf{z}\mathbf{W}_Q^i,\ \mathbf{z}\mathbf{W}_K^i,\ \mathbf{z}\mathbf{W}_V^i).
$$

Because every token attends to every other, the cost of this operation grows with the square of the sequence length, $\mathcal{O}(N^2 D)$; for ViT-B/16 at $224$ pixels the sequence is a modest $197$ tokens, so this quadratic term is affordable, but it is the reason transformers become expensive at high resolution and the reason the two-stage design keeps the classifier on small close-up crops rather than whole canopy images.

**The MLP sublayer and the classification head.** The second sublayer of each block is a position-wise feed-forward network—applied to each token independently—consisting of two linear layers with a GELU non-linearity between them, expanding the dimension from $D=768$ to $3072$ and back to $768$ (the expansion ratio of $4$ in Table 4). Where attention mixes information *across* tokens, this MLP transforms each token *within* itself, giving the block the capacity to re-combine the features that attention has gathered. After the twelfth block, the representation sitting in the class-token position—having attended to the whole image twelve times over—is taken as the global descriptor of the crop. It is layer-normalised and passed through a linear classification head to produce a score for each of the $n_{\text{cls}}$ pest and disease categories.

**Computational and memory profile.** Reading the cost of ViT-B/16 off its configuration clarifies why the classifier is placed where it is in the pipeline. Two kinds of operation dominate each encoder block. The linear projections—computing queries, keys, and values, the output projection, and the two MLP layers—scale as $\mathcal{O}(N D^2)$ in the sequence length $N$ and embedding dimension $D$; the attention interaction itself—forming $\mathbf{Q}\mathbf{K}^{\!\top}$ and applying the weights to $\mathbf{V}$—scales as $\mathcal{O}(N^2 D)$. At the standard setting, $N=197$ and $D=768$, the $D^2$ terms are the larger, so most of the roughly $17.6$ billion floating-point operations per image sit in the linear and MLP layers rather than in attention, and the per-block attention matrix of size $h\times N\times N$ is modest in memory. The significance is in how these terms scale with resolution: moving from $224$ to $384$ pixels raises the patch count from $196$ to $576$, nearly tripling $N$ and so multiplying the quadratic attention term by almost an order of magnitude. A transformer applied directly to a wide-field canopy image would be ruinously expensive for exactly this reason. The two-stage design sidesteps the problem by construction: the detector, not the transformer, scans the large image, and the classifier is only ever shown small, already-localised crops, keeping $N$ small and the quadratic term affordable.

**Inductive bias: what ViT gives up, and why it matters here.** The deeper reason ViT behaves so differently from the CNN baselines of Section 1.4 is a near-total absence of built-in assumptions. A convolution hard-codes three priors that are well matched to natural images: *locality* (a unit responds only to a small neighbourhood), *translation equivariance* (the same filter is applied at every position, so a feature learned in one place is recognised everywhere), and *hierarchical composition* (small patterns are assembled into larger ones across layers). These priors act as a strong regulariser: a CNN does not have to *learn* that nearby pixels are related, because its architecture already assumes it, and this is why CNNs train well on modest datasets. ViT discards all three. Self-attention is global from the very first block—every patch may attend to every other—and the only notion of spatial arrangement is the *learned* positional embedding, so the network must discover from data even the elementary fact that adjacent patches tend to be related. On a large pretraining corpus this freedom is an asset, because the model is not constrained by priors that are occasionally wrong and can instead learn whatever relational structure the data actually exhibit. On a small, specialised dataset it is a liability, because there are simply not enough examples to pin down $86$ million parameters' worth of unconstrained relationships. This single fact—great capacity, weak priors—is the pivot on which the whole classifier design turns, and it is why the remedy of Section 2.2.3 is about *initialisation and adaptation* rather than architecture.

**The supporting mechanisms: normalisation, activation, and residuals.** Three elements inside each block, easy to pass over, are what make a stack this deep trainable at all. *Layer normalisation*, applied in the pre-norm position before each sublayer, standardises each token's features and keeps the scale of activations and gradients stable through all twelve blocks, which matters especially when the network is first unfrozen for fine-tuning. The *GELU* activation in the MLP provides a smooth, differentiable non-linearity that empirically trains more stably than a hard rectifier in transformers. The *residual connections* around both sublayers let each block learn a small correction to its input rather than a full re-representation, so that—even before any block has learned anything useful—the identity path carries the signal and its gradient cleanly from the loss back to the patch embedding. Together these are why a twelve-block, $86$-million-parameter model can be optimised at all; the additional regularisers that keep it from over-fitting a small pest dataset once unfrozen—stochastic depth, label smoothing, weight decay, and weight averaging—are deferred to the fine-tuning schedule of Section 2.2.3, where they belong.

**Attention as a by-product: interpretability.** A final, practical virtue of this architecture is that its central operation is also an explanation. Because the class token's prediction is a weighted average over patch tokens, the attention weights it assigns—read off the final blocks—form a saliency map over the crop, indicating which regions the model relied on. For a grower or agronomist this means a prediction can be shown alongside a highlighted image region ("the model attended to this wing patch"), rather than delivered as an opaque label, which aligns with the attention-based localisation benefits reported for plant-disease transformers in Section 1.5 [37]. The same maps are valuable during development, because a model that attends to the background rather than the lesion is revealed as unreliable even when its accuracy on a given split happens to be high.

**Why this architecture, and why it is data-hungry.** This design is well matched to fine-grained pest identification precisely because global self-attention can, in principle, relate a discriminative wing pattern in one corner of the crop to feeding damage in another, without the locality constraint that a convolution imposes. But that same freedom is a liability on small datasets: lacking the convolutional priors of locality and translation equivariance, the network has roughly $86$ million parameters' worth of relationships to learn—including, through the positional embeddings, the very notion that neighbouring patches are related—entirely from the training data. On a corpus the size of a specialised greenhouse pest dataset, learning all of this from scratch over-fits badly. The whole burden of making this high-capacity architecture usable in our setting therefore falls on *how its weights are initialised and adapted*, which is the single modification developed in the next subsection.

### 2.2.3 Two-Phase Transfer-Learning and Fine-Tuning

The single, central modification of the classifier concerns *how* the transformer is adapted to the pest domain: rather than training from scratch, we transfer a strong pretrained model and adapt it with a disciplined two-phase schedule. The starting point is a ViT-B/16 backbone pre-trained on a large general corpus (ImageNet [31]); a data-efficient pretrained transformer such as DeiT [16] may be used interchangeably as the source of initial weights. These weights encode broadly useful visual features but were never exposed to pests, so the task of fine-tuning is to specialise them to the pest categories without destroying them.

The naive approach—attaching a freshly, randomly initialised classification head and immediately training the whole network end-to-end—is known to be harmful, and the reason is worth stating precisely. In the first few iterations the random head produces large, essentially meaningless errors; back-propagating these through the backbone yields large gradients that rewrite the lower layers before the head has learned anything useful, so the very features that motivated transfer learning are distorted. This *feature-distortion* effect is especially damaging when the deployment data differ in distribution from the pre-training data [49]—exactly the greenhouse domain-shift situation of Section 1.2.1. We therefore use a **two-phase schedule** that updates the head and the backbone in the right order; it is illustrated in Figure 6.

![Two-phase transfer-learning schedule for the ViT classifier. In Phase 1 (linear probing) the pretrained backbone is frozen and only the classification head is trained; in Phase 2 (full fine-tuning) the backbone is unfrozen and trained end-to-end with layer-wise learning-rate decay, so that lower layers—which carry generic, transferable features—adapt more gently than the upper, task-specific layers.](figs/fig_vit.png)

In **Phase 1 (linear probing)**, the entire transformer backbone is frozen—patch-embedding projection, positional embeddings, the class token, and all encoder blocks—and only the new linear classification head is trained, with the backbone's normalisation layers held in inference mode so their statistics are not disturbed. Because the head now learns on top of *fixed*, high-quality features, it converges quickly and, crucially, generates no destructive gradients into the backbone. A handful of epochs (typically of the order of ten) is sufficient for the head to settle into a sensible region of parameter space. In **Phase 2 (full fine-tuning)**, the backbone is unfrozen and the whole network is trained end-to-end at a much smaller base learning rate, using **layer-wise learning-rate decay (LLRD)** so that layers closer to the input—which encode generic, broadly transferable features—are updated more gently than layers closer to the output, which must specialise to pest categories. Concretely, the learning rate of layer $\ell$ is scaled as

$$
\eta_\ell = \eta_{\text{base}}\cdot \xi^{\,(L-\ell)},
$$

where $L$ is the number of layers, $\ell$ indexes from input ($\ell=1$) to output ($\ell=L$), and $\xi \in (0,1)$ is the decay factor. With $\xi=0.75$ and, say, $L=12$ encoder blocks, the earliest block is trained at $0.75^{11}\approx 0.04$ times the base rate while the head (treated as $\ell=L$) trains at essentially the full rate; the per-block rates form a smooth geometric ladder rather than a single global value. Parameters are grouped per encoder block for this purpose, with the patch-embedding and positional embeddings placed in the lowest (most slowly updated) group.

Several further choices stabilise Phase 2 and are easy to overlook. We optimise with **AdamW** [46], which decouples weight decay from the adaptive gradient update and is the standard choice for stable transformer fine-tuning; weight decay is *not* applied to LayerNorm parameters, biases, or the class token, since decaying these tends to hurt rather than regularise. The learning rate follows a **cosine schedule with a short linear warm-up** (a few hundred iterations), the warm-up being important because AdamW's second-moment estimates are unreliable at the very start of Phase 2 when the freshly unfrozen backbone first receives gradients. Mild **stochastic depth** (drop-path) in the encoder, **label smoothing** on the cross-entropy, **gradient clipping**, and an **exponential moving average (EMA)** of the weights further regularise a high-capacity model on a small dataset. Augmentations appropriate to fine-grained natural imagery (random resized crop, horizontal flip, colour jitter, and mild RandAugment) regularise training without distorting the diagnostic cues, and the **class-balanced sampling and loss re-weighting** of Section 2.3 are applied throughout both phases so that rare pest classes are not drowned out. Resolution is handled following the practice of training at a lower resolution and optionally fine-tuning at a higher one (e.g. $224\to384$), with positional embeddings bilinearly interpolated when the number of patches changes [16]. **Early stopping** monitors the macro-averaged F1 on the validation split—rather than top-1 accuracy—so that selection is driven by performance on the long tail rather than on the dominant classes.

This two-phase schedule is conceptually simple but materially important: linear probing first aligns the head, then layer-wise-decayed full fine-tuning specialises the backbone gently, so that a high-capacity transformer can be adapted reliably on a modest dataset without over-fitting or catastrophic forgetting. The empirical contribution of each design choice—linear probing, layer-wise decay, and the decay factor $\xi$—is isolated in the ablation of Section 3.7.1.

### 2.2.4 Summary of Section 2

The classifier therefore rests on a single, well-justified idea: data-efficient transfer learning, realised as a two-phase linear-probe-then-fine-tune schedule with layer-wise learning-rate decay, aimed squarely at the problem of making a data-hungry transformer work well on a modest, long-tailed pest dataset. In keeping with the design principle of Section 2.1, the contribution is deliberately narrow and is dissected component by component in the ablation of Chapter 3. Token-based knowledge distillation [16; 17] is a complementary route to the same data-efficiency goal; it is deliberately left out of scope here so that the effect of transfer learning can be isolated cleanly, and it is noted as a direction for future work in the conclusion.

\newpage
## 2.3 Data Preprocessing and Augmentation

Both stages rely on augmentation to bridge the gap between training data and greenhouse conditions, but the two stages are augmented differently because they face different invariances. For the **detector**, mosaic augmentation (compositing four images) enriches context and small-object frequency, and is disabled for the final training epochs because its synthetic layouts otherwise bias the late-stage optimisation; HSV jitter improves robustness to the greenhouse's variable lighting and colour temperature; and random scaling and translation build tolerance to the scale variation inherent in canopy imaging. For the **classifier**, augmentation must preserve the fine diagnostic cues that define pest identity, so random resized cropping, horizontal flipping, mild colour jitter, and a moderate RandAugment policy are used, while aggressive mixing augmentations are applied cautiously to avoid blending class-defining detail. Class imbalance—pronounced in pest data [29]—is addressed with class-balanced sampling and, where needed, loss re-weighting so that rare but important categories are not ignored. All images are normalised to the statistics of the pretraining corpus [31] to match the distribution the backbones expect.

## 2.4 Implementation of the Integrated Pipeline

At run time the system executes a simple, auditable loop per inspection cycle. For each canopy section: (1) acquire a wide-field frame and record the micro-climate; (2) run the improved detector to obtain lesion boxes; (3) apply confidence thresholding, NMS, and padding to form crop regions (Section 2.1.7); (4) acquire or extract close-up crops and classify each with the transfer-learned ViT; (5) write each classified detection, with its location, class, confidence, and timestamp, to the incidence record; and (6) update the forecasting/early-warning state (Chapter 3). The detector runs on the edge device and only the small crops and metadata are transmitted upstream, while the classifier and forecasting logic run on the server. Because the steps are explicit and the two models are decoupled, the pipeline is straightforward to test stage by stage, to profile for latency, and to extend—for example by inserting a tracking step so that the same lesion observed across cycles is associated into a single growing instance.

# Chapter 3 — System Configuration, Implementation, and Performance Evaluation

> **Note on results.** The quantitative values in the tables and result figures of this chapter are *illustrative placeholders* that show the intended structure of the evaluation. They must be replaced with the author's actual measured results before submission. The experimental design, metrics, baselines, and ablations are real and ready to use.

## 3.1 System Configuration

The deployed system, shown in Figure 7, consists of three tiers. A **greenhouse sensing node** carries two cameras and environmental sensors. A wide-field RGB camera images each canopy section at fixed intervals to feed Stage 1; a pan–tilt–zoom (PTZ) or motorised macro camera captures close-up images of the regions flagged by Stage 1 to feed Stage 2. (Where a PTZ camera is unavailable, the close-up image is approximated by a high-resolution crop of the wide-field frame around the detected box.) Temperature and relative-humidity sensors record the micro-climate, which is a strong covariate of pest and disease development and is used by the forecasting module.

![System configuration and data flow across the sensing node, edge device, and server.](figs/fig_system.png)

An **edge device** (e.g., an NVIDIA Jetson-class module) runs the Stage-1 detector in real time, so that only small cropped regions—rather than full-resolution video—need to be transmitted upstream. A **server** runs the Stage-2 transformer classifier and the forecasting/early-warning module, and hosts a dashboard for growers. This division keeps bandwidth and latency low while concentrating the heavier transformer computation where GPU resources are available.

### 3.1.1 From Detection to Forecasting

Forecasting is built on the time series of classified detections. For each canopy section and each pest/disease class, the system accumulates an incidence count per inspection cycle, producing a spatio-temporal record of where and how fast symptoms are appearing. A lightweight early-warning rule combines the trend in incidence with the measured micro-climate: when the rate of increase of a class crosses a threshold under conducive temperature/humidity conditions, an alert is raised and localised on a canopy map. This deliberately simple, interpretable mechanism is appropriate for grower decision support and avoids over-claiming predictive precision; more elaborate temporal models are noted as future work in the conclusion.

## 3.2 Implementation Details

The detector is implemented in PyTorch using the Ultralytics framework [7], extended with the additional P2 head and the Coordinate Attention module of Section 2.1. The classifier is implemented in PyTorch using a standard ViT-B/16 backbone (Section 2.2), initialised from ImageNet-pretrained weights and adapted with the two-phase transfer-learning schedule. Representative training configurations are summarised in Table 5; these should be adjusted to the author's hardware and final dataset.

Table 5. Representative training configuration (to be finalised by the author).

| Setting | Stage 1 — Improved YOLOv8 | Stage 2 — Transfer-Learned ViT |
|---|---|---|
| Backbone / scale | YOLOv8-s + P2 + CA | ViT-B/16 (ImageNet-pretrained) |
| Input resolution | 640 × 640 | 224 × 224 (opt. 384 fine-tune) |
| Optimiser | SGD / AdamW | AdamW [46] |
| LR schedule | cosine, warm-up | cosine, warm-up, layer-wise decay |
| Batch size | [fill in] | [fill in] |
| Epochs | [fill in] | Phase 1: [fill]; Phase 2: [fill] |
| Augmentation | mosaic, flip, HSV, scale | RRC, flip, colour jitter, RandAugment |
| Hardware | edge GPU (e.g. Jetson) | server GPU |

## 3.3 Datasets

Three categories of data support the system. For **Stage-1 detection**, public tomato leaf disease detection sets and field-style sets such as PlantDoc [28] provide bounding-box-annotated lesions, complemented by curated single-leaf imagery from the PlantVillage repository [26]. For **Stage-2 classification**, the large-scale IP102 insect-pest benchmark [29] supplies fine-grained pest categories, again complemented by leaf-disease classification data. A **self-collected greenhouse dataset**—wide-field and close-up image pairs captured under real production conditions and expert-annotated—is used to evaluate the integrated system under deployment-realistic distribution shift. Table 6 records the dataset composition; counts are placeholders to be completed by the author.

Table 6. Dataset composition (placeholder counts).

| Dataset | Role | Classes | Images | Annotation |
|---|---|---|---|---|
| Tomato leaf disease (public) | Stage-1 train/val | [n] | [n] | boxes |
| PlantDoc [28] | Stage-1 field test | [n] | [n] | boxes |
| IP102 [29] | Stage-2 train/val | up to 102 | ~75,000 | labels (subset: boxes) |
| Self-collected greenhouse | Integrated test | [n] | [n] | boxes + labels |

## 3.4 Evaluation Metrics

**Detection (Stage 1).** Detections are scored by Intersection over Union (IoU) between a predicted box $B_p$ and ground-truth box $B_{gt}$:

$$
\mathrm{IoU} = \frac{|B_p \cap B_{gt}|}{|B_p \cup B_{gt}|}.
$$

From IoU-thresholded matches we compute precision and recall,

$$
P = \frac{TP}{TP+FP}, \qquad R = \frac{TP}{TP+FN},
$$

and summarise the precision–recall curve by Average Precision (AP), the area under that curve, averaged over classes to give mean Average Precision (mAP). We report **mAP@0.5** (IoU threshold 0.5) and **mAP@0.5:0.95** (averaged over IoU thresholds from 0.5 to 0.95 in steps of 0.05), together with inference speed in frames per second (FPS) and model size (parameters), since real-time edge deployment is a design goal.

**Classification (Stage 2).** We report top-1 accuracy and, because the pest distribution is long-tailed, per-class precision and recall and the macro-averaged F1 score,

$$
F1 = \frac{2\,P\,R}{P+R},
$$

together with a confusion matrix to expose systematic inter-class errors.

### 3.4.1 Experimental Protocol

To make the comparison fair and the results trustworthy, all models within a stage are trained and evaluated under identical conditions: the same train/validation/test partition, the same input resolution, and the same augmentation budget, differing only in the architecture under test. Hyper-parameters are selected on the validation split only; the test split is touched once, for final reporting. Because deep-network training is stochastic, each configuration is run several times with different random seeds and results are reported as mean $\pm$ standard deviation, so that a claimed improvement can be distinguished from run-to-run noise; where appropriate, a paired significance test is applied to the per-image scores of two models. The self-collected greenhouse set is held out entirely from training and used only to measure performance under realistic distribution shift. Training uses early stopping on the validation metric to avoid over-fitting, and all software versions, seeds, and configurations are recorded for reproducibility.

## 3.5 Detection Results: Comparison with Prior Models

The improved detector is compared against representative prior models—Faster R-CNN [10], SSD [11], YOLOv5 [5], YOLOv7 [6], and the YOLOv8 baseline [7]—trained and evaluated under identical data splits and augmentation. Figure 8 and Table 7 report the comparison (illustrative values).

![Detection performance versus prior models (illustrative values; replace with measured results). Bars show mAP@0.5 and mAP@0.5:0.95; the dashed line shows inference speed (FPS).](figs/fig_det_compare.png)

Table 7. Detection comparison on the tomato lesion test set (ILLUSTRATIVE — replace with measured values).

| Model | mAP@0.5 (%) | mAP@0.5:0.95 (%) | Params (M) | FPS |
|---|---|---|---|---|
| Faster R-CNN [10] | 78.1 | 49.0 | 41.5 | 22 |
| SSD [11] | 74.5 | 45.2 | 24.0 | 61 |
| YOLOv5s [5] | 81.3 | 52.1 | 7.2 | 118 |
| YOLOv7 [6] | 83.0 | 54.3 | 36.9 | 96 |
| YOLOv8s [7] | 84.6 | 56.0 | 11.2 | 130 |
| **Ours (P2 + CA)** | **88.2** | **60.8** | 12.4 | 112 |

The intended narrative—to be confirmed by the author's data—is that the proposed detector achieves the highest mAP, with the largest relative gain on small lesions, while retaining real-time speed; the modest FPS reduction relative to the baseline is the expected cost of the high-resolution P2 branch.

## 3.6 Classification Results: Comparison with Prior Models

The transfer-learned classifier is compared against CNN baselines—ResNet-50 [18], MobileNetV3 [20], EfficientNet-B0 [19]—and against transformer baselines—a vanilla ViT-B/16 [15] and DeiT-B [16]—all fine-tuned on the same close-up data. Figure 9 and Table 8 report the comparison (illustrative values).

![Classification performance versus prior models (illustrative values; replace with measured results).](figs/fig_cls_compare.png)

Table 8. Classification comparison on the close-up pest test set (ILLUSTRATIVE — replace with measured values).

| Model | Top-1 Acc (%) | Macro F1 (%) | Params (M) |
|---|---|---|---|
| ResNet-50 [18] | 89.4 | 88.7 | 25.6 |
| MobileNetV3 [20] | 87.1 | 86.2 | 5.4 |
| EfficientNet-B0 [19] | 91.2 | 90.6 | 5.3 |
| ViT-B/16 [15] | 90.0 | 89.1 | 86.6 |
| DeiT-B [16] | 92.3 | 91.7 | 86.6 |
| **Ours (TL-ViT)** | **94.6** | **94.0** | 86.6 |

The intended finding is that the two-phase transfer-learning schedule lifts the transformer above both the CNN baselines and the naively fine-tuned transformer baselines, with the gain most pronounced on under-represented (long-tail) pest classes, where careful adaptation of the pre-trained features matters most. DeiT-B is included as a strong transformer baseline; the comparison isolates the effect of the adaptation schedule, since both it and our model share the same backbone capacity.

## 3.7 Ablation Studies

To isolate the contribution of each proposed change, Figure 10 reports two ablations: the detector with neither, either, or both of the P2 branch and Coordinate Attention; and the classifier across increasingly disciplined adaptation strategies, from training the backbone from scratch to the full two-phase transfer-learning schedule.

![Ablation studies (illustrative values; replace with measured results). Left: detector. Right: classifier.](figs/fig_ablation.png)

The detector ablation is intended to show that the P2 branch contributes the larger share of the small-object gain, that Coordinate Attention adds a further improvement chiefly by reducing false positives on cluttered high-resolution features, and that the two are complementary. The classifier ablation is intended to show that transfer learning is essential and that each element of the adaptation schedule—linear probing first, then layer-wise-decayed fine-tuning—contributes to the final result (analysed in detail in Section 3.7.1). A representative per-class error structure for the classifier is shown as a confusion matrix in Figure 11.

![Confusion matrix for the close-up pest classifier (illustrative). Off-diagonal mass indicates the most common inter-class confusions, e.g. between visually similar small insects.](figs/fig_confusion.png)

### 3.7.1 Transfer-Learning and Fine-Tuning Ablation

The classifier ablation above treats "the two-phase fine-tuning schedule" as a single switch. Because the transfer-learning strategy is the central contribution of the classifier stage and is easy to get wrong in practice, it warrants a finer-grained study of its own. Table 9 isolates the adaptation strategy while holding everything else fixed (the same ViT-B/16 backbone, the same data, augmentation, and epoch budget), varying *only* how the pretrained weights are adapted. Five strategies are compared: (a) training the backbone from scratch with no pretraining; (b) naive end-to-end fine-tuning from ImageNet weights with a random head; (c) linear probing alone (head trained, backbone permanently frozen); (d) the two-phase linear-probe-then-fine-tune (LP→FT) schedule but with a single global learning rate (no layer-wise decay); and (e) the full proposed schedule, LP→FT with layer-wise learning-rate decay (LLRD). Alongside top-1 accuracy and macro-F1 we report **tail-class F1**—the macro-F1 computed over the rarest third of the classes—since the long tail is where adaptation strategy matters most, and the **best validation epoch**, which exposes over-fitting.

Table 9. Effect of the transfer-learning and fine-tuning strategy on the close-up pest classifier, all else held equal (ILLUSTRATIVE — replace with measured values).

| # | Adaptation strategy | Top-1 Acc (%) | Macro F1 (%) | Tail-class F1 (%) | Best val. epoch |
|---|---|---|---|---|---|
| a | From scratch (no pretraining) | 71.5 | 68.9 | 52.1 | 92 |
| b | Naive full fine-tune (random head) | 90.8 | 89.6 | 80.4 | 23 |
| c | Linear probing only (backbone frozen) | 88.3 | 86.7 | 78.9 | 41 |
| d | Two-phase LP→FT, single global LR | 93.4 | 92.6 | 86.2 | 58 |
| e | **Two-phase LP→FT + LLRD (proposed)** | **94.6** | **94.0** | **89.1** | 63 |

The intended reading—to be confirmed by the author's measurements—is fourfold. First, from-scratch training (a) collapses on a dataset of this size, confirming that transfer is not optional but essential. Second, naive fine-tuning (b) recovers most of the accuracy but trails the disciplined schedules and, tellingly, reaches its best validation score very early (epoch 23) before degrading—the signature of the feature-distortion effect of Section 2.2.3, in which large early gradients from the random head corrupt the pretrained features. Third, linear probing alone (c) protects those features but cannot specialise them, so it under-performs on the fine-grained tail. Fourth, the two-phase schedule (d, e) combines the strengths of both, and adding layer-wise decay (e) gives a further gain that is largest on the tail classes, consistent with the argument that gentle updates to the lower layers preserve transferable structure while the upper layers specialise.

A second study examines the sensitivity of the full schedule to the layer-wise-decay factor $\xi$, the one new hyper-parameter the method introduces. Table 10 sweeps $\xi$ from aggressive decay ($\xi=0.5$, lower layers almost frozen) through no decay ($\xi=1.0$, a single global rate, equivalent to row d of Table 9). The intended finding is a shallow optimum near $\xi=0.75$: too small a value starves the lower layers of useful adaptation, while $\xi=1.0$ forfeits the protection that decay provides, with the difference again most visible on the tail.

Table 10. Sensitivity of the proposed schedule to the layer-wise learning-rate-decay factor $\xi$ (ILLUSTRATIVE — replace with measured values).

| $\xi$ | 0.50 | 0.65 | 0.75 | 0.90 | 1.00 |
|---|---|---|---|---|---|
| Top-1 Acc (%) | 93.1 | 94.0 | **94.6** | 94.1 | 93.4 |
| Macro F1 (%) | 92.3 | 93.4 | **94.0** | 93.5 | 92.6 |
| Tail-class F1 (%) | 85.0 | 87.6 | **89.1** | 87.2 | 86.2 |

Together these two tables turn "the fine-tuning schedule helps" into specific, testable claims: that pretraining is necessary, that the *order* of adaptation (probe first, then fine-tune) prevents an early-training pathology that is otherwise invisible in a single end-of-run accuracy number, that layer-wise decay adds a further tail-class gain, and that the method's single extra hyper-parameter has a broad, well-behaved optimum rather than a brittle one. Reporting the best-epoch column and the tail-class metric, in particular, is what makes the feature-distortion argument of Section 2.2.3 falsifiable rather than merely asserted.

## 3.8 Qualitative Results and Error Analysis

Beyond aggregate metrics, qualitative inspection is used to understand *how* the model succeeds or fails, since two models with similar mAP can behave very differently in practice. The improvements of Chapter 2 are expected to manifest in specific, visible ways: the P2 branch should recover small, early-stage lesions that the baseline misses entirely, shifting errors from missed detections (false negatives) toward, at worst, slightly imprecise boxes; Coordinate Attention should reduce false positives triggered by leaf veins, water droplets, and lighting gradients on the high-resolution feature map. For the classifier, the dominant residual errors are expected to be confusions between visually similar agents—for example among small sap-sucking insects, or between early symptoms of different foliar diseases—as reflected in the off-diagonal structure of the confusion matrix (Figure 11). The hardest cases are anticipated to be heavy occlusion, extreme back-lighting, and rare long-tail classes with few training examples; these define where additional data collection and the domain-adaptation work of the conclusion would be most valuable. Documenting representative success and failure crops, including the model's attention maps, is recommended both for transparency and because reviewers value seeing failure cases honestly reported.

## 3.9 Computational Cost and Deployment Considerations

Because the system is intended for real production use, computational cost is a first-class evaluation criterion alongside accuracy. The relevant quantities are the detector's edge latency and frame rate, the classifier's server-side throughput, peak memory on each device, and the upstream bandwidth required. The architecture is designed to keep these favourable: running the detector on the edge means only small crops and metadata, rather than full-resolution video, traverse the network, substantially reducing bandwidth; half-precision and engine-level optimisation keep edge latency within budget despite the added P2 branch; and batching crops amortises the classifier's per-image cost on the server. A deployment-cost table—edge latency, FPS, edge and server memory, and bandwidth per cycle—should be reported alongside the accuracy tables so that the accuracy gains of the proposed components can be weighed against their resource cost. Quantisation and detector–classifier co-distillation, noted in the conclusion, are the natural next steps for fully on-edge operation.

## 3.10 Discussion

Read together, the intended results support the thesis's central design choice: matching model family to spatial scale. Stage 1 shows that a small number of scale-aware modifications recover the small-lesion sensitivity that early warning requires, without sacrificing the real-time speed that makes YOLOv8 attractive in the first place. Stage 2 shows that the data-efficiency problem that normally discourages the use of transformers on specialised agricultural data can be addressed directly, through disciplined transfer learning, rather than by abandoning the transformer for a CNN.

Several limitations should be stated honestly. The placeholder results must be replaced by measured values, and the conducive-condition forecasting rule is deliberately simple. The system's accuracy under severe occlusion, extreme lighting, and rare pest classes remains to be characterised on the self-collected greenhouse set, and the close-up capture step assumes either a PTZ camera or sufficient wide-field resolution. These are addressed as future work.

\newpage

# Conclusion and Future Work

This thesis proposed and described in detail a two-stage visual framework for forecasting pests and diseases in greenhouse tomatoes. The first stage improves YOLOv8 for small-lesion detection in distant canopy images through two targeted, individually justified changes—a high-resolution P2 detection branch and a Coordinate Attention module before the heads. The second stage makes a Vision Transformer data-efficient for fine-grained pest identification in close-up images through transfer learning, using a two-phase linear-probe-then-fine-tune schedule with layer-wise learning-rate decay. The two stages are integrated into a sensing-to-decision system whose classified detections drive a simple, interpretable early-warning module. An evaluation protocol against representative prior detection and classification models, together with ablation studies, was specified to isolate the effect of each contribution.

Future work falls into three directions. First, the forecasting module can be strengthened with explicit temporal models (for example, sequence models that combine incidence trends with greenhouse micro-climate covariates) to move from threshold-based alerts toward calibrated risk prediction. Second, the classifier could be pushed further on data efficiency by adding token-based knowledge distillation from a convolutional teacher [16; 17] on top of the transfer-learning schedule used here—deliberately left out of the present scope so that the contribution of transfer learning could be measured in isolation—and the system as a whole can be made lighter through detector–classifier co-distillation and quantisation for fully on-edge operation. Third, robustness can be improved through domain adaptation between public training data and the self-collected greenhouse distribution, and through targeted collection of rare, long-tail pest classes. Completing the empirical evaluation with measured results on the self-collected dataset is the immediate next step.

\newpage
# References

The foundational references below (architectures, attention modules, datasets, and learning methods) are well-established works whose citation details are reliable. The recent domain-specific references on tomato disease detection and plant-disease transformers were retrieved during drafting; the author should verify exact page numbers, volume, and DOI against the publisher of record before final submission.

[1] J. Redmon, S. Divvala, R. Girshick, and A. Farhadi, "You Only Look Once: Unified, Real-Time Object Detection," in *Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 779–788.

[2] J. Redmon and A. Farhadi, "YOLO9000: Better, Faster, Stronger," in *Proc. IEEE CVPR*, 2017, pp. 7263–7271.

[3] J. Redmon and A. Farhadi, "YOLOv3: An Incremental Improvement," *arXiv:1804.02767*, 2018.

[4] A. Bochkovskiy, C.-Y. Wang, and H.-Y. M. Liao, "YOLOv4: Optimal Speed and Accuracy of Object Detection," *arXiv:2004.10934*, 2020.

[5] G. Jocher et al., "Ultralytics YOLOv5," software, 2020. [Online]. Available: https://github.com/ultralytics/yolov5

[6] C.-Y. Wang, A. Bochkovskiy, and H.-Y. M. Liao, "YOLOv7: Trainable Bag-of-Freebies Sets New State-of-the-Art for Real-Time Object Detectors," in *Proc. IEEE/CVF CVPR*, 2023, pp. 7464–7475.

[7] G. Jocher, A. Chaurasia, and J. Qiu, "Ultralytics YOLOv8," software, 2023. [Online]. Available: https://github.com/ultralytics/ultralytics

[8] R. Girshick, J. Donahue, T. Darrell, and J. Malik, "Rich Feature Hierarchies for Accurate Object Detection and Semantic Segmentation," in *Proc. IEEE CVPR*, 2014, pp. 580–587.

[9] R. Girshick, "Fast R-CNN," in *Proc. IEEE Int. Conf. Computer Vision (ICCV)*, 2015, pp. 1440–1448.

[10] S. Ren, K. He, R. Girshick, and J. Sun, "Faster R-CNN: Towards Real-Time Object Detection with Region Proposal Networks," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2015, pp. 91–99.

[11] W. Liu et al., "SSD: Single Shot MultiBox Detector," in *Proc. European Conf. Computer Vision (ECCV)*, 2016, pp. 21–37.

[12] T.-Y. Lin et al., "Feature Pyramid Networks for Object Detection," in *Proc. IEEE CVPR*, 2017, pp. 2117–2125.

[13] T.-Y. Lin, P. Goyal, R. Girshick, K. He, and P. Dollár, "Focal Loss for Dense Object Detection," in *Proc. IEEE ICCV*, 2017, pp. 2980–2988.

[14] A. Vaswani et al., "Attention Is All You Need," in *NeurIPS*, 2017, pp. 5998–6008.

[15] A. Dosovitskiy et al., "An Image Is Worth 16×16 Words: Transformers for Image Recognition at Scale," in *Proc. Int. Conf. Learning Representations (ICLR)*, 2021.

[16] H. Touvron, M. Cord, M. Douze, F. Massa, A. Sablayrolles, and H. Jégou, "Training Data-Efficient Image Transformers & Distillation Through Attention," in *Proc. Int. Conf. Machine Learning (ICML)*, vol. 139, 2021, pp. 10347–10357.

[17] G. Hinton, O. Vinyals, and J. Dean, "Distilling the Knowledge in a Neural Network," *arXiv:1503.02531*, 2015.

[18] K. He, X. Zhang, S. Ren, and J. Sun, "Deep Residual Learning for Image Recognition," in *Proc. IEEE CVPR*, 2016, pp. 770–778.

[19] M. Tan and Q. V. Le, "EfficientNet: Rethinking Model Scaling for Convolutional Neural Networks," in *Proc. ICML*, 2019, pp. 6105–6114.

[20] A. Howard et al., "Searching for MobileNetV3," in *Proc. IEEE/CVF ICCV*, 2019, pp. 1314–1324.

[21] S. Woo, J. Park, J.-Y. Lee, and I. S. Kweon, "CBAM: Convolutional Block Attention Module," in *Proc. ECCV*, 2018, pp. 3–19.

[22] Q. Hou, D. Zhou, and J. Feng, "Coordinate Attention for Efficient Mobile Network Design," in *Proc. IEEE/CVF CVPR*, 2021, pp. 13713–13722.

[23] J. Hu, L. Shen, and G. Sun, "Squeeze-and-Excitation Networks," in *Proc. IEEE/CVF CVPR*, 2018, pp. 7132–7141.

[24] Z. Liu et al., "Swin Transformer: Hierarchical Vision Transformer Using Shifted Windows," in *Proc. IEEE/CVF ICCV*, 2021, pp. 10012–10022.

[25] N. Carion et al., "End-to-End Object Detection with Transformers," in *Proc. ECCV*, 2020, pp. 213–229.

[26] D. P. Hughes and M. Salathé, "An Open Access Repository of Images on Plant Health to Enable the Development of Mobile Disease Diagnostics," *arXiv:1511.08060*, 2015.

[27] S. P. Mohanty, D. P. Hughes, and M. Salathé, "Using Deep Learning for Image-Based Plant Disease Detection," *Frontiers in Plant Science*, vol. 7, art. 1419, 2016.

[28] D. Singh, N. Jain, P. Jain, P. Kayal, S. Kumawat, and N. Batra, "PlantDoc: A Dataset for Visual Plant Disease Detection," in *Proc. 7th ACM IKDD CoDS and 25th COMAD*, 2020, pp. 249–253.

[29] X. Wu, C. Zhan, Y.-K. Lai, M.-M. Cheng, and J. Yang, "IP102: A Large-Scale Benchmark Dataset for Insect Pest Recognition," in *Proc. IEEE/CVF CVPR*, 2019, pp. 8787–8796.

[30] A. Krizhevsky, I. Sutskever, and G. E. Hinton, "ImageNet Classification with Deep Convolutional Neural Networks," in *NeurIPS*, 2012, pp. 1097–1105.

[31] J. Deng, W. Dong, R. Socher, L.-J. Li, K. Li, and L. Fei-Fei, "ImageNet: A Large-Scale Hierarchical Image Database," in *Proc. IEEE CVPR*, 2009, pp. 248–255.

[32] K. Simonyan and A. Zisserman, "Very Deep Convolutional Networks for Large-Scale Image Recognition," in *Proc. ICLR*, 2015.

[33] "Optimization of Improved YOLOv8 for Precision Tomato Leaf Disease Detection in Sustainable Agriculture," *Sensors / PMC*, 2025. [Online]. Available: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11902794/

[34] Q. Dong, F. Wang, M. Tang et al., "RSA-YOLO: An Improved YOLOv8-Based Model for Tomato Leaf Disease Detection," *Signal, Image and Video Processing*, vol. 20, art. 77, 2026, doi: 10.1007/s11760-026-05125-8.

[35] "Tomato Leaf Disease Detection Method Based on Improved YOLOv8n," *Scientific Reports*, vol. 15, 2025, doi: 10.1038/s41598-025-00405-8.

[36] "A Deep-Learning-Based Model for the Detection of Diseased Tomato Leaves," *Agronomy*, vol. 14, no. 7, art. 1593, 2024, doi: 10.3390/agronomy14071593.

[37] "Plant Leaf Disease Detection Using Vision Transformers for Precision Agriculture," *Scientific Reports*, vol. 15, 2025, doi: 10.1038/s41598-025-05102-0.

[38] "Lightweight Vision Transformer and ResNet-9 Models for Real-Time Plant Disease Detection and Pest Classification with SHAP Explainability," *BMC Plant Biology*, 2026, doi: 10.1186/s12870-026-08667-8.

[39] "Attention Score-Based Multi-Vision Transformer Technique for Plant Disease Classification," *Sensors / PMC*, 2025. [Online]. Available: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11723448/

[40] "Multi-Stage Vision Transformer and Knowledge Graph Fusion for Enhanced Plant Disease Classification," *Computer Systems Science and Engineering*, 2025.

[41] J. Terven and D. Córdova-Esparza, "A Comprehensive Review of YOLO Architectures in Computer Vision: From YOLOv1 to YOLOv8 and Beyond," *Machine Learning and Knowledge Extraction*, vol. 5, no. 4, pp. 1680–1716, 2023.

[42] "A Comprehensive Review on YOLO Versions for Object Detection," *Journal of King Saud University – Computer and Information Sciences / ScienceDirect*, 2025, doi: 10.1016/j.jksuci.2025.

[43] "Tomato Leaf Disease Detection Method Based on Multi-Scale Feature Fusion," *PMC*, 2025. [Online]. Available: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC12567417/

[44] R. R. Selvaraju et al., "Grad-CAM: Visual Explanations from Deep Networks via Gradient-Based Localization," in *Proc. IEEE ICCV*, 2017, pp. 618–626.

[45] S. M. Lundberg and S.-I. Lee, "A Unified Approach to Interpreting Model Predictions," in *NeurIPS*, 2017, pp. 4765–4774.

[46] I. Loshchilov and F. Hutter, "Decoupled Weight Decay Regularization," in *Proc. ICLR*, 2019.

[47] Z. Zheng et al., "Distance-IoU Loss: Faster and Better Learning for Bounding Box Regression," in *Proc. AAAI Conf. Artificial Intelligence*, 2020, pp. 12993–13000.

[48] Z. Ge, S. Liu, F. Wang, Z. Li, and J. Sun, "YOLOX: Exceeding YOLO Series in 2021," *arXiv:2107.08430*, 2021.

[49] A. Kumar, A. Raghunathan, R. Jones, T. Ma, and P. Liang, "Fine-Tuning Can Distort Pretrained Features and Underperform Out-of-Distribution," in *Proc. Int. Conf. Learning Representations (ICLR)*, 2022.
