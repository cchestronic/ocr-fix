---
title: "Estimation of Nitrogen and Phosphorus Status and Fertilizer Recommendation for Rice and Wheat from Low-Altitude RGB Drone Imagery Using a Dual-Pathway Multi-Task Deep Neural Network"
author: "[Author names]"
date: "2026"
---

\newpage

# Reading Guide

This paper is organized into three chapters and five appendices.

Chapter 1 reviews earlier work and defines the problem. A reader who wants the motivation and the formal problem definition should read this chapter first. The chapter also explains, in simple terms, why nitrogen and phosphorus appear differently in an image. This explanation is the basis of the whole method.

Chapter 2 presents the two proposed solutions. The first solution is the two-tier framework. The second solution is the dual-pathway multi-task network. A reader who is mainly interested in the network design should focus on Section 2.3.

Chapter 3 describes the implementation and the evaluation. A reader who is mainly interested in the experimental method and the results should focus on Sections 3.2 and 3.5. All numerical results in Chapter 3 are projected values and are marked as such. They are not measured results. They show the expected pattern and the format of the evaluation, and must be replaced by measured values after the experiment.

The appendices contain the reference list, the figure credits, the notation, a glossary of terms, a step-by-step procedure, and a field data collection checklist. The glossary and the notation are provided to help readers from different fields and to support translation into other languages.

\newpage

# Abstract

Fertilizer management is a central task in crop production. Too little fertilizer reduces yield. Too much fertilizer raises cost and causes environmental damage. Farmers need a low-cost method to decide how much nitrogen and phosphorus to apply, and they need this method to work at the scale of a whole field.

This paper studies how to estimate the nitrogen and phosphorus status of rice and wheat from images taken by an unmanned aerial vehicle (UAV). The UAV flies at an altitude of 100 metres and carries only a standard red-green-blue (RGB) camera. An RGB camera is far cheaper than a multispectral camera, so an RGB-based method is easier to use in practice. The main difficulty is that an RGB camera does not record the red-edge and near-infrared light that most earlier studies used to measure nitrogen. The difficulty is larger for phosphorus, because phosphorus has only a weak and indirect visual signal.

We propose a method built on two ideas. The first idea is a two-tier structure. A perception network estimates crop nutrient status from the image. A separate decision layer then converts this status into a fertilizer rate using agronomic rules. The second idea is a dual-pathway multi-task network. One pathway reads colour information, which carries the nitrogen signal. A second pathway reads canopy structure, which carries the phosphorus and biomass signal. The two pathways share a single network that predicts nitrogen status, phosphorus status, and above-ground biomass at the same time. A single model serves both rice and wheat through crop conditioning.

We describe the design of the network in detail. We also describe the data requirements, the training method for a small labelled dataset, and an evaluation protocol that avoids common errors. The evaluation protocol uses cross-validation that is blocked by field and by season. The projected results show that nitrogen status and biomass can be estimated with useful accuracy, while phosphorus status is harder and must be reported with care. Because the image is taken in the middle of the season but phosphorus is applied before sowing, nitrogen gives a direct in-season fertilizer rate, while phosphorus is delivered as a status and deficiency map with diagnostic and next-season planning value. The paper states the limitations of RGB-based phosphorus estimation in clear terms.

**Keywords:** precision agriculture; nitrogen nutrition index; phosphorus; unmanned aerial vehicle; RGB imagery; deep learning; multi-task learning; rice; wheat; variable-rate fertilization.

\newpage

# List of Abbreviations

| Abbreviation | Meaning |
|---|---|
| UAV | Unmanned aerial vehicle |
| RGB | Red, green, blue (colour image channels) |
| GSD | Ground sample distance |
| VI | Vegetation index |
| ExG | Excess green index |
| VARI | Visible atmospherically resistant index |
| GLI | Green leaf index |
| NGRDI | Normalized green-red difference index |
| N | Nitrogen |
| P | Phosphorus |
| NNI | Nitrogen nutrition index |
| PNI | Phosphorus nutrition index |
| GDD | Growing degree days |
| CNN | Convolutional neural network |
| FiLM | Feature-wise linear modulation |
| SSL | Self-supervised learning |
| EONR | Economic optimum nitrogen rate |
| RMSE | Root mean square error |
| rRMSE | Relative root mean square error |
| CV | Cross-validation |

\newpage

# List of Figures

- Figure 1.1. Overall concept of the two-tier UAV fertilizer-recommendation system.
- Figure 2.1. The two-tier perception–decision framework.
- Figure 2.2. The dual-pathway multi-task network (high-level view).
- Figure 2.3. Detailed layer-level architecture of the dual-pathway multi-task network.
- Figure 3.0. Illustrative aerial views of a rice field and a wheat field.
- Figure 3.1. The per-plot image preparation pipeline.
- Figure 3.2. Projected predicted-versus-measured plots for nitrogen, phosphorus, and biomass.
- Figure 3.3. Projected accuracy by crop and projected ablation results.
- Figure 3.4. Interpretability concept (schematic).
- Figure 3.5. Illustrative prescription map (projected output).

# List of Tables

- Table 2.1. Visible-band vegetation indices used as input channels.
- Table 2.2. Example network configuration.
- Table 2.3. Main design decisions (summary).
- Table 3.1. Planned dataset summary.
- Table 3.2. Projected status estimation accuracy.
- Table 3.3. Projected accuracy by crop.
- Table 3.4. Projected decision-tier and agronomic outcomes.
- Table 3.5. Projected ablation study.
- Table 3.6. Example training settings.

\newpage
# Chapter 1. Literature Review and Problem Formulation

## 1.1 Introduction

### 1.1.1 Background and motivation

Rice and wheat are two of the most important food crops in the world. Many countries depend on them for daily nutrition. The yield of these crops depends strongly on fertilizer, and the two most important nutrients are nitrogen and phosphorus. Nitrogen controls leaf growth, canopy size, and grain protein. Phosphorus controls root growth, energy transfer inside the plant, early development, and the number of tillers.

The amount of fertilizer must be chosen with care. If a farmer applies too little nitrogen or phosphorus, the crop grows slowly and the yield is low. If a farmer applies too much, the extra fertilizer is wasted. The extra cost reduces profit. The extra nutrient also leaves the field and pollutes water and air. Nitrogen loss causes nitrate in groundwater and greenhouse gas emission. Phosphorus loss causes algal growth in rivers and lakes. For these reasons, the correct fertilizer amount is both an economic question and an environmental question.

The correct amount is not the same across a whole field. Soil changes from place to place. Crop growth changes from place to place. A single uniform rate applied to the whole field is therefore not efficient. A better approach gives more fertilizer where the crop needs more, and less fertilizer where the crop needs less. This approach is called variable-rate fertilization. Variable-rate fertilization needs a map of crop nutrient status across the field. The central technical problem is how to produce this map at low cost.

### 1.1.2 Unmanned aerial vehicles and why RGB

An unmanned aerial vehicle, or UAV, is a small aircraft that is flown without a pilot on board. A UAV can carry a camera and fly over a field in a few minutes. It produces images with high spatial detail. A UAV is now a common tool in precision agriculture because it is fast, flexible, and does not need a satellite schedule.

The camera on the UAV decides what information can be measured. Two camera types are common. A multispectral camera records several narrow bands of light, including red-edge light and near-infrared light. These bands are strongly related to chlorophyll and to plant health. A red-green-blue camera, called an RGB camera, records only the three bands that the human eye can see. An RGB camera is much cheaper than a multispectral camera. It is also lighter, easier to use, and already present on most consumer UAVs.

This paper studies the RGB camera only. The reason is practical. A low-cost method based on an RGB camera can reach many more farmers, especially in regions where budgets are small. The scientific challenge is that the RGB camera does not record the red-edge and near-infrared bands. Most earlier methods for nitrogen estimation used exactly those bands. We must therefore design a method that works from colour and canopy structure alone.

### 1.1.3 Nitrogen and phosphorus in rice and wheat

Nitrogen and phosphorus differ in how they appear in an image. This difference is the key idea of the paper, so we state it early.

Nitrogen has a clear colour signal. When a plant has enough nitrogen, the leaves are dark green. When a plant lacks nitrogen, the leaves turn pale green and then yellow. This colour change is visible to an RGB camera. The nitrogen signal is therefore mostly a colour signal.

Phosphorus has a weak colour signal. A shortage of phosphorus does not usually turn the leaves yellow. Instead, it makes the plant grow more slowly. The plant becomes smaller. It produces fewer tillers. The canopy covers less ground. In some cases the leaves become dull or show a slight red or purple tint, but this tint is much weaker in rice and wheat than in maize. The phosphorus signal is therefore mostly a growth signal and a structure signal, not a colour signal.

This contrast is the reason a single simple model is not enough. Nitrogen must be read from colour. Phosphorus must be read from canopy structure and from plant size, which are linked to above-ground biomass. A good network must capture both kinds of information.

### 1.1.4 Problem statement

We state the problem as follows. A UAV flies over a rice field or a wheat field at an altitude of 100 metres. The UAV carries an RGB camera. The flight happens once, at a single fixed growth stage, which is the stage at which the in-season fertilizer decision is made. We stress that this stage is in the middle of the season, when the crop already has a developed canopy. The flight is not made at sowing, and the image is never of bare soil. The crop has been taking up nitrogen and phosphorus since germination, so its canopy carries a signal of both nutrients at the time of the flight.

From the resulting image, the system must estimate the nitrogen status and the phosphorus status of the crop. For nitrogen, the system then recommends an in-season nitrogen rate, because nitrogen can be applied as a top dressing during the season. For phosphorus, the situation is different. Phosphorus is usually applied before or at sowing, as a basal dressing, when there is no crop to image. A single mid-season image therefore cannot change the basal phosphorus dose of the current crop. For phosphorus, the system instead produces a status and deficiency map, which has a diagnostic value for the current season and a planning value for the basal phosphorus dose of the next season. This difference between the two nutrients is treated carefully throughout the paper.

The labelled data available for training is small, because ground measurement of nitrogen and phosphorus requires plant sampling and laboratory analysis. The method must therefore work well with few labelled samples.

### 1.1.5 Research questions

This paper addresses four research questions.

1. Can nitrogen status be estimated from RGB UAV imagery with useful accuracy, without red-edge or near-infrared bands?
2. To what degree can phosphorus status be recovered from RGB imagery, given that its visual signal is weak and indirect?
3. Can a single network serve both rice and wheat, instead of two separate models?
4. How should the system be evaluated so that the reported accuracy is honest and transfers to new fields and new seasons?

### 1.1.6 Contributions

This paper makes the following contributions.

1. A two-tier formulation that separates the learned estimation of crop nutrient status from the agronomic decision of the fertilizer rate. This separation keeps the method interpretable and defensible.
2. A dual-pathway multi-task network that reads the nitrogen signal from colour and the phosphorus signal from canopy structure, and that predicts nitrogen status, phosphorus status, and biomass together. A single model serves both rice and wheat through crop conditioning.
3. A clear and honest treatment of the phosphorus problem. This includes an evaluation that tests whether the phosphorus estimate is better than simple baselines, and a correct framing of the phosphorus output as a diagnostic and planning map rather than an in-season basal rate, because phosphorus is applied basally before the crop can be imaged.
4. An evaluation protocol based on cross-validation blocked by field and by season, which avoids the optimistic bias of random data splits.

### 1.1.7 Structure of the paper

The paper has three chapters. Chapter 1 reviews earlier work and formulates the problem. Chapter 2 presents the two proposed solutions. Chapter 3 describes the system implementation and the performance evaluation. Figure 1.1 shows the overall concept of the system.

![Figure 1.1. Overall concept of the two-tier UAV fertilizer-recommendation system. The UAV captures RGB images at 100 metres. A perception network (Tier 1) estimates nitrogen, phosphorus, and biomass status. A decision layer (Tier 2) converts status into a variable-rate fertilizer map.](figures/fig_concept.png)

### 1.1.8 Scope and assumptions

We state the scope of the paper clearly, so that the reader knows the limits of the claims.

The paper studies rice and wheat. It does not study other crops. The paper studies a single flight at a fixed growth stage. It does not study a full time series of flights. The paper uses an RGB camera only. It does not use a multispectral or hyperspectral camera. The paper studies nitrogen and phosphorus. It does not study other nutrients, such as potassium.

The paper makes three assumptions. The first assumption is that the flight is made at the growth stage at which the fertilizer decision is made, and that this stage is similar across plots. The second assumption is that ground-truth measurements of nitrogen, phosphorus, and biomass are available for a set of plots. The third assumption is that a large pool of unlabelled images is available for self-supervised pretraining. These assumptions match the design of the field trials in Chapter 3.

### 1.1.9 Environmental importance of correct fertilization

The correct fertilizer amount is not only an economic question. It is also an environmental question, and this question is now central to agriculture.

Excess nitrogen leaves the field in two main ways. It can dissolve in water as nitrate and move into groundwater and rivers. High nitrate in drinking water is a health risk. Nitrogen can also leave as gas, including nitrous oxide, which is a strong greenhouse gas. Excess phosphorus leaves the field mainly by attaching to soil particles and moving into rivers and lakes with eroded soil. In the water, the extra phosphorus feeds the growth of algae. This process is called eutrophication. It reduces oxygen in the water and harms fish and other life.

A method that matches the fertilizer amount to the crop need reduces both kinds of loss. It applies fertilizer where the crop will use it, and it avoids excess where the crop does not need it. In this way, the method supports both profit and environmental protection. This double benefit is a strong reason to develop low-cost tools for nutrient management.

## 1.2 Literature Review

### 1.2.1 UAV remote sensing for crop monitoring

UAV remote sensing has become a standard tool in precision agriculture. A UAV can capture images at a spatial detail of a few centimetres per pixel. This detail is much finer than most satellite images. The high detail allows measurement at the level of small plots and even single plants.

Earlier studies have used UAV imagery for many tasks. These tasks include the estimation of leaf area, the detection of weeds, the detection of disease, the estimation of yield, and the estimation of nitrogen status. Most of these studies used either a multispectral camera or a combination of RGB and multispectral cameras. The present paper focuses on the RGB camera because of its low cost and wide availability.

An important factor in UAV remote sensing is radiometric stability. The brightness of an image depends on the light during the flight. Clouds, sun angle, and time of day all change the brightness. Multispectral systems often use a calibration panel and a light sensor to correct for these changes. RGB systems usually do not have these tools. A method based on RGB must therefore be robust to changes in brightness. We return to this point in Chapter 2 and Chapter 3.

### 1.2.2 Nitrogen estimation from imagery

Nitrogen estimation from imagery has a long history. The most common approach uses a vegetation index. A vegetation index is a simple formula that combines image bands into a single number. The number is designed to track a plant property, such as greenness or chlorophyll content.

When red-edge and near-infrared bands are available, indices such as the normalized difference vegetation index and the red-edge chlorophyll index are strong predictors of nitrogen status. These indices are widely used and well understood. However, they require bands that an RGB camera does not record.

For an RGB camera, researchers use visible-band vegetation indices. These indices combine only the red, green, and blue channels. Common examples are the excess green index, the visible atmospherically resistant index, the green leaf index, and the normalized green-red difference index. These indices capture the green-versus-yellow balance of the canopy. They are weaker than red-edge indices, but they still carry useful nitrogen information, because the nitrogen signal is mainly a colour signal.

A known weakness of simple vegetation indices is saturation. When the canopy is dense and dark green, the index stops increasing even as nitrogen content keeps rising. This weakness limits the accuracy of index-based methods at high biomass. Deep learning methods can, in principle, learn features that are less affected by saturation, because they use spatial pattern and texture in addition to average colour.

### 1.2.3 Phosphorus estimation from imagery

Phosphorus estimation from imagery is far less developed than nitrogen estimation. The reason is biological. Phosphorus shortage does not create a strong and specific colour change in rice and wheat. Instead, it slows growth and reduces canopy size. These effects are also caused by other stresses, such as water shortage, nitrogen shortage, and disease. Phosphorus is therefore confounded with many other factors.

A small number of studies have reported links between spectral data and phosphorus content. Most of these studies used hyperspectral data, which records many narrow bands. Results from RGB data are rare and usually weak. This paper does not claim that RGB imagery contains a strong phosphorus signal. Instead, it studies how much phosphorus information can be recovered indirectly, mainly through canopy structure and biomass, and it reports the result honestly.

### 1.2.4 Deep learning in precision agriculture

Deep learning has become the dominant method in image analysis. A convolutional neural network, or CNN, learns features directly from image data. It does not need hand-designed features. CNNs have achieved strong results in crop classification, disease detection, and yield estimation.

Several network families are relevant to this paper. Residual networks introduced skip connections that allow deep networks to train well. Efficient networks improved the balance between accuracy and computation. Vision transformers and their hierarchical versions apply attention mechanisms to images and have reached strong results on large datasets. For the small datasets common in agriculture, smaller CNNs with strong regularization are often the most reliable choice.

A limitation of deep learning in agriculture is data. Labelled agricultural data is expensive, because it requires field sampling and laboratory analysis. This limitation motivates methods that use data efficiently, such as transfer learning, self-supervised learning, and multi-task learning. Chapter 2 and Chapter 3 describe how this paper uses these methods.

### 1.2.5 Multi-task learning and conditioned networks

Multi-task learning trains one network to predict several related outputs at the same time. The outputs share a common feature representation. Multi-task learning has two benefits. It uses each labelled sample more fully, because each sample supervises several outputs. It also acts as a form of regularization, because the shared representation must serve all tasks. In this paper, the network predicts nitrogen status, phosphorus status, and biomass together. The biomass task is especially useful, because it provides a strong and learnable signal that supports the phosphorus task.

Conditioned networks change their behaviour based on an extra input. Feature-wise linear modulation, known as FiLM, is a simple and effective conditioning method. It uses a conditioning input to produce a scale factor and a shift factor for each feature channel. In this paper, the conditioning input is the crop type and the growth information. This lets one network adapt to both rice and wheat without training two separate models.

### 1.2.6 Research gap

The review shows a clear gap. Most earlier methods for nitrogen estimation rely on red-edge or near-infrared bands, which an RGB camera does not record. Phosphorus estimation from RGB imagery is almost absent. Few methods estimate nitrogen and phosphorus together. Few methods serve two crops with one model. Many studies also use random data splits, which produce optimistic accuracy because nearby image patches are correlated.

This paper addresses the gap directly. It studies nitrogen and phosphorus estimation from RGB imagery alone, for both rice and wheat, with one model, and with an honest evaluation protocol.

### 1.2.7 Physical basis of the nitrogen and phosphorus signals

It is useful to explain why nitrogen and phosphorus appear so differently in an image. The explanation lies in the optical properties of leaves and canopies.

A green leaf interacts with light in a selective way. The green pigment, chlorophyll, absorbs strongly in the blue region and the red region of visible light. It absorbs less in the green region. For this reason, a healthy leaf reflects more green light and appears green to the eye. When a plant has plenty of nitrogen, it produces more chlorophyll, and the leaf appears a darker and more saturated green. When nitrogen is short, the leaf produces less chlorophyll, the red and blue absorption falls, and the leaf appears paler and more yellow. This chain of effects is the physical reason that nitrogen status is visible as a colour change in an RGB image. The red, green, and blue channels together measure the balance of absorbed and reflected light in the visible range, and this balance tracks chlorophyll, which in turn tracks nitrogen.

Phosphorus does not act through a pigment in the same direct way. Phosphorus is central to energy transfer and to the formation of new cells. A shortage of phosphorus slows cell division and reduces the rate of growth. The plant produces fewer tillers, shorter stems, and a smaller leaf area. In some species, a phosphorus shortage also causes the build-up of sugars, which can lead to the formation of red or purple pigments called anthocyanins. In maize this red tint is often clear. In rice and wheat the tint is weak and inconsistent. Therefore, the main effect of phosphorus shortage in rice and wheat is a reduction in plant size and canopy cover, not a change in leaf colour. This is the physical reason that phosphorus status must be read from canopy structure, and why it is harder to measure from an RGB image.

This physical understanding guides the network design in Chapter 2. A pathway that reads colour is well suited to nitrogen. A pathway that reads canopy size and density is needed for phosphorus. The design follows directly from the biology.

### 1.2.8 The role of spatial detail and texture

A further point concerns spatial detail. A single average colour of a plot loses much information. Two plots can have the same average colour but a different pattern of light and dark, caused by different canopy structure. This pattern is called texture. Texture carries information about the density of the canopy, the size of the plants, and the pattern of gaps between plants. These properties are linked to biomass and to phosphorus status.

A simple vegetation index uses only the average colour and ignores texture. A convolutional neural network, by contrast, can use texture, because it processes the spatial pattern of the image. This is one of the main reasons that a deep network can outperform a simple index, especially for phosphorus and biomass, where structure matters more than colour. The structural pathway in Chapter 2 is designed to exploit this texture information.

## 1.3 Problem Formulation

### 1.3.1 Notation and task definition

We now define the task in formal terms. Let $x$ be an RGB image patch of a crop plot, captured by the UAV at the fixed growth stage. Let $c \in \{\text{rice}, \text{wheat}\}$ be the crop type. Let $t$ be the growth information of the plot, expressed as growing degree days. The growing degree days measure the accumulated temperature since sowing or transplanting. They describe how far the crop has developed.

The system has two stages. The first stage is a perception function $f$. It maps the image and the side information to the crop nutrient status:

$$
(\hat{s}_N, \hat{s}_P, \hat{b}) = f(x, c, t; \theta),
$$

where $\hat{s}_N$ is the estimated nitrogen status, $\hat{s}_P$ is the estimated phosphorus status, $\hat{b}$ is the estimated above-ground biomass, and $\theta$ are the network parameters. The second stage is a decision function $g$. It maps the estimated status to the fertilizer rates:

$$
(r_N, r_P) = g(\hat{s}_N, \hat{s}_P, \hat{b}, c, t),
$$

where $r_N$ is the recommended nitrogen rate and $r_P$ is the recommended phosphorus rate, both in kilograms per hectare. The function $f$ is learned from data. The function $g$ is an agronomic rule and is not learned. This separation is the first proposed solution and is described in Chapter 2.

### 1.3.2 Nutrient status targets

We must choose a target quantity for nutrient status. A raw nutrient concentration is not the best target, because the correct concentration changes as the crop grows. A larger plant naturally has a lower nutrient concentration, even when it is healthy. This effect is called dilution. To remove this effect, we use a nutrition index.

The nitrogen nutrition index, or NNI, compares the actual nitrogen concentration with the critical nitrogen concentration. The critical nitrogen concentration is the lowest concentration that still allows maximum growth. It depends on the crop biomass through a dilution curve:

$$
N_c = a \, W^{-b},
$$

where $N_c$ is the critical nitrogen concentration, $W$ is the above-ground biomass, and $a$ and $b$ are crop-specific constants. The nitrogen nutrition index is then

$$
\text{NNI} = \frac{N_a}{N_c},
$$

where $N_a$ is the actual measured nitrogen concentration. An NNI value near one means the crop has enough nitrogen. A value below one means a shortage. A value above one means an excess.

We define the phosphorus nutrition index, or PNI, in the same way, using the relationship between phosphorus and nitrogen inside the plant:

$$
\text{PNI} = \frac{P_a}{P_c},
$$

where $P_a$ is the actual phosphorus concentration and $P_c$ is the critical phosphorus concentration for the current crop state. The use of a nutrition index has an extra benefit for our method. Because the index already accounts for crop size, the target depends less on growth stage. This reduces, but does not remove, the effect of growth stage on the learning problem.

### 1.3.3 The two-tier decomposition

The two functions $f$ and $g$ form the two tiers of the system. The perception tier is a learning problem. It must extract nutrient status from an image. The decision tier is an agronomic problem. It must choose a fertilizer rate from the status, the growth stage, and economic factors.

A simple design of the decision function uses the deficit relative to a target status. For nitrogen, the recommended rate increases as the estimated status falls below the target:

$$
r_N = k_N \, (\text{NNI}^{*} - \hat{s}_N)_{+} \, ,
$$

where $\text{NNI}^{*}$ is the target status, $k_N$ is a crop-specific and stage-specific coefficient that converts a status deficit into a mass of fertilizer, and $(\cdot)_{+}$ means that negative values are set to zero, because no fertilizer is added when the status is already at or above the target. The phosphorus rate follows the same form. This design is simple and transparent. More advanced designs are possible, and we discuss them in Chapter 2.

We keep the two tiers separate for three reasons. First, the separation makes the method easy to understand. A user can see the estimated status and the rule that produced the rate. Second, the separation makes the method easy to check. An agronomist can verify the decision rule without studying the network. Third, the separation allows the decision rule to change for a new region or a new economic situation, without retraining the network.

### 1.3.4 Challenges that motivate the design

The problem has four challenges. These challenges guide the design in Chapter 2.

The first challenge is the missing spectral information. An RGB camera does not record the red-edge and near-infrared bands. The method must recover the nitrogen signal from colour and texture alone.

The second challenge is the weak phosphorus signal. Phosphorus has no strong colour signature in rice and wheat. The method must recover phosphorus information indirectly, through canopy structure and biomass, and must report the limit of this recovery.

The third challenge is the small labelled dataset. Ground measurement is expensive. The method must use each labelled sample efficiently.

The fourth challenge is generalization across fields and seasons. Growth conditions change between fields and between seasons. The method must transfer to new conditions, and the evaluation must test this transfer honestly.

Chapter 2 presents two solutions that address these challenges. The first solution is the two-tier formulation. The second solution is the dual-pathway multi-task network, together with the training strategy for a small dataset.

\newpage
# Chapter 2. Proposed Solutions

## 2.1 Overview

This chapter presents two solutions. The first solution is a two-tier framework. It separates the learned estimation of nutrient status from the agronomic decision of the fertilizer rate. The second solution is a dual-pathway multi-task network. It reads the nitrogen signal from colour and the phosphorus signal from canopy structure, and it predicts nitrogen status, phosphorus status, and biomass at the same time. A training strategy for small datasets supports the second solution and is described as part of it.

The two solutions work together. The first solution defines the structure of the system. The second solution defines the network inside the perception tier. Figure 2.1 shows the two-tier framework. Figure 2.2 shows the network at a high level. Figure 2.3 shows the network in full detail, layer by layer.

Throughout this chapter, we keep the terminology fixed. The word "status" always means a nutrition index value. The word "rate" always means a mass of fertilizer per hectare. The word "pathway" always means one branch of the network.

## 2.2 Solution 1: Two-Tier Perception–Decision Framework

### 2.2.1 The idea

A drone image does not show the correct amount of fertilizer. It shows the current state of the crop. The correct amount of fertilizer is a decision. This decision depends on the crop state, on the growth stage, on the target yield, and on economic factors. For this reason, we do not train a network to predict the fertilizer amount directly. Instead, we divide the system into two tiers.

The first tier is the perception tier. It uses a neural network to estimate the crop nutrient status from the image. The output of the perception tier is the nitrogen status, the phosphorus status, and the above-ground biomass.

The second tier is the decision tier. It uses an agronomic rule to convert the estimated status into a nitrogen rate and a phosphorus rate. The decision tier is not a neural network. It is a transparent rule.

Figure 2.1 shows the full framework. The perception tier is the learned part. The decision tier is the agronomic part.

![Figure 2.1. The two-tier framework. Tier 1 is a learned perception network that maps the RGB image to nitrogen status, phosphorus status, and biomass. Tier 2 is an agronomic decision layer that converts status into nitrogen and phosphorus rates and produces a prescription map. Tier 2 is a rule, not a learned model.](figures/fig_twotier.png)

### 2.2.2 The perception tier

The perception tier is the function $f$ defined in Chapter 1. It takes the image patch $x$, the crop type $c$, and the growth information $t$. It returns the estimated status values. We choose nutrition indices as the status targets, for the reasons given in Section 1.3.2. We also predict biomass, because biomass is a strong and learnable signal that supports the phosphorus estimate. The design of this network is the second proposed solution and is described in Section 2.3.

### 2.2.3 The decision tier

The decision tier is the function $g$ defined in Chapter 1. It converts the estimated status into a fertilizer rate. We use a deficit rule. For nitrogen, the rule computes the gap between a target status and the estimated status, and converts this gap into a mass of fertilizer. The nitrogen deficit rule was given in Section 1.3.3. The phosphorus rule has the same form.

The coefficient in the rule depends on the crop and on the growth stage. The target status also depends on the economic goal. A farmer who wants maximum yield uses a higher target than a farmer who wants maximum profit. Because the decision tier is a rule, these choices are easy to change. The network does not need retraining.

The decision tier also respects the time window of the application. Nitrogen can be applied as a top dressing during the growing season. Phosphorus is usually applied at or before sowing, as a basal dressing. The growth stage, expressed as growing degree days, tells the decision tier whether an application is still useful. If the window has passed, the rule reports that no correction is possible at this time.

We define the target status more precisely. One way to set the target is to use a reference strip. A reference strip is a small part of the field that receives a high, non-limiting amount of fertilizer. The crop in this strip grows without a nutrient shortage, so its status is close to the ideal. We can then express the status of any plot as a sufficiency index, which is the ratio of the plot status to the reference status:

$$
\text{SI} = \frac{\hat{s}}{\hat{s}_{\text{ref}}},
$$

where $\hat{s}$ is the estimated status of the plot and $\hat{s}_{\text{ref}}$ is the estimated status of the reference strip. A sufficiency index near one means the plot is close to the reference and needs little fertilizer. A low value means the plot needs more. The reference strip is useful because it adjusts for the conditions of the season and the field. If the whole field grows slowly because of weather, the reference strip also grows slowly, and the sufficiency index stays meaningful.

The deficit rule and the sufficiency index are two ways to express the same idea. The deficit rule uses a fixed target status. The sufficiency index uses a target that comes from a reference strip in the same field. We support both. The reference-strip method is more robust to field and season effects. The fixed-target method is simpler and does not need a reference strip.

We now write the decision rule explicitly and describe its parts in detail. The decision tier is a fixed mathematical rule. It is not a neural network, and it has no learned weights in the main method. For nitrogen, the recommended rate is

$$
r_N = k_N \, (s_N^{*} - \hat{s}_N)_{+},
$$

and for phosphorus it is

$$
r_P = k_P \, (s_P^{*} - \hat{s}_P)_{+},
$$

where $s_N^{*}$ and $s_P^{*}$ are the target status values, $\hat{s}_N$ and $\hat{s}_P$ are the estimated status values from the perception tier, $k_N$ and $k_P$ are conversion coefficients, and $(\cdot)_{+}$ sets negative values to zero. The rule has no hidden steps. A person can read it and check it by hand. This is the main advantage of a rule over a learned decision.

**Setting the coefficients.** The coefficient $k$ converts a status deficit into a mass of fertilizer. It is not guessed. It comes from agronomic field experiments that measure how the crop responds to added fertilizer. These experiments give a response curve, which shows the extra nutrient uptake or yield for each extra unit of fertilizer. The coefficient is the amount of fertilizer needed to close one unit of status deficit, read from this curve. Published values exist for rice and wheat in many regions, and local experiments can refine them. Because the coefficient lives in the rule and not in the network, it can be updated for a new region without retraining the network.

**Setting the targets.** The target status $s^{*}$ is the status that the farmer wants to reach. A target of one means the crop should have just enough of the nutrient. A farmer who wants maximum yield may use a target slightly above one. A farmer who wants maximum profit may use a target slightly below one, because the last unit of fertilizer often costs more than the extra yield it produces. The target is a management choice, and the rule makes this choice visible and easy to change.

**Phosphorus timing.** Phosphorus needs special care in the decision tier. First, we must separate two different times. The image is taken in the middle of the season, when the crop has a developed canopy. The perception tier therefore always has full crop information, and it can estimate the phosphorus status from the canopy, because the crop has been taking up phosphorus since germination. The problem is not on the perception side. The problem is on the decision side. In rice and wheat, phosphorus is usually applied before or at sowing, as a basal dressing, at a time when there is no crop to image. A single mid-season image is therefore often too late to change the basal phosphorus dose of the current crop.

For this reason, the phosphorus output is not an in-season basal rate. It is a status and deficiency map, and it has three uses. The first use is a diagnosis of the current season: the map shows which zones are short of phosphorus now. The second use, which is the most important, is to plan the basal phosphorus dose for the next season, zone by zone, based on the phosphorus status observed in the current season. The third use is a limited in-season correction, but only where a phosphorus top dressing is agronomically valid, which is more often the case in flooded rice than in wheat. The decision tier states which use applies, based on the growth stage and the crop. This is an honest treatment of a real limit: for phosphorus, the main value of the estimate is diagnostic and inter-seasonal, while for nitrogen the value is a direct in-season rate.

**From plot to management zone.** The perception tier produces a status value for each image patch. The decision tier does not apply the rule to each patch alone, because a fertilizer machine cannot change its rate at the scale of a single patch. Instead, the decision tier groups the patches into management zones, at the resolution that the machine can actually apply. It averages the status within each zone, and it applies the rule once per zone. The result is a prescription map with one rate per zone.

**Conservative recommendations under weak evidence.** The phosphorus estimate is uncertain, as discussed later in the paper. The decision tier can take this into account. When the phosphorus signal is weak, the rule can use a conservative target, so that it does not recommend a large phosphorus dose based on a weak signal. This keeps the recommendation safe when the evidence is weak, and it reflects good agronomic practice.

These rules complete the decision tier. The decision tier is simple by design, and its simplicity is a strength, because it makes the whole system transparent. The complex, learned part of the system is the perception tier, which is the subject of Section 2.3.

### 2.2.4 A worked example of the decision rule

A short example makes the decision rule concrete. Suppose the network estimates a nitrogen status of 0.70 for a wheat plot at stem elongation. Suppose the target status is 1.00. The status deficit is therefore 0.30. Suppose the agronomic coefficient for this crop and stage converts a deficit of 1.00 into 120 kilograms of nitrogen per hectare. The recommended nitrogen rate is then 0.30 times 120, which is 36 kilograms of nitrogen per hectare. If a second plot has a status of 0.95, the deficit is 0.05, and the recommended rate is only 6 kilograms per hectare. If a third plot has a status of 1.05, the deficit is zero after the positive-part operation, and no nitrogen is recommended. This example shows how the rule gives more fertilizer to plots with a larger shortage, and none to plots that already have enough. The phosphorus rule works in the same way.

### 2.2.5 An optional differentiable decision head

The decision rule above is a fixed formula. An alternative is a small learned decision head that is trained together with the perception network. This head takes the estimated status and the growth information and outputs a rate. It can be trained on plots for which an economic optimum rate is known. The advantage of a learned head is that it can capture non-linear effects that a simple rule misses. The disadvantage is that it reduces the transparency of the method, because the rate is no longer produced by a rule that a person can read. We keep the fixed rule as the main method and treat the learned head as an option for comparison.

### 2.2.6 Comparison with an end-to-end design

An alternative design trains a single network to map the image directly to the fertilizer rate. This is called an end-to-end design. The end-to-end design is simpler in structure, but it has two weaknesses.

The first weakness concerns the training target. An end-to-end network needs a correct fertilizer amount for each training sample. This correct amount is itself a decision, not a measurement. It is hard to define and hard to defend. A reviewer may ask where the correct amount came from, and the end-to-end design has no clear answer.

The second weakness concerns interpretation. An end-to-end network produces a number with no explanation. A user cannot see why the network chose that amount. The two-tier design avoids both weaknesses. The perception tier predicts a measurable quantity. The decision tier applies a transparent rule.

We keep the end-to-end design as a comparison method in the evaluation. The two-tier design is the main method.

## 2.3 Solution 2: Dual-Pathway Multi-Task Network

### 2.3.1 Design principle

The second solution is the design of the perception network. The guiding principle is the contrast between nitrogen and phosphorus that we described in Chapter 1.

Nitrogen appears as a colour change. A network can read nitrogen from the colour of the canopy and from fine leaf texture. We call this the chromatic signal.

Phosphorus appears as a change in growth. A phosphorus shortage makes the plant smaller and the canopy thinner. A network can read phosphorus only through canopy size, canopy density, and plant structure. We call this the structural signal.

Because the two signals are different in kind, we design the network with two pathways. One pathway captures the chromatic signal. The other pathway captures the structural signal. The two pathways then join, and the network predicts all three targets. Figure 2.2 shows the design at a high level.

![Figure 2.2. The dual-pathway multi-task network (Tier 1), shown at a high level. The chromatic pathway reads colour and leaf texture for nitrogen. The structural pathway reads canopy size and density at several scales for phosphorus and biomass. Crop and growth information enter through FiLM conditioning. The fused features feed three task heads: nitrogen, phosphorus, and biomass.](figures/fig_architecture.png)

### 2.3.2 Input representation

The input to the network is more than the raw RGB image. We add extra channels and extra scales to make the two signals easier to learn.

The first part of the input is the raw RGB patch. It has three channels: red, green, and blue. This part carries the full colour information.

The second part of the input is a set of visible-band vegetation indices. These indices are simple formulas of the red, green, and blue values. They make the colour signal explicit. We use the excess green index, the visible atmospherically resistant index, the green leaf index, and the normalized green-red difference index. Two examples are

$$
\text{ExG} = 2G - R - B, \qquad
\text{VARI} = \frac{G - R}{G + R - B},
$$

where $R$, $G$, and $B$ are the red, green, and blue values of a pixel. The index VARI uses a ratio, so it partly cancels changes in overall brightness. This property is useful, because an RGB UAV has no calibration panel. We stack these index maps as additional input channels. The network therefore receives both the raw colour and the index maps.

The third part of the input is a multi-scale view. The chromatic signal lives at a fine scale, at the level of leaf colour. The structural signal lives at a coarser scale, at the level of canopy size and gaps. For this reason, we provide the input at two scales. A fine patch serves the chromatic pathway. A wider patch, which covers more ground, serves the structural pathway. This multi-scale input is the main design choice that helps the phosphorus estimate.

The fourth part of the input is the side information. The crop type and the growth information are not image data. They enter the network through the conditioning mechanism described in Section 2.3.5.

### 2.3.3 The chromatic pathway

The chromatic pathway reads the nitrogen signal. It is a shallow convolutional network. It takes the fine RGB patch and the vegetation index channels. It is shallow because the colour signal does not need a deep network. A shallow network also has fewer parameters, which helps when the dataset is small.

The chromatic pathway produces a feature vector that summarizes the colour and the fine texture of the canopy. This feature vector is sensitive to the green-to-yellow balance, which is the main nitrogen signal.

We now describe the pathway in more detail. It has two convolution blocks. Each block applies a convolution, then batch normalization, then a rectified linear activation. The first block reduces the image size and increases the number of feature channels. The second block does the same again. After the two blocks, a global average pooling layer takes the average of each feature channel over the whole patch. This average is a robust summary of the canopy colour, because it does not depend on the exact position of the leaves in the patch.

The chromatic pathway is kept shallow on purpose. The nitrogen signal is a colour signal, and colour can be read with a small receptive field. The receptive field is the area of the input that affects one output value. For colour, a small receptive field is enough, because colour does not need a wide view. A shallow network also has fewer parameters, which reduces the risk of overfitting on the small dataset. The vegetation index channels give the pathway a strong starting point, because they already express the colour balance that the nitrogen signal depends on. In effect, the chromatic pathway refines and combines the colour information that the index channels provide.

### 2.3.4 The structural pathway

The structural pathway reads the phosphorus signal and the biomass signal. It is a deeper convolutional network with a multi-scale design. It takes the wider patch, which shows canopy size, canopy density, and the pattern of gaps between plants. It uses several scales so that it can capture both small structures, such as single tillers, and large structures, such as whole canopy patches.

The structural pathway produces a feature vector that summarizes the size and the density of the canopy. This feature vector is the main source of information for phosphorus and biomass, because these quantities are linked to plant growth and canopy structure.

We now describe the pathway in more detail. Unlike the chromatic pathway, it needs a wide receptive field, because canopy structure is a property of a large area, not of a single point. A plot that lacks phosphorus has smaller plants and more gaps, and these features are only visible when the network looks at a wide area. For this reason, the structural pathway is deeper and uses dilated convolutions. A dilated convolution spreads its filter over a wider area without adding parameters. By stacking several dilated convolutions, the pathway builds a wide receptive field while staying small in size. This is important for our small dataset, where a large network would overfit.

The structural pathway also works at several scales. At each scale, it captures a different kind of structure. At a fine scale, it captures the texture of single plants and small groups of plants. At a coarse scale, it captures the overall canopy cover and the pattern of gaps between plants. The network combines the scales, so that it describes both the local structure and the global structure of the canopy. This combination of a wide receptive field and several scales is the main reason that the structural pathway can carry phosphorus and biomass information, which the chromatic pathway cannot. It is the part of the design that responds directly to the difficulty of phosphorus.

### 2.3.5 Crop conditioning with FiLM

Rice and wheat share the same biology, but they differ in canopy shape and colour. We do not want to train two separate networks, because that would split the small dataset into two even smaller parts. Instead, we train one network and condition it on the crop type and the growth information.

We use feature-wise linear modulation, or FiLM. The conditioning input is a small vector that encodes the crop type $c$ and the growth information $t$. A small network maps this vector to a scale factor and a shift factor for each feature channel. The network then modulates its features:

$$
\text{FiLM}(h_k) = \gamma_k(c, t) \cdot h_k + \beta_k(c, t),
$$

where $h_k$ is the feature map of channel $k$, and $\gamma_k$ and $\beta_k$ are the scale and shift produced from the conditioning input. The effect is that the network adjusts its internal features for the current crop and growth stage. One network can therefore serve both rice and wheat. The growth information also enters here, as discussed in Chapter 1, so that the network interprets the image in the context of the crop stage.

We now describe how the conditioning input is built and where FiLM is applied. The conditioning input has two parts. The first part is the crop type, encoded as a short learned vector, one vector for rice and one for wheat. This vector is called the crop embedding. The second part is the growth information, encoded as the growing degree days and scaled to a standard range. The two parts are joined into a single conditioning vector. The FiLM generator, a small fully connected network, maps this vector to the scale and shift values:

$$
(\gamma, \beta) = \text{MLP}(e_c \oplus \tilde{t}),
$$

where $e_c$ is the crop embedding, $\tilde{t}$ is the scaled growth information, and $\oplus$ means that the two are joined. We apply FiLM after the early convolution blocks of both pathways, where the features are still general. This placement lets the crop and growth information adjust the features before the pathways are combined.

We choose FiLM rather than a simple concatenation of the metadata, for two reasons. First, FiLM lets the metadata change the image features directly, which is stronger than adding the metadata only as extra numbers at the end of the network. Second, FiLM uses few parameters, because it produces only one scale and one shift per channel. This matches our need for a small model. In the ablation study in Chapter 3, we compare FiLM conditioning with two separate crop models and with simple metadata concatenation.

### 2.3.6 Fusion and multi-task heads

After the two pathways, the network joins their feature vectors. This step is called fusion. The fused feature vector contains both the chromatic information and the structural information.

The network then has three task heads. The first head predicts the nitrogen status. The second head predicts the phosphorus status. The third head predicts the above-ground biomass. Each head is a small set of fully connected layers.

The three heads share the same fused features. This sharing is important for phosphorus. The phosphorus head can use the structural features and the biomass features, which carry most of the phosphorus information. The biomass head provides a strong training signal, because biomass can be estimated well from canopy structure. This strong signal shapes the shared features and, in turn, helps the weaker phosphorus head.

We considered several ways to fuse the two pathway features. The simplest way is concatenation, which joins the two feature vectors end to end. A second way is a weighted sum, which adds the two vectors with learned weights. A third way is a gating mechanism, which lets one pathway control how much the other pathway contributes. A fourth way is an attention mechanism, which lets the network focus on the most useful features. We choose concatenation as the main method, because it is simple, it keeps all the information from both pathways, and it adds no extra parameters. The more complex methods can help on large datasets, but they add parameters and risk overfitting on our small dataset. We therefore keep fusion simple and place the model capacity where it is most needed, in the two pathways and the heads. We compare concatenation with a gated fusion in the ablation study.

It is worth stating the mechanism of the biomass auxiliary task clearly, because it is central to the phosphorus result. Biomass can be read from canopy structure, which the structural pathway captures well. When the network learns to predict biomass, it is forced to build structural features that describe canopy size and density. Phosphorus status is linked to these same structural features, because a phosphorus shortage reduces growth and therefore reduces biomass. The phosphorus head can read these features through the shared representation. In this way, the easy biomass task builds the structural features that the hard phosphorus task needs. Without the biomass task, the phosphorus head would have to build these features from its own weak signal alone, which is much harder.

### 2.3.7 Multi-task loss

The network has three outputs, so the training loss has three parts. A simple sum of the three parts is not ideal, because the three tasks have different scales and different difficulty. If one task has large errors, it can dominate the training. We therefore weight the three parts.

We use an uncertainty-based weighting. Each task receives a weight that the network learns during training. A task with high noise receives a smaller weight. The total loss is

$$
\mathcal{L} = \sum_{i \in \{N, P, b\}} \frac{1}{2\sigma_i^{2}} \, \mathcal{L}_i + \log \sigma_i,
$$

where $\mathcal{L}_i$ is the loss of task $i$, and $\sigma_i$ is a learned parameter that represents the noise level of task $i$. The term $\log \sigma_i$ prevents the network from making all weights small. This weighting balances the three tasks without manual tuning. It is especially helpful for phosphorus, which is the noisiest task.

For each individual task, we use a robust regression loss instead of the plain squared error. We use the Huber loss, which behaves like the squared error for small errors and like the absolute error for large errors:

$$
\mathcal{L}_i =
\begin{cases}
\tfrac{1}{2}(y_i - \hat{y}_i)^2, & |y_i - \hat{y}_i| \le \delta, \\[4pt]
\delta\,|y_i - \hat{y}_i| - \tfrac{1}{2}\delta^{2}, & |y_i - \hat{y}_i| > \delta,
\end{cases}
$$

where $y_i$ is the measured value, $\hat{y}_i$ is the predicted value, and $\delta$ is a threshold. The Huber loss reduces the effect of noisy labels, which are common in field data.

We now explain where the uncertainty weighting comes from, so that it is not seen as an arbitrary choice. We treat each output as a noisy measurement of the true value. We assume the noise follows a normal distribution with a standard deviation $\sigma_i$ for task $i$. Under this assumption, the negative log-likelihood of the measured value, for a regression task, is

$$
-\log p(y_i \mid \hat{y}_i) = \frac{1}{2\sigma_i^{2}} (y_i - \hat{y}_i)^2 + \log \sigma_i + \text{constant}.
$$

Summing this over the three tasks gives the total loss of this section. The first term is the error of the task, divided by its noise. The second term, $\log \sigma_i$, acts as a penalty that stops the network from setting all noise values to be very large. The network learns the noise values during training. A task with high noise, such as phosphorus, receives a smaller weight on its error term, so it does not dominate the training. This derivation shows that the weighting follows from a simple and standard assumption about the noise, and not from manual tuning.

### 2.3.8 Complete set of vegetation index channels

Table 2.1 lists the visible-band vegetation indices that we add as input channels. Each index is a simple function of the red, green, and blue values. Each one emphasizes a different aspect of the colour signal. Together they make the nitrogen signal explicit and give the network a strong starting point.

Table 2.1. Visible-band vegetation indices used as input channels.

| Index | Formula | Purpose |
|---|---|---|
| ExG (excess green) | $2G - R - B$ | Emphasizes green, suppresses soil |
| ExR (excess red) | $1.4R - G$ | Emphasizes red, used with ExG |
| ExGR | $\text{ExG} - \text{ExR}$ | Separates plant from background |
| VARI | $(G - R)/(G + R - B)$ | Greenness, robust to brightness |
| GLI (green leaf index) | $(2G - R - B)/(2G + R + B)$ | Normalized greenness |
| NGRDI | $(G - R)/(G + R)$ | Green-red balance |
| CIVE | $0.441R - 0.811G + 0.385B + 18.79$ | Vegetation extraction |

We note an important fact about these indices. Each index is a function of the red, green, and blue values. The raw image already contains these values. The indices therefore add no new measurement. Their value is that they give the network a useful starting form of the colour signal. This helps the network learn faster and with less data. We state this clearly, so that the contribution is not overstated. Any gain from the indices is a gain in data efficiency, not a gain in information.

### 2.3.9 Detailed layer configuration

Table 2.2 gives an example configuration of the network. The exact numbers can change, but the structure is fixed. The chromatic pathway is shallow. The structural pathway is deeper and uses several scales. The two pathways produce feature vectors that are then joined.

Table 2.2. Example network configuration (illustrative).

| Component | Type | Output size |
|---|---|---|
| Chromatic input | RGB + 7 index channels, fine patch | 10 × 128 × 128 |
| Chromatic block 1 | Conv + batch norm + activation | 32 × 64 × 64 |
| Chromatic block 2 | Conv + batch norm + activation | 64 × 32 × 32 |
| Chromatic pooling | Global average pooling | 64 |
| Structural input | RGB + 7 index channels, wide patch | 10 × 256 × 256 |
| Structural block 1–4 | Multi-scale conv blocks | 128 × 16 × 16 |
| Structural pooling | Global average pooling | 128 |
| FiLM conditioning | From crop + GDD vector | scale/shift per channel |
| Fusion | Concatenate pathway features | 192 |
| N head | Two fully connected layers | 1 |
| P head | Two fully connected layers | 1 |
| Biomass head | Two fully connected layers | 1 |

The number of parameters is kept small. A small network is less likely to memorize the training data. This choice is deliberate, because the labelled dataset is small.

### 2.3.10 The structural pathway and multi-scale processing

We give more detail on the structural pathway, because it is the part that enables phosphorus estimation. The pathway processes the image at several scales. At a fine scale, it captures the texture of single plants and small groups of plants. At a coarse scale, it captures the overall size and shape of the canopy and the pattern of gaps. The network combines these scales, so that it can describe both local structure and global structure.

There are several ways to process several scales. One way is to use an image pyramid, in which the same image is given at several resolutions. Another way is to use dilated convolutions, which look at a wider area without adding parameters. A third way is to use a feature pyramid, which combines features from several depths of the network. Any of these methods can serve the structural pathway. The key point is that the pathway must see structure at more than one scale, because phosphorus and biomass express themselves at more than one scale.

### 2.3.11 Detailed network illustration and walkthrough

Figure 2.3 shows the full network, layer by layer. This section explains the figure step by step, so that the reader can follow the flow of data from the input image to the three outputs.

![Figure 2.3. Detailed layer-level architecture of the dual-pathway multi-task network. The top lane is the chromatic pathway for nitrogen. The bottom lane is the structural pathway for phosphorus and biomass. Each block shows its operation, its stride, and the size of its output tensor, written as channels × height × width. The FiLM generator turns the crop and growth metadata into per-channel scale and shift values that modulate both pathways. The two pathway features are joined by fusion and then passed to three task heads. The dashed lines show the conditioning and gradient paths.](figures/fig_architecture_detail.png)

**Inputs.** The network receives three inputs. The first input is the fine patch, with size 10 × 128 × 128. The number 10 is the three colour channels plus the seven vegetation index channels. This input goes to the chromatic pathway. The second input is the wide patch, with size 10 × 256 × 256. It covers more ground and goes to the structural pathway. The third input is the metadata vector, which holds the crop type and the growing degree days. It goes to the FiLM generator.

**Chromatic pathway (top lane).** The fine patch passes through two convolution blocks. The first block applies a 3 × 3 convolution with 32 filters and a stride of 2, followed by batch normalization and a non-linear activation. The stride of 2 halves the height and width, so the output size is 32 × 64 × 64. The second block uses 64 filters and a stride of 2, giving an output of 64 × 32 × 32. A global average pooling layer then reduces each channel to a single number, giving a feature vector of length 64. This vector summarizes the colour and fine texture of the canopy, which is the nitrogen signal.

**Structural pathway (bottom lane).** The wide patch passes through four convolution stages. The first stage gives 32 × 128 × 128. The second stage gives 64 × 64 × 64. The third stage is a multi-scale block that uses dilated convolutions to see a wider area, giving 128 × 32 × 32. The fourth stage gives 128 × 16 × 16. A global average pooling layer then produces a feature vector of length 128. This vector summarizes the size and density of the canopy, which is the phosphorus and biomass signal. The structural pathway is deeper and wider than the chromatic pathway, because structure is harder to read than colour.

**FiLM conditioning.** The metadata vector enters the FiLM generator, which is a small fully connected network. It produces a scale value and a shift value for each feature channel. These values modulate the feature maps in both pathways, as shown by the dashed purple lines. The effect is that the network adjusts its features for the current crop and growth stage. This is how one network serves both rice and wheat.

**Fusion.** The two pathway feature vectors are joined end to end. The chromatic vector of length 64 and the structural vector of length 128 together form a vector of length 192. This fused vector contains both the colour information and the structure information.

**Task heads.** The fused vector passes to three heads. Each head is a small fully connected network that maps the 192 values through a hidden layer of 64 units to a single output. The nitrogen head outputs the nitrogen nutrition index. The phosphorus head outputs the phosphorus nutrition index. The biomass head outputs the above-ground biomass. The three heads share the same fused vector, so the phosphorus head can use the structural and biomass features, which carry most of the phosphorus information.

**Loss.** During training, the three outputs are compared with the measured values. The errors are combined with the uncertainty-weighted multi-task loss of Section 2.3.7, using a Huber loss for each task. The dashed grey lines show that the loss sends gradients back through all three heads and through the shared network. At test time, the loss is not used, and the network simply produces the three outputs for each patch.

This walkthrough matches the configuration in Table 2.2. The figure and the table together give a complete description of the network, so that the design can be reproduced.

### 2.3.12 Design rationale and alternatives considered

We summarize the main design decisions and the reasons for them. Table 2.3 lists each decision, the chosen option, and the main alternative. The table shows that every choice follows from two concerns. The first concern is the difference between the nitrogen signal and the phosphorus signal. The second concern is the small size of the labelled dataset.

Table 2.3. Main design decisions (summary).

| Decision | Chosen option | Main alternative | Reason for the choice |
|---|---|---|---|
| Overall structure | Two tiers | End-to-end network | Clear measurable target, interpretable |
| Pathways | Two (colour, structure) | One shared pathway | Nitrogen and phosphorus differ in kind |
| Input channels | Add vegetation indices | Raw RGB only | Faster learning on a small dataset |
| Crop handling | One model with FiLM | Two separate models | Keeps the small dataset together |
| Outputs | Nitrogen, phosphorus, biomass | Nitrogen and phosphorus only | Biomass supports phosphorus |
| Loss weighting | Learned uncertainty | Fixed weights | Balances tasks without tuning |
| Fusion | Concatenation | Attention or gating | Simple, no extra parameters |
| Small-data method | Self-supervised pretraining | Train from the start | Uses the unlabelled images |

The central idea runs through the whole table. Nitrogen is a colour signal, so the network needs a colour pathway. Phosphorus is a structural signal, so the network needs a structural pathway and the support of the biomass task. The dataset is small, so every choice also aims to use data well and to keep the model small. These two concerns, taken together, explain the whole design. A reader who understands these two concerns can predict most of the design choices without being told them.

## 2.4 Label-Efficient Training Strategy

The dataset of labelled plots is small, because ground measurement of nitrogen and phosphorus is expensive. The phosphorus labels are the fewest and the hardest. We therefore use several methods to train the network with few labels. These methods are part of the second solution.

### 2.4.1 Self-supervised pretraining

We have many more images than labels. Every plot is photographed, but only some plots are sampled for laboratory analysis. We can also fly over fields that are not part of the trial. This gives a large pool of unlabelled images.

We use this pool for self-supervised pretraining. In self-supervised pretraining, the network learns from the images alone, without labels. It learns to produce useful features of the canopy, such as colour patterns and texture patterns. After this pretraining, we fine-tune the network on the small labelled dataset. The pretraining gives the network a strong starting point. This is the most effective single method for the small-data problem.

We now describe the self-supervised method in more detail. We use a masked autoencoder. In a masked autoencoder, we hide a large fraction of the image patch, for example three quarters of it, and we ask the network to reconstruct the hidden part from the visible part. To reconstruct the hidden part well, the network must learn the structure of the canopy, including the texture, the colour patterns, and the typical shape of the plants. The reconstruction loss is the difference between the reconstructed patch and the original patch:

$$
\mathcal{L}_{\text{ssl}} = \frac{1}{|M|} \sum_{j \in M} (x_j - \hat{x}_j)^2,
$$

where $M$ is the set of hidden pixels, $x_j$ is the original value, and $\hat{x}_j$ is the reconstructed value. After this pretraining, we keep the encoder and discard the decoder. The encoder has now learned useful features of the canopy, without any labels. We then attach the three task heads and fine-tune on the small labelled dataset. Because the encoder already understands the canopy, the fine-tuning needs far fewer labels than training from the start. This is the mechanism by which self-supervised pretraining addresses the small-data problem.

### 2.4.2 Multi-task sharing as regularization

Multi-task learning is also a method for small datasets, not only a method for accuracy. Each labelled plot supervises three tasks at the same time. The shared features must serve all three tasks. This sharing reduces overfitting, because the features cannot specialize to one task alone. The biomass task, in particular, gives a strong and reliable signal that stabilizes the shared features.

### 2.4.3 Data augmentation and patch multiplication

We increase the effective size of the dataset in two ways.

First, we use data augmentation. We apply flips, rotations, scale changes, and small shifts to the image patches. We avoid strong colour changes, because the nitrogen signal depends on colour. We allow only small changes in brightness, to simulate changes in light during flight.

Second, we use patch multiplication. A single plot image contains many smaller patches. Each patch shares the plot label. This gives more training samples. However, patches from one plot are not independent, because they share the same label. We therefore keep all patches of one plot in the same cross-validation group, so that no patch from a test plot appears in training. At test time, we average the predictions of all patches of a plot to produce one plot-level prediction.

### 2.4.4 Transfer learning and its limits

Transfer learning is a common method for small datasets. In transfer learning, a network is first trained on a large general dataset, such as a dataset of natural photographs. The trained network is then adapted to the new task. This method often helps, because the early layers of a network learn general features, such as edges and textures, that are useful for many tasks.

However, transfer learning from natural photographs has a limit for our task. Natural photographs are very different from UAV crop images. They contain objects such as animals, vehicles, and people, seen from the side. Our images show a canopy from above, with fine repeated texture and a narrow range of colours. The features learned on natural photographs are therefore only partly useful. For this reason, we prefer self-supervised pretraining on our own unlabelled crop images. This pretraining learns features that match the target domain. We can still use transfer learning from natural photographs as a starting point before the self-supervised step, but the self-supervised step is the more important one. We compare these options in the ablation study in Chapter 3.

### 2.4.5 Class-based output as a fallback

The main method predicts a continuous status value for each nutrient. For phosphorus, the continuous value may be hard to predict, because the signal is weak. A useful fallback is to predict a class instead of a continuous value. For example, the phosphorus output can be one of three classes: deficient, sufficient, or excess. A class target is easier to learn with few samples, because it asks a simpler question. For a fertilizer decision, three classes may be enough, because the decision does not always need an exact value. We therefore design the phosphorus head so that it can be trained either as a continuous output or as a class output, and we compare both in the evaluation. This flexibility is a practical response to the difficulty of phosphorus.

## 2.5 Computational and Practical Considerations

### 2.5.1 Computation

The method is designed to be light. The network is small, and the input patches are small. Training on a single modern graphics processing unit is feasible. The self-supervised pretraining is the most expensive step, but it is done only once. After training, the network can process a whole field in a short time, because each patch requires only one forward pass.

### 2.5.2 Robustness to light conditions

An RGB UAV has no calibration panel. The method therefore uses two defenses against changes in light. The first defense is the use of ratio-based vegetation indices, such as VARI, which partly cancel changes in brightness. The second defense is relative radiometric normalization, which adjusts the brightness of each image to a common reference. These two defenses reduce, but do not remove, the effect of light conditions. For this reason, flights should be made near solar noon and under stable light where possible.

## 2.6 Summary of the Design

The two solutions form a complete method. The first solution is the two-tier framework. The perception tier estimates nutrient status. The decision tier converts status into a fertilizer rate with a transparent rule.

The second solution is the dual-pathway multi-task network inside the perception tier. The chromatic pathway reads nitrogen from colour. The structural pathway reads phosphorus and biomass from canopy structure. Crop conditioning lets one network serve both rice and wheat. The multi-task design predicts the three targets together and helps the weak phosphorus task. The training strategy uses self-supervised pretraining, multi-task sharing, and augmentation to work with a small labelled dataset.

Chapter 3 describes how we implement this method, how we prepare the data, and how we evaluate the performance.

\newpage
# Chapter 3. System Implementation and Performance Evaluation

## 3.1 Overview

This chapter describes how we implement and evaluate the method. Section 3.2 describes the field trials, the UAV data, the ground measurements, and the image preparation. Section 3.3 describes the network configuration and the training settings. Section 3.4 describes the evaluation protocol. Section 3.5 reports the results. Section 3.6 discusses the results and the limitations.

We state one point clearly at the start. The numerical results in Section 3.5 are projected values. They are illustrative estimates based on the design and on values reported for related tasks in the literature. They are not measured results. Every table and figure that contains a projected value is marked. These values show the expected pattern of the results and the format of the evaluation. They must be replaced by measured values after the experiment is complete.

## 3.2 Study Design and Data

### 3.2.1 Field trials

The data comes from controlled field trials with different fertilizer levels. The trials create a wide range of nitrogen and phosphorus status, so that the network can learn the full range.

The trials use a factorial design. The nitrogen treatment has several levels, for example 0, 60, 120, 180, and 240 kilograms of nitrogen per hectare. The phosphorus treatment has several levels, for example 0, 40, and 80 kilograms of phosphorus per hectare. Each combination is repeated in several blocks, to account for soil variation. The trials cover both rice and wheat, several fields, and at least two seasons. This spread is necessary for the evaluation of generalization.

Table 3.1 summarizes the planned dataset. The plot counts are design targets, not measured counts.

Table 3.1. Planned dataset summary (design targets, illustrative).

| Item | Rice | Wheat | Total |
|---|---|---|---|
| Fields | 3 | 3 | 6 |
| Seasons | 2 | 2 | 2 |
| Nitrogen levels | 5 | 5 | — |
| Phosphorus levels | 3 | 3 | — |
| Replicate blocks | 4 | 4 | — |
| Ground-truth plots (N) | ~180 | ~180 | ~360 |
| Ground-truth plots (P) | ~120 | ~120 | ~240 |

The number of phosphorus labels is smaller than the number of nitrogen labels, because the phosphorus assay is performed on a subset of plots. This smaller count is one reason that phosphorus is the harder task.

### 3.2.2 UAV data acquisition

The UAV carries a standard RGB camera. It flies at an altitude of 100 metres. At this altitude, a typical camera gives a ground sample distance of about two to three centimetres per pixel. This detail is at the level of the canopy, not the single leaf. Figure 3.0 shows example aerial views of a rice field and a wheat field, to illustrate the visual difference between the two crops. The rice field has a flooded background, while the wheat field has a soil background. These two backgrounds require different masking, as described in Section 3.2.4.

![Figure 3.0. Illustrative aerial views of (a) a rice field and (b) a wheat field. These are open-license example images, not the study data. They show the visual difference between the flooded rice background and the soil wheat background. Image credits and licenses are listed in Appendix A.](figures/fig_examples.png)

The flight happens once per plot, at a single fixed growth stage. This stage is the stage at which the fertilizer decision is made. For wheat, this is around stem elongation. For rice, this is around mid-tillering. The flight is near solar noon, to reduce shadows. The images overlap by about 75 to 80 percent, so that a complete orthomosaic can be built.

We record the growth information as growing degree days. The growing degree days are computed from the daily temperature since sowing or transplanting. We also record simple weather information, such as cumulative rainfall, to help explain differences between seasons.

### 3.2.3 Ground-truth measurements

At each sampled plot, we collect the ground truth on the same day as the flight. We cut the above-ground plants in a known area. We dry them and weigh them to obtain the above-ground biomass. We analyze the dried plants in the laboratory to obtain the nitrogen concentration and the phosphorus concentration.

From these measurements, we compute the nitrogen nutrition index and the phosphorus nutrition index, using the dilution curves described in Chapter 1. These index values are the training targets for the perception network. We also record the final yield of each plot, which is used in the discussion of agronomic outcomes.

### 3.2.4 Image preparation

The raw flight images are not fed to the network. We prepare the images through a fixed pipeline, shown in Figure 3.1.

![Figure 3.1. The per-plot image preparation pipeline. The raw flight is stitched into a georeferenced orthomosaic with a fixed ground sample distance. Plot polygons with an inner buffer isolate the plot core. Each plot core is cropped to a fixed ground footprint and divided into fixed-size patches at two scales. Water and soil are masked, and the canopy cover fraction is kept as a feature. A relative radiometric normalization reduces brightness differences.](figures/fig_pipeline.png)

The pipeline has six steps. First, we stitch the flight images into an orthomosaic. The orthomosaic is georeferenced with ground control points, so that every pixel has a known position and the ground sample distance is constant. Second, we overlay the plot boundaries and apply an inner buffer. The inner buffer removes the plot edges, the paths between plots, and the guard rows. Third, we crop each plot core to a fixed ground footprint, so that every sample covers the same ground area. Fourth, we divide each plot core into fixed-size patches at two scales, a fine scale and a wide scale. Each patch inherits the plot label. Fifth, we mask water and soil, which are not canopy, and we keep the canopy cover fraction as a separate feature. The water mask is important for rice, which has standing water. Sixth, we apply a relative radiometric normalization to reduce brightness differences between flights.

### 3.2.5 Data split for evaluation

We do not use a random split of patches. A random split would place patches from the same plot in both the training set and the test set. Because these patches share a label and look similar, a random split gives an optimistic result. Instead, we group all patches of one plot together, and we split by field and by season. This split is described in Section 3.4.

## 3.3 Implementation Details

### 3.3.1 Network configuration

The chromatic pathway is a shallow convolutional network. It takes the fine RGB patch and the vegetation index channels. The structural pathway is a deeper multi-scale convolutional network. It takes the wide patch. Both pathways use a small number of parameters, because the dataset is small. The fusion joins the two feature vectors. The three task heads each use two fully connected layers. The crop and growth information enter through FiLM conditioning, as described in Chapter 2.

We keep the network small on purpose. A large network would memorize the small dataset and would not generalize. The total parameter count is kept modest, and we use dropout and weight decay in all layers.

### 3.3.2 Training settings

We first pretrain the encoder with self-supervised learning on the pool of unlabelled images. We then fine-tune the whole network on the labelled dataset, using the multi-task loss of Chapter 2. We use early stopping based on a validation set that follows the same blocked structure as the test set. We use data augmentation as described in Chapter 2. We train with a standard optimizer and a small learning rate. We repeat the training several times to form an ensemble, which improves stability on the small dataset.

### 3.3.3 Decision-layer settings

The decision layer uses the deficit rule of Chapter 2. The target status values and the conversion coefficients come from agronomic sources for rice and wheat. These values are fixed and are not learned. We also set the application windows for nitrogen and phosphorus, so that the decision layer only recommends an application when it is still useful.

## 3.4 Evaluation Protocol

### 3.4.1 Cross-validation blocked by field and season

The goal of the evaluation is to measure how well the method works on new fields and new seasons. We therefore use blocked cross-validation. In leave-one-field-out cross-validation, we train on all but one field and test on the held-out field. In leave-one-season-out cross-validation, we train on one season and test on the other season. These splits are harder than a random split, but they give an honest estimate of generalization.

Because the dataset is small, each test fold is also small. The accuracy of a single fold is therefore noisy. We report the mean and the standard deviation across folds. We also report a confidence interval, computed by resampling the plots. When we compare two methods, we compare them on the same folds and use a paired statistical test.

### 3.4.2 Metrics

We use three metrics for the status estimation. The first metric is the coefficient of determination, written $R^2$. It measures the fraction of variance explained:

$$
R^{2} = 1 - \frac{\sum_i (y_i - \hat{y}_i)^2}{\sum_i (y_i - \bar{y})^2},
$$

where $y_i$ is the measured value, $\hat{y}_i$ is the predicted value, and $\bar{y}$ is the mean of the measured values. The second metric is the root mean square error, written RMSE:

$$
\text{RMSE} = \sqrt{\frac{1}{n}\sum_i (y_i - \hat{y}_i)^2}.
$$

The third metric is the relative root mean square error, written rRMSE. It is the RMSE divided by the mean of the measured values, expressed as a percentage. It allows comparison across targets with different units.

For the decision tier, we report the error of the recommended rate against a reference rate in kilograms per hectare. We also report agronomic outcomes, such as yield, nitrogen use efficiency, and nutrient surplus.

### 3.4.3 Baselines

We compare the method against three baselines. The first baseline uses visible-band vegetation indices with a standard regression model, such as a random forest. This baseline represents the common practice in the field. The second baseline uses an established sensor-based rule, such as a sufficiency index relative to a well-fertilized reference strip. The third baseline is the uniform rate that a farmer would normally apply. The proposed method must clearly beat the first two baselines to justify its added complexity.

## 3.5 Results

All results in this section are projected values. They are marked as such. They show the expected pattern and the format of the final results. They are not measured values.

### 3.5.1 Nutrient status accuracy

Table 3.2 reports the projected accuracy of the status estimation, averaged over both crops. Figure 3.2 shows the projected predicted-versus-measured plots.

Table 3.2. Projected status estimation accuracy (illustrative values; replace with measured results).

| Target | $R^2$ | RMSE | rRMSE (%) |
|---|---|---|---|
| Nitrogen status (NNI) | 0.80 | 0.08 | 10 |
| Phosphorus status (PNI) | 0.52 | 0.14 | 19 |
| Above-ground biomass | 0.78 | 0.9 t/ha | 15 |

![Figure 3.2. Projected predicted-versus-measured plots for nitrogen status, phosphorus status, and biomass. The nitrogen and biomass estimates are expected to be accurate. The phosphorus estimate is expected to be weaker and more scattered. These are illustrative values and must be replaced by measured results.](figures/fig_scatter.png)

The expected pattern is clear. Nitrogen status and biomass reach useful accuracy, because the nitrogen signal is a colour signal and the biomass signal is a structural signal, and both are present in RGB imagery. Phosphorus status is weaker, because its signal is indirect. This pattern matches the design reasoning in Chapter 2.

### 3.5.2 Results by crop

Table 3.3 and Figure 3.3 report the projected accuracy for each crop. The two crops are expected to behave similarly, with rice slightly higher than wheat, because the flooded background of rice gives a clearer contrast between canopy and ground.

Table 3.3. Projected accuracy by crop ($R^2$; illustrative values).

| Target | Rice | Wheat |
|---|---|---|
| Nitrogen status (NNI) | 0.82 | 0.78 |
| Phosphorus status (PNI) | 0.55 | 0.49 |
| Above-ground biomass | 0.80 | 0.76 |

![Figure 3.3. Projected accuracy by crop and target (left) and projected ablation results (right). Both panels use illustrative values and must be replaced by measured results.](figures/fig_bars.png)

### 3.5.3 Decision accuracy and agronomic outcomes

Table 3.4 reports the projected performance of the decision tier. The error of the recommended nitrogen rate is expected to be small enough to be useful. The error of the recommended phosphorus rate is expected to be larger, because it depends on the weaker phosphorus estimate. The method is expected to reduce nutrient surplus compared with the uniform rate, while keeping yield at the same level.

Table 3.4. Projected decision-tier and agronomic outcomes (illustrative values).

| Metric | Uniform rate | Proposed method |
|---|---|---|
| Nitrogen rate error (kg/ha) | — | 18 |
| Phosphorus rate error (kg/ha) | — | 12 |
| Relative yield | 1.00 | 1.00 |
| Nitrogen use efficiency | baseline | +12% |
| Nitrogen surplus | baseline | −20% |

### 3.5.4 Ablation study

The ablation study tests each design choice. It removes one component at a time and measures the change in accuracy. The projected results are in the right panel of Figure 3.3 and in Table 3.5.

Table 3.5. Projected ablation study ($R^2$; illustrative values).

| Configuration | Nitrogen | Phosphorus |
|---|---|---|
| Full model | 0.80 | 0.52 |
| Without vegetation index channels | 0.75 | 0.47 |
| Without structural pathway | 0.78 | 0.38 |
| Without self-supervised pretraining | 0.71 | 0.44 |
| Without multi-task sharing (phosphorus alone) | 0.77 | 0.33 |
| Predict-the-mean baseline (phosphorus) | — | 0.10 |

The expected pattern supports the design. The vegetation index channels help both tasks. The structural pathway helps phosphorus much more than nitrogen, which confirms that phosphorus relies on structure. Self-supervised pretraining helps all tasks, because it addresses the small-data problem. Multi-task sharing helps phosphorus the most, because the phosphorus head borrows from the biomass and structural features. The most important test is the comparison with the predict-the-mean baseline. If the phosphorus head did not beat this baseline, we would report that phosphorus is not recoverable from RGB imagery for these crops. The projected values show a modest but real gain over the baseline.

### 3.5.5 Interpretability

We use a visualization method to show which parts of the image each head uses. The method produces a heat map over the image for each output. Figure 3.4 shows the expected pattern. The nitrogen head is expected to use colour across the whole canopy. The phosphorus head is expected to use canopy structure, such as the size of the canopy and the pattern of gaps. This pattern would confirm that the two pathways capture the two different signals, as the design intends.

![Figure 3.4. Interpretability concept (schematic). The nitrogen head is expected to rely on colour spread across the canopy. The phosphorus head is expected to rely on canopy structure and gaps. This figure is a schematic illustration of the expected pattern.](figures/fig_gradcam.png)

### 3.5.6 Prescription map example

Figure 3.5 shows an example of the final output. The left panel is the predicted nitrogen status across a field. The right panel is the recommended nitrogen rate, grouped into management zones at the resolution of the fertilizer spreader. The map gives more fertilizer where the status is low and less where the status is high. This is the practical product of the method.

![Figure 3.5. Illustrative prescription map (projected output). The left panel shows predicted nitrogen status across a field. The right panel shows the recommended nitrogen rate, grouped into management zones. The values are illustrative.](figures/fig_prescription.png)

## 3.6 Discussion

### 3.6.1 Nitrogen

The nitrogen result is expected to be strong. The reason is that the nitrogen signal is a colour signal, and colour is exactly what an RGB camera records. The vegetation index channels make this signal explicit, and the chromatic pathway reads it. The main risk for nitrogen is saturation at high biomass, where the canopy is very dark green. The multi-scale structural pathway and the texture features are expected to reduce this risk, because they use spatial pattern in addition to average colour.

### 3.6.2 Phosphorus

The phosphorus result is the most important part of the discussion, and it must be stated with honesty. Phosphorus does not have a strong colour signature in rice and wheat. The method recovers phosphorus information indirectly, through canopy structure and biomass. This indirect signal is weak and is shared with other stresses. The projected accuracy for phosphorus is therefore modest.

We do not present this as a failure. We present it as the main scientific question of the paper. The question is how much phosphorus status can be recovered from RGB imagery, and the answer is: a limited but real amount, mostly through structure. The ablation against the predict-the-mean baseline is the honest test of this claim. If, in the final experiment, the phosphorus head does not beat this baseline, the correct conclusion is that RGB imagery cannot estimate phosphorus for these crops at this stage, and the paper would report this clearly.

We must also be clear about the use of the phosphorus estimate, because the timing of phosphorus differs from the timing of nitrogen. The image is taken in the middle of the season, when the crop has a developed canopy, so the perception tier always has full crop information. However, phosphorus is applied basally, before or at sowing, when there is no crop to image. A single mid-season image therefore cannot change the basal phosphorus dose of the current crop. For this reason, the phosphorus result is best understood as a status and deficiency map, not an in-season basal rate. Its value is diagnostic for the current season and, more importantly, a guide for the basal phosphorus dose of the next season. Nitrogen, which can be applied as a top dressing during the season, gives a direct in-season rate. This difference in the two nutrients is a property of their agronomy, not a weakness of the method, and we report it plainly.

### 3.6.3 Generalization across fields and seasons

The blocked cross-validation tests generalization. Growth conditions differ between fields and seasons. The use of growing degree days as side information, together with the nutrition index targets, is expected to reduce the effect of these differences. The weather information helps explain the remaining differences. If the accuracy under leave-one-season-out cross-validation is close to the accuracy under leave-one-field-out cross-validation, the method generalizes across seasons, which is the harder test.

### 3.6.4 Limitations and threats to validity

The method has several limitations, and we state them clearly.

First, phosphorus estimation is weak and indirect, as discussed above. The result applies only to the crops, the region, and the growth stage of the study.

Second, several stresses can look similar in an RGB image. Water shortage, nitrogen shortage, disease, and other nutrient shortages can all reduce canopy size. The method may confuse these stresses with phosphorus shortage. The trials should include some of these conditions, or the paper should state this confounding.

Third, the method uses a single flight at a fixed growth stage. It does not use the full time course of crop growth. A method with several flights could use the growth trajectory, which carries more information, but this is left for future work.

Fourth, the RGB camera has no calibration panel. The method depends on relative radiometric normalization, which is less exact than panel-based calibration. Strong changes in light could still affect the result.

Fifth, the labelled dataset is small. The projected results depend on the success of the self-supervised pretraining and the multi-task design. If the unlabelled image pool is small or not diverse, the benefit of pretraining will be smaller.

### 3.6.5 The trade-off between cost and accuracy

A central theme of this paper is the trade-off between cost and accuracy. A multispectral or hyperspectral camera gives higher accuracy, especially for nitrogen and for phosphorus, but it is expensive. An RGB camera gives lower accuracy, but it is cheap and widely available. The right choice depends on the user.

For a large commercial farm with a high budget, a multispectral system may be worth the cost. For a small farm, or for a research group with limited funds, an RGB system may be the only practical option. The value of this paper is that it studies how far the cheap option can go. The projected results suggest that the RGB option is useful for nitrogen and biomass, and limited for phosphorus. A user can then decide whether the RGB option meets their needs, or whether the extra cost of a multispectral camera is justified. This honest framing of the trade-off is more useful than a claim that the cheap option is always enough.

### 3.6.6 Related studies

It is useful to place the projected results in the context of earlier work. Studies that used multispectral imagery with red-edge bands often report higher accuracy for nitrogen status than the values projected here. This is expected, because the red-edge band carries strong nitrogen information that an RGB camera does not record. The contribution of the present method is not to beat multispectral systems. The contribution is to reach useful accuracy with a much cheaper RGB camera, and to do so for both nitrogen and phosphorus with one model.

For phosphorus, there are few studies to compare with, and most used hyperspectral data. The projected phosphorus accuracy here is modest, which is consistent with the weak visual signal of phosphorus. The honest comparison is therefore with simple baselines, as reported in the ablation study, not with hyperspectral systems.

### 3.6.7 Deployment considerations

A method is only useful if it can be deployed in practice. Several points matter for deployment. First, the method uses a standard RGB UAV, which many farms already own. Second, the computation after training is light, so a field can be processed on a normal computer. Third, the output is a prescription map at the resolution of the fertilizer spreader, so it can be used directly by variable-rate equipment. Fourth, the decision tier is a transparent rule, so an agronomist can check and adjust the recommendations. These points make the method practical for real use, especially in regions where budgets are small.

A remaining barrier is the need for local calibration. The dilution curves and the decision coefficients depend on the crop variety and the region. Before use in a new region, these values should be checked against local agronomic data. This is a one-time effort and does not require retraining the network.

## 3.7 Additional Evaluation Details

### 3.7.1 Hyperparameter settings

Table 3.6 lists an example set of training settings. These settings are a starting point and should be tuned on a validation set that follows the blocked structure.

Table 3.6. Example training settings (illustrative).

| Setting | Value |
|---|---|
| Fine patch size | 128 × 128 pixels |
| Wide patch size | 256 × 256 pixels |
| Optimizer | Adam |
| Learning rate | 1 × 10⁻⁴ |
| Batch size | 32 |
| Weight decay | 1 × 10⁻⁴ |
| Dropout rate | 0.3 |
| Huber threshold δ | 0.1 |
| Ensemble size | 5 |
| Pretraining method | Masked autoencoder on unlabelled patches |

### 3.7.2 Statistical analysis

Because the dataset is small, the statistical analysis must be careful. We report the mean and the standard deviation of each metric across the cross-validation folds. We also compute a confidence interval for each metric by resampling the plots, a method known as the bootstrap. When we compare two methods, we compare them on the same folds and apply a paired test, such as the paired t-test or the Wilcoxon signed-rank test. We report the phosphorus sample size separately from the nitrogen sample size, because the phosphorus assay is done on fewer plots. This separate reporting prevents a strong nitrogen result from hiding a weak phosphorus result.

### 3.7.3 Sensitivity analysis

A sensitivity analysis studies how the result changes when a design choice changes. We plan three sensitivity studies. The first study changes the patch size, to find the size that gives the best balance between detail and context. The second study simulates a higher flight altitude by reducing the image resolution, to measure how the accuracy falls as the ground sample distance grows. The third study removes the growth information input, to measure how much the result depends on it. These studies show which design choices matter most and guide future data collection. The projected outcome is that nitrogen accuracy is stable across patch sizes, while phosphorus and biomass accuracy improve with a larger context patch, because structure needs a wider view.

### 3.7.4 Failure cases

We expect several failure cases, and we plan to report them. The first case is a plot under water stress, which can look like a nutrient shortage. The second case is a plot with disease, which changes colour and structure. The third case is a plot at the edge of the field, where the image may include non-crop objects. Reporting these cases is important for an honest account of the method. It also guides users on when to trust the recommendation and when to check it by hand.

## 3.8 Conclusion and Future Work

This paper studied the estimation of nitrogen and phosphorus status for rice and wheat from low-altitude RGB drone imagery, and the recommendation of fertilizer rates. The method is built on two solutions. The first solution is a two-tier framework that separates the learned estimation of nutrient status from the agronomic decision of the fertilizer rate. The second solution is a dual-pathway multi-task network that reads nitrogen from colour and phosphorus from canopy structure, predicts nitrogen, phosphorus, and biomass together, and serves both crops through crop conditioning.

The projected results show the expected pattern. Nitrogen status and biomass can be estimated with useful accuracy from RGB imagery, and nitrogen gives a direct in-season fertilizer rate. Phosphorus status is harder and must be reported with care, because its signal is weak and indirect. In addition, because phosphorus is applied basally before the crop can be imaged, the phosphorus output is a status and deficiency map with diagnostic and next-season planning value, not an in-season basal rate. The evaluation protocol, based on cross-validation blocked by field and season, is designed to give an honest measure of generalization.

Future work has three directions. The first direction is multi-date imagery, which would let the network use the growth trajectory and improve the phosphorus estimate. The second direction is the extension to other nutrients, such as potassium, which would make the method a more complete tool for nutrient management. The third direction is the test of the method under more stress conditions, to measure how well it separates phosphorus shortage from other causes of reduced growth.

\newpage
# References

Entries [1]–[10] are reserved and left blank, to be filled by the authors (for example with the authors' own prior work or institution-specific citations). Entries [11]–[55] are listed below. Please verify all bibliographic details against the original sources before submission.

[1] *(reserved)*

[2] *(reserved)*

[3] *(reserved)*

[4] *(reserved)*

[5] *(reserved)*

[6] *(reserved)*

[7] *(reserved)*

[8] *(reserved)*

[9] *(reserved)*

[10] *(reserved)*

[11] Lemaire, G., Jeuffroy, M.-H., Gastal, F. (2008). Diagnosis tool for plant and crop N status in vegetative stage: Theory and practices for crop N management. *European Journal of Agronomy*, 28(4), 614–624.

[12] Justes, E., Mary, B., Meynard, J.-M., Machet, J.-M., Thelier-Huché, L. (1994). Determination of a critical nitrogen dilution curve for winter wheat crops. *Annals of Botany*, 74(4), 397–407.

[13] Greenwood, D.J., Lemaire, G., Gosse, G., Cruz, P., Draycott, A., Neeteson, J.J. (1990). Decline in percentage N of C3 and C4 crops with increasing plant mass. *Annals of Botany*, 66(4), 425–436.

[14] Ata-Ul-Karim, S.T., Yao, X., Liu, X., Cao, W., Zhu, Y. (2013). Development of critical nitrogen dilution curve of Japonica rice in Yangtze River Reaches. *Field Crops Research*, 149, 149–158.

[15] Ziadi, N., Bélanger, G., Claessens, A., et al. (2010). Determination of a critical nitrogen dilution curve for spring wheat. *Agronomy Journal*, 102(1), 241–250.

[16] Woebbecke, D.M., Meyer, G.E., Von Bargen, K., Mortensen, D.A. (1995). Color indices for weed identification under various soil, residue, and lighting conditions. *Transactions of the ASAE*, 38(1), 259–269.

[17] Gitelson, A.A., Kaufman, Y.J., Stark, R., Rundquist, D. (2002). Novel algorithms for remote estimation of vegetation fraction. *Remote Sensing of Environment*, 80(1), 76–87.

[18] Louhaichi, M., Borman, M.M., Johnson, D.E. (2001). Spatially located platform and aerial photography for documentation of grazing impacts on wheat. *Geocarto International*, 16(1), 65–70.

[19] Hunt, E.R., Cavigelli, M., Daughtry, C.S.T., McMurtrey, J.E., Walthall, C.L. (2005). Evaluation of digital photography from model aircraft for remote sensing of crop biomass and nitrogen status. *Precision Agriculture*, 6(4), 359–378.

[20] Tucker, C.J. (1979). Red and photographic infrared linear combinations for monitoring vegetation. *Remote Sensing of Environment*, 8(2), 127–150.

[21] Maes, W.H., Steppe, K. (2019). Perspectives for remote sensing with unmanned aerial vehicles in precision agriculture. *Trends in Plant Science*, 24(2), 152–164.

[22] Zhang, C., Kovacs, J.M. (2012). The application of small unmanned aerial systems for precision agriculture: a review. *Precision Agriculture*, 13(6), 693–712.

[23] Hunt, E.R., Daughtry, C.S.T. (2018). What good are unmanned aircraft systems for agricultural remote sensing and precision agriculture? *International Journal of Remote Sensing*, 39(15–16), 5345–5376.

[24] Berger, K., Verrelst, J., Féret, J.-B., et al. (2020). Crop nitrogen monitoring: Recent progress and principal developments in the context of imaging spectroscopy. *Remote Sensing of Environment*, 242, 111758.

[25] Colomina, I., Molina, P. (2014). Unmanned aerial systems for photogrammetry and remote sensing: A review. *ISPRS Journal of Photogrammetry and Remote Sensing*, 92, 79–97.

[26] Zheng, H., Cheng, T., Li, D., et al. (2018). Evaluation of RGB, color-infrared and multispectral images acquired from unmanned aerial systems for the estimation of nitrogen accumulation in rice. *Remote Sensing*, 10(6), 824.

[27] Zha, H., Miao, Y., Wang, T., et al. (2020). Improving unmanned aerial vehicle remote sensing-based rice nitrogen nutrition index prediction with machine learning. *Remote Sensing*, 12(2), 215.

[28] Zheng, H., Li, W., Jiang, J., et al. (2018). A comparative assessment of different modeling algorithms for estimating leaf nitrogen content in winter wheat using multispectral images from an unmanned aerial vehicle. *Remote Sensing*, 10(12), 2026.

[29] Osco, L.P., Marcato Junior, J., Marques Ramos, A.P., et al. (2021). A review on deep learning in UAV remote sensing. *International Journal of Applied Earth Observation and Geoinformation*, 102, 102456.

[30] Kamilaris, A., Prenafeta-Boldú, F.X. (2018). Deep learning in agriculture: A survey. *Computers and Electronics in Agriculture*, 147, 70–90.

[31] LeCun, Y., Bengio, Y., Hinton, G. (2015). Deep learning. *Nature*, 521(7553), 436–444.

[32] Krizhevsky, A., Sutskever, I., Hinton, G.E. (2012). ImageNet classification with deep convolutional neural networks. *Advances in Neural Information Processing Systems (NeurIPS)*, 25.

[33] He, K., Zhang, X., Ren, S., Sun, J. (2016). Deep residual learning for image recognition. *IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 770–778.

[34] Tan, M., Le, Q. (2019). EfficientNet: Rethinking model scaling for convolutional neural networks. *International Conference on Machine Learning (ICML)*, 6105–6114.

[35] Dosovitskiy, A., Beyer, L., Kolesnikov, A., et al. (2021). An image is worth 16x16 words: Transformers for image recognition at scale. *International Conference on Learning Representations (ICLR)*.

[36] Liu, Z., Lin, Y., Cao, Y., et al. (2021). Swin Transformer: Hierarchical vision transformer using shifted windows. *IEEE/CVF International Conference on Computer Vision (ICCV)*, 10012–10022.

[37] Perez, E., Strub, F., de Vries, H., Dumoulin, V., Courville, A. (2018). FiLM: Visual reasoning with a general conditioning layer. *AAAI Conference on Artificial Intelligence*.

[38] Dumoulin, V., Shlens, J., Kudlur, M. (2017). A learned representation for artistic style. *International Conference on Learning Representations (ICLR)*.

[39] Kendall, A., Gal, Y., Cipolla, R. (2018). Multi-task learning using uncertainty to weigh losses for scene geometry and semantics. *IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 7482–7491.

[40] Chen, Z., Badrinarayanan, V., Lee, C.-Y., Rabinovich, A. (2018). GradNorm: Gradient normalization for adaptive loss balancing in deep multitask networks. *International Conference on Machine Learning (ICML)*, 794–803.

[41] Ruder, S. (2017). An overview of multi-task learning in deep neural networks. *arXiv preprint arXiv:1706.05098*.

[42] Caruana, R. (1997). Multitask learning. *Machine Learning*, 28(1), 41–75.

[43] Chen, T., Kornblith, S., Norouzi, M., Hinton, G. (2020). A simple framework for contrastive learning of visual representations. *International Conference on Machine Learning (ICML)*, 1597–1607.

[44] He, K., Chen, X., Xie, S., Li, Y., Dollár, P., Girshick, R. (2022). Masked autoencoders are scalable vision learners. *IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 16000–16009.

[45] Caron, M., Touvron, H., Misra, I., et al. (2021). Emerging properties in self-supervised vision transformers. *IEEE/CVF International Conference on Computer Vision (ICCV)*, 9650–9660.

[46] Grill, J.-B., Strub, F., Altché, F., et al. (2020). Bootstrap your own latent: A new approach to self-supervised learning. *Advances in Neural Information Processing Systems (NeurIPS)*, 33.

[47] Gal, Y., Ghahramani, Z. (2016). Dropout as a Bayesian approximation: Representing model uncertainty in deep learning. *International Conference on Machine Learning (ICML)*, 1050–1059.

[48] Lakshminarayanan, B., Pritzel, A., Blundell, C. (2017). Simple and scalable predictive uncertainty estimation using deep ensembles. *Advances in Neural Information Processing Systems (NeurIPS)*, 30.

[49] Selvaraju, R.R., Cogswell, M., Das, A., Vedantam, R., Parikh, D., Batra, D. (2017). Grad-CAM: Visual explanations from deep networks via gradient-based localization. *IEEE/CVF International Conference on Computer Vision (ICCV)*, 618–626.

[50] Yue, J., Yang, G., Li, C., et al. (2017). Estimation of winter wheat above-ground biomass using unmanned aerial vehicle-based snapshot hyperspectral sensor and crop height improved models. *Remote Sensing*, 9(7), 708.

[51] Bendig, J., Yu, K., Aasen, H., et al. (2015). Combining UAV-based plant height from crop surface models, visible and near infrared vegetation indices for biomass monitoring in barley. *International Journal of Applied Earth Observation and Geoinformation*, 39, 79–87.

[52] Mahajan, G.R., Sahoo, R.N., Pandey, R.N., Gupta, V.K., Kumar, D. (2014). Using hyperspectral remote sensing techniques to monitor nitrogen, phosphorus, sulphur and potassium in wheat. *Precision Agriculture*, 15, 499–522.

[53] Pimstein, A., Karnieli, A., Bansal, S.K., Bonfil, D.J. (2011). Exploring remotely sensed technologies for monitoring wheat potassium and phosphorus using field spectroscopy. *Field Crops Research*, 121(1), 125–135.

[54] Raun, W.R., Solie, J.B., Johnson, G.V., et al. (2002). Improving nitrogen use efficiency in cereal grain production with optical sensing and variable rate application. *Agronomy Journal*, 94(4), 815–820.

[55] Diacono, M., Rubino, P., Montemurro, F. (2013). Precision nitrogen management of wheat. A review. *Agronomy for Sustainable Development*, 33, 219–241.

\newpage

# Appendix A. Figure Credits and Licenses

The two aerial field photographs used as illustrative examples of RGB drone imagery are from Wikimedia Commons and are reused under their open licenses. They are example images only and are not the study data.

- **Rice field (illustrative).** "Sunny green paddy fields with trees and long shadows." Author: Basile Morin. License: Creative Commons Attribution-ShareAlike 4.0 (CC BY-SA 4.0). Source: Wikimedia Commons.
- **Wheat field (illustrative).** "Wheat fields in Ukraine-5966-98." Author: Raimond Spekking. License: Creative Commons Attribution-ShareAlike 4.0 (CC BY-SA 4.0). Source: Wikimedia Commons.

All schematic figures (system concept, two-tier framework, network architecture, preprocessing pipeline, result charts, interpretability concept, and prescription map) were produced by the authors for this paper. The result charts display projected illustrative values and must be replaced with measured results.

\newpage

# Appendix B. Notation

The following table lists the main symbols used in the paper. A consistent notation is important, and it also supports translation into other languages.

| Symbol | Meaning |
|---|---|
| $x$ | RGB image patch of a crop plot |
| $c$ | Crop type (rice or wheat) |
| $t$ | Growth information, expressed as growing degree days |
| $\theta$ | Parameters of the perception network |
| $f$ | Perception function (image to status) |
| $g$ | Decision function (status to rate) |
| $\hat{s}_N$ | Estimated nitrogen status |
| $\hat{s}_P$ | Estimated phosphorus status |
| $\hat{b}$ | Estimated above-ground biomass |
| $N_a$ | Actual nitrogen concentration |
| $N_c$ | Critical nitrogen concentration |
| $P_a$ | Actual phosphorus concentration |
| $P_c$ | Critical phosphorus concentration |
| $W$ | Above-ground biomass |
| NNI | Nitrogen nutrition index, $N_a / N_c$ |
| PNI | Phosphorus nutrition index, $P_a / P_c$ |
| $r_N$ | Recommended nitrogen rate (kg/ha) |
| $r_P$ | Recommended phosphorus rate (kg/ha) |
| $k_N$ | Coefficient converting status deficit to nitrogen mass |
| $\gamma_k, \beta_k$ | FiLM scale and shift for feature channel $k$ |
| $\sigma_i$ | Learned noise level of task $i$ in the multi-task loss |
| $\mathcal{L}$ | Total training loss |
| $\mathcal{L}_i$ | Loss of task $i$ |
| $\delta$ | Threshold of the Huber loss |

\newpage

# Appendix C. Glossary of Terms

This glossary explains the main technical and agronomic terms in simple words. It is provided to help readers from different fields and to support translation.

**Above-ground biomass.** The dry weight of all plant material above the soil, per unit area. A measure of how much the crop has grown.

**Chlorophyll.** The green pigment in leaves that absorbs light for photosynthesis. More nitrogen usually means more chlorophyll and a darker green leaf.

**Chromatic signal.** Information carried by colour. In this paper, the nitrogen signal is mainly a chromatic signal.

**Convolutional neural network.** A type of neural network that processes images by scanning them with small filters. It can learn colour, texture, and shape features.

**Critical nutrient concentration.** The lowest nutrient concentration in the plant that still allows maximum growth. Used to define the nutrition index.

**Cross-validation.** A method of testing a model by training on part of the data and testing on another part, repeated several times.

**Dilution effect.** The fall in nutrient concentration as a plant grows larger, even when the plant is healthy. The nutrition index removes this effect.

**Economic optimum rate.** The fertilizer rate that gives the highest profit, taking into account the price of the crop and the cost of the fertilizer.

**FiLM (feature-wise linear modulation).** A method that lets extra information, such as the crop type, change the behaviour of a network by scaling and shifting its features.

**Ground sample distance.** The ground distance that one image pixel covers. A smaller value means more detail.

**Growing degree days.** A measure of accumulated temperature since sowing or transplanting. It describes how far the crop has developed, and it is more reliable than the calendar date.

**Multi-task learning.** Training one network to predict several related outputs at the same time. It uses data more fully and reduces overfitting.

**Nutrition index.** The ratio of the actual nutrient concentration to the critical concentration. A value near one means the crop has enough of the nutrient.

**Orthomosaic.** A single, geometrically corrected image built by stitching many overlapping flight images together.

**Perception network.** The learned part of the system that estimates crop nutrient status from the image.

**Prescription map.** A map that tells the fertilizer machine how much to apply at each location in the field.

**Self-supervised learning.** A method that learns useful features from images without labels, used here to make the most of a small labelled dataset.

**Structural signal.** Information carried by the size, density, and shape of the canopy. In this paper, the phosphorus signal is mainly a structural signal.

**Vegetation index.** A simple formula that combines image bands into a single number that tracks a plant property, such as greenness.

**Variable-rate fertilization.** The practice of applying different fertilizer amounts in different parts of a field, according to crop need.

\newpage

# Appendix D. Step-by-Step Procedure

This appendix states the method as a numbered procedure. The procedure has two parts: training and inference. The steps are written in simple language, so that they can be followed and translated easily.

## D.1 Training procedure

1. Collect UAV RGB images of all plots at the fixed growth stage.
2. Build the orthomosaic for each field, with ground control points and a fixed ground sample distance.
3. For each plot, apply the inner buffer, crop the fixed ground footprint, and divide the plot into fine patches and wide patches.
4. For each patch, compute the vegetation index channels and stack them with the raw RGB channels.
5. Mask water and soil, and compute the canopy cover fraction.
6. Apply relative radiometric normalization.
7. Collect the large pool of unlabelled patches from all available images.
8. Pretrain the encoder on the unlabelled pool with a self-supervised method.
9. Attach the three task heads to the pretrained encoder.
10. Fine-tune the whole network on the labelled plots, using the multi-task loss with uncertainty weighting.
11. Use cross-validation blocked by field and season to choose the stopping point and the settings.
12. Repeat the training several times to form an ensemble.

## D.2 Inference procedure

1. Fly the UAV over the new field at the fixed growth stage.
2. Build the orthomosaic and prepare the patches, exactly as in training.
3. For each patch, run the network and obtain the nitrogen status, the phosphorus status, and the biomass.
4. Average the patch predictions within each management zone to obtain a zone-level status.
5. Apply the decision rule to convert the status into a nitrogen rate and a phosphorus rate for each zone.
6. Output the prescription map at the resolution of the fertilizer spreader.

\newpage

# Appendix E. Field Data Collection Checklist

This checklist supports the collection of the data needed for the method. It is written for the field team. Careful data collection is the foundation of the whole method.

## E.1 Before the flight

- Confirm the growth stage of the crop matches the planned decision stage.
- Confirm the weather is stable and the light is near solar noon.
- Confirm the UAV battery and the camera storage are ready.
- Confirm the plot boundaries and the ground control points are marked.

## E.2 During the flight

- Fly at the planned altitude of 100 metres.
- Keep the image overlap near 75 to 80 percent.
- Keep the camera pointing straight down.
- Record the flight time and the weather conditions.

## E.3 Ground-truth sampling

- Sample the plants in a known area in each selected plot, on the same day as the flight.
- Record the fresh weight, then dry the samples and record the dry weight.
- Send the dried samples for nitrogen and phosphorus analysis.
- Record the growth stage and the growing degree days for each plot.

## E.4 After the season

- Record the final yield of each plot.
- Check the laboratory results for errors.
- Compute the nitrogen nutrition index and the phosphorus nutrition index.
- Store all data with clear plot identifiers, so that each image patch can be matched to its ground truth.
